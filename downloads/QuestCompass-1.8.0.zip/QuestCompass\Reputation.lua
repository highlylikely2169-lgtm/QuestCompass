-- QuestCompass: вкладка «Репутации» — нужные фракции, прогресс и как качать
local _, ns = ...
local FG = ns.FG
local L = FG.L
local R = {}
FG.Rep = R

local S
local page
local W = FG.PAGE_W
local ROW_H, ROWS = 74, 8

local function safe(f, ...) if not f then return nil end local ok, a, b, c, d, e, g, h = pcall(f, ...) if ok then return a, b, c, d, e, g, h end end
local function ru() return FG:Lang() == "ru" end
local function pick(t) if not t then return "" end return ru() and (t[2] or t[1]) or t[1] end

-- уровни отношения (1 — ненависть ... 8 — превознесение)
local STAND = { friendly = 5, honored = 6, revered = 7, exalted = 8 }
local STAND_NAME = {
    { "Hated", "Ненависть" }, { "Hostile", "Враждебность" }, { "Unfriendly", "Неприязнь" }, { "Neutral", "Равнодушие" },
    { "Friendly", "Дружелюбие" }, { "Honored", "Уважение" }, { "Revered", "Почтение" }, { "Exalted", "Превознесение" },
}
local STAND_COLOR = {
    { 0.8, 0.13, 0.13 }, { 0.75, 0.27, 0 }, { 0.75, 0.45, 0 }, { 0.9, 0.85, 0.2 },
    { 0.3, 0.8, 0.2 }, { 0.2, 0.75, 0.55 }, { 0.2, 0.6, 0.9 }, { 0.65, 0.35, 0.95 },
}

-- фракции: id, иконка, названия, как поднимать
local FACTIONS = {
    { id = 59, npcs = { 14627, 14624, 14625 }, icon = "Interface\\Icons\\INV_Ingot_Thorium", name = { "Thorium Brotherhood", "Братство Тория" },
      how = { "Thorium Point (Searing Gorge): Dark Iron Ore and Dark Iron Residue (BRD) up to Friendly, then Core Leather, Lava Core, Fiery Core.",
              "Поселение Тория (Тлеющее ущелье): руда черного железа и осадок черного железа (Глубины Черной горы) до дружелюбия, дальше сердцевинная кожа, ядра лавы и огненные ядра." },
      sells = { "Lokhtos Darkbargainer (BRD): Corehound Belt, Mighty Intellect/Spirit formulas", "Локтос Зловещий Торговец (Глубины Черной горы): Пояс гончей Недр, формулы оружия" } },
    { id = 270, npcs = { 14875, 15070, 14921 }, icon = "Interface\\Icons\\INV_Bijou_Green", name = { "Zandalar Tribe", "Племя Зандалар" },
      how = { "Zul'Gurub: every kill gives rep; turn in coins and bijous at Yojamba Isle (Stranglethorn Vale).",
              "Зул'Гуруб: репутация за каждое убийство; монеты и бижутерию сдавать на острове Йоджамба (Тернистая долина)." },
      sells = { "Rin'wosho the Trader: Bloodvine patterns, ZG enchants", "Рин'вошо Торговец: выкройки кровавой лозы, чары Зул'Гуруба" } },
    { id = 576, npcs = { 11557, 11556 }, icon = "Interface\\Icons\\INV_Misc_Bone_ElfSkull_01", name = { "Timbermaw Hold", "Древобрюхи" },
      how = { "Kill Deadwood (Felwood) and Winterfall (Winterspring) furbolgs; turn in their Feathers and Beads at Timbermaw Hold.",
              "Убивайте фурболгов Мертвого Леса (Оскверненный лес) и Зимней Спячки (Зимние Ключи), сдавайте перья и бусы в Крепости Древобрюхов." },
      sells = { "Meilosh (Felwood): Enchant 2H Weapon - Agility (Friendly)", "Мейлош (Оскверненный лес): чары двуручного оружия +25 ловкости (дружелюбие)" } },
    { id = 529, npcs = { 10840, 10839, 11536, 10857, 10856 }, icon = "Interface\\Icons\\INV_Jewelry_Talisman_07", name = { "Argent Dawn", "Серебряный Рассвет" },
      how = { "Wear the Argent Dawn Commission and kill undead in the Plaguelands; turn in Scourgestones; Stratholme and Scholomance.",
              "Носите Знак Серебряного Рассвета и убивайте нежить в Чумных землях; сдавайте камни Плети; Стратхольм и Некроситет." },
      sells = { "Argent Quartermasters: healing and mana bracer enchants (Revered)", "Интенданты Серебряного Рассвета: чары на наручи — исцеление и мана (почтение)" } },
    { id = 609, npcs = { 15282, 15176 }, icon = "Interface\\Icons\\Spell_Nature_HealingTouch", name = { "Cenarion Circle", "Круг Кенария" },
      how = { "Quests in Silithus (Cenarion Hold), Twilight Texts and Encrypted Twilight Texts, Ruins of Ahn'Qiraj.",
              "Задания в Силитусе (Крепость Кенария), сдача текстов Сумеречного Молота, Руины Ан'Киража." },
      sells = { "Cenarion Hold quartermaster: resistance gear and recipes", "Интендант Крепости Кенария: снаряжение с сопротивлениями и рецепты" } },
    { id = 749, npcs = { 13278 }, icon = "Interface\\Icons\\Spell_Frost_SummonWaterElemental", name = { "Hydraxian Waterlords", "Гидраксианские Повелители Вод" },
      how = { "Quests from Duke Hydraxis (Azshara); Molten Core trash and bosses after Honored.",
              "Задания герцога Гидраксиса (Азшара); существа и боссы Огненных Недр." },
      sells = { "Aqual Quintessence for Molten Core", "Квинтэссенция воды для Огненных Недр" } },
}
local CAPITALS = {
    Alliance = { { 72, { "Stormwind", "Штормград" }, 14722 }, { 47, { "Ironforge", "Стальгорн" }, 14723 }, { 69, { "Darnassus", "Дарнас" }, 14725 }, { 54, { "Gnomeregan Exiles", "Изгнанники Гномрегана" }, 14724 } },
    Horde = { { 76, { "Orgrimmar", "Оргриммар" }, 14726 }, { 81, { "Thunder Bluff", "Громовой Утес" }, 14728 }, { 68, { "Undercity", "Подгород" }, 14729 }, { 530, { "Darkspear Trolls", "Тролли Черного Копья" }, 14727 } },
}

local function factionInfo(id)
    local f = (C_Reputation and C_Reputation.GetFactionDataByID) and function(i)
        local d = C_Reputation.GetFactionDataByID(i)
        if d then return d.name, d.description, d.reaction, d.currentReactionThreshold, d.nextReactionThreshold, d.currentStanding end
    end or rawget(_G, "GetFactionInfoByID")
    if not f then return end
    local name, _, standing, bmin, bmax, value = safe(f, id)
    if not standing or standing == 0 then return end
    return name, standing, bmin or 0, bmax or 1, value or 0
end

-- что нужно игроку от фракции: { текст, уровень }
local function needsFor(id)
    local out = {}
    local craft = rawget(_G, "QuestCompassCraft")
    local bis = rawget(_G, "QuestCompassBiS")
    local cls = FG.BiS and FG.BiS.Class and safe(FG.BiS.Class, FG.BiS)
    local spec = FG.BiS and FG.BiS.Spec and safe(FG.BiS.Spec, FG.BiS)
    local list = bis and cls and bis[cls] and bis[cls][spec] or {}
    local repKey = { [59] = "thorium", [270] = "zandalar" }
    if craft and repKey[id] then
        for _, iid in pairs(list) do
            local c = craft.ITEMS[iid]
            if c and c.rep == repKey[id] then
                local nm = FG.BiS and FG.BiS.ItemName and safe(FG.BiS.ItemName, FG.BiS, iid) or ("#" .. iid)
                out[#out + 1] = { nm, STAND[c.stand] or 5 }
            end
        end
    end
    -- чары BiS: формулы за репутацию
    if FG.BiS and FG.BiS.EnchantFor then
        local wantE = { [576] = { agi2h = 5 }, [529] = { bracerheal = 7 } }
        local e = wantE[id]
        if e then
            for _, slot in ipairs({ "mh", "wrist" }) do
                local key, data = safe(FG.BiS.EnchantFor, FG.BiS, slot, list[slot])
                if key and e[key] then out[#out + 1] = { (L("bis_ench") .. " " .. (ru() and data.ru or data.en)), e[key] } end
            end
        end
    end
    return out
end

---------------------------------------------------------------------------
-- Страница
---------------------------------------------------------------------------
local function rowsData()
    local rows = {}
    for i, f in ipairs(FACTIONS) do
        local need = needsFor(f.id)
        rows[#rows + 1] = { f = f, need = need, i = i }
    end
    -- нужные для BiS — сверху
    table.sort(rows, function(a, b)
        if (#a.need > 0) ~= (#b.need > 0) then return #a.need > 0 end
        return a.i < b.i
    end)
    local fac = FG.cdb.faction or (UnitFactionGroup and UnitFactionGroup("player")) or "Alliance"
    for _, c in ipairs(CAPITALS[fac] or {}) do
        rows[#rows + 1] = { f = { id = c[1], name = c[2], capital = true, npcs = { c[3] },
            icon = fac == "Horde" and "Interface\\Icons\\INV_BannerPVP_01" or "Interface\\Icons\\INV_BannerPVP_02",
            how = { "City quests and cloth donations (quartermaster in the city); Exalted lets you buy other races' mounts.",
                    "Городские задания и сдача ткани интенданту в городе; на превознесении можно купить ездовых животных других рас." } },
            need = {} }
    end
    return rows
end

local function refresh()
    if not page or not page:IsVisible() then return end
    local rows = rowsData()
    local h = page:GetHeight() or 0
    local top = 64
    local vis = (type(h) == "number" and h > 0) and math.max(3, math.min(ROWS, math.floor((h - top - 10) / ROW_H))) or 6
    page.offset = math.max(0, math.min(page.offset or 0, #rows - vis))
    if page.sb then
        page.sb:ClearAllPoints(); page.sb:SetPoint("TOPRIGHT", page, "TOPRIGHT", -3, -top)
        page.sb:SetHeight(vis * ROW_H - 6)
        page.sb:Update(page.offset, #rows, vis)
    end
    for i = 1, ROWS do
        local r = page.rows[i]
        local e = i <= vis and rows[i + page.offset]
        if e then
            local f = e.f
            r.data = e
            r:ClearAllPoints(); r:SetPoint("TOPLEFT", 12, -top - (i - 1) * ROW_H)
            r.icon:SetTexture(f.icon)
            local gname, standing, bmin, bmax, value = factionInfo(f.id)
            r.name:SetText(ru() and f.name[2] or f.name[1])
            if standing then
                local c = STAND_COLOR[standing] or { 1, 1, 1 }
                r.stand:SetText(pick(STAND_NAME[standing]))
                r.stand:SetTextColor(c[1], c[2], c[3])
                local span = math.max(1, bmax - bmin)
                local cur = math.max(0, value - bmin)
                r.fill:SetVertexColor(c[1], c[2], c[3], 0.9)
                r.fill:SetWidth(math.max(1, (W - 30 - 60) * math.min(1, cur / span)))
                r.val:SetText(standing >= 8 and "" or (cur .. " / " .. span))
            else
                r.stand:SetText(L("rep_unknown")); r.stand:SetTextColor(0.6, 0.6, 0.6)
                r.fill:SetWidth(1); r.val:SetText("")
            end
            -- что нужно и как качать
            local line
            if #e.need > 0 then
                local best = 0
                for _, n in ipairs(e.need) do if n[2] > best then best = n[2] end end
                local okNow = standing and standing >= best
                line = (okNow and "|cff66e07a" or "|cffffd100") .. L("rep_need", pick(STAND_NAME[best]), e.need[1][1] .. (#e.need > 1 and (" +" .. (#e.need - 1)) or "")) .. "|r"
            else
                line = "|cff9aa0a8" .. pick(f.how) .. "|r"
            end
            r.sub:SetText(line)
            r:Show()
        else
            r.data = nil
            r:Hide()
        end
    end
end
R.Refresh = refresh

function R:BuildPage(parent)
    if page then return end
    S = FG.Style
    page = CreateFrame("Frame", "QuestCompassRepPage", parent)
    page:SetAllPoints(parent)
    page.offset, page.sb = 0, false
    page:HookScript("OnShow", function() refresh() end)
    local title = S:Text(page, "title", S.c.accent)
    title:SetPoint("TOPLEFT", 16, -14)
    FG:Localize(title, "rep_title")
    local hint = S:Text(page, "small", S.c.muted)
    hint:SetPoint("TOPLEFT", 16, -40); hint:SetPoint("RIGHT", -16, 0); hint:SetWordWrap(false)
    FG:Localize(hint, "rep_hint")
    page.rows = {}
    for i = 1, ROWS do
        local r = CreateFrame("Button", nil, page)
        r:SetSize(W - 30, ROW_H - 6)
        S:Box(r, 5, { 0.09, 0.09, 0.1, 0.85 }, { 1, 1, 1, 0.08 })
        r.hl = S:GoldBar(r, 0.18); r.hl:Hide()
        r.icon = r:CreateTexture(nil, "ARTWORK")
        r.icon:SetSize(36, 36); r.icon:SetPoint("TOPLEFT", 8, -8)
        r.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        r.name = S:Text(r, "label", S.c.text)
        r.name:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 10, 0); r.name:SetWordWrap(false)
        r.stand = S:Text(r, "small", S.c.text)
        r.stand:SetPoint("TOPRIGHT", -10, -8); r.stand:SetJustifyH("RIGHT")
        r.name:SetPoint("RIGHT", r.stand, "LEFT", -6, 0)
        local track = S.Tex(r, "ARTWORK", { 1, 1, 1, 0.08 })
        track:SetHeight(6); track:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 10, -20); track:SetPoint("RIGHT", -10, 0)
        r.fill = S.Tex(r, "OVERLAY", { 1, 0.82, 0, 0.9 })
        r.fill:SetHeight(6); r.fill:SetPoint("TOPLEFT", track, "TOPLEFT")
        r.val = S:Text(r, "small", S.c.muted)
        r.val:SetPoint("TOPRIGHT", track, "BOTTOMRIGHT", 0, -2); r.val:SetJustifyH("RIGHT")
        r.sub = S:Text(r, "small", S.c.muted)
        r.sub:SetPoint("BOTTOMLEFT", 8, 6); r.sub:SetPoint("RIGHT", -76, 0); r.sub:SetWordWrap(false)
        -- «Начать»: отдельное окошко с тем, что делать, и стрелка к нужному NPC
        r.go = FG.Go:Button(r, 70, 20, function(self)
            local e = self:GetParent().data
            if not e then return end
            if FG.cdb.repTrack ~= e.f.id then R:StartTrack(e.f.id) else FG.Go:Open("rep") end
        end)
        r.go:SetPoint("BOTTOMRIGHT", -6, 4)
        r:SetScript("OnEnter", function(self)
            self.hl:Show()
            local e = self.data
            if not e then return end
            local f = e.f
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine(ru() and f.name[2] or f.name[1], 1, 0.82, 0)
            for _, n in ipairs(e.need) do
                GameTooltip:AddDoubleLine(n[1], pick(STAND_NAME[n[2]]), 1, 1, 1, 0.4, 0.88, 0.48)
            end
            if f.sells then GameTooltip:AddLine(pick(f.sells), 0.72, 0.56, 1, true) end
            GameTooltip:AddLine(L("rep_how"), 0.6, 0.63, 0.66)
            GameTooltip:AddLine(pick(f.how), 1, 1, 1, true)
            GameTooltip:Show()
        end)
        r:SetScript("OnLeave", function(self) self.hl:Hide(); GameTooltip:Hide() end)
        page.rows[i] = r
    end
    page:EnableMouseWheel(true)
    page:SetScript("OnMouseWheel", function(_, d) page.offset = (page.offset or 0) - d; refresh() end)
    page.sb = S:ScrollBar(page, function(off) page.offset = off; refresh() end)
    page:SetScript("OnSizeChanged", function() refresh() end)
    FG:OnLanguageChanged(refresh)
end

FG:On("UPDATE_FACTION", function() refresh() end)

---------------------------------------------------------------------------
-- «Начать»: блок в отдельном окне + стрелка к NPC фракции
---------------------------------------------------------------------------
local function facById(id)
    for _, e in ipairs(rowsData()) do if e.f.id == id then return e end end
end
R.navInfo = nil
local lastRep
local function repTick(force)
    local id = FG.cdb and FG.cdb.repTrack
    local nt = FG.navTarget
    local e = id and facById(id)
    local paused = FG.Skills and FG.Skills.gatherPaused
    if not e or paused then
        if nt and nt.rep then FG:SetNavTarget(nil) end
        R.navInfo = nil
        return
    end
    local _, standing = factionInfo(id)
    if standing and standing >= 8 then
        if nt and nt.rep then FG:SetNavTarget(nil) end
        R.navInfo = nil
        return
    end
    if nt and not nt.rep then return end -- стрелка занята другой целью
    local N = FG.Nearby
    local best = N and N.NearestNpc and N:NearestNpc(nil, e.f.npcs or {})
    if not best then R.navInfo = nil return end
    R.navInfo = { name = best.name, dist = best.dist }
    local sig = best.id
    if not nt and lastRep == sig and not force then return end -- уже дошли
    lastRep = sig
    local pt = best.p
    if not (nt and nt.rep and nt.m == pt[1] and math.abs(nt.x - pt[2]) < 0.0001 and math.abs(nt.y - pt[3]) < 0.0001) then
        FG:SetNavTarget({ m = pt[1], x = pt[2], y = pt[3], t = best.name, k = "n", rep = true })
    end
end
local rAcc = 0
local rFrame = CreateFrame("Frame")
rFrame:SetScript("OnUpdate", function(_, dt)
    rAcc = rAcc + dt
    if rAcc < 2 then return end
    rAcc = 0
    if not (FG.cdb and FG.cdb.repTrack) then return end
    pcall(repTick)
    if FG.Tracker then pcall(FG.Tracker.Update, FG.Tracker) end
end)

function R:StartTrack(id)
    FG.cdb.repTrack = id
    lastRep = nil
    if FG.navTarget then FG:SetNavTarget(nil) end
    if FG.Skills then FG.Skills.gatherPaused = nil end
    pcall(repTick, true)
    refresh()
    if FG.Go then FG.Go:Open("rep") end
end
function R:StopTrack()
    FG.cdb.repTrack = nil
    R.navInfo = nil
    if FG.navTarget and FG.navTarget.rep then FG:SetNavTarget(nil) end
    refresh()
    if FG.Tracker then FG.Tracker:Update() end
end

local blk
local function sh(fs) local h = fs.GetStringHeight and fs:GetStringHeight() or 14 if type(h) ~= "number" then h = 14 end return h end
local function createBlock(parent, Wd)
    S = FG.Style
    local b = CreateFrame("Frame", nil, parent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    b:SetSize(Wd, 120)
    S:Backdrop(b, 0.92)
    local close = S:Close(b, function() R:StopTrack() end)
    close:SetSize(18, 18); close:SetPoint("TOPRIGHT", -6, -6)
    S:Tip(close, nil, "rep_stop_tip")
    b.icon = b:CreateTexture(nil, "OVERLAY")
    b.icon:SetSize(28, 28); b.icon:SetPoint("TOPLEFT", 8, -8)
    b.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    b.title = S:Text(b, "label", { 1, 0.82, 0, 1 })
    b.title:SetPoint("TOPLEFT", b.icon, "TOPRIGHT", 8, -1); b.title:SetPoint("RIGHT", close, "LEFT", -6, 0)
    b.title:SetWordWrap(false)
    b.stand = S:Text(b, "small", S.c.text)
    b.stand:SetPoint("BOTTOMLEFT", b.icon, "BOTTOMRIGHT", 8, 4)
    b.val = S:Text(b, "small", S.c.muted)
    b.val:SetPoint("RIGHT", -10, 0); b.val:SetPoint("BOTTOM", b.stand, "BOTTOM", 0, 0); b.val:SetJustifyH("RIGHT")
    local bt = S.Tex(b, "ARTWORK", { 1, 1, 1, 0.1 })
    bt:SetHeight(4); bt:SetPoint("TOPLEFT", b.icon, "BOTTOMRIGHT", 8, 4); bt:SetPoint("RIGHT", -10, 0)
    b.barW = Wd - 8 - 28 - 8 - 10
    b.bar = S.Tex(b, "OVERLAY", { 1, 0.82, 0, 0.9 })
    b.bar:SetHeight(4); b.bar:SetPoint("TOPLEFT", bt, "TOPLEFT")
    b.now = S:Text(b, "label", S.c.text)
    b.now:SetPoint("TOPLEFT", 10, -46); b.now:SetPoint("RIGHT", -10, 0); b.now:SetSpacing(2)
    b.sub = S:Text(b, "small", S.c.muted)
    b.sub:SetPoint("TOPLEFT", b.now, "BOTTOMLEFT", 0, -3); b.sub:SetPoint("RIGHT", -10, 0); b.sub:SetSpacing(2)
    b:EnableMouse(true)
    return b
end

function R.HideBlock() if blk then blk:Hide() end end
function R.TrackedName()
    local e = FG.cdb.repTrack and facById(FG.cdb.repTrack)
    return e and (ru() and e.f.name[2] or e.f.name[1])
end
function R.TrackedIcon()
    local e = FG.cdb.repTrack and facById(FG.cdb.repTrack)
    return e and e.f.icon
end
function R:TrackBlock(parent, x, y, Wd)
    local id = FG.cdb and FG.cdb.repTrack
    local e = id and facById(id)
    if not e then if blk then blk:Hide() end return 0 end
    if not blk or blk:GetParent() ~= parent or blk.W ~= Wd then if blk then blk:Hide() end blk = createBlock(parent, Wd); blk.W = Wd end
    local f = e.f
    blk.icon:SetTexture(f.icon)
    blk.title:SetText(L("rep_tr_head", ru() and f.name[2] or f.name[1]))
    local _, standing, bmin, bmax, value = factionInfo(id)
    if standing then
        local c = STAND_COLOR[standing] or { 1, 1, 1 }
        blk.stand:SetText(pick(STAND_NAME[standing])); blk.stand:SetTextColor(c[1], c[2], c[3])
        local span = math.max(1, bmax - bmin)
        local cur = math.max(0, value - bmin)
        blk.bar:SetVertexColor(c[1], c[2], c[3], 0.9)
        blk.bar:SetWidth(math.max(1, blk.barW * math.min(1, cur / span)))
        blk.val:SetText(standing >= 8 and "" or (cur .. " / " .. span))
    else
        blk.stand:SetText(L("rep_unknown")); blk.stand:SetTextColor(0.6, 0.6, 0.6)
        blk.bar:SetWidth(1); blk.val:SetText("")
    end
    -- цель
    local now
    if standing and standing >= 8 then
        now = "|cff66e07a" .. L("rep_tr_done") .. "|r"
    else
        local best, forWhat = 0, nil
        for _, n in ipairs(e.need) do if n[2] > best then best, forWhat = n[2], n[1] end end
        if best > 0 and (not standing or standing < best) then
            now = "|cff66e07a" .. L("rep_tr_goal", pick(STAND_NAME[best]), forWhat) .. "|r"
        else
            local nx = math.min(8, (standing or 4) + 1)
            now = "|cff66e07a" .. L("rep_tr_next", pick(STAND_NAME[nx])) .. "|r"
        end
        if standing and standing < 8 and bmax and value then
            now = now .. "  |cff9aa0a8" .. L("rep_tr_left", math.max(0, bmax - value)) .. "|r"
        end
    end
    blk.now:SetText(now)
    local sub = "|cffffd100" .. L("rep_how") .. "|r " .. pick(f.how)
    if f.sells then sub = sub .. "\n|cffb88fff" .. pick(f.sells) .. "|r" end
    local ni = R.navInfo
    if ni and ni.name then
        sub = sub .. "\n|cffffd100" .. L("sk_arrow_to", ni.name) .. (ni.dist and ni.dist < 1e6 and ("  |cff9aa0a8" .. L("yards", math.floor(ni.dist + 0.5)) .. "|r") or "") .. "|r"
    end
    blk.sub:SetText(sub)
    local h = 46 + sh(blk.now) + 3 + sh(blk.sub) + 10
    blk:SetHeight(h)
    blk:ClearAllPoints(); blk:SetPoint("TOPLEFT", parent, "TOPLEFT", x, -y); blk:SetWidth(Wd)
    blk:Show()
    return h
end
FG:On("PLAYER_ENTERING_WORLD", function() C_Timer.After(2.5, function() if FG.cdb and FG.cdb.repTrack and FG.Tracker then FG.Tracker:Update() end end) end)
