# QuestCompass — leveling helper for WoW: Forever

**EN.** QuestCompass tells you what to do next while leveling: which quests to pick up at a hub, where to do the objectives and where to turn them in. An on-screen arrow and a dotted line on the map and minimap lead the way. Quests are accepted and turned in automatically, the best-selling reward is picked for you.

- No other addons needed: the quest database comes with it (`QuestCompass_Data`).
- Install: copy both folders, `QuestCompass` and `QuestCompass_Data`, to `World of Warcraft\_classic_beta_\Interface\AddOns\` (or your Forever install's `Interface\AddOns`).
- Commands: `/qc` panel, `/qc menu` settings, `/qc help` all commands. Hold **Shift** while talking to an NPC to pause auto-quests.

**RU.** QuestCompass подсказывает, что делать дальше при прокачке: какие квесты собрать в точке с квестодателями, где выполнить цели и где сдать. Ведут стрелка на экране и пунктир на карте и миникарте. Квесты берутся и сдаются автоматически, награда выбирается самая дорогая при продаже.

- Других аддонов не нужно: база квестов идёт вместе с ним (`QuestCompass_Data`).
- Установка: скопируйте обе папки, `QuestCompass` и `QuestCompass_Data`, в `World of Warcraft\_classic_beta_\Interface\AddOns\` (или в `Interface\AddOns` вашей версии Forever).
- Команды: `/qc` — панель, `/qc menu` — меню, `/qc help` — все команды. **Shift** при разговоре с NPC — временно отключить авто-квесты.

Quest data: [QuestieDB](https://github.com/Questie/QuestieDB), packaged as `QuestCompass_Data` (Forever data only) — thanks to the Questie team.


## License and credits
Quest Compass is free software under the GNU General Public License v3 (see LICENSE.txt).
Quest data comes from QuestieDB (GPLv3), shipped as QuestCompass_Data. Russian quest, NPC, item and zone names are taken from
Questie's localization files (Questie, GPLv3, https://github.com/Questie/Questie). Thanks to the Questie team.
