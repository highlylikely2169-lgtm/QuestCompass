-- QuestCompass: иконка у миникарты и меню настроек
-- ЛКМ по иконке — меню, ПКМ — показать/скрыть панель подсказок, перетаскивание — переместить иконку.
local _, ns = ...
local FG = ns.FG
local S = FG.Style
local L = FG.L
local M = {}
FG.Menu = M

local ICON = "Interface\\Icons\\INV_Misc_Map_01"
local W = FG.PAGE_W -- ширина страницы (правой части), одна на все вкладки
local SIDE = 168   -- ширина боковой панели с вкладками
local TOPH = 58    -- высота шапки
local PAD = 18     -- внутренний отступ

---------------------------------------------------------------------------
-- Окно настроек
---------------------------------------------------------------------------
local menu
local createMenu -- объявлена ниже
local widgets = {}  -- всё, что нужно обновлять при открытии
local pages, pageH = {}, {} -- страницы вкладок и их высота
local TABS_KEYS = { "leveling", "skills", "talents", "nearby", "bis", "rep", "frames", "heal" }

local function applyOption(key)
    if key == "panelShown" then
        FG.UI:Toggle(FG.db.panelShown)
    elseif key == "minimapShown" then
        M:UpdateButton()
    end
    FG:Refresh()
end

local applyPending = false
local function applyFilters()
    if applyPending then return end
    applyPending = true
    C_Timer.After(0.6, function()
        applyPending = false
        FG.Advisor:ApplyFilters()
    end)
end

-- выбор маршрута или уровней — значит, нужны обычные квесты: выходим из режима подземелья/рейда
local function leaveDungeon()
    if FG.cdb.dungeon and FG.Advisor and FG.Advisor.SetDungeon then
        FG.Advisor:SetDungeon(nil)
        for _, w in ipairs(widgets) do if w.Refresh then pcall(w.Refresh, w) end end
    end
end

local function clampLevels(changed)
    local mn, mx = FG.cdb.levelMin or 1, FG.cdb.levelMax or 60
    mn = math.max(1, math.min(60, mn)); mx = math.max(1, math.min(60, mx))
    if mn > mx then if changed == "min" then mx = mn else mn = mx end end
    FG.cdb.levelMin, FG.cdb.levelMax = mn, mx
    for _, w in ipairs(widgets) do if w.isStepper then w:Refresh() end end
    leaveDungeon()
    applyFilters()
end

---------------------------------------------------------------------------
-- Окно выбора подземелья
---------------------------------------------------------------------------
local picker
local ROWS, ROW_H = 22, 24 -- создаём с запасом, видимых — сколько влезает по высоте меню
local NEW_C = { 0.3, 0.9, 0.72 }   -- новые подземелья Forever
local SOON_C = { 0.72, 0.56, 1 }   -- скоро появятся

-- надпись на кнопке: выбранное подземелье (или рейд), если оно этого вида
local function dungeonLabel(raid)
    local A = FG.Advisor
    local dg = FG.cdb.dungeon and A.dungeonByKey and A.dungeonByKey[FG.cdb.dungeon]
    if dg and (dg.raid and true or false) == (raid and true or false) then return A:DungeonName(dg) end
    return L("dungeon_none")
end

local function refreshPicker()
    if not picker then return end
    local A = FG.Advisor
    local items = { { key = false } }
    local list = {}
    local raid = picker.mode == "raid"
    for _, dg in ipairs(A.dungeonList or {}) do
        if (dg.raid and true or false) == raid then list[#list + 1] = { key = dg.key, dg = dg, lv = dg.minL or 0 } end
    end
    -- подземелья (рейды) Forever, которые скоро появятся: в общем списке по уровню, но выбрать нельзя
    for _, u in ipairs((raid and A.UpcomingRaids or A.UpcomingDungeons) or {}) do list[#list + 1] = { key = false, up = u, lv = u.min or 99 } end
    if picker.title then picker.title:SetText(L(raid and "raid_pick_title" or "dungeon_pick_title")) end
    for i, it in ipairs(list) do it.i = i end
    table.sort(list, function(a, b) if a.lv ~= b.lv then return a.lv < b.lv end return a.i < b.i end)
    for _, it in ipairs(list) do items[#items + 1] = it end
    picker.items = items
    local h = picker:GetHeight() or 0
    local vis = (type(h) == "number" and h > 0) and math.max(5, math.min(ROWS, math.floor((h - 62 - 34) / ROW_H))) or 14
    picker.vis = vis
    local maxOff = math.max(0, #items - vis)
    picker.offset = math.max(0, math.min(picker.offset or 0, maxOff))
    local level = UnitLevel("player")
    for i = 1, ROWS do
        local row = picker.rows[i]
        local it = i <= vis and items[i + picker.offset]
        if it then
            row:Show()
            row.item = it
            local selected = not it.up and (it.key or nil) == FG.cdb.dungeon
            if it.up then
                local u = it.up
                row.name:SetText(FG:Lang() == "ru" and u.ru or u.en)
                local c = u.beta and NEW_C or SOON_C
                row.name:SetTextColor(c[1], c[2], c[3])
                row.lvl:SetText(u.min and (u.min .. "–" .. u.max) or (u.size and (u.size .. " " .. L("raid_ppl")) or "—"))
                row.lvl:SetTextColor(c[1], c[2], c[3])
                row.info:SetText(u.when and (FG:Lang() == "ru" and u.when.ru or u.when.en) or L(u.beta and "dungeon_nodata" or "dungeon_soon"))
            elseif it.dg then
                local dg = it.dg
                local lvl = dg.minL and (dg.minL .. (dg.maxL ~= dg.minL and ("–" .. dg.maxL) or "")) or "?"
                local near = dg.minL and level >= dg.minL - 3 and level <= (dg.maxL or dg.minL) + 3
                row.name:SetText(A:DungeonName(dg))
                local low = (dg.enterL or dg.minL) and level < (dg.enterL or dg.minL) -- уровень ещё не позволяет войти
                if low then
                    row.name:SetTextColor(1, 0.36, 0.36)
                    row.lvl:SetTextColor(1, 0.36, 0.36)
                elseif dg.manual then
                    -- новое подземелье WoW Forever
                    row.name:SetTextColor(NEW_C[1], NEW_C[2], NEW_C[3])
                    row.lvl:SetTextColor(S.c.soft[1], S.c.soft[2], S.c.soft[3])
                else
                    if near then row.name:SetTextColor(1, 0.82, 0) else row.name:SetTextColor(0.78, 0.66, 0.25) end
                    row.lvl:SetTextColor(S.c.soft[1], S.c.soft[2], S.c.soft[3])
                end
                row.lvl:SetText(lvl)
                row.info:SetText(L("dungeon_quests", #dg.quests))
            else
                row.name:SetText(L("dungeon_none"))
                row.name:SetTextColor(S.c.muted[1], S.c.muted[2], S.c.muted[3])
                row.info:SetText("")
                row.lvl:SetText("")
            end
            if selected then row.sel:Show(); row.name:SetTextColor(1, 1, 1) else row.sel:Hide() end
        else
            row:Hide()
        end
    end
end

-- Выдвижная правая часть меню (список подземелий, BiS): одна общая рамка с меню
local drawerShell
local function menuBackdrop(show)
    S:BackdropShown(menu, show)
end
local function moveHeader(to)
    local c = menu.closeBtn
    if not c then return end
    c:ClearAllPoints()
    c:SetPoint("TOPRIGHT", to or menu, "TOPRIGHT", -8, -8)
end
function M:MakeDrawer(width, name)
    local d = CreateFrame("Frame", name, menu)
    d:SetWidth(width)
    d:SetPoint("TOPLEFT", menu, "TOPRIGHT", 0, 0)
    d:SetPoint("BOTTOMLEFT", menu, "BOTTOMRIGHT", 0, 0)
    d:EnableMouse(true)
    if (menu:GetFrameLevel() or 0) < 5 then menu:SetFrameLevel(5) end
    if not drawerShell then
        drawerShell = CreateFrame("Frame", nil, UIParent)
        drawerShell.qcRoot = true
        drawerShell:SetScale(menu:GetScale() or 1)
        drawerShell:SetFrameStrata(menu:GetFrameStrata() or "DIALOG")
        drawerShell:SetFrameLevel(math.max(1, (menu:GetFrameLevel() or 2) - 1))
        S:Backdrop(drawerShell, 0.92, nil, "window", 58)
        drawerShell:Hide()
        M.shell = drawerShell
    end
    -- вертикальная линия между меню и правой частью
    local vline = S.Tex(d, "ARTWORK", S.c.border)
    vline:SetWidth(1); vline:SetPoint("TOPLEFT", 0, -12); vline:SetPoint("BOTTOMLEFT", 0, 12)
    M.drawers = M.drawers or {}
    table.insert(M.drawers, d)
    d:HookScript("OnShow", function(self)
        S:SkinTree(self)
        for _, o in ipairs(M.drawers) do if o ~= self and o:IsShown() then o:Hide() end end
        drawerShell:ClearAllPoints()
        drawerShell:SetPoint("TOPLEFT", menu, "TOPLEFT", 0, 0)
        drawerShell:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", 0, 0)
        drawerShell:Show(); menuBackdrop(false); moveHeader(self)
    end)
    d:HookScript("OnHide", function()
        -- IsVisible: правая часть видна на самом деле (а не только помечена показанной)
        for _, o in ipairs(M.drawers) do if o:IsVisible() then return end end
        drawerShell:Hide(); menuBackdrop(true); moveHeader(nil)
    end)
    if not menu.drawerHooked then
        menu.drawerHooked = true
        -- рамка привязана к экрану, поэтому прячем её вместе с меню
        menu:HookScript("OnHide", function() if drawerShell then drawerShell:Hide() end end)
    end
    d:Hide()
    return d
end

local function createPicker()
    -- правая часть окна меню: выдвигается кнопкой «Подземелье»
    local PWD = 320
    picker = M:MakeDrawer(PWD, "QuestCompassDungeonPicker")
    picker:HookScript("OnShow", function() refreshPicker() end)
    local title = S:NoInk(S:Text(picker, "label", S.c.text)); title:SetTextColor(1, 1, 1)
    title:SetPoint("TOPLEFT", 16, -20)
    picker.title = title
    -- заголовки столбцов
    local COL_LVL, COL_Q = 64, 52 -- ширина столбцов «уровни» и «квесты»
    local hName = S:Text(picker, "head", S.c.muted)
    hName:SetPoint("TOPLEFT", 20, -44)
    FG:Localize(hName, "col_dungeon")
    local hQ = S:Text(picker, "head", S.c.muted)
    hQ:SetPoint("TOPRIGHT", -20, -44); hQ:SetWidth(COL_Q); hQ:SetJustifyH("RIGHT")
    FG:Localize(hQ, "col_quests")
    local hL = S:Text(picker, "head", S.c.muted)
    hL:SetPoint("TOPRIGHT", -20 - COL_Q, -44); hL:SetWidth(COL_LVL); hL:SetJustifyH("CENTER")
    FG:Localize(hL, "col_levels")
    local sep = S.Tex(picker, "ARTWORK", S.c.border)
    sep:SetHeight(1); sep:SetPoint("TOPLEFT", 16, -58); sep:SetPoint("TOPRIGHT", -16, -58)
    -- легенда цветов
    local legend = S:Text(picker, "small", S.c.muted)
    legend:SetPoint("BOTTOMLEFT", 20, 12)
    local function legendText()
        local function hex(c) return string.format("%02x%02x%02x", c[1] * 255, c[2] * 255, c[3] * 255) end
        legend:SetText("|cff" .. hex(NEW_C) .. L("legend_new") .. "|r     |cff" .. hex(SOON_C) .. L("legend_soon") .. "|r")
    end
    legendText()
    FG:OnLanguageChanged(legendText)
    picker.rows = {}
    for i = 1, ROWS do
        local row = CreateFrame("Button", nil, picker)
        row:SetSize(PWD - 24, ROW_H - 2)
        row:SetPoint("TOPLEFT", 12, -62 - (i - 1) * ROW_H)
        row.sel = S:GoldBar(row, 0.85)
        row.hl = S:GoldBar(row, 0.3)
        row.hl:Hide()
        row.name = S:Text(row, "label", S.c.text)
        row.name:SetPoint("LEFT", 8, 0)
        row.name:SetWidth(PWD - 24 - 16 - COL_LVL - COL_Q - 6)
        row.name:SetJustifyH("LEFT")
        row.name:SetWordWrap(false)
        row.info = S:Text(row, "small", S.c.muted)
        row.info:SetPoint("RIGHT", -8, 0)
        row.info:SetWidth(COL_Q)
        row.info:SetJustifyH("RIGHT")
        row.lvl = S:Text(row, "small", S.c.soft)
        row.lvl:SetPoint("RIGHT", -8 - COL_Q, 0)
        row.lvl:SetWidth(COL_LVL)
        row.lvl:SetJustifyH("CENTER")
        row:SetScript("OnEnter", function(self)
            local u = self.item and self.item.up
            if u then
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:AddLine(FG:Lang() == "ru" and u.ru or u.en, SOON_C[1], SOON_C[2], SOON_C[3])
                GameTooltip:AddLine((FG:Lang() == "ru" and u.zone.ru or u.zone.en) .. (u.min and (", " .. u.min .. "–" .. u.max) or ""), 1, 1, 1)
                if u.when then GameTooltip:AddLine(L("tip_raid_when", FG:Lang() == "ru" and u.when.ru or u.when.en), 0.8, 0.8, 0.8, true)
                else GameTooltip:AddLine(L(u.beta and "tip_dungeon_nodata" or "tip_dungeon_soon"), 0.8, 0.8, 0.8, true) end
                GameTooltip:Show()
                return
            end
            self.hl:Show()
        end)
        row:SetScript("OnLeave", function(self) self.hl:Hide(); GameTooltip:Hide() end)
        row:SetScript("OnClick", function(self)
            if self.item and self.item.up then return end -- ещё не вышло — выбрать нельзя
            FG.Advisor:SetDungeon(self.item and self.item.key or nil)
            picker:Hide()
            M:Sync()
        end)
        picker.rows[i] = row
    end
    picker:EnableMouseWheel(true)
    picker:SetScript("OnMouseWheel", function(_, delta)
        picker.offset = (picker.offset or 0) - delta * 2
        refreshPicker()
    end)
    picker:Hide()
end

-- открыть меню, если закрыто; вернуть true, если только что открыли
function M:EnsureMenu()
    if not menu then createMenu() end
    if not menu:IsShown() then menu:Show(); return true end
    return false
end

function M:ShowDungeonPicker(mode)
    mode = mode or "dungeon"
    pcall(FG.Advisor.ApplyGameLevels, FG.Advisor) -- уровни из игры могли загрузиться позже
    -- /qc dungeon: открыть меню вместе со списком
    local opened = false
    if not menu then createMenu() end
    if not menu:IsShown() then menu:Show(); opened = true end
    if not picker then createPicker() end
    -- кнопка открывает и закрывает правую часть
    if picker:IsShown() and not opened and picker.mode == mode then picker:Hide() return end
    picker.mode = mode
    -- прокрутить к подземельям своего уровня
    local level = UnitLevel("player")
    picker.offset = 0
    refreshPicker()
    for i, it in ipairs(picker.items or {}) do
        local mx = it.dg and it.dg.maxL or (it.up and it.up.max)
        if mode == "raid" then mx = nil end
        if mx and mx >= level - 3 then picker.offset = math.max(0, i - 3) break end
    end
    picker:Show()
    refreshPicker()
end

local function toggle(parent, y, key, tipKey)
    local row = S:Toggle(parent, "opt_" .. key, tipKey,
        function() return FG.db[key] ~= false and FG.db[key] ~= nil end,
        function(v) FG.db[key] = v; applyOption(key) end,
        W - PAD * 2 + 4)
    row:SetPoint("TOPLEFT", PAD - 2, y)
    table.insert(widgets, row)
    return y - 27
end

function createMenu()
    menu = CreateFrame("Frame", "QuestCompassMenu", UIParent)
    menu.qcRoot = true
    menu:SetSize(SIDE + W, 500)
    menu:SetScale(1.15) -- крупнее: шрифт меню лучше читается
    menu:SetPoint("CENTER")
    menu:SetFrameStrata("DIALOG")
    menu:EnableMouse(true)
    menu:SetMovable(true)
    menu:RegisterForDrag("LeftButton")
    menu:SetClampedToScreen(true)
    menu:SetScript("OnDragStart", menu.StartMoving)
    menu:SetScript("OnDragStop", menu.StopMovingOrSizing)
    S:Window(menu, { header = TOPH })
    tinsert(UISpecialFrames, "QuestCompassMenu") -- закрывается по Esc

    -- шапка: иконка, название, язык, крестик
    local icon = menu:CreateTexture(nil, "ARTWORK")
    icon:SetTexture(S.media.logo)
    icon:SetSize(32, 32)
    icon:SetPoint("TOPLEFT", PAD - 2, -13)

    local title = S:Text(menu, "title", S.c.text)
    S:NoInk(title); title:SetTextColor(1, 1, 1)
    title:SetPoint("LEFT", icon, "RIGHT", 9, -1)
    title:SetText("Quest|cff" .. S.hex.accent .. "Compass|r")

    local close = S:Close(menu, function() menu:Hide() end)
    close:SetPoint("TOPRIGHT", -8, -8)
    menu.closeBtn = close

    local lang = S:Segmented(menu, { { "ru", "RU" }, { "en", "EN" } }, 70, 22,
        function() return FG:Lang() end,
        function(v) FG:SetLanguage(v) end,
        { raw = true, tip = "tip_lang" })
    lang:SetPoint("RIGHT", close, "LEFT", -8, 0)
    menu.langSeg = lang
    lang.qcNoInk = true
    table.insert(widgets, lang)
    FG:OnLanguageChanged(function() lang:Refresh() end)

    S:Divider(menu, 1, -TOPH, -1)

    ---------------- ВКЛАДКИ СБОКУ: каждая открывает свой блок
    local TABS = {
        { "leveling", "tab_leveling", "Interface\\Icons\\INV_Misc_Map_01" },
        { "skills", "tab_skills", "Interface\\Icons\\Trade_BlackSmithing" },
        { "talents", "tab_talents", "Interface\\Icons\\INV_Misc_Book_07" },
        { "nearby", "tab_nearby", "Interface\\Icons\\INV_Misc_Spyglass_03" },
        { "bis", "tab_bis", "Interface\\Icons\\INV_Chest_Plate06" },
        { "rep", "tab_rep", "Interface\\Icons\\INV_Scroll_03" },
        { "frames", "tab_frames", "Interface\\Icons\\INV_Misc_Gear_01" },
        { "heal", "tab_heal", "Interface\\Icons\\Spell_Holy_FlashHeal" },
    }
    -- боковая панель: тёмная подложка с лёгким золотым отливом сверху
    local sbg = S.Tex(menu, "BACKGROUND", { 0, 0, 0, 0.35 }, 3)
    sbg:SetPoint("TOPLEFT", 4, -TOPH - 1); sbg:SetPoint("BOTTOMLEFT", 4, 4); sbg:SetWidth(SIDE - 4)
    local sglow = S.Tex(menu, "BACKGROUND", { 1, 0.82, 0, 0.06 }, 4)
    sglow:SetPoint("TOPLEFT", sbg, "TOPLEFT"); sglow:SetPoint("TOPRIGHT", sbg, "TOPRIGHT"); sglow:SetHeight(120)
    if sglow.SetGradient and CreateColor then
        pcall(sglow.SetGradient, sglow, "VERTICAL", CreateColor(1, 0.82, 0, 0), CreateColor(1, 0.82, 0, 0.08))
    end
    local vline = S.Tex(menu, "ARTWORK", S.c.border)
    vline:SetWidth(1); vline:SetPoint("TOPLEFT", SIDE, -TOPH); vline:SetPoint("BOTTOMLEFT", SIDE, 6)
    vline:SetAlpha(0.6)
    menu.tabBtns = {}
    for i, t in ipairs(TABS) do
        local b = CreateFrame("Button", nil, menu)
        b:SetSize(SIDE - 16, 48)
        b:SetPoint("TOPLEFT", 8, -TOPH - 12 - (i - 1) * 54)
        S:Box(b, 5, { 1, 1, 1, 0.03 }, { 1, 1, 1, 0.07 })
        b.sel = S:GoldBar(b, 0.5); b.sel:Hide()
        b.hl = S:GoldBar(b, 0.18); b.hl:Hide()
        b.edge = b:CreateTexture(nil, "OVERLAY")
        b.edge:SetTexture("Interface\\Buttons\\WHITE8x8"); b.edge:SetVertexColor(1, 0.82, 0, 1)
        b.edge:SetWidth(3); b.edge:SetPoint("TOPLEFT", 1, -6); b.edge:SetPoint("BOTTOMLEFT", 1, 6); b.edge:Hide()
        local ib = b:CreateTexture(nil, "ARTWORK", nil, 1)
        ib:SetTexture("Interface\\Buttons\\WHITE8x8"); ib:SetVertexColor(0, 0, 0, 0.8)
        ib:SetSize(32, 32); ib:SetPoint("LEFT", 10, 0)
        b.icon = b:CreateTexture(nil, "ARTWORK", nil, 2)
        b.icon:SetSize(30, 30); b.icon:SetPoint("CENTER", ib, "CENTER"); b.icon:SetTexture(t[3])
        b.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        b.label = S:Text(b, "label", S.c.text)
        b.label:SetPoint("LEFT", ib, "RIGHT", 10, 0); b.label:SetPoint("RIGHT", -6, 0)
        b.label:SetJustifyH("LEFT"); b.label:SetWordWrap(false)
        FG:Localize(b.label, t[2])
        b.key = t[1]
        b:SetScript("OnEnter", function(self) if M.tab ~= self.key then self.hl:Show() end end)
        b:SetScript("OnLeave", function(self) self.hl:Hide() end)
        b:SetScript("OnClick", function(self) self.hl:Hide(); M:ShowTab(self.key) end)
        menu.tabBtns[i] = b
    end
    -- версия внизу боковой панели
    local ver = S:Text(menu, "small", S.c.muted)
    ver:SetPoint("BOTTOMLEFT", 14, 12)
    local v = (C_AddOns and C_AddOns.GetAddOnMetadata and select(2, pcall(C_AddOns.GetAddOnMetadata, "QuestCompass", "Version")))
        or (rawget(_G, "GetAddOnMetadata") and select(2, pcall(GetAddOnMetadata, "QuestCompass", "Version")))
    ver:SetText(type(v) == "string" and ("v" .. v) or "")
    ver:SetAlpha(0.7)
    local tabs = { Refresh = function()
        for _, b in ipairs(menu.tabBtns) do
            local on = b.key == M.tab
            if on then b.sel:Show(); b.edge:Show(); b.label:SetTextColor(1, 0.86, 0.3); b.icon:SetDesaturated(false)
            else b.sel:Hide(); b.edge:Hide(); b.label:SetTextColor(S.c.text[1], S.c.text[2], S.c.text[3]); b.icon:SetDesaturated(true) end
        end
    end }
    menu.tabs = tabs

    local function newPage()
        local p = CreateFrame("Frame", nil, menu)
        p:SetPoint("TOPLEFT", menu, "TOPLEFT", SIDE, -TOPH)
        p:SetPoint("BOTTOMRIGHT", menu, "BOTTOMRIGHT", 0, 0)
        p:Hide()
        return p
    end
    local page = newPage()
    pages.leveling = page

    local y = -14
    ---------------- ПРОКАЧКА
    S:Section(page, "sec_leveling", PAD, y)
    y = y - 22

    local rl = S:Text(page, "label", S.c.muted)
    rl:SetPoint("TOPLEFT", PAD, y - 6)
    FG:Localize(rl, "route_label")
    local route = S:Segmented(page, { { "xp", "route_xp" }, { "near", "route_near" } }, 200, 26,
        function() return FG.db.route or "xp" end,
        function(v) FG.db.route = v; leaveDungeon(); FG:Refresh(true) end, { tip = "tip_route" })
    route:SetPoint("TOPRIGHT", -PAD, y)
    table.insert(widgets, route)
    y = y - 34

    local fl = S:Text(page, "label", S.c.muted)
    fl:SetPoint("TOPLEFT", PAD, y - 6)
    FG:Localize(fl, "faction")
    local fac = S:Segmented(page, { { "Alliance", "f_alliance" }, { "Horde", "f_horde" } }, 200, 26,
        function() return FG.cdb.faction or (UnitFactionGroup and UnitFactionGroup("player")) or "Alliance" end,
        function(v) FG.cdb.faction = v; applyFilters() end,
        { icons = { { "Interface\\TargetingFrame\\UI-PVP-Alliance", { 0.05, 0.62, 0.02, 0.62 } },
                    { "Interface\\TargetingFrame\\UI-PVP-Horde", { 0.05, 0.62, 0.02, 0.62 } } } })
    fac:SetPoint("TOPRIGHT", -PAD, y)
    table.insert(widgets, fac)
    y = y - 32

    local ll = S:Text(page, "label", S.c.muted)
    ll:SetPoint("TOPLEFT", PAD, y - 4)
    FG:Localize(ll, "levels")
    local maxS = S:Stepper(page,
        function() return FG.cdb.levelMax or 60 end,
        function(v) FG.cdb.levelMax = v; clampLevels("max") end)
    maxS:SetPoint("TOPRIGHT", -PAD, y)
    maxS.isStepper = true
    local dash = S:Text(page, "label", S.c.muted)
    dash:SetPoint("RIGHT", maxS, "LEFT", -7, 0)
    dash:SetText("—")
    local minS = S:Stepper(page,
        function() return FG.cdb.levelMin or 1 end,
        function(v) FG.cdb.levelMin = v; clampLevels("min") end)
    minS:SetPoint("RIGHT", dash, "LEFT", -7, 0)
    minS.isStepper = true
    table.insert(widgets, minS); table.insert(widgets, maxS)
    y = y - 30
    -- «Идти»: окно с картой и тем, что делать по заданиям
    local gl = S:Text(page, "label", S.c.muted)
    gl:SetPoint("TOPLEFT", PAD, y - 5)
    FG:Localize(gl, "go_quest_label")
    local gbtn = FG.Go:Button(page, 200, 24, function() FG.Go:Open("quest") end)
    gbtn:SetPoint("TOPRIGHT", -PAD, y)
    y = y - 30

    y = y - 6

    ---------------- ПОДЗЕМЕЛЬЕ
    S:Section(page, "sec_dungeon", PAD, y)
    y = y - 22
    local dl = S:Text(page, "label", S.c.muted)
    dl:SetPoint("TOPLEFT", PAD, y - 5)
    FG:Localize(dl, "dungeon_label")
    local dbtn = S:Button(page, nil, 200, 24, function() M:ShowDungeonPicker("dungeon") end, { font = "label" })
    dbtn:SetPoint("TOPRIGHT", -PAD, y)
    function dbtn:Refresh() self.label:SetText(dungeonLabel(false)) end
    dbtn:Refresh()
    table.insert(widgets, dbtn)
    y = y - 30
    -- рейды — отдельной кнопкой
    local rlb = S:Text(page, "label", S.c.muted)
    rlb:SetPoint("TOPLEFT", PAD, y - 5)
    FG:Localize(rlb, "raid_label")
    local rbtn = S:Button(page, nil, 200, 24, function() M:ShowDungeonPicker("raid") end, { font = "label" })
    rbtn:SetPoint("TOPRIGHT", -PAD, y)
    function rbtn:Refresh() self.label:SetText(dungeonLabel(true)) end
    rbtn:Refresh()
    table.insert(widgets, rbtn)
    y = y - 30
    y = y - 6

    ---------------- АВТОМАТИКА
    S:Section(page, "sec_auto", PAD, y)
    y = y - 18
    y = toggle(page, y, "autoAccept", "tip_autoAccept")
    y = toggle(page, y, "autoTurnIn")
    y = y - 10

    ---------------- ИНТЕРФЕЙС
    S:Section(page, "sec_ui", PAD, y)
    y = y - 18
    y = toggle(page, y, "panelShown")
    y = toggle(page, y, "showArrow")
    y = toggle(page, y, "showMapPin")
    y = toggle(page, y, "showLine", "tip_showLine")

    y = y - 4
    y = y - 6

    -- высота страницы «Прокачка»
    pageH.leveling = -y + 14

    ---------------- РЕПУТАЦИИ
    pages.rep = newPage()
    pageH.rep = 600

    ---------------- СПУТНИК
    pages.nearby = newPage()
    pageH.nearby = 640

    ---------------- ТАЛАНТЫ
    pages.talents = newPage()
    pageH.talents = 640

    ---------------- BiS: страница заполняется модулем BiS при первом открытии
    pages.bis = newPage()
    pageH.bis = 600

    ---------------- НАВЫКИ: страница заполняется модулем Skills
    pages.skills = newPage()
    pageH.skills = 600

    ---------------- ИНТЕРФЕЙС: рамка здоровья, баффы, полоса опыта (Frames.lua)
    pages.frames = newPage()
    pageH.frames = 640

    ---------------- ЛЕЧЕНИЕ: клики по рамкам и рамки группы/рейда (Frames.lua)
    pages.heal = newPage()
    pageH.heal = 640

    FG:OnLanguageChanged(function()
        refreshPicker()
        tabs:Refresh()
        if dbtn and dbtn.Refresh then dbtn:Refresh() end
        if rbtn and rbtn.Refresh then rbtn:Refresh() end
    end)

    menu:Hide()
    menu:SetScript("OnShow", function() M:ShowTab(M.tab or FG.db.menuTab or "leveling"); M:Sync() end)
end

-- переключение вкладок
function M:ShowTab(key)
    if not menu then createMenu() end
    if not pages[key] then key = "leveling" end
    M.tab = key
    FG.db.menuTab = key
    for _, d in ipairs(M.drawers or {}) do if d:IsShown() then d:Hide() end end
    if key == "bis" and FG.BiS and FG.BiS.BuildPage then FG.BiS:BuildPage(pages.bis) end
    if key == "skills" and FG.Skills and FG.Skills.BuildPage then FG.Skills:BuildPage(pages.skills) end
    if key == "talents" and FG.Talents and FG.Talents.BuildPage then FG.Talents:BuildPage(pages.talents) end
    if key == "frames" and FG.Frames and FG.Frames.BuildPage then FG.Frames:BuildPage(pages.frames) end
    if key == "heal" and FG.Frames and FG.Frames.BuildHealPage then FG.Frames:BuildHealPage(pages.heal) end
    -- вернулись на «Прокачку» — снимаем цель из «Спутника»; прокачку профессии не трогаем
    -- (она открыта по умолчанию, и раньше из-за этого стрелка уходила с профессии на квест)
    if key == "leveling" and FG.navTarget and FG.navTarget.nearby and FG.SetNavTarget then FG:SetNavTarget(nil) end
    if key == "nearby" and FG.Nearby and FG.Nearby.BuildPage then FG.Nearby:BuildPage(pages.nearby) end
    if key == "rep" and FG.Rep and FG.Rep.BuildPage then FG.Rep:BuildPage(pages.rep) end
    -- окно всегда одного размера: ширина FG.PAGE_W, высота по самой высокой вкладке; доп. части открываются справа (MakeDrawer)
    local hmax = 12 + #TABS_KEYS * 54 + 50
    for _, h in pairs(pageH) do if h > hmax then hmax = h end end
    menu:SetHeight(TOPH + hmax)
    for k, p in pairs(pages) do if k == key then p:Show() else p:Hide() end end
    if key ~= "bis" and FG.BiS and FG.BiS.detail then FG.BiS.detail:Hide() end
    if key == "talents" and FG.Talents and FG.Talents.Refresh then FG.Talents.Refresh() end
    if key == "nearby" and FG.Nearby and FG.Nearby.Refresh then FG.Nearby.Refresh() end
    if key == "rep" and FG.Rep and FG.Rep.Refresh then FG.Rep.Refresh() end
    S:SkinTree(menu)
    if key == "skills" and FG.Skills and FG.Skills.Refresh then
        -- гайд профессии открывается только по нажатию на её карточку
        FG.Skills.Refresh()
    end

    if menu.tabs then menu.tabs:Refresh() end
    if key == "bis" and FG.BiS and FG.BiS.Refresh then FG.BiS.Refresh() end
end

-- открыть меню на вкладке; повторное нажатие на ту же вкладку закрывает меню
function M:ToggleTab(key)
    if not menu then createMenu() end
    if menu:IsShown() and M.tab == key then menu:Hide() return end
    M.tab = key
    if menu:IsShown() then M:ShowTab(key) else menu:Show() end
end

function M:Sync()
    for _, w in ipairs(widgets) do if w.Refresh then w:Refresh() end end
end

function M:Toggle()
    if not menu then createMenu() end
    if menu:IsShown() then menu:Hide() else menu:Show() end
end

function M:ResetPositions()
    FG.db.panelPos = { "TOPRIGHT", "TOPRIGHT", -230, -220 }
    FG.db.arrowPos = { "TOP", "TOP", 0, -110 }
    local p, a = QuestCompassPanel, QuestCompassArrow
    if p then p:ClearAllPoints(); p:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -230, -220) end
    if a then a:ClearAllPoints(); a:SetPoint("TOP", UIParent, "TOP", 0, -110) end
    FG:Print(L("reset_done"))
end

---------------------------------------------------------------------------
-- Иконка у миникарты
---------------------------------------------------------------------------
local button

local function placeButton()
    local angle = math.rad(FG.db.minimapAngle or 215)
    local r = (Minimap:GetWidth() / 2) + 5
    button:ClearAllPoints()
    button:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * r, math.sin(angle) * r)
end

local function createButton()
    button = CreateFrame("Button", "QuestCompassMinimapButton", Minimap)
    button:SetSize(31, 31)
    button:SetFrameStrata("MEDIUM")
    button:SetFrameLevel(8)
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button:RegisterForDrag("LeftButton")
    button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    local bg = button:CreateTexture(nil, "BACKGROUND")
    bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    bg:SetSize(20, 20)
    bg:SetPoint("TOPLEFT", 7, -5)

    local icon = button:CreateTexture(nil, "ARTWORK")
    icon:SetTexture(S.media.logo)
    icon:SetSize(20, 20)
    icon:SetPoint("TOPLEFT", 6, -5)

    local border = button:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(53, 53)
    border:SetPoint("TOPLEFT")

    button:SetScript("OnClick", function(_, btn)
        if btn == "RightButton" then FG.UI:Toggle() else M:Toggle() end
    end)

    -- перетаскивание по краю миникарты
    button:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            cx, cy = cx / scale, cy / scale
            FG.db.minimapAngle = math.deg(math.atan2(cy - my, cx - mx))
            placeButton()
        end)
    end)
    button:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)

    button:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("Quest|cff" .. S.hex.accent .. "Compass|r")
        local s = FG.Advisor and FG.Advisor.step
        if s then GameTooltip:AddLine(FG.Advisor:Describe(s), 1, 1, 1, true) end
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine(L("tt_left"), 0.75, 0.78, 0.82)
        GameTooltip:AddLine(L("tt_right"), 0.75, 0.78, 0.82)
        GameTooltip:AddLine(L("tt_drag"), 0.75, 0.78, 0.82)
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)

    placeButton()
end

function M:UpdateButton()
    if not button then return end
    button:Show() -- иконка у миникарты всегда видна
end

---------------------------------------------------------------------------
-- Раздел в стандартных настройках игры (Esc » Options » AddOns » QuestCompass)
---------------------------------------------------------------------------
local function registerGameOptions()
    local panel = CreateFrame("Frame")
    panel.name = "QuestCompass"
    local title = S:Text(panel, "title", S.c.text)
    title:SetPoint("TOPLEFT", 16, -16)
    title:SetText("Quest|cff" .. S.hex.accent .. "Compass|r")
    local desc = S:Text(panel, "body", S.c.muted)
    desc:SetPoint("TOPLEFT", 16, -48)
    desc:SetWidth(520)
    FG:Localize(desc, "options_desc")
    local b = S:Button(panel, "open_menu", 220, 28, function()
        if SettingsPanel and SettingsPanel:IsShown() and HideUIPanel then HideUIPanel(SettingsPanel) end
        if not menu or not menu:IsShown() then M:Toggle() end
    end, { primary = true, font = "label" })
    b:SetPoint("TOPLEFT", 16, -90)
    if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
        pcall(function()
            local cat = Settings.RegisterCanvasLayoutCategory(panel, "QuestCompass")
            Settings.RegisterAddOnCategory(cat)
        end)
    elseif InterfaceOptions_AddCategory then
        pcall(InterfaceOptions_AddCategory, panel)
    end
end

FG:OnInit(function()
    FG.db.minimapShown = true
    createButton()
    M:UpdateButton()
    pcall(registerGameOptions)
end)
