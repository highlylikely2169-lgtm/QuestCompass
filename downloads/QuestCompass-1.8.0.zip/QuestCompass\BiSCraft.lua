-- Рецепты изготавливаемых BiS-вещей (данные WoW Forever, metaforge.app / VMaNGOS)
-- prof: ключ профессии; skill: нужный навык; spec/rep: специализация и репутация для рецепта
-- mats: { itemID, количество, англ. имя (если вещи нет в базе), рус. имя }
-- recipe: kind = vendor | drop | trainer | cache; npcs = ID NPC
QuestCompassCraft = {
  PROF = {
    tailoring      = { "Tailoring", "Портняжное дело" },
    leatherworking = { "Leatherworking", "Кожевничество" },
    blacksmithing  = { "Blacksmithing", "Кузнечное дело" },
    engineering    = { "Engineering", "Инженерное дело" },
  },
  SPEC = {
    armorsmith = { "Armorsmith", "Бронник" },
    axesmith   = { "Master Axesmith", "Мастер ковки топоров" },
    tribal     = { "Tribal Leatherworking", "Традиционное кожевничество" },
    elemental  = { "Elemental Leatherworking", "Кожевничество стихий" },
  },
  REP = {
    zandalar = { "Zandalar Tribe", "Племя Зандалар" },
    thorium  = { "Thorium Brotherhood", "Братство Тория" },
  },
  STAND = {
    friendly = { "Friendly", "Дружелюбие" },
    honored  = { "Honored", "Уважение" },
    revered  = { "Revered", "Почтение" },
  },
  ITEMS = {
    -- Lionheart Helm
    [12640] = { prof = "blacksmithing", skill = 300, spec = "armorsmith",
      mats = { {12359, 80}, {12360, 12}, {8146, 40}, {12361, 10}, {12800, 4} },
      recipe = { kind = "drop", npcs = { 11502, 10184, 6109, 12397 } } },
    -- Titanic Leggings
    [22385] = { prof = "blacksmithing", skill = 300, spec = "armorsmith",
      mats = { {12360, 12}, {12655, 20}, {7076, 10}, {13510, 2} },
      recipe = { kind = "drop", npcs = { 11502, 10184, 6109 } } },
    -- Arcanite Reaper
    [12784] = { prof = "blacksmithing", skill = 300, spec = "axesmith",
      mats = { {12360, 20}, {12810, 6}, {12644, 2} },
      recipe = { kind = "drop", npcs = { 9596 } } },
    -- Devilsaur Gauntlets
    [15063] = { prof = "leatherworking", skill = 265, spec = "tribal",
      mats = { {8170, 30}, {15417, 8}, {14341, 1} },
      recipe = { kind = "vendor", npcs = { 12959 }, limited = true } },
    -- Devilsaur Leggings
    [15062] = { prof = "leatherworking", skill = 290, spec = "tribal",
      mats = { {8170, 30}, {15417, 14}, {15407, 1}, {14341, 1} },
      recipe = { kind = "drop", text = { "Oozes in Un'Goro Crater and Silithus (~1%)", "Слизни в кратере Ун'Горо и Силитусе (~1%)" } } },
    -- Hide of the Wild
    [18510] = { prof = "leatherworking", skill = 300, spec = "tribal",
      mats = { {8170, 30}, {12803, 12}, {7080, 10}, {18512, 8}, {15407, 3}, {14341, 8} },
      recipe = { kind = "cache", npcs = { 11448 } } },
    -- Living Shoulders
    [15061] = { prof = "leatherworking", skill = 245, spec = "elemental",
      mats = { {8170, 12}, {12803, 4}, {14341, 1} },
      recipe = { kind = "vendor", npcs = { 7852, 7854 }, limited = true } },
    -- Corehound Belt
    [19162] = { prof = "leatherworking", skill = 300, spec = "tribal", rep = "thorium", stand = "revered",
      mats = { {17010, 8}, {17012, 12}, {12810, 10}, {15407, 4}, {14227, 4} },
      recipe = { kind = "vendor", npcs = { 12944 } } },
    -- Bloodvine Vest
    [19682] = { prof = "tailoring", skill = 300, rep = "zandalar", stand = "revered",
      mats = { {14342, 3}, {19726, 5}, {12804, 4}, {14048, 4}, {14227, 2} },
      recipe = { kind = "vendor", npcs = { 14921 } } },
    -- Bloodvine Leggings
    [19683] = { prof = "tailoring", skill = 300, rep = "zandalar", stand = "honored",
      mats = { {14342, 4}, {19726, 4}, {12804, 4}, {14048, 4}, {14227, 2} },
      recipe = { kind = "vendor", npcs = { 14921 } } },
    -- Bloodvine Boots
    [19684] = { prof = "tailoring", skill = 300, rep = "zandalar", stand = "friendly",
      mats = { {14342, 3}, {19726, 3}, {12810, 4}, {14048, 4}, {14227, 4} },
      recipe = { kind = "vendor", npcs = { 14921 } } },
    -- Felcloth Gloves
    [18407] = { prof = "tailoring", skill = 280,
      mats = { {14048, 12}, {14256, 20}, {12662, 6}, {12808, 8}, {14341, 2} },
      recipe = { kind = "cache", npcs = { 11450 } } },
    -- Felcloth Shoulders
    [14112] = { prof = "tailoring", skill = 265,
      mats = { {14048, 7}, {14256, 6}, {12662, 4}, {8170, 4}, {14341, 2} },
      recipe = { kind = "drop", npcs = { 12397 }, text = { "rare drop from level 58+ mobs and chests", "редкая добыча с существ 58+ и сундуков" } } },
    -- Robe of Winter Night
    [14136] = { prof = "tailoring", skill = 245,
      mats = { {14048, 10}, {14256, 12}, {12808, 4}, {7080, 4}, {14341, 1} },
      recipe = { kind = "drop", npcs = { 7437 } } },
    -- Truefaith Vestments
    [14154] = { prof = "tailoring", skill = 295,
      mats = { {14048, 12}, {14342, 8}, {12811, 2}, {13926, 2}, {9210, 8}, {14341, 2}, {0, 10, "Viridian Dye", "Изумрудный краситель"} },
      recipe = { kind = "drop", npcs = { 10813 } } },
    -- Green Lens
    [10504] = { prof = "engineering", skill = 245,
      mats = { {4304, 8}, {1529, 3}, {7909, 3}, {10286, 2}, {8153, 2} },
      recipe = { kind = "trainer" } },
  },
}

-- Рекомендуемые чары (наложение чар) для BiS-вещей — данные WoW Forever (metaforge.app)
-- spell: ID заклинания чар (название берётся из игры), enchant: ID эффекта на вещи (для проверки «уже наложено»)
-- skill: навык наложения чар; mats: { ID, кол-во } (на 1 раз); src: где взять формулу
QuestCompassEnchant = {
  E = {
    crusader     = { spell = 20034, enchant = 1900, skill = 300, en = "Crusader", ru = "Рыцарь",
                     fx = { "heals 75-125 and +100 Strength for 15 sec (proc)", "иногда лечит на 75–125 и даёт +100 силы на 15 сек." },
                     mats = { {14344, 4}, {12811, 2} }, src = { "drop: Scarlet Spellbinder (W. Plaguelands)", "добыча: Алый заклинатель (Западные Чумные земли)" } },
    spellpower   = { spell = 22749, enchant = 2504, skill = 300, en = "Spell Power", ru = "Сила заклинаний",
                     fx = { "+30 spell damage", "+30 к урону от заклинаний" },
                     mats = { {14344, 4}, {16203, 12}, {7078, 4}, {7080, 4}, {7082, 4}, {13926, 2} }, src = { "drop: Molten Core bosses", "добыча: боссы Огненных Недр" } },
    healweapon   = { spell = 22750, enchant = 2505, skill = 300, en = "Healing Power (weapon)", ru = "Сила исцеления (оружие)",
                     fx = { "+55 healing", "+55 к исцелению" },
                     mats = { {14344, 4}, {16203, 8}, {7080, 6}, {12803, 6}, {12811, 1} }, src = { "drop: Molten Core bosses", "добыча: боссы Огненных Недр" } },
    agi2h        = { spell = 27837, enchant = 2646, skill = 290, en = "2H Agility", ru = "Ловкость (двуручное)",
                     fx = { "+25 Agility (two-handed)", "+25 к ловкости (двуручное)" },
                     mats = { {14344, 10}, {16203, 6}, {16204, 14}, {7082, 4} }, src = { "sold: Meilosh (Felwood), Timbermaw Friendly", "продаёт Мейлош (Оскверненный лес), Древобрюхи — дружелюбие" } },
    stats        = { spell = 20025, enchant = 1891, skill = 300, en = "Greater Stats", ru = "Большие характеристики",
                     fx = { "+4 all stats", "+4 ко всем характеристикам" },
                     mats = { {14344, 4}, {16204, 15}, {16203, 10} }, src = { "drop: dragons of Nightmare, Azuregos", "добыча: драконы Кошмара, Азурегос" } },
    cloakagi     = { spell = 13882, enchant = 849, skill = 225, en = "Lesser Agility (cloak)", ru = "Малая ловкость (плащ)",
                     fx = { "+3 Agility", "+3 к ловкости" },
                     mats = { {11174, 1} }, src = { "drop: Wastewander rogues (Tanaris)", "добыча: разбойники Скитальцев (Танарис)" } },
    cloakarmor   = { spell = 20015, enchant = 1889, skill = 285, en = "Superior Defense", ru = "Превосходная защита",
                     fx = { "+70 armor", "+70 к броне" },
                     mats = { {16204, 8} }, src = { "sold: Lorelae Wintersong (Moonglade)", "продаёт Лорелай Зимняя Песнь (Лунная поляна)" } },
    bracerstr    = { spell = 20010, enchant = 1885, skill = 295, en = "Superior Strength", ru = "Превосходная сила",
                     fx = { "+9 Strength", "+9 к силе" },
                     mats = { {16204, 6}, {16203, 6} }, src = { "drop: Deadwind Warlock (Deadwind Pass)", "добыча: Чернокнижник Мертвого леса (Перевал Мертвого Ветра)" } },
    bracersta    = { spell = 20011, enchant = 1886, skill = 300, en = "Superior Stamina", ru = "Превосходная выносливость",
                     fx = { "+9 Stamina", "+9 к выносливости" },
                     mats = { {16204, 15} }, src = { "drop: Lord Kazzak, Nathanos Blightcaller", "добыча: Владыка Каззак, Натанос Гнилостень" } },
    bracerint    = { spell = 20008, enchant = 1883, skill = 255, en = "Greater Intellect", ru = "Большой интеллект",
                     fx = { "+7 Intellect", "+7 к интеллекту" },
                     mats = { {16202, 3} }, src = { "drop: Vilebranch Shadowcaster (Hinterlands)", "добыча: Заклинатель теней из племени Сквернобивней" } },
    bracerheal   = { spell = 23802, enchant = 2566, skill = 300, en = "Healing Power (bracer)", ru = "Сила исцеления (наручи)",
                     fx = { "+24 healing", "+24 к исцелению" },
                     mats = { {14344, 2}, {16204, 20}, {16203, 4}, {12803, 6} }, src = { "sold: Argent Dawn quartermasters (Revered)", "продают интенданты Серебряного Рассвета (почтение)" } },
    glovestr     = { spell = 20013, enchant = 927, skill = 295, en = "Greater Strength (gloves)", ru = "Большая сила (перчатки)",
                     fx = { "+10 Strength", "+10 к силе" },
                     mats = { {16203, 4}, {16204, 4} }, src = { "drop: Spirestone Mystic (Blackrock Spire)", "добыча: Мистик Шпиля (Вершина Черной горы)" } },
    gloveagi     = { spell = 20012, skill = 270, en = "Greater Agility (gloves)", ru = "Большая ловкость (перчатки)",
                     fx = { "+10 Agility", "+10 к ловкости" },
                     mats = { {16202, 3}, {16204, 3} }, src = { "drop: Legashi Rogue (Azshara)", "добыча: Разбойник Легаши (Азшара)" } },
    gloveheal    = { spell = 25079, enchant = 2617, skill = 300, en = "Healing Power (gloves)", ru = "Сила исцеления (перчатки)",
                     fx = { "+35 healing (Ahn'Qiraj formula)", "+35 к исцелению (формула из Ан'Киража)" },
                     mats = { {20725, 1}, {14344, 3} }, src = { "drop: Ahn'Qiraj bosses", "добыча: боссы Ан'Киража" } },
    glovefire    = { spell = 25078, enchant = 2616, skill = 300, en = "Fire Power", ru = "Сила огня",
                     fx = { "+20 fire damage (Ahn'Qiraj formula)", "+20 к урону от огня (формула из Ан'Киража)" },
                     mats = { {20725, 2}, {14344, 4}, {7078, 4} }, src = { "drop: Ahn'Qiraj bosses", "добыча: боссы Ан'Киража" } },
    glovefrost   = { spell = 25074, enchant = 2615, skill = 300, en = "Frost Power", ru = "Сила льда",
                     fx = { "+20 frost damage (Ahn'Qiraj formula)", "+20 к урону от льда (формула из Ан'Киража)" },
                     mats = { {20725, 2}, {14344, 4}, {7080, 4} }, src = { "drop: Ahn'Qiraj bosses", "добыча: боссы Ан'Киража" } },
    gloveshadow  = { spell = 25073, enchant = 2614, skill = 300, en = "Shadow Power", ru = "Сила тьмы",
                     fx = { "+20 shadow damage (Ahn'Qiraj formula)", "+20 к урону от тьмы (формула из Ан'Киража)" },
                     mats = { {20725, 2}, {14344, 4}, {12808, 6} }, src = { "drop: Ahn'Qiraj bosses", "добыча: боссы Ан'Киража" } },
    bootagi      = { spell = 20023, skill = 295, en = "Greater Agility (boots)", ru = "Большая ловкость (обувь)",
                     fx = { "+7 Agility", "+7 к ловкости" },
                     mats = { {16203, 8} }, src = { "drop: Lord Kazzak and others", "добыча: Владыка Каззак и другие" } },
    bootsta      = { spell = 20020, enchant = 929, skill = 260, en = "Greater Stamina (boots)", ru = "Большая выносливость (обувь)",
                     fx = { "+7 Stamina", "+7 к выносливости" },
                     mats = { {11176, 10} }, src = { "drop: Lord Kazzak, Krellack (Silithus)", "добыча: Владыка Каззак, Креллак (Силитус)" } },
    bootspirit   = { spell = 20024, skill = 275, en = "Spirit (boots)", ru = "Дух (обувь)",
                     fx = { "+5 Spirit", "+5 к духу" },
                     mats = { {16202, 2}, {11176, 1} }, src = { "drop: Lord Kazzak, Hematos", "добыча: Владыка Каззак, Гематос" } },
    shieldsta    = { spell = 20017, enchant = 929, skill = 265, en = "Greater Stamina (shield)", ru = "Большая выносливость (щит)",
                     fx = { "+9 Stamina", "+9 к выносливости" },
                     mats = { {11176, 10} }, src = { "sold: Mythrin'dir (Darnassus) / Daniel Bartlett (Undercity)", "продаёт Митрин'дир (Дарнас) / Дэниел Бартлетт (Подгород)" } },
  },
  -- роль -> слот -> чары
  ROLE = {
    str    = { back = "cloakagi", chest = "stats", wrist = "bracerstr", hands = "glovestr", feet = "bootagi", mh = "crusader", oh = "crusader" },
    agi    = { back = "cloakagi", chest = "stats", wrist = "bracerstr", hands = "gloveagi", feet = "bootagi", mh = "crusader", oh = "crusader" },
    hunter = { back = "cloakagi", chest = "stats", wrist = "bracersta", hands = "gloveagi", feet = "bootagi", mh = "agi2h" },
    caster = { back = "cloakarmor", chest = "stats", wrist = "bracerint", hands = "glovefire", feet = "bootsta", mh = "spellpower" },
    heal   = { back = "cloakarmor", chest = "stats", wrist = "bracerheal", hands = "gloveheal", feet = "bootspirit", mh = "healweapon", oh = "shieldsta" },
  },
}
