-- QuestCompass: пунктир от игрока до цели на карте мира и на миникарте.
-- Линия идёт по маршруту: через распорядителей полётов и записанные пути (Travel.lua).
local _, ns = ...
local FG = ns.FG
local A = FG.Advisor
local R = {}
FG.Route = R

local COLOR = { 0.25, 0.85, 1 } -- яркий голубой: хорошо виден на жёлто-коричневой карте

-- Пул точек: создаём текстуры по мере надобности и прячем лишние
-- Точки рисуются на отдельном прозрачном слое поверх карты, чтобы тайлы карты их не закрывали
-- level = абсолютный слой. Содержимое большой карты начинается примерно со слоя 2000,
-- значки Questie — от 2016, поэтому линию кладём на 2010: над картой, под значками квестов.
local function newPool(host, level)
    local layer = CreateFrame("Frame", nil, host)
    layer:SetAllPoints(host)
    if layer.SetFixedFrameLevel then layer:SetFixedFrameLevel(false) end
    layer:SetFrameLevel(level or 2010)
    if layer.SetFixedFrameLevel then layer:SetFixedFrameLevel(true) end
    return { parent = layer, host = host, layer = "OVERLAY", dots = {}, used = 0 }
end

local function poolBegin(pool) pool.used = 0 end

local function poolDot(pool, x, y, size, alpha)
    pool.used = pool.used + 1
    local t = pool.dots[pool.used]
    if not t then
        -- точка = чёрная обводка + цветная середина
        -- круглая точка: тёмная подложка + цветная середина
        local CIRCLE = FG.Style and FG.Style.media.circle or "Interface\\Buttons\\WHITE8x8"
        t = pool.parent:CreateTexture(nil, pool.layer, nil, 6)
        t:SetTexture(CIRCLE)
        t:SetVertexColor(0, 0, 0, 0.85)
        t.inner = pool.parent:CreateTexture(nil, pool.layer, nil, 7)
        t.inner:SetTexture(CIRCLE)
        t.inner:SetVertexColor(COLOR[1], COLOR[2], COLOR[3], 1)
        t.inner:SetPoint("CENTER", t, "CENTER")
        local hide = t.Hide
        t.Hide = function(self) hide(self); self.inner:Hide() end
        pool.dots[pool.used] = t
    end
    local border = math.max(0.6, size * 0.28)
    t:SetSize(size + border * 2, size + border * 2)
    t.inner:SetSize(size, size)
    t:SetAlpha(alpha or 1)
    t.inner:SetAlpha(alpha or 1)
    t:ClearAllPoints()
    t:SetPoint("CENTER", pool.parent, pool.anchor or "TOPLEFT", x, y)
    t:Show()
    t.inner:Show()
end

local function poolEnd(pool)
    for i = pool.used + 1, #pool.dots do pool.dots[i]:Hide() end
end

local function poolHide(pool)
    poolBegin(pool)
    poolEnd(pool)
end

-- Рисует пунктир из (x1,y1) в (x2,y2); step — шаг между точками в пикселях
local function dashed(pool, x1, y1, x2, y2, step, size, maxDots)
    local dx, dy = x2 - x1, y2 - y1
    local len = math.sqrt(dx * dx + dy * dy)
    if len < step then return end
    local n = math.min(math.floor(len / step), maxDots)
    for i = 1, n do
        local k = i / (n + 1)
        poolDot(pool, x1 + dx * k, y1 + dy * k, size)
    end
end

---------------------------------------------------------------------------
-- Карта мира
---------------------------------------------------------------------------
local mapPool

-- Отсекаем отрезок прямоугольником [0,W]x[0,H] (Лианг–Барски)
local function clip(x1, y1, x2, y2, W, H)
    local dx, dy = x2 - x1, y2 - y1
    local t0, t1 = 0, 1
    local p = { -dx, dx, -dy, dy }
    local q = { x1, W - x1, y1, H - y1 }
    for i = 1, 4 do
        if p[i] == 0 then
            if q[i] < 0 then return nil end
        else
            local r = q[i] / p[i]
            if p[i] < 0 then if r > t1 then return nil elseif r > t0 then t0 = r end
            else if r < t0 then return nil elseif r < t1 then t1 = r end end
        end
    end
    return x1 + dx * t0, y1 + dy * t0, x1 + dx * t1, y1 + dy * t1
end

-- Точки рисуем в видимом окне карты (ScrollContainer), в экранных пикселях:
-- шаг всегда одинаковый при любом приближении, а точки вне окна не рисуются.
local STEP, SIZE, TURN = 9, 3.2, 6
local function viewDots(pool, x1, y1, x2, y2, W, H, phase)
    local len = math.sqrt((x2 - x1) ^ 2 + (y2 - y1) ^ 2)
    local cx1, cy1, cx2, cy2 = clip(x1, y1, x2, y2, W, H)
    if not cx1 then return (phase + len) % STEP end
    -- фаза считается от начала отрезка, чтобы при сдвиге карты точки не «прыгали»
    local skip = math.sqrt((cx1 - x1) ^ 2 + (cy1 - y1) ^ 2)
    local vis = math.sqrt((cx2 - cx1) ^ 2 + (cy2 - cy1) ^ 2)
    if len > 0 and vis > 0 then
        local ux, uy = (x2 - x1) / len, (y2 - y1) / len
        local d = (STEP - (phase + skip) % STEP) % STEP
        local n = 0
        while d <= vis and n < 400 do
            poolDot(pool, cx1 + ux * d, -(cy1 + uy * d), SIZE)
            d = d + STEP; n = n + 1
        end
    end
    return (phase + len) % STEP
end

local function updateWorldMap()
    if not mapPool then return end
    poolBegin(mapPool)
    local s = FG:NavStep()
    if FG.db.showLine and s and s.m and WorldMapFrame:IsShown() then
        local mapID = WorldMapFrame:GetMapID()
        local pos = mapID and C_Map.GetPlayerMapPosition(mapID, "player")
        local px, py
        if pos then px, py = pos:GetXY() end
        -- игрок не на открытой карте (например, смотришь другой город): пересчитываем
        -- его позицию в координаты открытой карты, даже если она за краем карты
        if not px or (px == 0 and py == 0) then
            local pm, x, y = FG:GetPlayerPos()
            if pm and x then px, py = FG:ConvertPos(pm, x, y, mapID) end
        end
        -- точки маршрута: с поворотами (полёты, записанные пути) или сразу к цели
        local pts = {}
        local route = FG.Travel and FG.Travel:Get(s)
        if route then for _, p in ipairs(route) do pts[#pts + 1] = p end else pts[1] = s end
        local canvas = WorldMapFrame:GetCanvas()
        local sc = WorldMapFrame.ScrollContainer
        if type(sc) ~= "table" then sc = nil end
        local cl, ct = canvas:GetLeft(), canvas:GetTop()
        local vl, vt = sc and sc:GetLeft(), sc and sc:GetTop()
        if px and not (px == 0 and py == 0) and type(cl) == "number" and type(vl) == "number" then
            if mapPool.host ~= sc then
                for _, d in ipairs(mapPool.dots) do d:Hide() end
                mapPool = newPool(sc)
            end
            local ce, ve = canvas:GetEffectiveScale(), sc:GetEffectiveScale()
            local k = ce / ve
            local w, h = canvas:GetWidth(), canvas:GetHeight()
            local W, H = sc:GetWidth(), sc:GetHeight()
            -- нормированные координаты карты -> пиксели видимого окна (y вниз)
            local function toView(nx, ny)
                return (cl + nx * w) * k - vl, vt - (ct - ny * h) * k
            end
            local ax, ay = toView(px, py)
            local phase = 0
            for i, p in ipairs(pts) do
                local tx, ty = FG:ConvertPos(p.m, p.x, p.y, mapID)
                if not tx then break end
                -- точки за краем карты не обрезаем: линию отсекает окно карты
                local bx, by = toView(tx, ty)
                phase = viewDots(mapPool, ax, ay, bx, by, W, H, phase)
                if p ~= s and i < #pts and bx >= 0 and bx <= W and by >= 0 and by <= H then
                    poolDot(mapPool, bx, -by, TURN) -- поворот
                end
                ax, ay = bx, by
            end
        end
    end
    poolEnd(mapPool)
end

---------------------------------------------------------------------------
-- Миникарта
---------------------------------------------------------------------------
local miniPool
-- Диаметр миникарты в ярдах для каждого уровня приближения
local outdoorSize = { [0] = 466 + 2 / 3, 400, 333 + 1 / 3, 266 + 2 / 3, 200, 133 + 1 / 3 }
local indoorSize = { [0] = 300, 240, 180, 120, 80, 50 }

local function updateMinimap()
    if not miniPool then return end
    poolBegin(miniPool)
    local s = FG:NavStep()
    if FG.db.showLine and s and s.m and Minimap:IsShown() then
        local dist, _, zone, east, north = FG.UI:Navigate(s)
        if dist and east and dist > 5 then
            local radiusPx = Minimap:GetWidth() / 2
            local radiusYards
            if C_Minimap and C_Minimap.GetViewRadius then
                radiusYards = C_Minimap.GetViewRadius() -- точный радиус от самой игры
            end
            if not radiusYards or radiusYards <= 0 then
                local zoom = Minimap:GetZoom() or 0
                -- так же определяют «в помещении» библиотеки карт (HereBeDragons)
                local outdoor = tonumber(GetCVar("minimapZoom")) == zoom
                radiusYards = ((outdoor and outdoorSize[zoom] or indoorSize[zoom]) or 466) / 2
            end
            local pxPerYard = radiusPx / radiusYards
            local x, y = east * pxPerYard, north * pxPerYard
            if GetCVar and GetCVar("rotateMinimap") == "1" then
                local f = GetPlayerFacing and GetPlayerFacing()
                if f then
                    local c, sn = math.cos(f), math.sin(f)
                    x, y = x * c + y * sn, -x * sn + y * c
                end
            end
            -- до края круга миникарты
            local len = math.sqrt(x * x + y * y)
            local maxLen = radiusPx - 6
            if len > maxLen then x, y = x / len * maxLen, y / len * maxLen end
            dashed(miniPool, 0, 0, x, y, 7, 3.5, 40)
        end
    end
    poolEnd(miniPool)
end

---------------------------------------------------------------------------
-- Запуск
---------------------------------------------------------------------------
FG:OnInit(function()
    if WorldMapFrame and WorldMapFrame.GetCanvas then
        local sc = WorldMapFrame.ScrollContainer
        mapPool = newPool(type(sc) == "table" and sc or WorldMapFrame:GetCanvas())
        local ticker = CreateFrame("Frame", nil, WorldMapFrame)
        local t = 0
        ticker:SetScript("OnUpdate", function(_, dt)
            t = t + dt
            if t < 0.1 then return end
            t = 0
            local ok, err = pcall(updateWorldMap)
            if not ok then poolHide(mapPool) end
        end)
    end
    if Minimap then
        miniPool = newPool(Minimap, (Minimap:GetFrameLevel() or 1) + 6)
        miniPool.anchor = "CENTER"
        local ticker = CreateFrame("Frame", nil, Minimap)
        local t = 0
        ticker:SetScript("OnUpdate", function(_, dt)
            t = t + dt
            if t < 0.05 then return end
            t = 0
            local ok = pcall(updateMinimap)
            if not ok then poolHide(miniPool) end
        end)
    end
end)

-- для отладки: /run QuestCompass.Route.Debug()
R.UpdateWorldMap, R.UpdateMinimap = updateWorldMap, updateMinimap
function R.Debug()
    local function count(p) local n = 0 if p then for _, d in ipairs(p.dots) do if d:IsShown() then n = n + 1 end end end return n end
    FG:Print(FG.L("dots", count(mapPool), count(miniPool)))
    return count(mapPool), count(miniPool)
end
