-- QuestCompass: лучшие вещи до рейдов (BiS) для класса игрока.
-- Списки: Icy Veins, WoW Classic pre-raid BiS (BiSData.lua). Где добыть — из базы Questie.
-- Окно — выдвижная правая часть меню (как список подземелий).
local _, ns = ...
local FG = ns.FG
local L = FG.L
local B = {}
FG.BiS = B

-- порядок ячеек и номера слотов персонажа
B.SLOTS = {
    { "head", 1 }, { "neck", 2 }, { "shoulder", 3 }, { "back", 15 }, { "chest", 5 }, { "wrist", 9 },
    { "hands", 10 }, { "waist", 6 }, { "legs", 7 }, { "feet", 8 }, { "ring1", 11, 12 }, { "ring2", 12, 11 },
    { "trinket1", 13, 14 }, { "trinket2", 14, 13 }, { "mh", 16 }, { "oh", 17 }, { "ranged", 18 },
}

local function DB() return (rawget(_G, "QuestCompassDataLib") or rawget(_G, "LibQuestieDB")) end
local function safe(fn, ...) if not fn then return end local ok, r = pcall(fn, ...) if ok then return r end end

-- В новых клиентах функции предметов переехали в C_Item; берём то, что есть
local function itemInfo(id)
    local f = (C_Item and C_Item.GetItemInfo) or rawget(_G, "GetItemInfo")
    if not f then return end
    local ok, name, _, quality = pcall(f, id)
    if ok then return name, quality end
end
local function itemIcon(id)
    local f = (C_Item and C_Item.GetItemIconByID) or rawget(_G, "GetItemIcon")
    if f then local ok, ic = pcall(f, id) if ok then return ic end end
end
local function qualityColor(q)
    if not q then return end
    local f = (C_Item and C_Item.GetItemQualityColor) or rawget(_G, "GetItemQualityColor")
    if f then local ok, r, g, b = pcall(f, q) if ok and r then return r, g, b end end
    local c = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q]
    if c then return c.r, c.g, c.b end
end

function B:Class()
    local _, cls = UnitClass("player")
    return cls
end

-- Специализация по талантам: где больше очков. Варианты: dps / heal
function B:AutoSpec(cls)
    local specs = QuestCompassBiS and QuestCompassBiS[cls]
    if not specs then return end
    if specs.dps and not specs.heal then return "dps" end
    if specs.heal and not specs.dps then return "heal" end
    local pts = {}
    for t = 1, 3 do
        local f = rawget(_G, "GetTalentTabInfo")
        local res = f and { pcall(f, t) } or { false }
        -- в классике очки — третье значение; в новых клиентах — пятое
        local p = 0
        if res[1] then p = (type(res[4]) == "number" and res[4]) or (type(res[6]) == "number" and res[6]) or 0 end
        pts[t] = tonumber(p) or 0
    end
    local best = 1
    for t = 2, 3 do if pts[t] > pts[best] then best = t end end
    if pts[best] == 0 then return "dps" end
    local healTab = ({ PRIEST = { [1] = true, [2] = true }, PALADIN = { [1] = true }, DRUID = { [3] = true }, SHAMAN = { [3] = true } })[cls] or {}
    return healTab[best] and "heal" or "dps"
end

function B:Spec()
    local cls = self:Class()
    local specs = QuestCompassBiS and QuestCompassBiS[cls] or {}
    local s = FG.cdb.bisSpec
    if s and specs[s] then return s end
    return self:AutoSpec(cls) or "dps"
end

-- название предмета на выбранном языке
function B:ItemName(id)
    local name, quality = itemInfo(id)
    local D = DB()
    local en = name or (D and safe(D.Item.name, id)) or ("#" .. id)
    -- название на языке аддона, а не клиента: EN — из базы Questie, RU — перевод
    en = FG:TrItem(id, en)
    return en, quality
end


-- где стоят сундуки/объекты: подземелье (ключ) и до 4 названий зон
local function objectWhere(D, od)
    local A = FG.Advisor
    local zones, seen, dkey = {}, {}, nil
    for _, oid in ipairs(od) do
        local sp = safe(D.Object.spawns, oid)
        if type(sp) == "table" then
            for area, pts in pairs(sp) do
                local k = A.areaToKey and A.areaToKey[area]
                local name
                if k then
                    dkey = dkey or k
                    local dg = A.dungeonByKey and A.dungeonByKey[k]
                    name = dg and A:DungeonName(dg) or k
                elseif C_Map and C_Map.GetAreaInfo then
                    local ok, an = pcall(C_Map.GetAreaInfo, area)
                    if ok and an then name = FG:TrZone(an) end
                end
                if name then
                    if not seen[name] then seen[name] = 0; zones[#zones + 1] = name end
                    seen[name] = seen[name] + (type(pts) == "table" and #pts or 1)
                end
            end
        end
    end
    table.sort(zones, function(a, b) if seen[a] ~= seen[b] then return seen[a] > seen[b] end return a < b end)
    local more = #zones > 4 and (#zones - 4) or 0
    while #zones > 4 do table.remove(zones) end
    return zones, more, dkey
end

-- где добыть: босс и подземелье, квест, продавец или «изготовление»
function B:Source(id)
    local D = DB()
    if not D then return "" end
    local A = FG.Advisor
    local drops = safe(D.Item.npcDrops, id) or {}
    if #drops > 0 then
        local n = drops[1]
        local npc = FG:TrNpc(n, safe(D.Npc.name, n)) or "?"
        local zone = safe(D.Npc.zoneID, n)
        local dkey = zone and A.areaToKey and A.areaToKey[zone]
        local where
        if dkey then
            local dg = A.dungeonByKey and A.dungeonByKey[dkey]
            where = dg and A:DungeonName(dg) or dkey
        elseif zone and C_Map and C_Map.GetAreaInfo then
            local ok, an = pcall(C_Map.GetAreaInfo, zone)
            if ok and an then where = FG:TrZone(an) end
        end
        local more = #drops > 1 and (" " .. L("bis_more", #drops - 1)) or ""
        return L("bis_drop", npc .. more) .. (where and (" — " .. where) or ""), dkey
    end
    local od = safe(D.Item.objectDrops, id) or {}
    if #od > 0 then
        local zones, more, dkey = objectWhere(D, od)
        local obj = FG:TrObject(od[1], safe(D.Object.name, od[1])) or "?"
        return L("bis_chest", obj) .. (#zones > 0 and (" — " .. table.concat(zones, ", ") .. (more > 0 and (" +" .. more) or "")) or ""), dkey
    end
    local qr = safe(D.Item.questRewards, id) or {}
    if #qr > 0 then
        local q = qr[1]
        local qn = FG:TrQuest(q) or safe(D.Quest.name, q) or ("#" .. q)
        return L("bis_quest", qn)
    end
    local v = safe(D.Item.vendors, id) or {}
    if #v > 0 then return L("bis_vendor", FG:TrNpc(v[1], safe(D.Npc.name, v[1])) or "?") end
    local c = B:Craft(id)
    if c then return B:CraftPick(QuestCompassCraft.PROF[c.prof]) .. " " .. c.skill .. " - " .. L("bis_craft") end
    return L("bis_world")
end

-- данные рецепта для изготавливаемой вещи
function B:Craft(id)
    local t = rawget(_G, "QuestCompassCraft")
    return t and t.ITEMS and t.ITEMS[id]
end
function B:CraftPick(pair)
    if not pair then return "" end
    return FG:Lang() == "ru" and (pair[2] or pair[1]) or pair[1]
end


---------------------------------------------------------------------------
-- Чары (наложение чар) для BiS-вещей
---------------------------------------------------------------------------
local ROLE_OF = {
    WARRIOR = { dps = "str" }, PALADIN = { dps = "str", heal = "heal" }, HUNTER = { dps = "hunter" },
    ROGUE = { dps = "agi" }, PRIEST = { dps = "caster", heal = "heal" }, SHAMAN = { dps = "str", heal = "heal" },
    MAGE = { dps = "caster" }, WARLOCK = { dps = "caster" }, DRUID = { dps = "agi", heal = "heal" },
}
local SLOT_INV = { back = 15, chest = 5, wrist = 9, hands = 10, feet = 8, mh = 16, oh = 17 }
function B:Role()
    local r = ROLE_OF[B:Class() or ""] or {}
    return r[B:Spec()] or r.dps or "str"
end
local function equipLoc(id)
    if not (C_Item and C_Item.GetItemInfoInstant) then return end
    local ok, _, _, _, loc = pcall(C_Item.GetItemInfoInstant, id)
    if ok then return loc end
end
-- рекомендуемые чары для слота (и вещи): ключ, данные
function B:EnchantFor(slot, itemId)
    local T = rawget(_G, "QuestCompassEnchant")
    if not T or not SLOT_INV[slot] then return end
    local role = B:Role()
    local key = T.ROLE[role] and T.ROLE[role][slot]
    local loc = itemId and equipLoc(itemId)
    if slot == "oh" then
        if loc == "INVTYPE_SHIELD" then key = "shieldsta"
        elseif loc == "INVTYPE_HOLDABLE" or loc == "INVTYPE_RANGED" then key = nil end
    end
    if slot == "mh" and role == "hunter" and loc and loc ~= "INVTYPE_2HWEAPON" then key = "crusader" end
    -- перчатки заклинателя: по школе
    if key == "glovefire" then
        local c = B:Class()
        if c == "WARLOCK" or c == "PRIEST" then key = "gloveshadow"
        elseif c == "MAGE" and FG.Talents and FG.Talents.Spec and safe(FG.Talents.Spec, FG.Talents) == 3 then key = "glovefrost" end
    end
    if not key then return end
    return key, T.E[key]
end
-- чары на надетой вещи в слоте: ID эффекта или 0
function B:SlotEnchant(slot)
    local inv = SLOT_INV[slot]
    local f = rawget(_G, "GetInventoryItemLink")
    local link = inv and f and safe(f, "player", inv)
    if type(link) ~= "string" then return nil end
    local e = link:match("item:%d+:(%-?%d*)")
    return tonumber(e) or 0
end
-- состояние: "ok" — наложены нужные, "other" — другие чары, "none" — без чар, nil — нет вещи/нельзя проверить
function B:EnchantState(slot, e)
    local cur = B:SlotEnchant(slot)
    if cur == nil then return nil end
    if cur == 0 then return "none" end
    if e and e.enchant and cur == e.enchant then return "ok" end
    return "other"
end
function B:EnchantName(e)
    if not e then return "" end
    -- режим EN: своё английское название (клиент может быть русским)
    if FG:Lang() ~= "ru" then return e.en end
    local n
    if C_Spell and C_Spell.GetSpellInfo then
        local i = safe(C_Spell.GetSpellInfo, e.spell)
        if type(i) == "table" then n = i.name end
    end
    if not n and rawget(_G, "GetSpellInfo") then n = safe(GetSpellInfo, e.spell) end
    if not n or n == "" then n = (FG:Lang() == "ru" and e.ru or e.en) end
    return n
end

-- надет ли предмет (кольца и аксессуары — в любом из двух слотов)
function B:Equipped(id, s1, s2)
    local f = rawget(_G, "GetInventoryItemID")
    local a = f and safe(f, "player", s1)
    local b = s2 and f and safe(f, "player", s2)
    return a == id or b == id
end

---------------------------------------------------------------------------
-- «Мой уровень»: лучшие вещи, которые можно надеть сейчас.
-- Кандидаты: награды за квесты (своя фракция и класс) и добыча с боссов подземелий.
-- Оценка — по характеристикам предмета (GetItemStats) с весами для роли.
---------------------------------------------------------------------------
local WEAPONS = { -- подклассы оружия, которыми владеет класс
    WARRIOR = { [0]=1, [1]=1, [2]=1, [3]=1, [4]=1, [5]=1, [6]=1, [7]=1, [8]=1, [10]=1, [13]=1, [15]=1, [16]=1, [18]=1 },
    PALADIN = { [0]=1, [1]=1, [4]=1, [5]=1, [6]=1, [7]=1, [8]=1 },
    HUNTER  = { [0]=1, [1]=1, [2]=1, [3]=1, [6]=1, [7]=1, [8]=1, [10]=1, [13]=1, [15]=1, [16]=1, [18]=1 },
    ROGUE   = { [2]=1, [3]=1, [4]=1, [7]=1, [13]=1, [15]=1, [16]=1, [18]=1 },
    PRIEST  = { [4]=1, [10]=1, [15]=1, [19]=1 },
    SHAMAN  = { [0]=1, [1]=1, [4]=1, [5]=1, [10]=1, [13]=1, [15]=1 },
    MAGE    = { [7]=1, [10]=1, [15]=1, [19]=1 },
    WARLOCK = { [7]=1, [10]=1, [15]=1, [19]=1 },
    DRUID   = { [4]=1, [5]=1, [10]=1, [13]=1, [15]=1 },
}
local SHIELD = { WARRIOR = true, PALADIN = true, SHAMAN = true }
local DUAL = { WARRIOR = true, ROGUE = true, HUNTER = true }
local function armorType(cls, lvl)
    if cls == "WARRIOR" or cls == "PALADIN" then return lvl >= 40 and 4 or 3 end
    if cls == "HUNTER" or cls == "SHAMAN" then return lvl >= 40 and 3 or 2 end
    if cls == "ROGUE" or cls == "DRUID" then return 2 end
    return 1
end
-- веса характеристик по роли
local W_STR = { ITEM_MOD_STRENGTH_SHORT = 1, ITEM_MOD_AGILITY_SHORT = 0.6, ITEM_MOD_STAMINA_SHORT = 0.3, ITEM_MOD_ATTACK_POWER_SHORT = 0.5,
    ITEM_MOD_CRIT_RATING_SHORT = 10, ITEM_MOD_HIT_RATING_SHORT = 10, ITEM_MOD_DAMAGE_PER_SECOND_SHORT = 3, RESISTANCE0_NAME = 0.01 }
local W_AGI = { ITEM_MOD_AGILITY_SHORT = 1, ITEM_MOD_STRENGTH_SHORT = 0.5, ITEM_MOD_STAMINA_SHORT = 0.3, ITEM_MOD_ATTACK_POWER_SHORT = 0.5,
    ITEM_MOD_CRIT_RATING_SHORT = 10, ITEM_MOD_HIT_RATING_SHORT = 10, ITEM_MOD_DAMAGE_PER_SECOND_SHORT = 3, RESISTANCE0_NAME = 0.01 }
local W_HUNT = { ITEM_MOD_AGILITY_SHORT = 1, ITEM_MOD_STRENGTH_SHORT = 0.1, ITEM_MOD_STAMINA_SHORT = 0.3, ITEM_MOD_INTELLECT_SHORT = 0.3,
    ITEM_MOD_ATTACK_POWER_SHORT = 0.4, ITEM_MOD_RANGED_ATTACK_POWER_SHORT = 0.5, ITEM_MOD_CRIT_RATING_SHORT = 10, ITEM_MOD_HIT_RATING_SHORT = 10,
    ITEM_MOD_DAMAGE_PER_SECOND_SHORT = 2, RESISTANCE0_NAME = 0.01 }
local W_CASTER = { ITEM_MOD_INTELLECT_SHORT = 1, ITEM_MOD_STAMINA_SHORT = 0.4, ITEM_MOD_SPIRIT_SHORT = 0.3, ITEM_MOD_SPELL_POWER_SHORT = 1.2,
    ITEM_MOD_SPELL_DAMAGE_DONE_SHORT = 1.2, ITEM_MOD_CRIT_RATING_SHORT = 8, ITEM_MOD_HIT_RATING_SHORT = 8, RESISTANCE0_NAME = 0.005 }
local W_HEAL = { ITEM_MOD_INTELLECT_SHORT = 1, ITEM_MOD_SPIRIT_SHORT = 0.6, ITEM_MOD_STAMINA_SHORT = 0.3, ITEM_MOD_SPELL_HEALING_DONE_SHORT = 1,
    ITEM_MOD_SPELL_POWER_SHORT = 0.8, ITEM_MOD_MANA_REGENERATION_SHORT = 2, RESISTANCE0_NAME = 0.005 }
local function weights(cls, spec)
    if spec == "heal" then return W_HEAL end
    if cls == "WARRIOR" or cls == "PALADIN" then return W_STR end
    if cls == "ROGUE" or cls == "DRUID" then return W_AGI end
    if cls == "HUNTER" then return W_HUNT end
    if cls == "SHAMAN" then return W_STR end
    return W_CASTER
end

local function getStats(id)
    local f = (C_Item and C_Item.GetItemStats) or rawget(_G, "GetItemStats")
    if not f then return end
    local ok, st = pcall(f, "item:" .. id)
    if ok and type(st) == "table" then return st end
end
local function equipLoc(id)
    local f = (C_Item and C_Item.GetItemInfoInstant) or rawget(_G, "GetItemInfoInstant")
    if not f then return end
    local ok, _, _, _, loc, _, classID, subID = pcall(f, id)
    if ok then return loc, classID, subID end
end
local function requestLoad(id)
    if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, id) end
end

local RACEBIT = { Human = 1, Orc = 2, Dwarf = 4, NightElf = 8, Scourge = 16, Undead = 16, Tauren = 32, Gnome = 64, Troll = 128 }
local CLASSBIT = { WARRIOR = 1, PALADIN = 2, HUNTER = 4, ROGUE = 8, PRIEST = 16, SHAMAN = 64, MAGE = 128, WARLOCK = 256, DRUID = 1024 }
local function hasBit(mask, bit) return not mask or mask == 0 or (math.floor(mask / bit) % 2) == 1 end

-- кандидаты для класса и уровня (кэш)
local poolCache = {}
local function candidates(cls, lvl)
    local key = cls .. lvl
    if poolCache[key] then return poolCache[key] end
    local D = DB()
    local A = FG.Advisor
    local out = {}
    if not D then return out end
    local _, race = UnitRace("player")
    local rbit, cbit = RACEBIT[race or ""], CLASSBIT[cls]
    local minL = math.max(1, lvl - 12)
    for _, id in ipairs(safe(D.Item.GetAllIds) or {}) do
        local c = safe(D.Item.class, id)
        if c == 2 or c == 4 then
            local rl = safe(D.Item.requiredLevel, id) or 0
            if rl <= lvl + 3 and rl >= minL then
                local ok = false
                for _, q in ipairs(safe(D.Item.questRewards, id) or {}) do
                    if hasBit(safe(D.Quest.requiredRaces, q), rbit or 0) and hasBit(safe(D.Quest.requiredClasses, q), cbit or 0) then ok = true break end
                end
                if not ok then
                    local drops = safe(D.Item.npcDrops, id) or {}
                    if #drops > 0 and #drops <= 6 then
                        for _, n in ipairs(drops) do
                            local z = safe(D.Npc.zoneID, n)
                            local dk = z and A.areaToKey and A.areaToKey[z]
                            local dg = dk and A.dungeonByKey and A.dungeonByKey[dk]
                            if dg and not dg.raid then ok = true break end
                        end
                    end
                end
                if ok then out[#out + 1] = id end
            end
        end
    end
    poolCache[key] = out
    return out
end

local LOCSLOT = {
    INVTYPE_HEAD = "head", INVTYPE_NECK = "neck", INVTYPE_SHOULDER = "shoulder", INVTYPE_CLOAK = "back", INVTYPE_CHEST = "chest",
    INVTYPE_ROBE = "chest", INVTYPE_WRIST = "wrist", INVTYPE_HAND = "hands", INVTYPE_WAIST = "waist", INVTYPE_LEGS = "legs",
    INVTYPE_FEET = "feet", INVTYPE_FINGER = "ring", INVTYPE_TRINKET = "trinket", INVTYPE_WEAPON = "weapon", INVTYPE_2HWEAPON = "2h",
    INVTYPE_WEAPONMAINHAND = "mh", INVTYPE_WEAPONOFFHAND = "ohw", INVTYPE_SHIELD = "shield", INVTYPE_HOLDABLE = "holdable",
    INVTYPE_RANGED = "ranged", INVTYPE_RANGEDRIGHT = "ranged", INVTYPE_THROWN = "ranged",
}

function B:Score(id, w)
    local st = getStats(id)
    if not st then return nil end
    local sc = 0
    for k, v in pairs(st) do if w[k] then sc = sc + w[k] * v end end
    return sc
end

-- лучшие вещи по ячейкам для текущего уровня; второе значение — сколько ещё не загрузилось
function B:LevelList(cls, spec)
    local lvl = UnitLevel("player") or 1
    local w = weights(cls, spec)
    local wantArmor = armorType(cls, lvl)
    local wpn = WEAPONS[cls] or {}
    local best, pending = {}, 0
    local function consider(slot, id, sc)
        best[slot] = best[slot] or {}
        local t = best[slot]
        t[#t + 1] = { id = id, sc = sc }
    end
    for _, id in ipairs(candidates(cls, lvl)) do
        local loc, classID, sub = equipLoc(id)
        local kind = loc and LOCSLOT[loc]
        if kind then
            local fits = true
            if classID == 4 and sub and sub >= 1 and sub <= 4 and kind ~= "back" then fits = (sub == wantArmor) end
            if classID == 4 and sub == 6 then fits = SHIELD[cls] and spec ~= "dps" or (cls == "PALADIN" and spec == "heal") or false end
            if classID == 2 then fits = wpn[sub] and true or false end
            if kind == "ranged" and sub == 19 then fits = wpn[19] and true or false end
            if kind == "holdable" then fits = (w == W_CASTER or w == W_HEAL) end
            if kind == "ohw" then fits = DUAL[cls] and spec == "dps" end
            if fits then
                local sc = B:Score(id, w)
                if sc then consider(kind, id, sc) else pending = pending + 1; requestLoad(id) end
            end
        end
    end
    -- что надето сейчас (номер и оценка)
    local invF = rawget(_G, "GetInventoryItemID")
    local equipped, eqScore = {}, {}
    for _, inv in ipairs({ 1, 2, 3, 15, 5, 9, 10, 6, 7, 8, 11, 12, 13, 14, 16, 17, 18 }) do
        local eid = invF and safe(invF, "player", inv)
        if eid then equipped[eid] = true; eqScore[inv] = B:Score(eid, w) or 0 end
    end
    local function top(kind, n)
        local t = best[kind] or {}
        table.sort(t, function(a, b) return a.sc > b.sc end)
        local r = {}
        for _, e in ipairs(t) do
            if not equipped[e.id] then r[#r + 1] = e end -- надетое не предлагаем
            if #r >= (n or 1) then break end
        end
        return r
    end
    local list, info = {}, {}
    -- предлагаем вещь, только если она лучше надетой; иначе показываем надетое
    local function pick(slot, cand, inv)
        local cur = eqScore[inv] or -1
        if cand and cand.sc > cur + 0.5 then list[slot] = cand.id; info[slot] = { up = true }
        else
            local eid = invF and safe(invF, "player", inv)
            if eid then list[slot] = eid; info[slot] = { up = false } end
        end
    end
    local INV = { head = 1, neck = 2, shoulder = 3, back = 15, chest = 5, wrist = 9, hands = 10, waist = 6, legs = 7, feet = 8 }
    for k, inv in pairs(INV) do pick(k, top(k)[1], inv) end
    -- кольца и аксессуары: сравниваем с более слабым из двух надетых
    local function pair(kind, s1, s2, i1, i2)
        local c = top(kind, 2)
        local weak, strong = i1, i2
        if (eqScore[i1] or -1) > (eqScore[i2] or -1) then weak, strong = i2, i1 end
        pick(s1, c[1], weak)
        if info[s1] and info[s1].up then pick(s2, c[2], strong) else pick(s2, nil, strong) end
    end
    pair("ring", "ring1", "ring2", 11, 12)
    pair("trinket", "trinket1", "trinket2", 13, 14)
    -- оружие: двуручное или одноручное + левая рука
    local two, one, mh = top("2h")[1], top("weapon", 2), top("mh")[1]
    local oneBest = one[1]
    if mh and (not oneBest or mh.sc > oneBest.sc) then oneBest = mh end
    local off
    if DUAL[cls] and spec == "dps" then
        off = top("ohw")[1]
        local second = one[1] == oneBest and one[2] or one[1]
        if second and (not off or second.sc > off.sc) then off = second end
    else
        local sh, hold = top("shield")[1], top("holdable")[1]
        off = sh
        if hold and (not off or hold.sc > off.sc) then off = hold end
    end
    local both = (oneBest and oneBest.sc or 0) + (off and off.sc or 0)
    local curW = (eqScore[16] or 0) + (eqScore[17] or 0)
    if two and two.sc >= both then
        if two.sc > curW + 0.5 then list.mh = two.id; info.mh = { up = true } else pick("mh", nil, 16); pick("oh", nil, 17) end
    else
        pick("mh", oneBest, 16); pick("oh", off, 17)
    end
    pick("ranged", top("ranged")[1], 18)
    return list, pending, info
end

---------------------------------------------------------------------------
-- Окно
---------------------------------------------------------------------------
local panel
local ROW_H, ROWS = 38, 17
local S

local function refresh()
    if not panel or not panel:IsVisible() then return end
    local cls = B:Class()
    local specs = QuestCompassBiS and QuestCompassBiS[cls]
    local spec = B:Spec()
    local mode = FG.cdb.bisMode or "raid"
    local list, pending, info = specs and specs[spec] or {}, 0, nil
    if mode == "level" then list, pending, info = B:LevelList(cls, spec) end
    if panel.mode then panel.mode:Refresh() end
    panel.note:SetText(L(mode == "level" and "bis_note_level" or "bis_note", UnitLevel("player") or 1))
    if pending > 0 then panel.note:SetText(L("bis_loading", pending)) end
    local cname = L("class_" .. tostring(cls))
    panel.title:SetText(mode == "level" and L("bis_title_lvl", cname, UnitLevel("player") or 1) or L("bis_title", cname))
    if panel.spec then panel.spec:Refresh() end
    -- какие ячейки есть у этого класса
    local items = {}
    for _, sl in ipairs(B.SLOTS) do
        local id = list[sl[1]]
        if id then items[#items + 1] = { slot = sl[1], id = id, s1 = sl[2], s2 = sl[3] } end
    end
    local h = panel:GetHeight() or 0
    local vis = (type(h) == "number" and h > 0) and math.max(4, math.min(ROWS, math.floor((h - 102 - 30) / ROW_H))) or 12
    panel.offset = math.max(0, math.min(panel.offset or 0, #items - vis))
    if panel.sb then
        panel.sb:ClearAllPoints()
        panel.sb:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -3, -98)
        panel.sb:SetHeight(vis * ROW_H - 4)
        panel.sb:Update(panel.offset, #items, vis)
    end
    local have = 0
    for _, it in ipairs(items) do if B:Equipped(it.id, it.s1, it.s2) then have = have + 1 end end
    -- заранее просим игру загрузить все предметы списка (для подсказок)
    if C_Item and C_Item.RequestLoadItemDataByID then
        B.preloaded = B.preloaded or {}
        for _, it in ipairs(items) do
            if not B.preloaded[it.id] then B.preloaded[it.id] = true; pcall(C_Item.RequestLoadItemDataByID, it.id) end
        end
    end
    local eNeed, eOk = 0, 0
    for _, it in ipairs(items) do
        local _, e = B:EnchantFor(it.slot, it.id)
        if e then eNeed = eNeed + 1; if B:EnchantState(it.slot, e) == "ok" then eOk = eOk + 1 end end
    end
    panel.count:SetText(L("bis_have", have, #items) .. (eNeed > 0 and ("   |cffb88fff" .. L("bis_ench_count", eOk, eNeed) .. "|r") or ""))
    for i = 1, ROWS do
        local row = panel.rows[i]
        local it = i <= vis and items[i + panel.offset]
        if it then
            row.item = it
            local name, q = B:ItemName(it.id)
            local r, g, b = qualityColor(q)
            if not r then r, g, b = 0.64, 0.21, 0.93 end -- эпик по умолчанию, пока игра не загрузила предмет
            row.name:SetText(name); row.name:SetTextColor(r, g, b)
            row.slot:SetText(L("slot_" .. it.slot))
            local src, dkey = B:Source(it.id)
            row.dkey = dkey
            local inf = info and info[it.slot]
            if inf and not inf.up then
                src = "|cff8a909a" .. L("bis_have_best") .. "|r"
                row.name:SetTextColor(0.6, 0.6, 0.6)
            elseif inf then
                local D = DB()
                local rl = D and safe(D.Item.requiredLevel, it.id) or 0
                if rl > (UnitLevel("player") or 1) then src = "|cffff9a40" .. L("bis_from_lvl", rl) .. "|r  " .. src end
            end
            row.src:SetText(src)
            local icon = itemIcon(it.id)
            row.icon:SetTexture(icon or "Interface\\Icons\\INV_Misc_QuestionMark")
            local _, e = B:EnchantFor(it.slot, it.id)
            if e then
                local st = B:EnchantState(it.slot, e)
                row.ench:Show()
                row.ench:SetDesaturated(st ~= "ok")
                row.ench:SetAlpha(st == "ok" and 1 or (st == "other" and 0.8 or 0.45))
            else
                row.ench:Hide()
            end
            if B:Equipped(it.id, it.s1, it.s2) then row.check:Show(); row.icon:SetDesaturated(false)
            else row.check:Hide() end
            row:Show()
        else
            row:Hide()
        end
    end
end
B.Refresh = refresh

local function create(parent)
    S = FG.Style
    local W = FG.PAGE_W
    -- страница «BiS» внутри меню (вкладка)
    panel = CreateFrame("Frame", "QuestCompassBiSPage", parent)
    panel:SetAllPoints(parent)
    panel.offset, panel.sb = 0, false
    panel:HookScript("OnShow", function() panel.offset = 0; refresh() end)
    panel:HookScript("OnHide", function() if B.detail then B.detail:Hide() end end)
    local title = S:Text(panel, "title", S.c.accent)
    title:SetPoint("TOPLEFT", 16, -14)
    panel.title = title
    -- выбор специализации (если у класса их две)
    local cls = B:Class()
    local specs = QuestCompassBiS and QuestCompassBiS[cls] or {}
    -- сверху: «до рейдов» или «мой уровень»
    local mseg = S:Segmented(panel, { { "raid", "bis_mode_raid" }, { "level", "bis_mode_level" } }, 176, 22,
        function() return FG.cdb.bisMode or "raid" end,
        function(v) FG.cdb.bisMode = v; panel.offset = 0; refresh() end)
    mseg:SetPoint("TOPLEFT", 16, -46)
    panel.mode = mseg
    if specs.dps and specs.heal then
        local seg = S:Segmented(panel, { { "dps", "bis_dps" }, { "heal", "bis_heal" } }, 146, 22,
            function() return B:Spec() end,
            function(v) FG.cdb.bisSpec = v; refresh() end)
        seg:SetPoint("TOPRIGHT", -16, -46)
        panel.spec = seg
    end
    panel.count = S:Text(panel, "small", S.c.muted)
    panel.count:SetPoint("TOPRIGHT", -18, -76)
    local sep = S.Tex(panel, "ARTWORK", S.c.border)
    sep:SetHeight(1); sep:SetPoint("TOPLEFT", 16, -92); sep:SetPoint("TOPRIGHT", -16, -92)
    -- источник списков
    local note = S:Text(panel, "small", S.c.muted)
    note:SetPoint("BOTTOMLEFT", 16, 12); note:SetPoint("BOTTOMRIGHT", -16, 12); note:SetJustifyH("LEFT")
    panel.note = note
    panel.rows = {}
    for i = 1, ROWS do
        local row = CreateFrame("Button", nil, panel)
        row:SetSize(W - 30, ROW_H - 2)
        row:SetPoint("TOPLEFT", 12, -98 - (i - 1) * ROW_H)
        row.hl = S:GoldBar(row, 0.3); row.hl:Hide()
        row.icon = row:CreateTexture(nil, "ARTWORK")
        row.icon:SetSize(30, 30); row.icon:SetPoint("LEFT", 4, 0)
        row.check = row:CreateTexture(nil, "OVERLAY")
        row.check:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready")
        row.check:SetSize(16, 16); row.check:SetPoint("BOTTOMRIGHT", row.icon, "BOTTOMRIGHT", 4, -4)
        row.check:Hide()
        row:Hide()
        row.slot = S:Text(row, "small", S.c.muted)
        row.slot:SetPoint("TOPRIGHT", -6, -3); row.slot:SetJustifyH("RIGHT")
        row.name = S:Text(row, "label", S.c.text)
        row.name:SetPoint("TOPLEFT", row.icon, "TOPRIGHT", 8, 1)
        row.name:SetPoint("RIGHT", row.slot, "LEFT", -6, 0)
        row.name:SetJustifyH("LEFT"); row.name:SetWordWrap(false)
        row.src = S:Text(row, "small", S.c.muted)
        row.src:SetPoint("BOTTOMLEFT", row.icon, "BOTTOMRIGHT", 8, -1)
        row.src:SetPoint("RIGHT", -26, 0)
        row.src:SetJustifyH("LEFT"); row.src:SetWordWrap(false)
        -- значок чар: цветной — нужные чары наложены, серый — нет
        row.ench = row:CreateTexture(nil, "OVERLAY")
        row.ench:SetSize(16, 16); row.ench:SetPoint("BOTTOMRIGHT", -6, 2)
        row.ench:SetTexture("Interface\\Icons\\Trade_Engraving")
        row.ench:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        row.ench:Hide()
        row:SetScript("OnEnter", function(self)
            self.hl:Show()
            -- предмет ещё не загружен игрой — просим загрузить, подсказка обновится сама
            if self.item and not itemInfo(self.item.id) then
                if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, self.item.id) end
                B.tipRow = self
            end
            if self.item then
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                if itemInfo(self.item.id) and GameTooltip.SetItemByID then
                    GameTooltip:SetItemByID(self.item.id)
                else
                    -- игра не дала данные о предмете (ещё грузит или его нет в этой версии) — своя подсказка из базы
                    local nm, q = B:ItemName(self.item.id)
                    local r, g, b = qualityColor(q)
                    GameTooltip:SetText(nm or "?", r or 0.64, g or 0.21, b or 0.93)
                    GameTooltip:AddLine(L("slot_" .. self.item.slot), 1, 1, 1)
                    local D = DB()
                    local il = D and safe(D.Item.itemLevel, self.item.id)
                    local rl = D and safe(D.Item.requiredLevel, self.item.id)
                    if il and il > 0 then GameTooltip:AddLine(L("bis_ilvl", il), 1, 0.82, 0) end
                    if rl and rl > 0 then GameTooltip:AddLine(L("bis_rlvl", rl), 1, 1, 1) end
                    GameTooltip:AddLine((B:Source(self.item.id)), 0.8, 0.8, 0.8, true)
                    GameTooltip:AddLine(L("bis_noinfo"), 0.6, 0.6, 0.6, true)
                end
                local _, e = B:EnchantFor(self.item.slot, self.item.id)
                if e then
                    GameTooltip:AddLine(" ")
                    GameTooltip:AddLine(L("bis_ench") .. " " .. B:EnchantName(e), 0.72, 0.56, 1)
                    GameTooltip:AddLine(FG:Lang() == "ru" and e.fx[2] or e.fx[1], 0.85, 0.85, 0.85, true)
                    local st = B:EnchantState(self.item.slot, e)
                    if st then GameTooltip:AddLine(L("bis_ench_" .. st), st == "ok" and 0.4 or 1, st == "ok" and 0.88 or 0.6, st == "ok" and 0.48 or 0.3) end
                end
                GameTooltip:AddLine(L("bis_click"), 0.4, 0.88, 0.48, true)
                GameTooltip:Show()
            end
        end)
        row:SetScript("OnLeave", function(self) self.hl:Hide(); GameTooltip:Hide(); if B.tipRow == self then B.tipRow = nil end end)
        -- клик: включить режим этого подземелья
        -- клик: окно предмета — где выбить, с кого, модель
        row:SetScript("OnClick", function(self)
            if self.item then B:ShowItem(self.item.id, self.item.slot) end
        end)
        panel.rows[i] = row
    end
    panel:EnableMouseWheel(true)
    panel:SetScript("OnMouseWheel", function(_, delta)
        panel.offset = (panel.offset or 0) - delta * 2
        refresh()
    end)
    panel.sb = S:ScrollBar(panel, function(off) panel.offset = off; refresh() end)
    panel:SetScript("OnSizeChanged", function() refresh() end)
    FG:OnLanguageChanged(refresh)
end

---------------------------------------------------------------------------
-- Окно предмета: где выбить, с кого, модель босса (или NPC квеста/продавца)
---------------------------------------------------------------------------
function B:SourceDetail(id)
    local D = DB()
    local A = FG.Advisor
    local d = { kind = "craft" }
    if not D then return d end
    local function npcName(n) return FG:TrNpc(n, safe(D.Npc.name, n)) or ("#" .. n) end
    local function zoneOf(n)
        local zone = safe(D.Npc.zoneID, n)
        local dkey = zone and A.areaToKey and A.areaToKey[zone]
        if dkey then
            local dg = A.dungeonByKey and A.dungeonByKey[dkey]
            return dg and A:DungeonName(dg) or dkey, dkey
        end
        if zone and C_Map and C_Map.GetAreaInfo then
            local ok, an = pcall(C_Map.GetAreaInfo, zone)
            if ok and an then return FG:TrZone(an) end
        end
    end
    local drops = safe(D.Item.npcDrops, id) or {}
    if #drops > 0 then
        d.kind = "drop"
        d.npc = drops[1]; d.npcName = npcName(drops[1])
        d.where, d.dkey = zoneOf(drops[1])
        d.others = {}
        for i = 2, math.min(#drops, 6) do d.others[#d.others + 1] = npcName(drops[i]) end
        if #drops > 6 then d.others[#d.others + 1] = L("bis_more", #drops - 6) end
        return d
    end
    local qr = safe(D.Item.questRewards, id) or {}
    if #qr > 0 then
        d.kind = "quest"
        local q = qr[1]
        d.quest = FG:TrQuest(q) or safe(D.Quest.name, q) or ("#" .. q)
        local st = safe(D.Quest.startedBy, q) or {}
        local n = st[1] and st[1][1]
        if n then d.npc = n; d.npcName = npcName(n); d.where, d.dkey = zoneOf(n) end
        return d
    end
    local v = safe(D.Item.vendors, id) or {}
    if #v > 0 then
        d.kind = "vendor"
        d.npc = v[1]; d.npcName = npcName(v[1]); d.where = zoneOf(v[1])
        return d
    end
    local od = safe(D.Item.objectDrops, id) or {}
    if #od > 0 then
        d.kind = "object"; d.npcName = FG:TrObject(od[1], safe(D.Object.name, od[1]))
        d.zones, d.zonesMore, d.dkey = objectWhere(D, od)
        if d.dkey then
            local dg = A.dungeonByKey and A.dungeonByKey[d.dkey]
            d.where = dg and A:DungeonName(dg) or d.dkey
        end
        return d
    end
    local c = B:Craft(id)
    if not c then d.kind = "world"; return d end
    local CT = QuestCompassCraft
    local G, W, M, OK = "|cffffd100", "|cffe6e6e6", "|cff9aa0a8", "|cff5ee07a"
    local out = {}
    out[#out + 1] = G .. L("bis_cr_prof") .. "|r " .. W .. B:CraftPick(CT.PROF[c.prof]) .. " (" .. c.skill .. ")|r"
    if c.spec then out[#out + 1] = G .. L("bis_cr_spec") .. "|r " .. W .. B:CraftPick(CT.SPEC[c.spec]) .. "|r" end
    if c.rep then out[#out + 1] = G .. L("bis_cr_rep") .. "|r " .. W .. B:CraftPick(CT.REP[c.rep]) .. " — " .. B:CraftPick(CT.STAND[c.stand]) .. "|r" end
    -- откуда рецепт
    local r = c.recipe or {}
    local names = {}
    for i, n in ipairs(r.npcs or {}) do if i <= 4 then names[#names + 1] = npcName(n) end end
    local rtxt
    if r.kind == "vendor" then
        local wz = r.npcs and r.npcs[1] and zoneOf(r.npcs[1])
        rtxt = L("bis_cr_sold", table.concat(names, " / ")) .. (wz and (", " .. wz) or "")
        if r.limited then rtxt = rtxt .. " (" .. L("bis_cr_limited") .. ")" end
    elseif r.kind == "cache" then
        rtxt = L("bis_cr_cache") .. "; " .. L("bis_cr_drop", table.concat(names, ", "))
    elseif r.kind == "trainer" then
        rtxt = L("bis_cr_trainer")
    else
        local parts = {}
        for i, n in ipairs(r.npcs or {}) do
            if i <= 4 then
                local wz = zoneOf(n)
                parts[#parts + 1] = names[i] .. (wz and (" (" .. wz .. ")") or "")
            end
        end
        if r.text then parts[#parts + 1] = B:CraftPick(r.text) end
        rtxt = L("bis_cr_drop", table.concat(parts, ", "))
        -- первый босс с подземельем — для кнопки «перейти»
        for _, n in ipairs(r.npcs or {}) do
            local _, dk = zoneOf(n)
            if dk then d.dkey = dk; break end
        end
    end
    out[#out + 1] = G .. L("bis_cr_recipe") .. "|r " .. W .. rtxt .. "|r"
    -- материалы: иконка, имя, сколько есть / сколько нужно
    out[#out + 1] = G .. L("bis_cr_mats") .. "|r"
    local cnt = rawget(_G, "GetItemCount")
    for _, m in ipairs(c.mats or {}) do
        local mid, need = m[1], m[2]
        local nm
        if mid and mid > 0 then nm = FG:TrItem(mid, FG:EnName("Item", mid) or m[3]) or m[3] or ("#" .. mid)
        else nm = FG:Lang() == "ru" and (m[4] or m[3]) or m[3] end
        local have = (mid and mid > 0 and cnt) and select(2, pcall(cnt, mid, true)) or nil
        if type(have) ~= "number" then have = nil end
        local ic = (mid and mid > 0) and itemIcon(mid)
        local icon = ic and ("|T" .. ic .. ":14:14|t ") or "  "
        local num
        if have then num = ((have >= need) and OK or M) .. have .. "/" .. need .. "|r" else num = M .. need .. "x|r" end
        out[#out + 1] = "  " .. icon .. num .. " " .. W .. (nm or "?") .. "|r"
    end
    out[#out + 1] = M .. L("bis_cr_ah") .. "|r"
    d.kind = "craft"
    d.craftLines = out
    return d
end

local function createDetail()
    -- правая часть самого меню (одна общая рамка), а не отдельное окно
    if not rawget(_G, "QuestCompassMenu") and FG.Menu.EnsureMenu then FG.Menu:EnsureMenu() end
    local f = FG.Menu:MakeDrawer(330, "QuestCompassBiSItem")
    f.icon = f:CreateTexture(nil, "ARTWORK")
    f.icon:SetSize(32, 32); f.icon:SetPoint("TOPLEFT", 14, -14)
    f.name = S:NoInk(S:Text(f, "label", S.c.text))
    -- справа в шапке — переключатель языка и крестик меню
    f.name:SetPoint("TOPLEFT", f.icon, "TOPRIGHT", 8, 0); f.name:SetPoint("RIGHT", f, "RIGHT", -112, 0)
    f.name:SetJustifyH("LEFT")
    f.slot = S:NoInk(S:Text(f, "small", S.c.muted)); f.slot:SetTextColor(0.75, 0.72, 0.66)
    f.slot:SetPoint("BOTTOMLEFT", f.icon, "BOTTOMRIGHT", 8, 0)
    -- модель: босс / NPC; для изготовления — персонаж в этой вещи. Вращается мышью.
    local mbg = f:CreateTexture(nil, "BACKGROUND", nil, 1)
    mbg:SetColorTexture(0, 0, 0, 0.5)
    mbg:SetPoint("TOPLEFT", 12, -56); mbg:SetPoint("TOPRIGHT", -12, -56); mbg:SetHeight(250)
    f.mbg = mbg
    local m = CreateFrame("DressUpModel", nil, f)
    m:SetPoint("TOPLEFT", mbg, "TOPLEFT", 2, -2); m:SetPoint("BOTTOMRIGHT", mbg, "BOTTOMRIGHT", -2, 2)
    m:EnableMouse(true)
    m:SetScript("OnMouseDown", function(self) self.dragX = GetCursorPosition() end)
    m:SetScript("OnMouseUp", function(self) self.dragX = nil end)
    m:SetScript("OnUpdate", function(self)
        if not self.dragX then return end
        local x = GetCursorPosition()
        self.facing = (self.facing or 0) + (x - self.dragX) * 0.02
        self.dragX = x
        pcall(self.SetFacing, self, self.facing)
    end)
    f.model = m
    f.noModel = S:Text(f, "small", S.c.muted)
    f.noModel:SetPoint("CENTER", mbg, "CENTER")
    f.info = S:Text(f, "label", S.c.text)
    f.info:SetPoint("TOPLEFT", mbg, "BOTTOMLEFT", 2, -10); f.info:SetPoint("RIGHT", -14, 0)
    f.info:SetJustifyH("LEFT"); f.info:SetSpacing(3)
    f.go = S:Button(f, "bis_go", 272, 24, function()
        if f.dkey and FG.Advisor.dungeonByKey and FG.Advisor.dungeonByKey[f.dkey] then
            FG.Advisor:SetDungeon(f.dkey)
            if FG.Menu.Sync then FG.Menu:Sync() end
        end
    end, { font = "label" })
    f.go:SetPoint("BOTTOM", 0, 14)
    f:Hide()
    return f
end

function B:ShowItem(id, slot)
    if not B.detail then B.detail = createDetail() end
    local f = B.detail
    if f:IsShown() and f.itemId == id and f.itemSlot == slot then f:Hide() return end
    f.itemId, f.itemSlot = id, slot
    local name, q = B:ItemName(id)
    local r, g, b = qualityColor(q)
    f.name:SetText(name); f.name:SetTextColor(r or 0.64, g or 0.21, b or 0.93)
    f.slot:SetText(slot and L("slot_" .. slot) or "")
    f.icon:SetTexture(itemIcon(id) or "Interface\\Icons\\INV_Misc_QuestionMark")
    local d = B:SourceDetail(id)
    local G, W, M = "|cffffd100", "|cffe6e6e6", "|cff9aa0a8"
    local lines = {}
    if d.kind == "drop" then
        if d.where then lines[#lines + 1] = G .. L("bis_where") .. "|r " .. W .. d.where .. "|r" end
        lines[#lines + 1] = G .. L("bis_boss") .. "|r " .. W .. d.npcName .. "|r"
        if d.others and #d.others > 0 then lines[#lines + 1] = M .. L("bis_also", table.concat(d.others, ", ")) .. "|r" end
    elseif d.kind == "quest" then
        lines[#lines + 1] = G .. L("bis_questq") .. "|r " .. W .. d.quest .. "|r"
        if d.npcName then lines[#lines + 1] = G .. L("qd_take") .. "|r " .. W .. d.npcName .. (d.where and (", " .. d.where) or "") .. "|r" end
    elseif d.kind == "vendor" then
        lines[#lines + 1] = G .. L("bis_seller") .. "|r " .. W .. d.npcName .. (d.where and (", " .. d.where) or "") .. "|r"
    elseif d.kind == "object" then
        lines[#lines + 1] = G .. L("bis_chest_from") .. "|r " .. W .. (d.npcName or "?") .. "|r"
        if d.zones and #d.zones > 0 then
            lines[#lines + 1] = G .. L("bis_where") .. "|r " .. W .. table.concat(d.zones, ", ") .. (d.zonesMore and d.zonesMore > 0 and (" " .. L("bis_more", d.zonesMore)) or "") .. "|r"
        end
        lines[#lines + 1] = M .. L("bis_chest_hint") .. "|r"
    elseif d.kind == "craft" and d.craftLines then
        for _, l in ipairs(d.craftLines) do lines[#lines + 1] = l end
    else
        lines[#lines + 1] = M .. L("bis_world_long") .. "|r"
    end
    -- чары для этого слота
    local _, e = B:EnchantFor(slot, id)
    local hasEnch = false
    if e then
        hasEnch = true
        local P = "|cffb88fff"
        lines[#lines + 1] = ""
        lines[#lines + 1] = P .. L("bis_ench") .. "|r " .. W .. B:EnchantName(e) .. "|r " .. M .. "(" .. (FG:Lang() == "ru" and e.fx[2] or e.fx[1]) .. ")|r"
        lines[#lines + 1] = M .. L("bis_ench_skill", e.skill) .. " - " .. (FG:Lang() == "ru" and e.src[2] or e.src[1]) .. "|r"
        local mt = {}
        local cnt = rawget(_G, "GetItemCount")
        for _, m in ipairs(e.mats or {}) do
            local nm = FG:TrItem(m[1], FG:EnName("Item", m[1])) or FG:EnName("Item", m[1]) or ("#" .. m[1])
            local ic = itemIcon(m[1])
            local have = cnt and safe(cnt, m[1], true)
            local hv = (type(have) == "number") and ((have >= m[2] and "|cff66e07a" or "|cff9aa0a8") .. have .. "/" .. m[2] .. "|r") or (m[2] .. "x")
            mt[#mt + 1] = "  " .. (ic and ("|T" .. ic .. ":14:14|t ") or "") .. hv .. " " .. W .. nm .. "|r"
        end
        for _, l in ipairs(mt) do lines[#lines + 1] = l end
        local st = B:EnchantState(slot, e)
        if st then lines[#lines + 1] = (st == "ok" and "|cff66e07a" or "|cffff9a40") .. L("bis_ench_" .. st) .. "|r" end
    end
    -- для рецептов модель ниже, чтобы влез список материалов
    local mh = (d.kind == "craft" or hasEnch) and 220 or 250
    if d.kind == "craft" and hasEnch then mh = 200 end
    f.mbg:SetHeight(mh)
    f.info:SetText(table.concat(lines, "\n"))
    local ih = (f.info.GetStringHeight and f.info:GetStringHeight()) or 0
    -- модель
    local m = f.model
    m.facing = 0
    local shown = false
    if d.npc then
        if m.ClearModel then pcall(m.ClearModel, m) end
        shown = pcall(m.SetCreature, m, d.npc)
    end
    if not shown then
        -- изготовление/объект: персонаж, примеривший вещь
        local ok = pcall(m.SetUnit, m, "player")
        if ok then pcall(m.Undress, m); pcall(m.TryOn, m, "item:" .. id) end
        shown = ok
    end
    -- вся фигура целиком: камера чуть дальше, без приближения к лицу
    if m.SetPortraitZoom then pcall(m.SetPortraitZoom, m, 0) end
    if m.SetCamDistanceScale then pcall(m.SetCamDistanceScale, m, d.npc and 1 or 1.35) end
    if m.SetPosition then pcall(m.SetPosition, m, 0, 0, 0) end
    pcall(m.SetFacing, m, 0)
    if shown then f.noModel:SetText("") else f.noModel:SetText(L("bis_nomodel")) end
    f.dkey = d.dkey
    if d.dkey then f.go:Show() else f.go:Hide() end
    f:Show()
end

---------------------------------------------------------------------------
-- BiS-вещи, которые падают в подземелье (для входа в подземелье и шапки панели)
---------------------------------------------------------------------------
local dgCache, dgCacheT = {}, 0
function B:DungeonItems(dkey)
    if not dkey then return {} end
    local now = GetTime and GetTime() or 0
    if now - dgCacheT > 10 then dgCache, dgCacheT = {}, now end
    if dgCache[dkey] then return dgCache[dkey] end
    local D = DB()
    local A = FG.Advisor
    local out, seen = {}, {}
    if not D then return out end
    local cls, spec = B:Class(), B:Spec()
    local function add(id, kind)
        if not id or seen[id] then return end
        local hit = {}
        for _, n in ipairs(safe(D.Item.npcDrops, id) or {}) do
            local z = safe(D.Npc.zoneID, n)
            if z and A.areaToKey and A.areaToKey[z] == dkey then hit[#hit + 1] = FG:TrNpc(n, safe(D.Npc.name, n)) end
        end
        if #hit > 0 then
            seen[id] = true
            out[#out + 1] = { id = id, boss = table.concat(hit, ", ", 1, math.min(#hit, 3)), kind = kind }
        end
    end
    local pre = QuestCompassBiS and QuestCompassBiS[cls] and QuestCompassBiS[cls][spec] or {}
    for _, sl in ipairs(B.SLOTS) do add(pre[sl[1]], "raid") end
    local ok, lvl, _, info = pcall(B.LevelList, B, cls, spec)
    if ok and type(lvl) == "table" then
        for _, sl in ipairs(B.SLOTS) do
            local inf = info and info[sl[1]]
            if inf and inf.up then add(lvl[sl[1]], "level") end
        end
    end
    -- надетое не показываем
    local f = rawget(_G, "GetInventoryItemID")
    if f then
        local worn = {}
        for i = 1, 18 do local e = safe(f, "player", i) if e then worn[e] = true end end
        for i = #out, 1, -1 do if worn[out[i].id] then table.remove(out, i) end end
    end
    dgCache[dkey] = out
    return out
end

-- строки для подсказки/чата: «[предмет] — босс»
function B:DungeonLines(dkey, links)
    local lines = {}
    for _, it in ipairs(B:DungeonItems(dkey)) do
        local name, q = B:ItemName(it.id)
        local r, g, b = qualityColor(q)
        local txt
        local f = (C_Item and C_Item.GetItemInfo) or rawget(_G, "GetItemInfo")
        local link
        if links and f then local ok, _, lnk = pcall(f, it.id) if ok then link = lnk end end
        if links and type(link) == "string" and link:find("|H") then txt = link
        else txt = string.format("|cff%02x%02x%02x%s|r", (r or 0.64) * 255, (g or 0.21) * 255, (b or 0.93) * 255, name) end
        local tag = it.kind == "level" and (" |cffff9a40" .. L("bis_tag_level") .. "|r") or ""
        lines[#lines + 1] = txt .. " |cff9aa0a8— " .. it.boss .. "|r" .. tag
    end
    return lines
end

-- найти подземелье по экземпляру, в котором стоит игрок
local function currentDungeonKey()
    if not IsInInstance then return end
    local inside, itype = IsInInstance()
    if not inside or (itype ~= "party" and itype ~= "raid") then return end
    local name = GetInstanceInfo and GetInstanceInfo()
    local A = FG.Advisor
    if not name or not A.dungeonByKey then return end
    if A.dungeonByKey[name] then return name end
    local low = name:lower()
    for k, dg in pairs(A.dungeonByKey) do
        if (dg.locEn and dg.locEn:lower() == low) or k:lower() == low or (A:DungeonName(dg) or ""):lower() == low then return k end
    end
end

local lastAnnounced
local function announce()
    local dkey = currentDungeonKey()
    if not dkey then lastAnnounced = nil return end
    if dkey == lastAnnounced then return end
    lastAnnounced = dkey
    local lines = B:DungeonLines(dkey, true)
    if #lines == 0 then return end
    local dg = FG.Advisor.dungeonByKey[dkey]
    FG:Print(L("bis_here", dg and FG.Advisor:DungeonName(dg) or dkey, #lines))
    for _, l in ipairs(lines) do print("   " .. l) end
end
FG:On("PLAYER_ENTERING_WORLD", function() C_Timer.After(3, function() pcall(announce) end) end)
FG:On("ZONE_CHANGED_NEW_AREA", function() C_Timer.After(2, function() pcall(announce) end) end)

function B:BuildPage(page)
    if not panel then create(page) end
end

function B:Toggle()
    if FG.Menu.ToggleTab then FG.Menu:ToggleTab("bis") end
end

-- предметы подгружаются игрой не сразу; надетые вещи меняются
local pendingRefresh
FG:On("GET_ITEM_INFO_RECEIVED", function(_, id)
    local r = B.tipRow
    if r and r.item and (not id or id == r.item.id) and GameTooltip:IsOwned(r) then
        local fn = r:GetScript("OnEnter")
        if fn then pcall(fn, r) end
    end
end)
FG:On("GET_ITEM_INFO_RECEIVED", function()
    if not (panel and panel:IsVisible()) or pendingRefresh then return end
    pendingRefresh = true
    C_Timer.After(0.4, function() pendingRefresh = nil; refresh() end)
end)
FG:On("PLAYER_LEVEL_UP", function() if panel and panel:IsVisible() then C_Timer.After(1, refresh) end end)
FG:On("PLAYER_EQUIPMENT_CHANGED", function() if panel and panel:IsVisible() then refresh() end end)
FG:On("PLAYER_TALENT_UPDATE", function() if panel and panel:IsVisible() then refresh() end end)
