-- QuestCompass: вкладка «Навыки» — все профессии и пошаговые гайды прокачки
local _, ns = ...
local FG = ns.FG
local L = FG.L
local K = {}
FG.Skills = K

local S
local page, guide
local tr -- блок «прокачка» в гайде
local CW = 360
local GW = 450          -- ширина окна гайда (правая часть меню)
local CARD_W, CARD_H = math.floor((FG.PAGE_W - 36) / 2), 50 -- две карточки в ряд на всю ширину страницы
local ROW_H, ROWS = 48, 14
local RANK_MAX = { apprentice = 75, journeyman = 150, expert = 225, artisan = 300 }
local RANK_ORDER = { "apprentice", "journeyman", "expert", "artisan" }

local function safe(f, ...) if not f then return nil end local ok, a, b, c = pcall(f, ...) if ok then return a, b, c end end
local function ru() return FG:Lang() == "ru" end
local function pick(t) if not t then return nil end return ru() and (t[2] or t[1]) or t[1] end

local function itemIcon(id)
    if not id or id <= 0 then return nil end
    local f = (C_Item and C_Item.GetItemIconByID) or rawget(_G, "GetItemIconByID")
    local ic = safe(f, id)
    if not ic and C_Item and C_Item.GetItemInfoInstant then ic = select(5, safe(C_Item.GetItemInfoInstant, id)) end
    return ic
end
local function itemName(id)
    local en = FG:EnName("Item", id)
    return FG:TrItem(id, en) or en or ("#" .. tostring(id))
end
local function itemCount(id)
    local f = rawget(_G, "GetItemCount") or (C_Item and C_Item.GetItemCount)
    local n = safe(f, id, true)
    return type(n) == "number" and n or nil
end
local function playerFaction()
    local f = FG.cdb and FG.cdb.faction
    if not f and UnitFactionGroup then f = UnitFactionGroup("player") end
    return f == "Horde" and "H" or "A"
end
local function npcInfo(id)
    local D = (rawget(_G, "QuestCompassDataLib") or rawget(_G, "LibQuestieDB"))
    local name = FG:TrNpc(id, FG:EnName("Npc", id)) or ("#" .. id)
    local zone = D and D.Npc and safe(D.Npc.GetRaw, id, "zoneID")
    local where
    if zone and C_Map and C_Map.GetAreaInfo then
        local an = safe(C_Map.GetAreaInfo, zone)
        if an then where = FG:TrZone(an) end
    end
    local fr = D and D.Npc and safe(D.Npc.GetRaw, id, "friendlyToFaction")
    return name, where, fr
end

---------------------------------------------------------------------------
-- Текущие навыки персонажа (окно навыков игры)
---------------------------------------------------------------------------
local skillCache, skillT = {}, -1
-- ID линий навыков и заклинания профессий (для запасных способов)
local SKILL_ID = { alchemy = 171, blacksmithing = 164, enchanting = 333, engineering = 202, herbalism = 182,
    leatherworking = 165, mining = 186, skinning = 393, tailoring = 197, cooking = 185, firstaid = 129, fishing = 356 }
-- заклинания рангов: Ученик, Подмастерье, Умелец, Искусник
local PROF_SPELLS = {
    alchemy = { 2259, 3101, 3464, 11611 }, blacksmithing = { 2018, 3100, 3538, 9785 },
    enchanting = { 7411, 7412, 7413, 13920 }, engineering = { 4036, 4037, 4038, 12656 },
    herbalism = { 2366, 2368, 3570, 11993 }, leatherworking = { 2108, 3104, 3811, 10662 },
    mining = { 2575, 2576, 3564, 10248 }, skinning = { 8613, 8617, 8618, 10768 },
    tailoring = { 3908, 3909, 3910, 12180 }, cooking = { 2550, 3102, 3413, 18260 },
    firstaid = { 3273, 3274, 7924, 10846 }, fishing = { 7620, 7731, 7732, 18248 },
}
local LINE_TO_KEY = {}
for k, v in pairs(SKILL_ID) do LINE_TO_KEY[v] = k end
-- нормализация названия: без пробелов по краям и регистра (кириллица — вручную)
local UP = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ"
local LO = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя"
local caseMap = {}
do
    local ui, li = {}, {}
    for ch in UP:gmatch("[%z\1-\127\194-\244][\128-\191]*") do ui[#ui + 1] = ch end
    for ch in LO:gmatch("[%z\1-\127\194-\244][\128-\191]*") do li[#li + 1] = ch end
    for i = 1, #ui do caseMap[ui[i]] = li[i] end
end
local function norm(s)
    if type(s) ~= "string" then return "" end
    s = s:gsub("[%z\1-\127\194-\244][\128-\191]*", function(ch) return caseMap[ch] or ch end)
    s = s:lower():gsub("\194\160", " "):gsub("^%s+", ""):gsub("%s+$", "")
    return s
end
local NAMES
local function nameMap()
    if NAMES then return NAMES end
    NAMES = {}
    for _, p in ipairs(QuestCompassProf or {}) do NAMES[norm(p.en)] = p.key; NAMES[norm(p.ru)] = p.key end
    local extra = { ["рыбалка"] = "fishing", ["рыбная ловля"] = "fishing", ["снятие шкур"] = "skinning", ["свежевание"] = "skinning",
        ["наложение чар"] = "enchanting", ["зачарование"] = "enchanting", ["первая помощь"] = "firstaid", ["травничество"] = "herbalism",
        ["горное дело"] = "mining", ["инженерное дело"] = "engineering", ["кузнечное дело"] = "blacksmithing",
        ["кожевничество"] = "leatherworking", ["портняжное дело"] = "tailoring", ["кулинария"] = "cooking", ["алхимия"] = "alchemy" }
    for k, v in pairs(extra) do NAMES[norm(k)] = v end
    return NAMES
end
local function keyFor(name)
    local m = nameMap()
    local n = norm(name)
    if m[n] then return m[n] end
    for k, v in pairs(m) do if k ~= "" and n:find(k, 1, true) then return v end end
end

function K:Levels()
    local now = GetTime and GetTime() or 0
    if now - skillT < 1 then return skillCache end
    skillT = now
    local out = {}
    -- 1) классическое окно навыков
    local num = rawget(_G, "GetNumSkillLines")
    local gi = rawget(_G, "GetSkillLineInfo")
    local n = 0
    if num then local ok, v = pcall(num); if ok and type(v) == "number" then n = v end end
    for i = 1, n do
        local res = gi and { pcall(gi, i) } or {}
        if res[1] and res[2] and not res[3] then
            local k = keyFor(res[2])
            if k then out[k] = { rank = tonumber(res[5]) or 0, max = tonumber(res[8]) or 0 } end
        end
    end
    -- 2) новый API профессий
    local gp, gpi = rawget(_G, "GetProfessions"), rawget(_G, "GetProfessionInfo")
    if gp and gpi then
        -- в ответе бывают пустые места (нет второй профессии, археологии) — считаем по select("#")
        local ids = { pcall(gp) }
        local cnt = select("#", pcall(gp))
        for i = 2, math.max(cnt, 6) do
            local idx = ids[i]
            if idx then
                local r = { pcall(gpi, idx) }
                if r[1] then
                    local k = LINE_TO_KEY[r[8]] or keyFor(r[2])
                    if k and not out[k] then out[k] = { rank = tonumber(r[4]) or 0, max = tonumber(r[5]) or 0 } end
                end
            end
        end
    end
    -- 2б) по ID линии навыка (новый интерфейс профессий)
    local TS = rawget(_G, "C_TradeSkillUI")
    if TS and TS.GetProfessionInfoBySkillLineID then
        for k, line in pairs(SKILL_ID) do
            if not out[k] then
                local ok, info = pcall(TS.GetProfessionInfoBySkillLineID, line)
                if ok and type(info) == "table" and (info.maxSkillLevel or 0) > 0 then
                    out[k] = { rank = tonumber(info.skillLevel) or 0, max = tonumber(info.maxSkillLevel) or 0 }
                end
            end
        end
    end
    -- 2в) что показало окно профессии, когда его открывали
    local seen = FG.cdb and type(FG.cdb.skillSeen) == "table" and FG.cdb.skillSeen or {}
    -- 3) по выученным заклинаниям профессий (ранг известен, точный навык — нет)
    local known = rawget(_G, "IsPlayerSpell") or rawget(_G, "IsSpellKnown")
    if known then
        for k, ids in pairs(PROF_SPELLS) do
            if not out[k] then
                for ri = #ids, 1, -1 do
                    local ok, has = pcall(known, ids[ri])
                    if ok and has then
                        local sv = seen[k]
                        if type(sv) == "table" and sv.rank then out[k] = { rank = sv.rank, max = (sv.max and sv.max > 0) and sv.max or ri * 75 }
                        else out[k] = { rank = -1, max = ri * 75 } end
                        break
                    end
                end
            end
        end
    end
    skillCache = out
    return out
end

-- /qc skills — что отдаёт игра (для отладки)
function K:Debug()
    local num, gi = rawget(_G, "GetNumSkillLines"), rawget(_G, "GetSkillLineInfo")
    local n = 0
    if num then local ok, v = pcall(num); if ok then n = v end end
    FG:Print("GetNumSkillLines=" .. tostring(n) .. " GetSkillLineInfo=" .. tostring(gi ~= nil) .. " GetProfessions=" .. tostring(rawget(_G, "GetProfessions") ~= nil))
    for i = 1, (tonumber(n) or 0) do
        local r = gi and { pcall(gi, i) } or {}
        print(i, tostring(r[2]), "hdr=" .. tostring(r[3]), tostring(r[5]) .. "/" .. tostring(r[8]), "->", tostring((keyFor(r[2]))))
    end
    skillT = -1
    local lv = K:Levels()
    for k, v in pairs(lv) do print("  " .. k .. " " .. v.rank .. "/" .. v.max) end
end

local function rankOf(max)
    if not max or max <= 0 then return nil end
    if max <= 75 then return "apprentice" elseif max <= 150 then return "journeyman" elseif max <= 225 then return "expert" end
    return "artisan"
end

---------------------------------------------------------------------------
-- Страница со списком профессий
---------------------------------------------------------------------------
local cards = {}
local function refresh()
    if not page or not page:IsVisible() then return end
    local lv = K:Levels()
    for _, c in ipairs(cards) do
        local p = c.prof
        c.name:SetText(ru() and p.ru or p.en)
        local s = lv[p.key]
        if s then
            c.icon:SetDesaturated(false)
            c.val:SetText(s.rank >= 0 and (s.rank .. " / " .. s.max) or (L("sk_learned") .. " - " .. L("rank_" .. (rankOf(s.max) or "apprentice"))))
            c.val:SetTextColor(1, 0.86, 0.3)
            c.bar:Set(math.max(0, s.rank), s.max)
            c.bar:Show()
        else
            c.icon:SetDesaturated(true)
            c.val:SetText(L("sk_not_learned"))
            c.val:SetTextColor(0.55, 0.57, 0.6)
            c.bar:Hide()
        end
        local on = K.sel == p.key and guide and guide:IsShown()
        if on then c.sel:Show(); c.box.border:SetColor(1, 0.82, 0, 0.9) else c.sel:Hide(); c.box.border:SetColor(1, 1, 1, 0.1) end
        if FG.cdb.profTrack == p.key then c.val:SetText(c.val:GetText() .. "  |cff66e07a" .. L("sk_tracking") .. "|r") end
    end
    if guide and guide:IsShown() then K:FillGuide() end
end
K.Refresh = refresh

-- Полоса навыка как в окне навыков игры: тёмная подложка с рамкой, зелёная заливка,
-- светлее — до предела текущего ранга, деления на 75 / 150 / 225, внутри «155 / 225».
-- Свои цвета (не «под пергамент»), иначе на бумаге полосу почти не видно.
local SKILL_TEX = "Interface\\TargetingFrame\\UI-StatusBar"
local SKILL_C = { 0.25, 0.75, 0.25 }
local function skillBar(parent, h, withText)
    local f = CreateFrame("Frame", nil, parent)
    f.qcNoInk = true
    f:SetHeight(h)
    local bg = f:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(); bg:SetColorTexture(0.07, 0.05, 0.03, 0.9)
    for _, p in ipairs({ { "TOPLEFT", "TOPRIGHT", true }, { "BOTTOMLEFT", "BOTTOMRIGHT", true }, { "TOPLEFT", "BOTTOMLEFT" }, { "TOPRIGHT", "BOTTOMRIGHT" } }) do
        local e = f:CreateTexture(nil, "OVERLAY", nil, 2)
        e:SetColorTexture(0, 0, 0, 1); e:SetPoint(p[1]); e:SetPoint(p[2])
        if p[3] then e:SetHeight(1) else e:SetWidth(1) end
    end
    f.cap = f:CreateTexture(nil, "BORDER")
    f.cap:SetTexture(SKILL_TEX); f.cap:SetVertexColor(SKILL_C[1], SKILL_C[2], SKILL_C[3], 0.28)
    f.cap:SetPoint("TOPLEFT", 1, -1); f.cap:SetPoint("BOTTOMLEFT", 1, 1)
    f.fill = f:CreateTexture(nil, "ARTWORK")
    f.fill:SetTexture(SKILL_TEX); f.fill:SetVertexColor(SKILL_C[1], SKILL_C[2], SKILL_C[3], 1)
    f.fill:SetPoint("TOPLEFT", 1, -1); f.fill:SetPoint("BOTTOMLEFT", 1, 1)
    f.marks = {}
    for i = 1, 3 do
        local m = f:CreateTexture(nil, "OVERLAY", nil, 1)
        m:SetColorTexture(0, 0, 0, 0.75); m:SetWidth(1)
        f.marks[i] = m
    end
    if withText then
        f.text = f:CreateFontString(nil, "OVERLAY")
        f.text:SetFont("Fonts\\FRIZQT___CYR.TTF", math.max(9, h - 3), "OUTLINE")
        f.text:SetPoint("CENTER", 0, 0); f.text:SetTextColor(1, 1, 1)
    end
    function f:Set(cur, max)
        self.last = { cur, max }
        local w = (self:GetWidth() or 0) - 2
        if w <= 0 then return end
        cur, max = math.max(0, cur or 0), math.max(0, max or 0)
        self.fill:SetWidth(math.max(1, w * math.min(1, cur / 300))); self.fill:SetShown(cur > 0)
        self.cap:SetWidth(math.max(1, w * math.min(1, max / 300))); self.cap:SetShown(max > 0)
        for i, v in ipairs({ 75, 150, 225 }) do
            local m = self.marks[i]
            m:ClearAllPoints(); m:SetPoint("TOP", self, "TOPLEFT", 1 + w * v / 300, -1); m:SetPoint("BOTTOM", self, "BOTTOMLEFT", 1 + w * v / 300, 1)
        end
        if self.text then self.text:SetText(max > 0 and (cur .. " / " .. max) or "") end
    end
    f:SetScript("OnSizeChanged", function(self) if self.last then self:Set(self.last[1], self.last[2]) end end)
    return f
end

local function makeCard(parent, p)
    local c = CreateFrame("Button", nil, parent)
    c:SetSize(CARD_W, CARD_H)
    c.prof = p
    c.box = S:Box(c, 5, { 0.09, 0.09, 0.1, 0.9 }, { 1, 1, 1, 0.1 })
    c.sel = S:GoldBar(c, 0.45); c.sel:Hide()
    c.hl = S:GoldBar(c, 0.22); c.hl:Hide()
    c.icon = c:CreateTexture(nil, "ARTWORK")
    c.icon:SetSize(36, 36); c.icon:SetPoint("LEFT", 7, 0); c.icon:SetTexture(p.icon)
    c.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    c.name = S:Text(c, "label", S.c.text)
    c.name:SetPoint("TOPLEFT", c.icon, "TOPRIGHT", 8, -1); c.name:SetPoint("RIGHT", -4, 0)
    c.name:SetWordWrap(false)
    c.val = S:Text(c, "small", S.c.muted)
    c.val:SetPoint("BOTTOMLEFT", c.icon, "BOTTOMRIGHT", 8, 6)
    -- полоска навыка (из 300)
    c.bar = skillBar(c, 6, false)
    c.bar:SetPoint("BOTTOMLEFT", c.icon, "BOTTOMRIGHT", 8, -2); c.bar:SetWidth(CARD_W - 60)
    c:SetScript("OnEnter", function(self) self.hl:Show(); self.box.border:SetColor(1, 0.82, 0, 0.5) end)
    c:SetScript("OnLeave", function(self) self.hl:Hide(); refresh() end)
    c:SetScript("OnClick", function(self) K:Open(self.prof.key) end)
    cards[#cards + 1] = c
    return c
end

function K:BuildPage(parent)
    if page then return end
    S = FG.Style
    page = CreateFrame("Frame", "QuestCompassSkillsPage", parent)
    page:SetAllPoints(parent)
    page:HookScript("OnShow", function() refresh() end)
    local title = S:Text(page, "title", S.c.accent)
    title:SetPoint("TOPLEFT", 16, -14)
    FG:Localize(title, "sk_title")
    local hint = S:Text(page, "small", S.c.muted)
    hint:SetPoint("TOPLEFT", 16, -40); hint:SetPoint("RIGHT", -16, 0)
    FG:Localize(hint, "sk_hint")
    local y = -76
    local function section(key)
        S:Section(page, key, 16, y)
        y = y - 22
    end
    local function grid(kind)
        local i = 0
        for _, p in ipairs(QuestCompassProf or {}) do
            local sec = (p.key == "cooking" or p.key == "firstaid" or p.key == "fishing")
            if (kind == "sec") == sec then
                local c = makeCard(page, p)
                local col, row = i % 2, math.floor(i / 2)
                c:SetPoint("TOPLEFT", 14 + col * (CARD_W + 8), y - row * (CARD_H + 8))
                i = i + 1
            end
        end
        y = y - math.ceil(i / 2) * (CARD_H + 8) - 10
    end
    section("sk_primary"); grid("main")
    section("sk_secondary"); grid("sec")
    FG:OnLanguageChanged(refresh)
end

---------------------------------------------------------------------------
-- Гайд по одной профессии (правая часть меню)
---------------------------------------------------------------------------
local function profByKey(k) for _, p in ipairs(QuestCompassProf or {}) do if p.key == k then return p end end end

local function stepTitle(st)
    if st.gather then
        local t = {}
        for _, id in ipairs(st.gather) do t[#t + 1] = itemName(id) end
        return table.concat(t, ", ")
    end
    local nm = st.item and itemName(st.item) or pick(st.name) or "?"
    return nm .. "  |cff9aa0a8×" .. st.n .. "|r"
end
local function zonesFor(st)
    local z = playerFaction() == "H" and st.zH or st.zA
    local t = {}
    for _, e in ipairs(z or {}) do t[#t + 1] = FG:TrZone(e) end
    return table.concat(t, ", ")
end
local function matsLine(st)
    local t = {}
    for _, m in ipairs(st.mats or {}) do t[#t + 1] = m[2] .. "× " .. itemName(m[1]) end
    return table.concat(t, ", ")
end

---------------------------------------------------------------------------
-- Рецепты: что можно сделать, реагенты и где взять рецепт (RecipeData.lua)
-- запись: {spell, created, qty, c1, c2, c3, c4, src, {id,n,...}, recipeItem, nameEN}
---------------------------------------------------------------------------
local function recName(id)
    if not id or id <= 0 then return "?" end
    local en = FG:EnName("Item", id) or (QuestCompassItemEN and QuestCompassItemEN[id])
    if not ru() then return en or itemName(id) end
    local tr = FG:TrItem(id, nil)
    if tr then return tr end
    local n = rawget(_G, "GetItemInfo") and safe(GetItemInfo, id)
    return n or en or ("#" .. id)
end
local function recTitle(r)
    if ru() then
        local sn = rawget(_G, "GetSpellInfo") and safe(GetSpellInfo, r[1])
        if type(sn) == "string" and sn ~= "" then return sn end
        if r[2] and r[2] > 0 then
            local tr = FG:TrItem(r[2], nil) or (rawget(_G, "GetItemInfo") and safe(GetItemInfo, r[2]))
            if tr then return tr end
        end
    end
    return r[11] or "?"
end
local function recIcon(r, p)
    local ic = r[2] and r[2] > 0 and itemIcon(r[2])
    if not ic and rawget(_G, "GetSpellTexture") then ic = safe(GetSpellTexture, r[1]) end
    return ic or p.icon
end
-- цвет сложности рецепта при текущем навыке
local function recColor(r, cur)
    if cur < r[4] then return 0.9, 0.3, 0.3 end
    if cur < r[5] then return 1, 0.5, 0.25 end
    if cur < r[6] then return 1, 0.82, 0 end
    if cur < r[7] then return 0.25, 0.75, 0.25 end
    return 0.55, 0.57, 0.6
end
local function hexOf(r, g, b) return string.format("|cff%02x%02x%02x", r * 255, g * 255, b * 255) end

-- изученные рецепты: IsPlayerSpell + снимок окна профессии
local function recKnown(key, r)
    if rawget(_G, "IsPlayerSpell") and safe(IsPlayerSpell, r[1]) then return true end
    local c = FG.cdb and type(FG.cdb.recKnown) == "table" and FG.cdb.recKnown[key]
    if type(c) ~= "table" then return false end
    if c[norm(r[11])] then return true end
    local sn = rawget(_G, "GetSpellInfo") and safe(GetSpellInfo, r[1])
    if sn and c[norm(sn)] then return true end
    if r[2] and r[2] > 0 then
        local n = rawget(_G, "GetItemInfo") and safe(GetItemInfo, r[2])
        if n and c[norm(n)] then return true end
    end
    return false
end
local function hasCache(key)
    return FG.cdb and type(FG.cdb.recKnown) == "table" and type(FG.cdb.recKnown[key]) == "table"
end
function K:ScanKnown(craft)
    if not FG.cdb then return end
    local line, num, info
    if craft then
        line = rawget(_G, "GetCraftDisplaySkillLine") and safe(GetCraftDisplaySkillLine)
        num, info = rawget(_G, "GetNumCrafts"), rawget(_G, "GetCraftInfo")
    else
        line = rawget(_G, "GetTradeSkillLine") and safe(GetTradeSkillLine)
        num, info = rawget(_G, "GetNumTradeSkills"), rawget(_G, "GetTradeSkillInfo")
    end
    local key = line and keyFor(line)
    -- навык из окна профессии (старое окно: имя, навык, максимум; новое — C_TradeSkillUI)
    local rank, maxR
    if craft then rank, maxR = select(2, safe(GetCraftDisplaySkillLine)) else rank, maxR = select(2, safe(GetTradeSkillLine)) end
    local TS = rawget(_G, "C_TradeSkillUI")
    if (not key or not rank) and TS then
        for _, fn in ipairs({ "GetChildProfessionInfo", "GetBaseProfessionInfo" }) do
            local f = TS[fn]
            local ok, inf = false, nil
            if f then ok, inf = pcall(f) end
            if ok and type(inf) == "table" and (inf.maxSkillLevel or 0) > 0 then
                key = key or keyFor(inf.professionName or inf.parentProfessionName or "")
                rank, maxR = inf.skillLevel, inf.maxSkillLevel
                if key then break end
            end
        end
    end
    if key and tonumber(rank) and FG.cdb then
        FG.cdb.skillSeen = type(FG.cdb.skillSeen) == "table" and FG.cdb.skillSeen or {}
        FG.cdb.skillSeen[key] = { rank = tonumber(rank), max = tonumber(maxR) or 0 }
        skillT = -1
        if FG.Tracker then pcall(FG.Tracker.Update, FG.Tracker) end
    end
    if not key or not num or not info then return end
    local n = safe(num) or 0
    if n <= 0 then return end
    local t = {}
    for i = 1, n do
        local ok, name, a, b = pcall(info, i)
        local typ = craft and b or a
        if ok and name and typ ~= "header" then t[norm(name)] = true end
    end
    FG.cdb.recKnown = type(FG.cdb.recKnown) == "table" and FG.cdb.recKnown or {}
    FG.cdb.recKnown[key] = t
    if guide and guide:IsShown() and K.view == "recipes" and K.sel == key then K:FillGuide() end
end
do
    local ev = CreateFrame("Frame")
    for _, e in ipairs({ "TRADE_SKILL_SHOW", "TRADE_SKILL_UPDATE", "CRAFT_SHOW", "CRAFT_UPDATE" }) do pcall(ev.RegisterEvent, ev, e) end
    ev:SetScript("OnEvent", function(_, e) K:ScanKnown(e == "CRAFT_SHOW" or e == "CRAFT_UPDATE") end)
end

local function recSource(r)
    local SRC = QuestCompassRecipeSrc or {}
    if r[8] == "a" then return { kind = "auto" } end
    if r[8] == "t" then return { kind = "trainer" } end
    local s = r[10] and SRC[r[10]]
    if not s then return { kind = "unknown" } end
    local me = playerFaction() == "H" and "Horde" or "Alliance"
    local vend = {}
    for _, v in ipairs(s.v or {}) do if not v[3] or v[3] == me then vend[#vend + 1] = v end end
    return { kind = (#vend > 0 and "vendor") or ((#(s.d or {}) > 0) and "drop") or ((#(s.o or {}) > 0) and "other") or "unknown",
        v = vend, d = s.d or {}, o = s.o or {}, m = s.m or 0 }
end
local function otherText(o)
    if not ru() then return o end
    local map = { { "^Reward from ", "Награда за задание: " }, { "^Found in ", "Сундук: " }, { "^Contained in ", "Внутри: " },
        { "^World drop", "Случайная добыча в мире" }, { "^Choice of ", "На выбор: " } }
    for _, m in ipairs(map) do if o:find(m[1]) then return (o:gsub(m[1], m[2])) end end
    return o
end
local function zoneTr(z) return z and FG:TrZone(z) or nil end
local function srcShort(src)
    if src.kind == "auto" then return "|cff9aa0a8" .. L("rc_src_auto") .. "|r" end
    if src.kind == "trainer" then return "|cffb88fff" .. L("rc_src_trainer") .. "|r" end
    if src.kind == "vendor" then
        local v = src.v[1]
        return "|cff66e07a" .. L("rc_src_vendor") .. ":|r " .. v[1] .. (v[2] and (" (" .. zoneTr(v[2]) .. ")") or "")
    end
    if src.kind == "drop" then
        local d = src.d[1]
        return "|cffff9a40" .. L("rc_src_drop") .. ":|r " .. d[1] .. (d[2] and (" (" .. zoneTr(d[2]) .. ")") or "")
    end
    if src.kind == "other" then return "|cffff9a40" .. L("rc_src_other") .. ":|r " .. otherText(src.o[1]) end
    return "|cff9aa0a8" .. L("rc_src_unknown") .. "|r"
end

local function buildRecipes(p, cur, filter)
    local all = QuestCompassRecipes and QuestCompassRecipes[p.key] or {}
    local out, known, learnable = {}, 0, 0
    for _, r in ipairs(all) do
        local k = recKnown(p.key, r)
        if k then known = known + 1 end
        if not k and r[4] <= cur then learnable = learnable + 1 end
        local ok = filter == "all" or (filter == "now" and r[4] <= math.max(1, cur)) or (filter == "miss" and not k)
        if ok then out[#out + 1] = { rec = r, known = k } end
    end
    if filter == "now" then
        local n = #out
        for i = 1, math.floor(n / 2) do out[i], out[n - i + 1] = out[n - i + 1], out[i] end
    end
    return out, known, #all, learnable
end

function K:RecipeTip(r, e)
    local rec, p = e.rec, profByKey(K.sel)
    local lv = p and K:Levels()[p.key]
    local cur = lv and math.max(0, lv.rank) or 0
    GameTooltip:SetOwner(r, "ANCHOR_RIGHT")
    if rec[2] and rec[2] > 0 then
        local ok = pcall(GameTooltip.SetItemByID, GameTooltip, rec[2])
        if not ok or (GameTooltip.NumLines and (GameTooltip:NumLines() or 0) == 0) then GameTooltip:AddLine(recTitle(rec), 1, 0.82, 0) end
    else
        GameTooltip:AddLine(recTitle(rec), 1, 0.82, 0)
    end
    GameTooltip:AddLine(" ")
    local cs = {}
    for i = 4, 7 do
        local col = ({ "|cffff8040", "|cffffd100", "|cff40c040", "|cff9aa0a8" })[i - 3]
        cs[#cs + 1] = col .. rec[i] .. "|r"
    end
    GameTooltip:AddDoubleLine(L("rc_skill") .. " " .. table.concat(cs, " / "),
        e.known and ("|cff66e07a" .. L("rc_known") .. "|r") or ("|cffff9a40" .. L("rc_unknown") .. "|r"), 1, 1, 1, 1, 1, 1)
    GameTooltip:AddLine(L("rc_reagents"), 0.6, 0.63, 0.66)
    local rg = rec[9] or {}
    for i = 1, #rg, 2 do
        local id, n = rg[i], rg[i + 1]
        local have = itemCount(id)
        local ic = itemIcon(id)
        local okc = have and have >= n
        GameTooltip:AddDoubleLine((ic and ("|T" .. ic .. ":14:14|t ") or "") .. recName(id), have and (have .. " / " .. n) or tostring(n),
            0.9, 0.9, 0.9, okc and 0.4 or 0.9, okc and 0.88 or 0.9, okc and 0.48 or 0.9)
    end
    local src = recSource(rec)
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine(L("rc_get"), 1, 0.82, 0)
    if src.kind == "auto" or src.kind == "trainer" or src.kind == "unknown" then
        GameTooltip:AddLine(srcShort(src), 1, 1, 1, true)
    else
        for _, v in ipairs(src.v or {}) do
            local price = (v[4] and v[4] > 0 and rawget(_G, "GetCoinTextureString")) and safe(GetCoinTextureString, v[4]) or nil
            GameTooltip:AddDoubleLine("|cff66e07a" .. L("rc_src_vendor") .. ":|r " .. v[1], (zoneTr(v[2]) or "") .. (price and ("  " .. price) or ""), 1, 1, 1, 0.8, 0.8, 0.8)
        end
        for _, d in ipairs(src.d or {}) do
            GameTooltip:AddDoubleLine("|cffff9a40" .. L("rc_src_drop") .. ":|r " .. d[1] .. ((d[3] and d[3] > 0) and (" (" .. d[3] .. " " .. L("rc_lvl") .. ")") or ""),
                zoneTr(d[2]) or "", 1, 1, 1, 0.8, 0.8, 0.8)
        end
        for _, o in ipairs(src.o or {}) do GameTooltip:AddLine("- " .. otherText(o), 0.85, 0.85, 0.85, true) end
        if src.m and src.m > 0 then GameTooltip:AddLine(L("rc_more", src.m), 0.6, 0.63, 0.66) end
    end
    if rec[4] > cur then GameTooltip:AddLine(L("rc_need_skill", rec[4]), 0.9, 0.3, 0.3) end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine(L("rc_click"), 0.4, 0.88, 0.48, true)
    if rec[10] and rec[10] > 0 and not e.known then GameTooltip:AddLine(L("rc_rclick"), 0.4, 0.88, 0.48, true) end
    GameTooltip:Show()
end

local function createGuide()
    S = FG.Style
    guide = FG.Menu:MakeDrawer(GW, "QuestCompassSkillGuide")
    guide:HookScript("OnShow", function() K:FillGuide(true); refresh() end)
    guide:HookScript("OnHide", function() refresh() end)
    guide.icon = guide:CreateTexture(nil, "ARTWORK")
    guide.icon:SetSize(36, 36); guide.icon:SetPoint("TOPLEFT", 16, -16)
    guide.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    guide.title = S:NoInk(S:Text(guide, "label", S.c.text)); guide.title:SetTextColor(1, 1, 1)
    guide.title:SetPoint("TOPLEFT", guide.icon, "TOPRIGHT", 10, -1)
    guide.lvl = S:NoInk(S:Text(guide, "small", S.c.muted)); guide.lvl:SetTextColor(0.75, 0.72, 0.66)
    guide.lvl:SetPoint("BOTTOMLEFT", guide.icon, "BOTTOMRIGHT", 10, 1)
    -- полоса навыка с делениями рангов
    guide.skill = skillBar(guide, 14, true)
    guide.skill:SetPoint("TOPLEFT", 16, -56); guide.skill:SetPoint("TOPRIGHT", -16, -56)
    -- переключатель: пошаговый маршрут / список покупок
    -- «Идти»: окно с картой и что делать, стрелка ведёт куда нужно
    guide.track = FG.Go:Button(guide, 132, 24, function()
        if FG.cdb.profTrack ~= K.sel then K:StartTrack(K.sel) else FG.Go:Open("prof") end
        K:FillGuide()
    end)
    guide.track:SetPoint("TOPRIGHT", -16, -74)
    guide.viewSeg = S:Segmented(guide, { { "route", "sk_view_route" }, { "mats", "sk_view_mats" }, { "recipes", "sk_view_rec" } }, GW - 32 - 140, 24,
        function() return K.view or "route" end,
        function(v) K.view = v; guide.offset = nil; K:FillGuide(true) end)
    guide.viewSeg:SetPoint("TOPLEFT", 16, -74)
    -- фильтр рецептов
    guide.recSeg = S:Segmented(guide, { { "now", "rc_f_now" }, { "miss", "rc_f_miss" }, { "all", "rc_f_all" } }, GW - 32, 22,
        function() return K.recFilter or "now" end,
        function(v) K.recFilter = v; guide.offset = nil; K:FillGuide(true) end)
    guide.recSeg:SetPoint("TOPLEFT", 16, -106)
    guide.recSeg:Hide()
    guide.rank = S:Text(guide, "small", S.c.text)
    guide.rank:SetPoint("TOPLEFT", 16, -106); guide.rank:SetPoint("RIGHT", -16, 0)
    guide.rank:SetSpacing(2)
    guide.sep = S.Tex(guide, "ARTWORK", S.c.border)
    guide.sep:SetHeight(1)
    guide.rows = {}
    for i = 1, ROWS do
        local r = CreateFrame("Button", nil, guide)
        r:SetSize(GW - 30, ROW_H - 4)
        r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        r.cur = S:GoldBar(r, 0.45); r.cur:Hide()
        r.hl = S:GoldBar(r, 0.2); r.hl:Hide()
        r.range = S:Text(r, "small", S.c.accent)
        r.range:SetPoint("LEFT", 2, 0); r.range:SetWidth(66); r.range:SetJustifyH("CENTER")
        r.icon = r:CreateTexture(nil, "ARTWORK")
        r.icon:SetSize(30, 30); r.icon:SetPoint("LEFT", 70, 0)
        r.check = r:CreateTexture(nil, "OVERLAY")
        r.check:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready")
        r.check:SetSize(14, 14); r.check:SetPoint("BOTTOMRIGHT", r.icon, "BOTTOMRIGHT", 3, -3); r.check:Hide()
        r.name = S:Text(r, "label", S.c.text)
        r.name:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 8, 1); r.name:SetPoint("RIGHT", -4, 0)
        r.name:SetWordWrap(false)
        r.sub = S:Text(r, "small", S.c.muted)
        r.sub:SetPoint("BOTTOMLEFT", r.icon, "BOTTOMRIGHT", 8, -1); r.sub:SetPoint("RIGHT", -4, 0)
        r.sub:SetWordWrap(false)
        r:SetScript("OnEnter", function(self) self.hl:Show(); if self.entry and self.entry.rec then K:RecipeTip(self, self.entry) else K:StepTip(self) end end)
        r:SetScript("OnClick", function(self, btn)
            local e = self.entry
            if not e then return end
            if e.rec then
                local rec = e.rec
                if btn == "RightButton" and rec[10] and rec[10] > 0 then
                    FG:AHSearch(rec[10], QuestCompassItemEN and QuestCompassItemEN[rec[10]])
                    return
                end
                local rg = rec[9] or {}
                for i = 1, #rg, 2 do
                    if (itemCount(rg[i]) or 0) < rg[i + 1] then FG:AHSearch(rg[i], recName(rg[i])) return end
                end
                if rg[1] then FG:AHSearch(rg[1], recName(rg[1])) end
                return
            end
            if e.mat then FG:AHSearch(e.mat, itemName(e.mat))
            elseif e.step and e.step.mats and e.step.mats[1] then
                -- шаг: ищем первый материал, которого не хватает
                local n = e.left or e.step.n
                for _, m in ipairs(e.step.mats) do
                    if (itemCount(m[1]) or 0) < m[2] * n then FG:AHSearch(m[1], itemName(m[1])) return end
                end
                FG:AHSearch(e.step.mats[1][1], itemName(e.step.mats[1][1]))
            end
        end)
        r:SetScript("OnLeave", function(self) self.hl:Hide(); GameTooltip:Hide() end)
        guide.rows[i] = r
    end
    guide.note = S:Text(guide, "small", S.c.muted)
    guide.note:SetPoint("BOTTOMLEFT", 16, 12); guide.note:SetPoint("BOTTOMRIGHT", -16, 12)
    FG:Localize(guide.note, "sk_note")
    guide.sb = S:ScrollBar(guide, function(off) guide.offset = off; K:FillGuide() end)
    guide:EnableMouseWheel(true)
    guide:SetScript("OnMouseWheel", function(_, d)
        guide.offset = (guide.offset or 0) - d * 2
        K:FillGuide()
    end)
end

-- сколько ещё сделать на шаге при текущем навыке
local function remaining(st, cur)
    if cur <= st.a then return st.n end
    local span = math.max(1, st.b - st.a)
    return math.max(1, math.ceil(st.n * (st.b - cur) / span))
end

-- маршрут: шаги + обязательные визиты к учителю (ранги) в нужных местах
local RANK_CAP = { journeyman = 75, expert = 150, artisan = 225 }
local function buildRoute(p)
    local out, placed = {}, {}
    for _, st in ipairs(p.steps or {}) do
        for _, r in ipairs(p.ranks or {}) do
            local cap = RANK_CAP[r[1]]
            if cap and not placed[r[1]] and not st.alt and st.b > cap then
                placed[r[1]] = true
                out[#out + 1] = { rank = r, cap = cap }
            end
        end
        out[#out + 1] = { step = st }
    end
    return out
end

-- список покупок на оставшиеся шаги: промежуточные изделия вычитаются
local function buildMats(p, cur)
    local need, order, pool = {}, {}, {}
    for _, st in ipairs(p.steps or {}) do
        if not st.alt and not st.gather and cur < st.b then
            local n = remaining(st, cur)
            for _, m in ipairs(st.mats or {}) do
                local q = m[2] * n
                local fromPool = math.min(pool[m[1]] or 0, q)
                pool[m[1]] = (pool[m[1]] or 0) - fromPool
                q = q - fromPool
                if q > 0 then
                    if not need[m[1]] then need[m[1]] = 0; order[#order + 1] = m[1] end
                    need[m[1]] = need[m[1]] + q
                end
            end
            if st.item then pool[st.item] = (pool[st.item] or 0) + n end
        end
    end
    local out = {}
    for _, id in ipairs(order) do out[#out + 1] = { mat = id, need = need[id] } end
    return out
end

-- подсказка строки
function K:StepTip(r)
    local e = r.entry
    if not e then return end
    GameTooltip:SetOwner(r, "ANCHOR_RIGHT")
    if e.mat then
        local ok = pcall(GameTooltip.SetItemByID, GameTooltip, e.mat)
        if not ok then GameTooltip:AddLine(itemName(e.mat), 1, 1, 1) end
        GameTooltip:AddLine(L("ah_click"), 0.4, 0.88, 0.48, true)
        GameTooltip:Show()
        return
    end
    if e.rank then
        GameTooltip:AddLine(L("sk_train", L("rank_" .. e.rank[1])), 1, 0.82, 0)
        GameTooltip:AddLine(L("sk_train_req", e.rank[2], e.rank[3]), 1, 1, 1)
        GameTooltip:AddLine(pick(e.rank[4]) or "", 0.8, 0.8, 0.8, true)
        GameTooltip:Show()
        return
    end
    local st = e.step
    GameTooltip:AddLine(st.a .. "–" .. st.b .. "  " .. stepTitle(st), 1, 0.82, 0)
    if st.gather then
        GameTooltip:AddLine(L("sk_where") .. " " .. zonesFor(st), 1, 1, 1, true)
    else
        local n = e.left or st.n
        GameTooltip:AddLine(L("sk_mats_total_n", n), 0.6, 0.63, 0.66)
        for _, m in ipairs(st.mats or {}) do
            local need = m[2] * n
            local have = itemCount(m[1])
            local ic = itemIcon(m[1])
            local left = (ic and ("|T" .. ic .. ":14:14|t ") or "") .. itemName(m[1])
            local right = have and (have .. " / " .. need) or tostring(need)
            local ok = have and have >= need
            GameTooltip:AddDoubleLine(left, right, 0.9, 0.9, 0.9, ok and 0.4 or 0.9, ok and 0.88 or 0.9, ok and 0.48 or 0.9)
        end
    end
    if st.note then GameTooltip:AddLine(pick(st.note), 0.4, 0.88, 0.48, true) end
    if not st.gather then GameTooltip:AddLine(L("ah_click_step"), 0.4, 0.88, 0.48, true) end
    local me = playerFaction()
    for _, id in ipairs(st.npcs or {}) do
        local name, where, fr = npcInfo(id)
        if not fr or fr == "AH" or fr == me then
            GameTooltip:AddLine("- " .. name .. (where and (" — " .. where) or ""), 0.8, 0.8, 0.8)
        end
    end
    GameTooltip:Show()
end

function K:FillGuide(scroll)
    if not guide then return end
    local p = profByKey(K.sel)
    if not p then return end
    local lv = K:Levels()[p.key]
    local cur = lv and math.max(0, lv.rank) or 0
    local gather = p.kind == "gather"
    local view = gather and "route" or (K.view or "route")
    guide.icon:SetTexture(p.icon)
    guide.title:SetText(ru() and p.ru or p.en)
    local rk = lv and rankOf(lv.max)
    if lv and lv.rank < 0 then guide.lvl:SetText(L("sk_learned") .. " - " .. L("rank_" .. (rk or "apprentice")))
    elseif lv then guide.lvl:SetText(L("sk_level", cur, lv.max, L("rank_" .. (rk or "apprentice"))))
    else guide.lvl:SetText(L("sk_not_learned_long")) end
    guide.skill:Set(cur, lv and lv.max or 0)
    if gather then guide.viewSeg:Hide() else guide.viewSeg:Show(); guide.viewSeg:Refresh() end

    local tracking = FG.cdb.profTrack == p.key
    if view == "recipes" then return K:FillRecipes(p, lv, cur, scroll) end
    guide.recSeg:Hide()
    local textTop = -106
    guide.rank:ClearAllPoints(); guide.rank:SetPoint("TOPLEFT", 16, textTop); guide.rank:SetPoint("RIGHT", -16, 0)

    -- «что делать сейчас»
    local lines = {}
    local nextR
    for _, r in ipairs(p.ranks or {}) do
        if not lv or RANK_MAX[r[1]] > (lv.max or 0) then nextR = r break end
    end
    local nowStep
    for _, st in ipairs(p.steps or {}) do if not st.alt and cur < st.b then nowStep = st break end end
    if not lv then
        lines[#lines + 1] = "|cffffd100" .. L("sk_learn") .. "|r " .. L("sk_learn_where")
    elseif nextR and cur >= (lv.max or 0) then
        -- упёрлись в предел ранга
        local ready = (UnitLevel("player") or 1) >= nextR[3]
        lines[#lines + 1] = (ready and "|cff66e07a" or "|cffff9a40") .. L("sk_cap", lv.max, L("rank_" .. nextR[1]), nextR[3]) .. "|r"
        lines[#lines + 1] = "|cffbfc4ca" .. (pick(nextR[4]) or "") .. "|r"
    elseif nowStep then
        if nowStep.gather then
            lines[#lines + 1] = "|cff66e07a" .. L("sk_now") .. "|r " .. stepTitle(nowStep) .. " — " .. zonesFor(nowStep)
        else
            local nm = nowStep.item and itemName(nowStep.item) or pick(nowStep.name) or "?"
            lines[#lines + 1] = "|cff66e07a" .. L("sk_now") .. "|r " .. L("sk_now_craft", remaining(nowStep, cur), nm, nowStep.b)
        end
        if nextR then lines[#lines + 1] = "|cff9aa0a8" .. L("sk_next", L("rank_" .. nextR[1]), nextR[2], nextR[3]) .. "|r" end
    else
        lines[#lines + 1] = "|cff66e07a" .. L("sk_done") .. "|r"
    end
    -- «Начать прокачку»: подсказки и стрелка — в отдельном маленьком окне
    if tracking then lines[#lines + 1] = "|cffb88fff" .. L("sk_tr_window") .. "|r" end
    guide.rank:SetText(table.concat(lines, "\n"))
    local rh = (guide.rank.GetStringHeight and guide.rank:GetStringHeight()) or 24
    if type(rh) ~= "number" then rh = 24 end
    local top = textTop - rh - 8
    guide.sep:ClearAllPoints()
    guide.sep:SetPoint("TOPLEFT", 16, top); guide.sep:SetPoint("TOPRIGHT", -16, top)

    -- строки
    local list = view == "mats" and buildMats(p, cur) or buildRoute(p)
    local h = guide:GetHeight() or 0
    local vis = (type(h) == "number" and h > 0) and math.max(3, math.min(ROWS, math.floor((h + top - 6 - 34) / ROW_H))) or 8
    if scroll then
        guide.offset = 0
        if view == "route" and lv then
            for i, e in ipairs(list) do
                if (e.step and not e.step.alt and cur < e.step.b) or (e.rank and lv.max <= e.cap) then guide.offset = math.max(0, i - 2) break end
            end
        end
    end
    guide.offset = math.max(0, math.min(guide.offset or 0, #list - vis))
    if guide.sb then
        guide.sb:ClearAllPoints()
        guide.sb:SetPoint("TOPRIGHT", guide, "TOPRIGHT", -3, top - 6)
        guide.sb:SetHeight(vis * ROW_H - 4)
        guide.sb:Update(guide.offset, #list, vis)
    end
    for i = 1, ROWS do
        local r = guide.rows[i]
        local e = i <= vis and list[i + guide.offset]
        r.cur:Hide(); r.check:Hide(); r.icon:SetDesaturated(false); r.name:SetAlpha(1)
        if e then
            r.entry = e
            r:ClearAllPoints(); r:SetPoint("TOPLEFT", 12, top - 6 - (i - 1) * ROW_H)
            if e.mat then
                local have = itemCount(e.mat)
                r.range:SetText(e.need .. "×"); r.range:SetTextColor(1, 0.82, 0)
                r.icon:SetTexture(itemIcon(e.mat) or "Interface\\Icons\\INV_Misc_QuestionMark")
                r.name:SetText(itemName(e.mat))
                if have then
                    local ok = have >= e.need
                    r.sub:SetText((ok and "|cff66e07a" or "|cff9aa0a8") .. L("sk_have", have, e.need) .. "|r")
                    if ok then r.check:Show() end
                else
                    r.sub:SetText("")
                end
            elseif e.rank then
                local has = lv and lv.max > e.cap
                r.range:SetText(tostring(e.cap)); r.range:SetTextColor(0.72, 0.56, 1)
                r.icon:SetTexture("Interface\\Icons\\INV_Misc_Book_11")
                r.name:SetText("|cffb88fff" .. L("sk_train", L("rank_" .. e.rank[1])) .. "|r")
                r.sub:SetText(L("sk_train_req_short", e.rank[2], e.rank[3]) .. " - " .. (pick(e.rank[4]) or ""))
                if has then r.check:Show(); r.icon:SetDesaturated(true); r.name:SetAlpha(0.55)
                elseif lv and cur >= lv.max then r.cur:Show() end
            else
                local st = e.step
                local done = lv and cur >= st.b
                local now = lv and not st.alt and cur >= st.a and cur < st.b
                e.left = (now and not st.gather) and remaining(st, cur) or nil
                r.range:SetText(st.a .. "–" .. st.b)
                local ic = st.gather and itemIcon(st.gather[1]) or (st.item and itemIcon(st.item)) or (st.mats and st.mats[1] and itemIcon(st.mats[1][1]))
                r.icon:SetTexture(ic or p.icon)
                if st.gather then
                    r.name:SetText(stepTitle(st))
                    r.sub:SetText(zonesFor(st))
                else
                    local nm = st.item and itemName(st.item) or pick(st.name) or "?"
                    local cnt = e.left and (e.left .. "/" .. st.n) or tostring(st.n)
                    r.name:SetText("|cffffd100" .. cnt .. "×|r " .. nm .. (st.alt and ("  |cff9aa0a8" .. L("sk_alt") .. "|r") or ""))
                    if st.note then r.sub:SetText("|cff66e07a" .. pick(st.note) .. "|r") else r.sub:SetText(matsLine(st)) end
                end
                if now then r.cur:Show() end
                if done then
                    r.check:Show(); r.icon:SetDesaturated(true); r.name:SetAlpha(0.55); r.range:SetTextColor(0.55, 0.57, 0.6)
                elseif now then r.range:SetTextColor(0.4, 0.88, 0.48)
                else r.range:SetTextColor(1, 0.82, 0) end
            end
            r:Show()
        else
            r.entry = nil
            r:Hide()
        end
    end
    if view == "mats" and #list == 0 then guide.rank:SetText(guide.rank:GetText() .. "\n|cff66e07a" .. L("sk_mats_none") .. "|r") end
end

-- вид «Рецепты»: что можно сделать на навыке, реагенты, где взять рецепт
function K:FillRecipes(p, lv, cur, scroll)
    guide.recSeg:Show(); guide.recSeg:Refresh()
    local filter = K.recFilter or "now"
    local list, known, total, learnable = buildRecipes(p, cur, filter)
    local lines = { L("rc_sum", known, total, learnable) }
    if not hasCache(p.key) then lines[#lines + 1] = "|cffff9a40" .. L("rc_sum_nocache") .. "|r" end
    if #list == 0 then lines[#lines + 1] = "|cff9aa0a8" .. L("rc_none") .. "|r" end
    local textTop = -134
    guide.rank:ClearAllPoints(); guide.rank:SetPoint("TOPLEFT", 16, textTop); guide.rank:SetPoint("RIGHT", -16, 0)
    guide.rank:SetText(table.concat(lines, "\n"))
    local rh = (guide.rank.GetStringHeight and guide.rank:GetStringHeight()) or 24
    if type(rh) ~= "number" then rh = 24 end
    local top = textTop - rh - 8
    guide.sep:ClearAllPoints()
    guide.sep:SetPoint("TOPLEFT", 16, top); guide.sep:SetPoint("TOPRIGHT", -16, top)
    local h = guide:GetHeight() or 0
    local vis = (type(h) == "number" and h > 0) and math.max(3, math.min(ROWS, math.floor((h + top - 6 - 34) / ROW_H))) or 8
    if scroll then
        guide.offset = 0
        if filter ~= "now" then
            for i, e in ipairs(list) do if e.rec[4] >= cur - 5 then guide.offset = math.max(0, i - 2) break end end
        end
    end
    guide.offset = math.max(0, math.min(guide.offset or 0, #list - vis))
    if guide.sb then
        guide.sb:ClearAllPoints()
        guide.sb:SetPoint("TOPRIGHT", guide, "TOPRIGHT", -3, top - 6)
        guide.sb:SetHeight(vis * ROW_H - 4)
        guide.sb:Update(guide.offset, #list, vis)
    end
    for i = 1, ROWS do
        local r = guide.rows[i]
        local e = i <= vis and list[i + guide.offset]
        r.cur:Hide(); r.check:Hide(); r.icon:SetDesaturated(false); r.name:SetAlpha(1)
        if e then
            local rec = e.rec
            r.entry = e
            r:ClearAllPoints(); r:SetPoint("TOPLEFT", 12, top - 6 - (i - 1) * ROW_H)
            local cr, cg, cb = recColor(rec, cur)
            r.range:SetText(tostring(rec[4])); r.range:SetTextColor(cr, cg, cb)
            r.icon:SetTexture(recIcon(rec, p))
            local qty = (rec[3] and rec[3] > 1) and ("  |cff9aa0a8×" .. rec[3] .. "|r") or ""
            r.name:SetText(hexOf(cr, cg, cb) .. recTitle(rec) .. "|r" .. qty)
            r.sub:SetText(srcShort(recSource(rec)))
            if e.known then r.check:Show()
            elseif rec[4] <= cur then r.cur:Show() end
            r:Show()
        else
            r.entry = nil
            r:Hide()
        end
    end
end


---------------------------------------------------------------------------
-- «Начать прокачку»: маленькое окно, которое ведёт по шагам само
---------------------------------------------------------------------------
local MAXM = 7

local function isVendorItem(id)
    local D = (rawget(_G, "QuestCompassDataLib") or rawget(_G, "LibQuestieDB"))
    local v = D and D.Item and D.Item.vendors and safe(D.Item.vendors, id)
    return type(v) == "table" and #v > 0
end

local function createTracker(parent, W)
    S = FG.Style
    local tr = CreateFrame("Frame", nil, parent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    tr:SetSize(W, 200)
    tr.W = W
    -- рамка как у блоков подземелья в основной панели
    if S:IsPaper() then
        S:Backdrop(tr, 0.92)
    elseif tr.SetBackdrop then
        tr:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
        tr:SetBackdropColor(0, 0, 0, 0.92)
        tr:SetBackdropBorderColor(0.62, 0.62, 0.62, 1)
    else
        S:Box(tr, 4, { 0, 0, 0, 0.92 }, { 0.5, 0.5, 0.5, 1 })
    end
    -- шапка с золотой полосой
    tr.head = tr:CreateTexture(nil, "ARTWORK")
    tr.head:SetTexture("Interface\\QuestFrame\\UI-QuestLogTitleHighlight")
    if S:IsPaper() then tr.head:SetBlendMode("BLEND"); tr.head:SetVertexColor(0.42, 0.27, 0.1, 0.25)
    else tr.head:SetBlendMode("ADD"); tr.head:SetVertexColor(1, 0.75, 0, 0.3) end
    tr.head:SetPoint("TOPLEFT", 4, -4); tr.head:SetPoint("TOPRIGHT", -4, -4); tr.head:SetHeight(36)
    local close = S:Close(tr, function() K:StopTrack() end)
    close:SetSize(18, 18); close:SetPoint("TOPRIGHT", -6, -6)
    S:Tip(close, nil, "sk_tr_stop_tip")
    tr.icon = tr:CreateTexture(nil, "OVERLAY")
    tr.icon:SetSize(28, 28); tr.icon:SetPoint("TOPLEFT", 8, -8)
    tr.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    tr.title = S:Text(tr, "label", { 1, 0.82, 0, 1 })
    tr.title:SetPoint("TOPLEFT", tr.icon, "TOPRIGHT", 8, -1); tr.title:SetPoint("RIGHT", close, "LEFT", -60, 0)
    tr.title:SetWordWrap(false)
    tr.lvl = S:Text(tr, "small", S.c.text)
    tr.lvl:SetPoint("RIGHT", close, "LEFT", -6, 0); tr.lvl:SetJustifyH("RIGHT")
    local bt = S.Tex(tr, "ARTWORK", { 1, 1, 1, 0.1 })
    bt:SetHeight(4); bt:SetPoint("BOTTOMLEFT", tr.icon, "BOTTOMRIGHT", 8, 0); bt:SetPoint("RIGHT", -10, 0)
    tr.barW = W - 8 - 28 - 8 - 10
    tr.bar = S.Tex(tr, "OVERLAY", { 1, 0.82, 0, 0.9 })
    tr.bar:SetHeight(4); tr.bar:SetPoint("TOPLEFT", bt, "TOPLEFT")
    -- что делать сейчас
    tr.now = S:Text(tr, "label", S.c.text)
    tr.now:SetPoint("TOPLEFT", 10, -46); tr.now:SetPoint("RIGHT", -10, 0)
    tr.now:SetSpacing(2)
    tr.sub = S:Text(tr, "small", S.c.muted)
    tr.sub:SetPoint("TOPLEFT", tr.now, "BOTTOMLEFT", 0, -3); tr.sub:SetPoint("RIGHT", -10, 0)
    tr.sub:SetSpacing(2)
    -- «нужно с собой»: крупные значки (удочка, наживка, кирка...) с отметкой есть/нет
    tr.thead = S:Text(tr, "small", S.c.accent)
    tr.tools = {}
    for i = 1, 4 do
        local b = CreateFrame("Button", nil, tr)
        b:SetSize(30, 30)
        b.icon = b:CreateTexture(nil, "ARTWORK"); b.icon:SetAllPoints(); b.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        b.edge = b:CreateTexture(nil, "BACKGROUND"); b.edge:SetPoint("TOPLEFT", -2, 2); b.edge:SetPoint("BOTTOMRIGHT", 2, -2)
        b.edge:SetColorTexture(0.3, 0.3, 0.3, 1)
        b.mark = b:CreateTexture(nil, "OVERLAY"); b.mark:SetSize(14, 14); b.mark:SetPoint("BOTTOMRIGHT", 4, -4)
        b.name = S:Text(tr, "small", S.c.text); b.name:SetPoint("LEFT", b, "RIGHT", 6, 0); b.name:SetWordWrap(false)
        b:SetScript("OnEnter", function(self)
            if not self.id then return end
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            pcall(GameTooltip.SetItemByID, GameTooltip, self.id)
            GameTooltip:AddLine(self.tipLine or "", 1, 1, 1, true)
            if not self.have then GameTooltip:AddLine(L("ah_click"), 0.4, 0.88, 0.48, true) end
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        b:SetScript("OnClick", function(self) if self.id and not self.have then FG:AHSearch(self.id, itemName(self.id)) end end)
        b:Hide(); b.name:Hide()
        tr.tools[i] = b
    end
    tr.mhead = S:Text(tr, "small", S.c.accent)
    tr.mats = {}
    for i = 1, MAXM do
        local r = CreateFrame("Button", nil, tr)
        r:SetSize(W - 20, 18)
        r.hl = S:GoldBar(r, 0.25); r.hl:Hide()
        -- клик по материалу — найти его на аукционе
        r:SetScript("OnClick", function(self) if self.itemId then FG:AHSearch(self.itemId, itemName(self.itemId)) end end)
        r:SetScript("OnEnter", function(self)
            self.hl:Show()
            if not self.itemId then return end
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            pcall(GameTooltip.SetItemByID, GameTooltip, self.itemId)
            GameTooltip:AddLine(L("ah_click"), 0.4, 0.88, 0.48, true)
            GameTooltip:Show()
        end)
        r:SetScript("OnLeave", function(self) self.hl:Hide(); GameTooltip:Hide() end)
        r.icon = r:CreateTexture(nil, "ARTWORK"); r.icon:SetSize(16, 16); r.icon:SetPoint("LEFT", 0, 0)
        r.name = S:Text(r, "small", S.c.text); r.name:SetPoint("LEFT", r.icon, "RIGHT", 6, 0); r.name:SetWordWrap(false)
        r.cnt = S:Text(r, "small", S.c.text); r.cnt:SetPoint("RIGHT", 0, 0); r.cnt:SetJustifyH("RIGHT")
        r.name:SetPoint("RIGHT", r.cnt, "LEFT", -6, 0)
        tr.mats[i] = r
    end
    tr.next = S:Text(tr, "small", S.c.muted)
    tr.next:SetSpacing(2)
    -- клик по блоку — открыть гайд этой профессии
    tr:EnableMouse(true)
    tr:Hide()
    return tr
end

function K.HideBlock() if tr then tr:Hide() end end

-- что нужно иметь с собой: { {варианты ID}, с навыка, до навыка, необязательно }
local TOOLS = {
    fishing = { { { 6256, 6365, 6366, 6367, 12225, 19022, 19970 } },
        { { 6529 }, 1, 50, true }, { { 6530, 6529 }, 50, 100, true }, { { 6533, 6532, 7307, 6530 }, 100, 301, true } },
    mining = { { { 2901, 756, 778, 1819, 1959, 9465, 20723 } } },
    skinning = { { { 7005, 12709, 19901 } } },
    blacksmithing = { { { 5956 } } },
    engineering = { { { 6219 } }, { { 5956 }, 50, 301 }, { { 10498 }, 175, 301 } },
    enchanting = { { { 6218 }, 1, 100 }, { { 6339 }, 100, 155 }, { { 11130 }, 155, 200 }, { { 11145 }, 200, 285 }, { { 16207 }, 285, 301 } },
    cooking = { { { 4471 }, 1, 301, true } },
}
local function hasItem(id)
    if (itemCount(id) or 0) > 0 then return true end
    local eq = rawget(_G, "IsEquippedItem") or (C_Item and C_Item.IsEquippedItem)
    return eq and safe(eq, id) and true or false
end
-- что взять с собой: { id, have, optional }; первым в списке — лучший вариант
local function toolsList(key, cur)
    local out = {}
    for _, t in ipairs(TOOLS[key] or {}) do
        local a, b = t[2] or 0, t[3] or 999
        if cur >= a and cur < b then
            local have
            for _, id in ipairs(t[1]) do if hasItem(id) then have = id break end end
            out[#out + 1] = { id = have or t[1][1], best = t[1][1], have = have and true or false, opt = t[4] }
        end
    end
    return out
end

-- строка «куда ведёт стрелка»
local function navLine()
    local gi = K.gatherInfo
    if not (gi and gi.name) then return "" end
    local txt = gi.why and L(gi.why, gi.name, gi.item) or L("sk_arrow_to", gi.name)
    local nt = FG.navTarget
    if nt and nt.gather and FG.UI and FG.UI.Navigate then
        local ok, d = pcall(FG.UI.Navigate, FG.UI, nt)
        if ok and type(d) == "number" then gi.dist = d end
    end
    return "\n|cffffd100" .. txt .. (gi.dist and gi.dist < 1e6 and ("  |cff9aa0a8" .. L("yards", math.floor(gi.dist + 0.5)) .. "|r") or "") .. "|r"
end

-- блок прокачки (в отдельном окне); возвращает высоту (0 — нет блока)
function K:PanelBlock(parent, x, y, W)
    local key = FG.cdb and FG.cdb.profTrack
    local p = key and profByKey(key)
    if not p then if tr then tr:Hide() end return 0 end
    if not tr or tr:GetParent() ~= parent or tr.W ~= W then if tr then tr:Hide() end tr = createTracker(parent, W) end
    local lv = K:Levels()[key]
    local cur = lv and math.max(0, lv.rank) or 0
    local maxS = lv and lv.max or 0
    tr.icon:SetTexture(p.icon)
    tr.title:SetText(L("sk_tr_head", ru() and p.ru or p.en))
    tr.lvl:SetText(lv and lv.rank >= 0 and (cur .. " / " .. maxS) or L("sk_not_learned"))
    tr.bar:SetWidth(math.max(1, tr.barW * math.min(1, cur / 300)))
    local nextR
    for _, r in ipairs(p.ranks or {}) do if not lv or RANK_MAX[r[1]] > maxS then nextR = r break end end
    local step, stepI
    for i, st in ipairs(p.steps or {}) do if not st.alt and cur < st.b then step, stepI = st, i break end end
    local now, sub, mats = "", "", nil
    local capped = lv and nextR and cur >= maxS and maxS > 0
    if not lv then
        now = "|cffffd100" .. L("sk_tr_learn", ru() and p.ru or p.en) .. "|r"
        sub = L("sk_learn_where") .. navLine()
    elseif capped then
        local ok = (UnitLevel("player") or 1) >= nextR[3]
        now = (ok and "|cff66e07a" or "|cffff9a40") .. L("sk_tr_cap", maxS, L("rank_" .. nextR[1])) .. "|r"
        sub = (ok and "" or (L("sk_tr_needlvl", nextR[3]) .. "\n")) .. (pick(nextR[4]) or "") .. navLine()
    elseif step then
        if step.gather then
            now = "|cff66e07a" .. L("sk_now") .. "|r " .. stepTitle(step)
            sub = L("sk_where") .. " " .. zonesFor(step) .. (step.note and ("\n|cff66e07a" .. pick(step.note) .. "|r") or "")
            sub = sub .. navLine()
        else
            local nm = step.item and itemName(step.item) or pick(step.name) or "?"
            local left = remaining(step, cur)
            now = "|cff66e07a" .. L("sk_now") .. "|r " .. L("sk_tr_make", left, nm)
            sub = L("sk_tr_until", step.b) .. (step.note and ("\n|cff66e07a" .. pick(step.note) .. "|r") or "")
            mats = {}
            local ready = true
            for _, m in ipairs(step.mats or {}) do
                mats[#mats + 1] = { m[1], m[2] * left }
                if (itemCount(m[1]) or 0) < m[2] * left then ready = false end
            end
            if ready and #mats > 0 then sub = sub .. "\n|cff66e07a" .. L("sk_tr_ready") .. "|r" else sub = sub .. navLine() end
        end
    else
        now = "|cff66e07a" .. L("sk_done") .. "|r"
    end
    tr.now:SetText(now); tr.sub:SetText(sub)
    local function sh(fs) local h = fs.GetStringHeight and fs:GetStringHeight() or 14 if type(h) ~= "number" then h = 14 end return h end
    local yy = -46 - sh(tr.now) - 3 - ((sub ~= "" and sh(tr.sub)) or 0) - 8
    -- значки «нужно с собой»
    local tl = lv and toolsList(key, cur) or {}
    for i = 1, 4 do tr.tools[i]:Hide(); tr.tools[i].name:Hide() end
    if #tl > 0 then
        tr.thead:ClearAllPoints(); tr.thead:SetPoint("TOPLEFT", 10, yy)
        tr.thead:SetText(L("sk_tools")); tr.thead:Show()
        yy = yy - 18
        for i, t in ipairs(tl) do
            local b = tr.tools[i]
            if not b then break end
            b.id, b.have = t.id, t.have
            b.icon:SetTexture(itemIcon(t.id) or "Interface\\Icons\\INV_Misc_QuestionMark")
            b.icon:SetDesaturated(not t.have)
            if t.have then b.edge:SetColorTexture(0.25, 0.7, 0.25, 1); b.mark:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready")
            elseif t.opt then b.edge:SetColorTexture(0.6, 0.5, 0.3, 1); b.mark:SetTexture(nil)
            else b.edge:SetColorTexture(0.8, 0.2, 0.2, 1); b.mark:SetTexture("Interface\\RaidFrame\\ReadyCheck-NotReady") end
            local st = t.have and ("|cff66e07a" .. L("sk_tool_have") .. "|r")
                or (t.opt and ("|cff9aa0a8" .. L("sk_tool_best") .. "|r"))
                or ("|cffff7070" .. L("sk_tool_need") .. (isVendorItem(t.id) and (", " .. L("sk_tr_vendor")) or "") .. "|r")
            b.tipLine = st
            b:ClearAllPoints(); b:SetPoint("TOPLEFT", 12, yy)
            b.name:SetText(itemName(t.id) .. "\n" .. st)
            b.name:SetPoint("RIGHT", tr, "RIGHT", -10, 0)
            b:Show(); b.name:Show()
            yy = yy - 36
        end
        yy = yy - 2
    else
        tr.thead:Hide()
    end
    for i = 1, MAXM do tr.mats[i]:Hide() end
    if mats and #mats > 0 then
        tr.mhead:ClearAllPoints(); tr.mhead:SetPoint("TOPLEFT", 10, yy)
        tr.mhead:SetText(L("sk_tr_buy")); tr.mhead:Show()
        yy = yy - 16
        for i, m in ipairs(mats) do
            local r = tr.mats[i]
            if not r then break end
            local have = itemCount(m[1]) or 0
            local ok = have >= m[2]
            r:ClearAllPoints(); r:SetPoint("TOPLEFT", 10, yy)
            r.itemId = m[1]
            r.icon:SetTexture(itemIcon(m[1]) or "Interface\\Icons\\INV_Misc_QuestionMark")
            local vend = (not ok and isVendorItem(m[1])) and ("  |cff9aa0a8" .. L("sk_tr_vendor") .. "|r") or ""
            r.name:SetText(itemName(m[1]) .. vend)
            r.cnt:SetText((ok and "|cff66e07a" or "|cffff7070") .. have .. " / " .. m[2] .. "|r")
            r:Show()
            yy = yy - 18
        end
        yy = yy - 4
    else
        tr.mhead:Hide()
    end
    local nx
    if lv and step and stepI then
        for i = stepI + 1, #(p.steps or {}) do
            local st = p.steps[i]
            if not st.alt then nx = st break end
        end
    end
    local nextLines = {}
    if capped and step then nx = step end
    if not capped and lv and nextR and step and step.b > maxS then
        nextLines[#nextLines + 1] = "|cffb88fff" .. L("sk_tr_at", maxS, L("sk_train", L("rank_" .. nextR[1]))) .. "|r"
    end
    if nx then
        local t = nx.gather and stepTitle(nx) or ((nx.item and itemName(nx.item) or pick(nx.name) or "?") .. " ×" .. nx.n)
        nextLines[#nextLines + 1] = L("sk_tr_next", nx.a, nx.b, t)
    end
    if #nextLines > 0 then
        tr.next:ClearAllPoints(); tr.next:SetPoint("TOPLEFT", 10, yy); tr.next:SetPoint("RIGHT", -10, 0)
        tr.next:SetText(table.concat(nextLines, "\n")); tr.next:Show()
        yy = yy - sh(tr.next) - 4
    else
        tr.next:Hide()
    end
    local h = -yy + 8
    tr:SetHeight(h)
    tr:ClearAllPoints(); tr:SetPoint("TOPLEFT", parent, "TOPLEFT", x, -y); tr:SetWidth(W)
    tr:Show()
    K.block = tr
    return h
end

-- обновить основную панель (блок прокачки рисуется в ней)
function K:UpdateTracker()
    skillT = -1
    if guide and guide:IsVisible() then K:FillGuide() end
    refresh()
    if FG.Tracker then FG.Tracker:Update() end
end


---------------------------------------------------------------------------
-- Сбор (травы, руда, шкуры, рыба): стрелка ведёт к лучшему месту сейчас
---------------------------------------------------------------------------
-- объекты базы (жилы и травы): название -> ID, мин. навык
local NODES = {
    ["Copper Vein"] = { { 1731, 2055, 3763, 103713 }, 1 }, ["Tin Vein"] = { { 1732, 2054, 3764, 103711 }, 65 },
    ["Silver Vein"] = { { 1733, 105569 }, 75 }, ["Iron Deposit"] = { { 1735 }, 125 }, ["Gold Vein"] = { { 1734, 150080 }, 155 },
    ["Mithril Deposit"] = { { 2040, 150079, 176645 }, 175 }, ["Truesilver Deposit"] = { { 2047, 150081 }, 230 },
    ["Small Thorium Vein"] = { { 324, 150082, 176643 }, 230 }, ["Rich Thorium Vein"] = { { 175404 }, 255 },
    ["Peacebloom"] = { { 1618, 3724 }, 1 }, ["Silverleaf"] = { { 1617, 3725 }, 1 }, ["Earthroot"] = { { 1619, 3726 }, 15 },
    ["Mageroyal"] = { { 1620, 3727 }, 50 }, ["Briarthorn"] = { { 1621, 3729 }, 70 }, ["Stranglekelp"] = { { 2045 }, 85 },
    ["Bruiseweed"] = { { 1622, 3730 }, 100 }, ["Wild Steelbloom"] = { { 1623 }, 115 }, ["Kingsblood"] = { { 1624 }, 125 },
    ["Liferoot"] = { { 2041 }, 150 }, ["Fadeleaf"] = { { 2042 }, 160 }, ["Goldthorn"] = { { 2046 }, 170 },
    ["Khadgar's Whisker"] = { { 2043 }, 185 }, ["Firebloom"] = { { 2866 }, 205 }, ["Purple Lotus"] = { { 142140, 180165 }, 210 },
    ["Sungrass"] = { { 142142, 176636, 180164 }, 230 }, ["Ghost Mushroom"] = { { 142144 }, 245 }, ["Gromsblood"] = { { 142145, 176637 }, 250 },
    ["Golden Sansam"] = { { 176583, 176638, 180167 }, 260 }, ["Dreamfoil"] = { { 176584, 176639, 180168 }, 270 },
    ["Mountain Silversage"] = { { 176586, 176640, 180166 }, 280 }, ["Plaguebloom"] = { { 176587, 176641 }, 285 },
}
-- руда -> жилы
local ORE = { ["Copper Ore"] = { "Copper Vein" }, ["Tin Ore"] = { "Tin Vein" }, ["Silver Ore"] = { "Silver Vein" },
    ["Iron Ore"] = { "Iron Deposit" }, ["Gold Ore"] = { "Gold Vein" }, ["Mithril Ore"] = { "Mithril Deposit" },
    ["Truesilver Ore"] = { "Truesilver Deposit" }, ["Thorium Ore"] = { "Small Thorium Vein", "Rich Thorium Vein" } }

local visited = {}      -- точки, где уже собрали: { m, x, y, t }
local VISIT_YD, RESPAWN = 25, 300

local function nodeNamesFor(step, cur)
    local out = {}
    for _, iid in ipairs(step.gather or {}) do
        local en = FG:EnName("Item", iid)
        for _, nm in ipairs(ORE[en or ""] or { en }) do
            local n = NODES[nm or ""]
            if n and cur >= n[2] then out[#out + 1] = nm end
        end
    end
    return out
end

local function isVisited(p)
    local now = GetTime and GetTime() or 0
    for i = #visited, 1, -1 do
        local v = visited[i]
        if now - v.t > RESPAWN then table.remove(visited, i)
        elseif v.m == p[1] and math.abs(v.x - p[2]) < 0.004 and math.abs(v.y - p[3]) < 0.004 then return true end
    end
end

-- ближайшая точка сбора: {m, x, y, name} и дистанция
local function bestNode(step, cur)
    local A = FG.Advisor
    if not (A and A.SpawnPoints and A.Nearest) then return end
    local pm, px, py = FG:GetPlayerPos()
    if not px then return end
    local w, h = FG:MapSize(pm)
    if not w then return end
    local best, bestD, bestName
    for _, nm in ipairs(nodeNamesFor(step, cur)) do
        for _, oid in ipairs(NODES[nm][1]) do
            local pts = {}
            for _, p in ipairs(A.SpawnPoints("o", oid) or {}) do if not isVisited(p) then pts[#pts + 1] = p end end
            if #pts > 0 then
                local d, p = A.Nearest(pts, pm, px, py, w, h)
                if d and (not bestD or d < bestD) then best, bestD, bestName = p, d, nm end
            end
        end
    end
    return best, bestD, bestName
end

-- зоны (для шкур и рыбы): центр ближайшей рекомендованной зоны
local zoneMaps
local function mapForZone(en)
    if not zoneMaps then
        zoneMaps = {}
        local function walk(id, depth)
            if depth > 3 or not (C_Map and C_Map.GetMapChildrenInfo) then return end
            local ok, kids = pcall(C_Map.GetMapChildrenInfo, id)
            if not ok or type(kids) ~= "table" then return end
            for _, k in ipairs(kids) do
                if k.name then zoneMaps[k.name] = zoneMaps[k.name] or k.mapID end
                walk(k.mapID, depth + 1)
            end
        end
        walk(1414, 0); walk(1415, 0)
    end
    return zoneMaps[en] or zoneMaps[(FG.RuZones and FG.RuZones[en]) or ""]
end
-- рыбалка: точка на воде в рекомендованных зонах (центр зоны часто в горах)
local FISH_SPOTS = {
    ["Elwynn Forest"] = { 0.515, 0.645 }, ["Dun Morogh"] = { 0.345, 0.465 }, ["Teldrassil"] = { 0.56, 0.61 },
    ["Durotar"] = { 0.63, 0.80 }, ["Mulgore"] = { 0.445, 0.60 }, ["Tirisfal Glades"] = { 0.65, 0.47 },
    ["Stormwind City"] = { 0.58, 0.57 }, ["Westfall"] = { 0.295, 0.46 }, ["Loch Modan"] = { 0.50, 0.30 },
    ["The Barrens"] = { 0.64, 0.38 }, ["Silverpine Forest"] = { 0.59, 0.47 },
    ["Dustwallow Marsh"] = { 0.72, 0.40 }, ["Stranglethorn Vale"] = { 0.27, 0.77 }, ["Wetlands"] = { 0.06, 0.60 },
    ["Desolace"] = { 0.21, 0.72 }, ["Feralas"] = { 0.30, 0.45 }, ["Tanaris"] = { 0.74, 0.45 },
    ["The Hinterlands"] = { 0.79, 0.64 }, ["Un'Goro Crater"] = { 0.32, 0.50 },
}
local function bestZone(step)
    local pm, px, py = FG:GetPlayerPos()
    local z = (FG.cdb.faction or (UnitFactionGroup and UnitFactionGroup("player"))) == "Horde" and step.zH or step.zA
    local best, bestD, bestName
    for _, en in ipairs(z or {}) do
        local m = mapForZone(en)
        if m then
            local d = 1e9
            if pm and px then
                if m == pm then d = 0 else
                    local cx, cy = FG:ConvertPos(m, 0.5, 0.5, pm)
                    local w, h = FG:MapSize(pm)
                    if cx and w then d = math.sqrt(((cx - px) * w) ^ 2 + ((cy - py) * h) ^ 2) end
                end
            end
            local spot = (FG.cdb.profTrack == "fishing") and FISH_SPOTS[en] or nil
            if spot and pm and px and m ~= pm then
                local cx, cy = FG:ConvertPos(m, spot[1], spot[2], pm)
                local w, h = FG:MapSize(pm)
                if cx and w then d = math.sqrt(((cx - px) * w) ^ 2 + ((cy - py) * h) ^ 2) end
            end
            if not bestD or d < bestD then best, bestD, bestName = { m, spot and spot[1] or 0.5, spot and spot[2] or 0.5 }, d, en end
        end
    end
    return best, bestD, bestName
end

K.gatherInfo = nil
-- ремесло: стрелка к торговцу недостающего материала, на аукцион или к учителю
local lastCraft, craftAcc = nil, 99
local function vendorsOf(id)
    local D = (rawget(_G, "QuestCompassDataLib") or rawget(_G, "LibQuestieDB"))
    local v = D and D.Item and D.Item.vendors and safe(D.Item.vendors, id)
    return type(v) == "table" and v or nil
end
local function craftTick(p, force)
    local N = FG.Nearby
    if not (N and N.NearestNpc) then return end
    local nt = FG.navTarget
    if nt and not nt.gather then return end -- стрелка занята другой целью
    craftAcc = craftAcc + 1.5
    if not force and craftAcc < 6 then return end
    craftAcc = 0
    local lv = K:Levels()[p.key]
    local cur = lv and math.max(0, lv.rank) or 0
    local nextR
    for _, r in ipairs(p.ranks or {}) do if not lv or RANK_MAX[r[1]] > (lv.max or 0) then nextR = r break end end
    local step
    for _, st in ipairs(p.steps or {}) do if not st.alt and cur < st.b then step = st break end end
    local best, why, item
    if not lv or (nextR and lv.max and cur >= lv.max and lv.max > 0) then
        best = N:NearestNpc(N.ProfTest(p.key)); why = "sk_go_trainer"
    elseif step and not step.gather then
        local left = remaining(step, cur)
        for _, m in ipairs(step.mats or {}) do
            if (itemCount(m[1]) or 0) < m[2] * left then
                local v = vendorsOf(m[1])
                if v then best = N:NearestNpc(nil, v); why = "sk_go_vendor" end
                if not best then best = N:NearestNpc(N.AuctionTest); why = "sk_go_ah" end
                item = itemName(m[1])
                break
            end
        end
    end
    if not best then
        K.gatherInfo = nil
        if nt and nt.gather then FG:SetNavTarget(nil) end
        lastCraft = nil
        return
    end
    local pt = best.p
    K.gatherInfo = { name = best.name, dist = best.dist, why = why, item = item }
    local sig = best.id .. ":" .. tostring(item)
    -- уже дошли до этой цели (стрелка сама сброшена) — не ставим её снова
    if not nt and lastCraft == sig then return end
    lastCraft = sig
    if not (nt and nt.gather and nt.m == pt[1] and math.abs(nt.x - pt[2]) < 0.0001 and math.abs(nt.y - pt[3]) < 0.0001) then
        FG:SetNavTarget({ m = pt[1], x = pt[2], y = pt[3], t = best.name, k = "n", gather = true })
    end
end

local function gatherTick()
    local key = FG.cdb and FG.cdb.profTrack
    local p = key and profByKey(key)
    local nt = FG.navTarget
    if p and p.kind ~= "gather" and not K.gatherPaused then return craftTick(p) end
    if not p or p.kind ~= "gather" or K.gatherPaused then
        if nt and nt.gather then FG:SetNavTarget(nil) end
        K.gatherInfo = nil
        return
    end
    if nt and not nt.gather then return end -- стрелка занята целью из «Спутника»
    local lv = K:Levels()[key]
    local cur = lv and math.max(0, lv.rank) or 0
    local step
    for _, st in ipairs(p.steps or {}) do if cur < st.b then step = st break end end
    if not step or not lv then return end
    -- дошли до точки — запоминаем и ищем следующую
    if nt and nt.gather and nt.node then
        local dist = FG.UI and FG.UI.Navigate and FG.UI:Navigate(nt)
        if dist and dist <= VISIT_YD then
            visited[#visited + 1] = { m = nt.m, x = nt.x, y = nt.y, t = GetTime() }
            nt = nil
        end
    end
    local pt, d, name, isNode
    if key == "mining" or key == "herbalism" then
        pt, d, name = bestNode(step, cur); isNode = true
    end
    if not pt then pt, d, name = bestZone(step); isNode = false end
    if not pt then
        if nt and nt.gather then FG:SetNavTarget(nil) end
        K.gatherInfo = nil
        return
    end
    local label = isNode and name or FG:TrZone(name)
    if isNode then
        -- название жилы/травы на языке интерфейса
        local D = (rawget(_G, "QuestCompassDataLib") or rawget(_G, "LibQuestieDB"))
        local oid = NODES[name] and NODES[name][1][1]
        if oid and FG:Lang() == "ru" then label = FG:TrObject(oid, name) or name end
    end
    K.gatherInfo = { name = label, dist = d, node = isNode }
    if not (nt and nt.gather and nt.m == pt[1] and math.abs(nt.x - pt[2]) < 0.0001 and math.abs(nt.y - pt[3]) < 0.0001) then
        FG:SetNavTarget({ m = pt[1], x = pt[2], y = pt[3], t = label, k = "o", gather = true, node = isNode })
    end
end
local gAcc = 0
local gFrame = CreateFrame("Frame")
gFrame:SetScript("OnUpdate", function(_, dt)
    gAcc = gAcc + dt
    if gAcc < 1.5 then return end
    gAcc = 0
    pcall(gatherTick)
    if FG.cdb and FG.cdb.profTrack and FG.Tracker then pcall(FG.Tracker.Update, FG.Tracker) end
end)
function K:GatherNow() gAcc = 99; craftAcc = 99; lastCraft = nil end
K._gatherTick = gatherTick

function K:StartTrack(key)
    FG.cdb.profTrack = key
    K.gatherPaused = nil
    K.gatherInfo = nil
    if FG.navTarget then FG:SetNavTarget(nil) end
    K:GatherNow()
    K:UpdateTracker()
    if FG.Go then FG.Go:Open("prof") end
end
function K:StopTrack()
    FG.cdb.profTrack = nil
    K.gatherInfo = nil
    if FG.navTarget and FG.navTarget.gather then FG:SetNavTarget(nil) end
    if tr then tr:Hide() end
    if guide and guide:IsVisible() then K:FillGuide() end
    refresh()
    if FG.Tracker then FG.Tracker:Update() end
end

local trPending
local function trSoon()
    if not (FG.cdb and FG.cdb.profTrack) or trPending then return end
    trPending = true
    C_Timer.After(0.3, function() trPending = nil; K:UpdateTracker() end)
end
-- «Ваш навык … повысился до N» — запоминаем навык (нужно, когда игра не отдаёт его напрямую)
FG:On("CHAT_MSG_SKILL", function(_, msg)
    if type(msg) ~= "string" or not FG.cdb then return end
    local n = tonumber(msg:match("(%d+)%D*$"))
    if not n then return end
    local key
    local low = norm(msg)
    for name, k in pairs(nameMap()) do if name ~= "" and low:find(name, 1, true) then key = k break end end
    if not key then return end
    FG.cdb.skillSeen = type(FG.cdb.skillSeen) == "table" and FG.cdb.skillSeen or {}
    local old = FG.cdb.skillSeen[key]
    FG.cdb.skillSeen[key] = { rank = n, max = old and old.max or 0 }
    skillT = -1
end)
FG:On("SKILL_LINES_CHANGED", trSoon)
FG:On("BAG_UPDATE_DELAYED", trSoon)
FG:On("CHAT_MSG_SKILL", trSoon)
FG:On("PLAYER_LEVEL_UP", trSoon)
FG:On("GET_ITEM_INFO_RECEIVED", trSoon)
FG:On("PLAYER_ENTERING_WORLD", function() C_Timer.After(2, function() if FG.cdb and FG.cdb.profTrack then K:UpdateTracker() end end) end)

function K:OpenTracked()
    local k = FG.cdb.profTrack
    if not k then return end
    if guide and guide:IsShown() and K.sel == k then return end
    K:Open(k)
end

function K:Open(key)
    if not guide then createGuide() end
    if guide:IsShown() and K.sel == key then guide:Hide() return end
    K.sel = key
    if not guide:IsShown() then guide:Show() end
    K:FillGuide(true); refresh()
end

FG:On("SKILL_LINES_CHANGED", function() skillT = -1; refresh() end)
FG:On("PLAYER_ENTERING_WORLD", function() skillT = -1 end)
FG:On("LEARNED_SPELL_IN_TAB", function() skillT = -1; refresh() end)
FG:On("BAG_UPDATE_DELAYED", function() if guide and guide:IsVisible() then K:FillGuide() end end)
