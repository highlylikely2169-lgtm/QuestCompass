-- QuestCompass: автоматическое взятие и сдача квестов, выбор награды
-- Зажатый Shift при разговоре с NPC отключает автоматику.
local _, ns = ...
local FG = ns.FG
local AQ = { warned = {} }
FG.AutoQuest = AQ

local function paused() return IsShiftKeyDown() end

-- Нужен ли этот квест (по ID или названию)
function AQ:Wanted(questID, title, isTrivial)
    if not FG.db.autoAccept or paused() then return false end
    if isTrivial then return false end -- серые (слишком лёгкие) квесты не берём
    if questID and FG.cdb.ignored[questID] then return false end
    -- берём только квест, выбранный на панели (подсказка «Взять: …»), остальные — вручную
    return AQ:IsSelected(questID, title)
end

-- Совпадает ли квест с тем, что сейчас выбран на панели
function AQ:IsSelected(questID, title)
    local A = FG.Advisor
    local s = A and A.step
    if not s or s.k ~= "a" then return false end
    if questID and s.q and s.q > 0 and questID == s.q then return true end
    -- в Forever у квеста может быть другой номер, чем в базе — сверяем и по названию
    if not title or title == "" then return false end
    local function norm(t) return (t:lower():gsub("^%s+", ""):gsub("%s+$", ""):gsub("%s+", " ")) end
    title = norm(title)
    local names = { s.t, s.mt }
    if s.q and s.q > 0 then
        names[#names + 1] = (FG:TrQuest(s.q))
        local DB = (rawget(_G, "QuestCompassDataLib") or rawget(_G, "LibQuestieDB"))
        if DB and DB.Quest then
            local ok, n = pcall(DB.Quest.name, s.q)
            if ok then names[#names + 1] = n end
        end
    end
    for _, n in pairs(names) do
        if type(n) == "string" and norm(n) == title then return true end
    end
    return false
end

local function canTurnIn() return FG.db.autoTurnIn and not paused() end

---------------------------------------------------------------------------
-- Окно разговора (Gossip)
---------------------------------------------------------------------------
local function gossipQuests()
    local avail, active = {}, {}
    if C_GossipInfo and C_GossipInfo.GetAvailableQuests then
        for i, q in ipairs(C_GossipInfo.GetAvailableQuests() or {}) do
            avail[#avail + 1] = { i = i, id = q.questID, title = q.title, trivial = q.isTrivial }
        end
        for i, q in ipairs(C_GossipInfo.GetActiveQuests() or {}) do
            active[#active + 1] = { i = i, id = q.questID, title = q.title, complete = q.isComplete }
        end
    elseif GetGossipAvailableQuests then
        -- старый API: блоки по 6 (название, уровень, серый, ежедневный, повторяемый, легендарный)
        local a = { GetGossipAvailableQuests() }
        for i = 1, #a, 6 do avail[#avail + 1] = { i = (i + 5) / 6, title = a[i], trivial = a[i + 2] } end
        local b = { GetGossipActiveQuests() }
        for i = 1, #b, 6 do active[#active + 1] = { i = (i + 5) / 6, title = b[i], complete = b[i + 3] } end
    end
    return avail, active
end

local function selectAvailable(q)
    if C_GossipInfo and C_GossipInfo.SelectAvailableQuest then
        C_GossipInfo.SelectAvailableQuest(q.id or q.i)
    elseif SelectGossipAvailableQuest then
        SelectGossipAvailableQuest(q.i)
    end
end

local function selectActive(q)
    if C_GossipInfo and C_GossipInfo.SelectActiveQuest then
        C_GossipInfo.SelectActiveQuest(q.id or q.i)
    elseif SelectGossipActiveQuest then
        SelectGossipActiveQuest(q.i)
    end
end

FG:On("GOSSIP_SHOW", function()
    local avail, active = gossipQuests()
    -- сначала сдаём готовые
    if canTurnIn() then
        for _, q in ipairs(active) do
            local done = q.complete
            if q.id and FG.log[q.id] then done = FG.log[q.id].complete end
            if done then selectActive(q) return end
        end
    end
    -- потом берём нужные
    for _, q in ipairs(avail) do
        if AQ:Wanted(q.id, q.title, q.trivial) then selectAvailable(q) return end
    end
    AQ:Explain(avail)
end)

-- Почему выбранный квест не взялся — пишем в чат один раз на квест
function AQ:Explain(avail)
    local A = FG.Advisor
    local s = A and A.step
    if not s or s.k ~= "a" then return end
    for _, q in ipairs(avail) do
        if AQ:IsSelected(q.id, q.title) then
            local why
            if not FG.db.autoAccept then why = FG.L("aq_off")
            elseif paused() then return
            elseif q.trivial then why = FG.L("aq_trivial")
            elseif q.id and FG.cdb.ignored[q.id] then why = FG.L("aq_ignored") end
            if why and AQ.warned[q.title or q.id] ~= why then
                AQ.warned[q.title or q.id] = why
                FG:Print(why)
            end
            return
        end
    end
    -- выбранного квеста нет в списке, но NPC — тот, у кого брать: сообщим, что видим
    if FG.db.debugAQ then
        local t = {}
        for _, q in ipairs(avail) do t[#t + 1] = tostring(q.id) .. " " .. tostring(q.title) end
        FG:Print("AQ: step " .. tostring(s.q) .. " " .. tostring(s.t) .. " | NPC: " .. table.concat(t, "; "))
    end
end

---------------------------------------------------------------------------
-- Окно приветствия NPC с несколькими квестами (без Gossip)
---------------------------------------------------------------------------
FG:On("QUEST_GREETING", function()
    if canTurnIn() then
        for i = 1, (GetNumActiveQuests() or 0) do
            local title, isComplete = GetActiveTitle(i)
            if isComplete then SelectActiveQuest(i) return end
        end
    end
    for i = 1, (GetNumAvailableQuests() or 0) do
        local title = GetAvailableTitle(i)
        local trivial, id
        if GetAvailableQuestInfo then
            local a, _, _, _, e = GetAvailableQuestInfo(i)
            trivial, id = a, e
        end
        if AQ:Wanted(id, title, trivial) then SelectAvailableQuest(i) return end
    end
end)

---------------------------------------------------------------------------
-- Описание квеста -> принять
---------------------------------------------------------------------------
FG:On("QUEST_DETAIL", function()
    local id = GetQuestID and GetQuestID()
    local title = GetTitleText and GetTitleText()
    if AQ:Wanted(id, title, false) then AcceptQuest()
    else AQ:Explain({ { id = id, title = title } }) end
end)

-- Сопровождение, предложенное другим игроком
FG:On("QUEST_ACCEPT_CONFIRM", function()
    if FG.db.autoAccept and not paused() and ConfirmAcceptQuest then ConfirmAcceptQuest() end
end)

---------------------------------------------------------------------------
-- Сдача
---------------------------------------------------------------------------
FG:On("QUEST_PROGRESS", function()
    if canTurnIn() and IsQuestCompletable() then CompleteQuest() end
end)

local function itemValue(i)
    local link = GetQuestItemLink and GetQuestItemLink("choice", i)
    if not link then return 0 end
    local price = select(11, GetItemInfo(link))
    return price or 0
end

FG:On("QUEST_COMPLETE", function()
    if not canTurnIn() then return end
    local n = GetNumQuestChoices() or 0
    if n <= 1 then
        GetQuestReward(n)
        return
    end
    if not FG.db.autoReward then return end
    local best, bestVal = nil, 0
    for i = 1, n do
        local v = itemValue(i)
        if v > bestVal then best, bestVal = i, v end
    end
    if best then
        local link = GetQuestItemLink("choice", best)
        FG:Print(FG.L("reward_pick", link or "?"))
        GetQuestReward(best)
    else
        FG:Print(FG.L("reward_manual"))
    end
end)
