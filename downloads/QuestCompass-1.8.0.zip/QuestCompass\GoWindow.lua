-- QuestCompass: одно маленькое окно «Идти» — карта (размер меняется) и под ней что делать.
-- Режимы: quest (задания), prof (прокачка профессии), rep (репутация), nearby (Спутник).
local _, ns = ...
local FG = ns.FG
local L = FG.L
local G = {}
FG.Go = G
FG.Tracker = G -- старое имя: профессии и репутация зовут FG.Tracker:Update()

local S
local win
local MINW, MAXW, DEFW = 240, 560, 300
local HEAD = 34
local tiles = {}

local function safe(f, ...) if not f then return nil end local ok, a, b, c = pcall(f, ...) if ok then return a, b, c end end
local function sh(fs) local h = fs.GetStringHeight and fs:GetStringHeight() or 14 if type(h) ~= "number" then h = 14 end return h end
local function strip(s) return (tostring(s or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")) end
local function distText(d)
    if not d or d >= 1e6 then return L("nb_far") end
    if d >= 1000 then return string.format("%.1f", d / 1000) .. " " .. L("nb_kyd") end
    return L("yards", math.floor(d + 0.5))
end

---------------------------------------------------------------------------
-- Карта
---------------------------------------------------------------------------
local function layerInfo(m)
    if not (C_Map and C_Map.GetMapArtLayers) then return end
    local ok, layers = pcall(C_Map.GetMapArtLayers, m)
    if ok and type(layers) == "table" and layers[1] then return layers[1] end
end
local function drawTiles(m, view)
    for _, t in ipairs(tiles) do t:Hide() end
    local li = layerInfo(m)
    local ok, files = false, nil
    if C_Map and C_Map.GetMapArtLayerTextures then ok, files = pcall(C_Map.GetMapArtLayerTextures, m, 1) end
    if not li or not ok or type(files) ~= "table" or #files == 0 then view.empty:Show() return false end
    view.empty:Hide()
    local vw, vh = view:GetWidth(), view:GetHeight()
    local scale = math.min(vw / li.layerWidth, vh / li.layerHeight)
    view.canvas:SetSize(li.layerWidth * scale, li.layerHeight * scale)
    view.canvas:ClearAllPoints(); view.canvas:SetPoint("CENTER")
    local nx = math.ceil(li.layerWidth / li.tileWidth)
    local tw, th = li.tileWidth * scale, li.tileHeight * scale
    for i, fid in ipairs(files) do
        local t = tiles[i]
        if not t then t = view.canvas:CreateTexture(nil, "BACKGROUND"); tiles[i] = t end
        local col, row = (i - 1) % nx, math.floor((i - 1) / nx)
        t:SetTexture(fid); t:SetSize(tw, th)
        t:ClearAllPoints(); t:SetPoint("TOPLEFT", view.canvas, "TOPLEFT", col * tw, -row * th)
        t:Show()
    end
    return true
end
local function placeDot(dot, canvas, x, y)
    if not x or x < 0 or x > 1 or y < 0 or y > 1 then dot:Hide() return false end
    dot:ClearAllPoints()
    dot:SetPoint("CENTER", canvas, "TOPLEFT", x * canvas:GetWidth(), -y * canvas:GetHeight())
    dot:Show()
    return true
end

-- цель стрелки сейчас (для режима «задания» — шаг подсказки)
local function target()
    local nt = FG.navTarget
    if G.mode == "quest" then
        local st = FG.Advisor and FG.Advisor.step
        if nt and not nt.gather and not nt.rep then return nt end
        return st
    end
    if G.mode == "prof" then return (nt and nt.gather) and nt or nil end
    if G.mode == "rep" then return (nt and nt.rep) and nt or nil end
    return nt
end

function G:UpdateInfo()
    if not win or not win:IsShown() or not win.info:IsShown() then return end
    local t = target()
    if not (t and t.m and t.x) then win.info:SetText("") return end
    local dist = FG.UI and FG.UI.Navigate and safe(FG.UI.Navigate, FG.UI, t)
    win.info:SetText("|cffffd100" .. L("nb_dist") .. "|r " .. distText(dist) .. "  |cff9aa0a8" .. FG:MapName(t.m) .. "|r")
end

local function updateMap()
    if not win or not win:IsShown() then return end
    local view = win.view
    if not view:IsShown() then return end
    local t = target()
    if not (t and t.m and t.x) then
        for _, x in ipairs(tiles) do x:Hide() end
        view.empty:Show(); win.pin:Hide(); win.me:Hide()
        for _, d in ipairs(win.dots) do d:Hide() end
        win.info:SetText("")
        return
    end
    local m = t.m
    if win.drawn ~= m then win.hasArt = drawTiles(m, view); win.drawn = m end
    local canvas = view.canvas
    placeDot(win.pin, canvas, t.x, t.y)
    local pm, px, py = FG:GetPlayerPos()
    local mx, my
    if pm and px then mx, my = FG:ConvertPos(pm, px, py, m) end
    local onMap = placeDot(win.me, canvas, mx, my)
    if onMap then
        local f = GetPlayerFacing and GetPlayerFacing()
        if f and win.meTex.SetRotation then win.meTex:SetRotation(f) end
    end
    for _, d in ipairs(win.dots) do d:Hide() end
    if onMap then
        local cw, chh = canvas:GetWidth(), canvas:GetHeight()
        local ax, ay, bx, by = mx * cw, my * chh, t.x * cw, t.y * chh
        local len = math.sqrt((bx - ax) ^ 2 + (by - ay) ^ 2)
        local n = math.min(#win.dots, math.floor(len / 9))
        for i = 1, n do
            local k = i / (n + 1)
            local d = win.dots[i]
            d:ClearAllPoints(); d:SetPoint("CENTER", canvas, "TOPLEFT", ax + (bx - ax) * k, -(ay + (by - ay) * k))
            d:Show()
        end
    end
    local dist = FG.UI and FG.UI.Navigate and safe(FG.UI.Navigate, FG.UI, t)
    local line = "|cffffd100" .. L("nb_dist") .. "|r " .. distText(dist) .. "  |cff9aa0a8" .. FG:MapName(m) .. "|r"
    if not onMap then line = line .. "\n|cff9aa0a8" .. L("nb_offmap") .. "|r" end
    win.info:SetText(line)
end

---------------------------------------------------------------------------
-- Окно
---------------------------------------------------------------------------
local function savePos()
    local a, _, b, x, y = win:GetPoint()
    FG.db.goPos = { a, b, x, y }
end

local function create()
    S = FG.Style
    win = CreateFrame("Frame", "QuestCompassGo", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    win.qcRoot = true
    win:SetSize(FG.db.goW or DEFW, 400)
    win:SetFrameStrata("MEDIUM")
    local pos = FG.db.goPos
    if type(pos) == "table" and pos[1] then win:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4])
    else win:SetPoint("RIGHT", UIParent, "RIGHT", -250, 0) end
    win:SetMovable(true); win:EnableMouse(true); win:RegisterForDrag("LeftButton"); win:SetClampedToScreen(true)
    win:SetScript("OnDragStart", win.StartMoving)
    win:SetScript("OnDragStop", function(f) f:StopMovingOrSizing(); savePos() end)
    S:Backdrop(win, 0.92, nil, "window", HEAD)
    local close = S:Close(win, function() G:Close() end)
    close:SetSize(20, 20); close:SetPoint("TOPRIGHT", -10, -8)
    S:Tip(close, nil, "go_close_tip")
    win.icon = win:CreateTexture(nil, "OVERLAY")
    win.icon:SetSize(20, 20); win.icon:SetPoint("TOPLEFT", 14, -8)
    win.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    win.title = S:NoInk(S:Text(win, "label", S.c.accent)); win.title:SetTextColor(1, 0.82, 0)
    win.title:SetPoint("LEFT", win.icon, "RIGHT", 6, 0); win.title:SetPoint("RIGHT", close, "LEFT", -4, 0)
    win.title:SetWordWrap(false)
    -- карта
    local view = CreateFrame("Frame", nil, win)
    if view.SetClipsChildren then view:SetClipsChildren(true) end
    local bg = view:CreateTexture(nil, "BACKGROUND", nil, -8)
    bg:SetAllPoints(); bg:SetColorTexture(0, 0, 0, 0.6)
    view.canvas = CreateFrame("Frame", nil, view)
    view.canvas:SetSize(10, 10); view.canvas:SetPoint("CENTER")
    view.empty = S:Text(view, "small", S.c.muted)
    view.empty:SetPoint("CENTER"); FG:Localize(view.empty, "nb_nomap")
    win.view = view
    win.dots = {}
    for i = 1, 60 do
        local d = view.canvas:CreateTexture(nil, "OVERLAY", nil, 1)
        d:SetTexture(S.media and S.media.circle or "Interface\\Buttons\\WHITE8x8")
        d:SetSize(4, 4); d:SetVertexColor(1, 0.82, 0, 0.85); d:Hide()
        win.dots[i] = d
    end
    win.pin = CreateFrame("Frame", nil, view.canvas)
    win.pin:SetSize(22, 22); win.pin:SetFrameLevel(view.canvas:GetFrameLevel() + 3)
    local pg = win.pin:CreateTexture(nil, "OVERLAY", nil, 2)
    pg:SetAllPoints(); pg:SetTexture(S.media.pin); pg:SetVertexColor(1, 0.82, 0, 1)
    win.me = CreateFrame("Frame", nil, view.canvas)
    win.me:SetSize(24, 24); win.me:SetFrameLevel(view.canvas:GetFrameLevel() + 4)
    win.meTex = win.me:CreateTexture(nil, "OVERLAY", nil, 3)
    win.meTex:SetAllPoints(); win.meTex:SetTexture("Interface\\Minimap\\MinimapArrow")
    -- клик по карте — большая карта на этой зоне
    view:EnableMouse(true)
    view:SetScript("OnMouseUp", function()
        local t = target()
        if not (t and t.m) then return end
        if rawget(_G, "OpenWorldMap") then pcall(OpenWorldMap, t.m) elseif ToggleWorldMap then pcall(ToggleWorldMap) end
        if WorldMapFrame and WorldMapFrame.SetMapID then pcall(WorldMapFrame.SetMapID, WorldMapFrame, t.m) end
    end)
    S:Tip(view, nil, "go_map_tip")
    -- расстояние и зона
    win.info = S:Text(win, "small", S.c.text)
    win.info:SetSpacing(2)
    -- описание для заданий и Спутника
    win.text = S:Text(win, "label", S.c.text)
    win.text:SetSpacing(3)
    -- кнопка «Стоп»
    win.stop = S:Button(win, "go_stop", 90, 22, function() G:Stop() end, { font = "small" })
    -- уголок: тянуть, чтобы изменить размер
    local grip = CreateFrame("Button", nil, win)
    grip:SetSize(16, 16); grip:SetPoint("BOTTOMRIGHT", -8, 8)
    grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    S:Tip(grip, nil, "go_resize_tip")
    grip:SetScript("OnMouseDown", function()
        local cx = GetCursorPosition()
        grip.sx, grip.sw = cx, win:GetWidth()
        grip:SetScript("OnUpdate", function()
            local x = GetCursorPosition()
            local sc = win:GetEffectiveScale() or 1
            local w = math.max(MINW, math.min(MAXW, grip.sw + (x - grip.sx) / sc))
            if math.abs(w - win:GetWidth()) >= 1 then win:SetWidth(w); G:Layout(true) end
        end)
    end)
    grip:SetScript("OnMouseUp", function()
        grip:SetScript("OnUpdate", nil)
        FG.db.goW = math.floor(win:GetWidth() + 0.5)
        G:Layout()
    end)
    win.grip = grip
    local acc, acc2 = 0, 0
    win:SetScript("OnUpdate", function(_, dt)
        acc = acc + dt; acc2 = acc2 + dt
        if acc < 0.1 then return end
        acc = 0
        G:UpdateInfo()
        -- задания и Спутник: текст и высоту обновляем раз в секунду
        if acc2 > 1 and (G.mode == "quest" or G.mode == "nearby") then acc2 = 0; G:Update() end
    end)
    win:Hide()
end

-- описание режима: возвращает высоту
local function questText()
    local A = FG.Advisor
    local nt = FG.navTarget
    if nt and not nt.gather and not nt.rep then
        return "|cffffd100" .. L("go_to") .. "|r " .. (nt.t or "?") .. (nt.sub and ("\n|cff9aa0a8" .. nt.sub .. "|r") or "")
    end
    local st = A and A.step
    if not st then return "|cff9aa0a8" .. ((A and A.status) or L("go_noquest")) .. "|r" end
    return A:Describe(st)
end

function G:Layout(mapOnly)
    if not win then return end
    local w = win:GetWidth()
    local mh = math.floor((w - 24) * 0.68)
    local y = HEAD + 8
    -- карты нет: только расстояние и зона цели, потом описание
    win.view:Hide()
    local t = target()
    if t and t.m and t.x and not (G.mode == "prof" and FG.Skills and not (FG.navTarget and FG.navTarget.gather)) then
        win.info:Show()
        win.info:ClearAllPoints(); win.info:SetPoint("TOPLEFT", 14, -y); win.info:SetPoint("RIGHT", -14, 0)
        G:UpdateInfo()
        y = y + sh(win.info) + 8
    else
        win.info:Hide()
    end
    if mapOnly and win.lastDescH then
        win:SetHeight(y + win.lastDescH + 42)
        return
    end
    -- описание
    local mode = G.mode
    local dh = 0
    local inner = w - 20
    if mode == "prof" then
        win.text:Hide()
        dh = FG.Skills and FG.Skills.PanelBlock and FG.Skills:PanelBlock(win, 10, y, inner) or 0
        if FG.Rep and FG.Rep.HideBlock then FG.Rep.HideBlock() end
    elseif mode == "rep" then
        win.text:Hide()
        dh = FG.Rep and FG.Rep.TrackBlock and FG.Rep:TrackBlock(win, 10, y, inner) or 0
        if FG.Skills and FG.Skills.HideBlock then FG.Skills.HideBlock() end
    else
        if FG.Skills and FG.Skills.HideBlock then FG.Skills.HideBlock() end
        if FG.Rep and FG.Rep.HideBlock then FG.Rep.HideBlock() end
        win.text:ClearAllPoints(); win.text:SetPoint("TOPLEFT", 14, -y); win.text:SetPoint("RIGHT", -14, 0)
        win.text:SetText(questText())
        win.text:Show()
        dh = sh(win.text)
    end
    win.lastDescH = dh
    y = y + dh + 8
    win.stop:ClearAllPoints(); win.stop:SetPoint("BOTTOMLEFT", 12, 10)
    win:SetHeight(y + 34)
    S:SkinTree(win)
end

local ICONS = { quest = "Interface\\Icons\\INV_Misc_Map_01", nearby = "Interface\\Icons\\INV_Misc_Spyglass_03",
    rep = "Interface\\Icons\\INV_Misc_Note_06", prof = "Interface\\Icons\\Trade_Engineering" }

local function modeValid(mode)
    if mode == "prof" then return FG.cdb.profTrack ~= nil end
    if mode == "rep" then return FG.cdb.repTrack ~= nil end
    if mode == "nearby" then return FG.navTarget and FG.navTarget.nearby and true or false end
    return mode == "quest"
end

function G:Update()
    if not FG.cdb then return end
    if not win or not win:IsShown() then return end
    if not modeValid(G.mode) then
        -- режим закончился: переходим к другому активному или закрываемся
        if FG.cdb.profTrack then G.mode = "prof" elseif FG.cdb.repTrack then G.mode = "rep"
        else win:Hide(); FG.cdb.goMode = nil; return end
        FG.cdb.goMode = G.mode
    end
    local mode = G.mode
    local title
    if mode == "prof" then
        local p
        for _, x in ipairs(QuestCompassProf or {}) do if x.key == FG.cdb.profTrack then p = x end end
        title = L("go_t_prof", p and (FG:Lang() == "ru" and p.ru or p.en) or "?")
        win.icon:SetTexture(p and p.icon or ICONS.prof)
    elseif mode == "rep" then
        title = L("go_t_rep", FG.Rep and FG.Rep.TrackedName and FG.Rep.TrackedName() or "?")
        win.icon:SetTexture(FG.Rep and FG.Rep.TrackedIcon and FG.Rep.TrackedIcon() or ICONS.rep)
    elseif mode == "nearby" then
        title = L("go_t_nearby"); win.icon:SetTexture(ICONS.nearby)
    else
        title = L("go_t_quest"); win.icon:SetTexture(ICONS.quest)
    end
    win.title:SetText(title)
    G:Layout()
end

-- открыть окно в режиме
function G:Open(mode)
    if not win then create() end
    G.mode = mode or G.mode or "quest"
    FG.cdb.goMode = G.mode
    local nt = FG.navTarget
    -- чужая цель стрелки (например, из Спутника) не должна мешать новому режиму
    if nt then
        if (G.mode == "quest" and (nt.nearby or nt.gather or nt.rep))
            or (G.mode == "prof" and not nt.gather) or (G.mode == "rep" and not nt.rep) then
            FG:SetNavTarget(nil)
        end
    end
    if FG.Skills then FG.Skills.gatherPaused = (G.mode == "quest") or nil end
    win:Show()
    G:Update()
end
function G:Close()
    if win then win:Hide() end
    FG.cdb.goMode = nil
end
-- «Стоп»: остановить то, что ведём, и закрыть
function G:Stop()
    local mode = G.mode
    if mode == "prof" and FG.Skills then FG.Skills:StopTrack()
    elseif mode == "rep" and FG.Rep then FG.Rep:StopTrack()
    elseif mode == "nearby" then FG:SetNavTarget(nil); if FG.Nearby and FG.Nearby.Refresh then FG.Nearby.Refresh() end end
    G:Close()
end
function G:IsShown() return win and win:IsShown() end

-- единая кнопка «Идти»: иконка карты + подпись; одинаковая во всех вкладках
function G:Button(parent, w, h, onClick, key)
    S = FG.Style
    local b = S:Button(parent, key or "go_btn", w, h or 24, onClick, { font = "label", tip = "go_btn_tip" })
    b.mapIcon = b:CreateTexture(nil, "OVERLAY")
    b.mapIcon:SetTexture("Interface\\Icons\\INV_Misc_Map_01")
    b.mapIcon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    local ih = math.max(12, (h or 24) - 8)
    b.mapIcon:SetSize(ih, ih)
    if b.label then
        b.label:ClearAllPoints(); b.label:SetPoint("CENTER", ih / 2 + 2, 0)
        b.mapIcon:SetPoint("RIGHT", b.label, "LEFT", -4, 0)
    else
        b.mapIcon:SetPoint("LEFT", 6, 0)
    end
    return b
end

FG:On("PLAYER_ENTERING_WORLD", function()
    C_Timer.After(3, function()
        local m = FG.cdb and FG.cdb.goMode
        if m and modeValid(m) then G:Open(m) end
    end)
end)
-- задания поменялись — обновить текст
FG:On("QUEST_LOG_UPDATE", function() if win and win:IsShown() and G.mode == "quest" then G:Update() end end)
