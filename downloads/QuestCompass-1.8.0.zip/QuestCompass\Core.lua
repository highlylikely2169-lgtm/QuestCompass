-- QuestCompass: ядро (база настроек, события, общие функции)
local ADDON, ns = ...

local FG = CreateFrame("Frame")
ns.FG = FG
FG.PAGE_W = 640 -- ширина правой части меню: одинаковая на всех вкладках
_G.QuestCompass = FG

FG.version = "1.0.0"
FG.log = {}             -- журнал заданий: [questID] = {...}
FG.initFuncs = {}
FG.handlers = {}

local defaults = {
    autoAccept = true,       -- автоматически брать квесты
    autoTurnIn = true,       -- автоматически сдавать готовые
    autoReward = false,      -- выбор награды — всегда сам игрок
    showArrow = true,
    showMapPin = true,
    showLine = true,         -- пунктир до цели на карте и миникарте
    panelShown = true,
    minimapShown = true,
    font = "game",
    route = "xp",             -- маршрут: "xp" (быстрее по опыту) или "near" (ближайшие)
    travel = true,            -- маршрут через полёты и корабли
    lang = "ru",              -- язык аддона: "ru" или "en"
    minimapAngle = 215,
    panelPos = { "TOPRIGHT", "TOPRIGHT", -230, -220 },
    arrowPos = { "TOP", "TOP", 0, -110 },
    -- вкладка «Интерфейс» (Frames.lua): всё выключено, пока игрок сам не включит
    frames = {
        pf = { on = false, target = true, pmode = "face", power = true, name = true, level = true, color = "class", text = "both", tex = "flat", w = 150, h = 22, scale = 100 },
        xp = { on = false, hideDef = false, dock = true, rested = true, ticks = true, text = "full", w = 600, h = 14 },
        bf = { on = false, hideDef = false, debuffs = true, timers = true, grow = "left", size = 32, row = 10 },
        party = { on = false, healClicks = true }, -- healClicks: клики по рамкам как настроено в разделе «Клики»
        raid = { on = false, size = "m", names = true, range = true },
        look = "dark",
    },
}

local charDefaults = {
    ignored = {},        -- квесты, которые вы попросили не предлагать
    ignoredOrder = {},
}

local function copyDefaults(dst, src)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then dst[k] = {} end
            copyDefaults(dst[k], v)
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
end

---------------------------------------------------------------------------
-- События
---------------------------------------------------------------------------
function FG:On(event, fn)
    if not self.handlers[event] then
        self.handlers[event] = {}
        pcall(self.RegisterEvent, self, event) -- событие может не существовать в этой версии клиента
    end
    table.insert(self.handlers[event], fn)
end

function FG:OnInit(fn) table.insert(self.initFuncs, fn) end

FG:SetScript("OnEvent", function(self, event, ...)
    local list = self.handlers[event]
    if not list then return end
    for i = 1, #list do
        local ok, err = pcall(list[i], event, ...)
        if not ok then geterrorhandler()(err) end
    end
end)

function FG:Print(...)
    print("|cffffd100QuestCompass:|r", ...)
end

FG:On("ADDON_LOADED", function(_, name)
    if name ~= ADDON then return end
    QuestCompassDB = QuestCompassDB or {}
    QuestCompassCharDB = QuestCompassCharDB or {}
    copyDefaults(QuestCompassDB, defaults)
    copyDefaults(QuestCompassCharDB, charDefaults)
    FG.db = QuestCompassDB
    FG.cdb = QuestCompassCharDB
    -- новый вид в стиле окон игры: один раз включаем игровой шрифт
    if not FG.db.themeBlizz then FG.db.font = "game"; FG.db.themeBlizz = true end
    FG.db.autoReward = false -- награду выбирает игрок
    FG.db.autoTaxi = nil
end)

FG:On("PLAYER_LOGIN", function()
    if not FG.db then -- на случай, если ADDON_LOADED не пришёл
        QuestCompassDB = QuestCompassDB or {}
        QuestCompassCharDB = QuestCompassCharDB or {}
        copyDefaults(QuestCompassDB, defaults)
        copyDefaults(QuestCompassCharDB, charDefaults)
        FG.db, FG.cdb = QuestCompassDB, QuestCompassCharDB
    end
    FG:ScanLog()
    for _, fn in ipairs(FG.initFuncs) do
        local ok, err = pcall(fn)
        if not ok then geterrorhandler()(err) end
    end
    FG:Print(FG.L("loaded", "|cffffd100/qc help|r"))
end)

---------------------------------------------------------------------------
-- Позиция игрока и карты
---------------------------------------------------------------------------
function FG:GetPlayerPos()
    if not (C_Map and C_Map.GetBestMapForUnit) then return end
    local m = C_Map.GetBestMapForUnit("player")
    if not m then return end
    local p = C_Map.GetPlayerMapPosition(m, "player")
    if not p then return m end
    local x, y = p:GetXY()
    if not x or (x == 0 and y == 0) then return m end
    return m, x, y
end

-- Поиск предмета на открытом аукционе (новый и классический интерфейс аукциона)
function FG:AHSearch(id, fallbackName)
    local name
    if C_Item and C_Item.GetItemInfo then local ok, n = pcall(C_Item.GetItemInfo, id); if ok then name = n end end
    if not name and rawget(_G, "GetItemInfo") then local ok, n = pcall(GetItemInfo, id); if ok then name = n end end
    name = name or fallbackName
    if not name then return false end
    -- новый аукцион (вкладка «Купить», строка поиска)
    local AH = rawget(_G, "AuctionHouseFrame")
    if AH and AH:IsShown() then
        if AH.SetDisplayMode and AuctionHouseFrameDisplayMode then pcall(AH.SetDisplayMode, AH, AuctionHouseFrameDisplayMode.Buy) end
        local bar = AH.SearchBar
        if bar and bar.SearchBox then
            pcall(bar.SearchBox.SetText, bar.SearchBox, name)
            if bar.StartSearch then pcall(bar.StartSearch, bar)
            elseif bar.SearchButton then pcall(bar.SearchButton.Click, bar.SearchButton) end
            return true
        end
    end
    -- классический аукцион (вкладка «Обзор»)
    local AF = rawget(_G, "AuctionFrame")
    if AF and AF:IsShown() then
        if rawget(_G, "AuctionFrameTab1") and rawget(_G, "AuctionFrameTab_OnClick") then pcall(AuctionFrameTab_OnClick, AuctionFrameTab1) end
        local box = rawget(_G, "BrowseName")
        if box then
            pcall(box.SetText, box, name)
            local btn = rawget(_G, "BrowseSearchButton")
            if btn then pcall(btn.Click, btn) elseif rawget(_G, "AuctionFrameBrowse_Search") then pcall(AuctionFrameBrowse_Search) end
            return true
        end
    end
    FG:Print(FG.L("ah_closed", name))
    return false
end

-- куда ведут стрелка и линия: своя цель (вкладка «Спутник») или шаг подсказки
function FG:NavStep()
    if self.navTarget then return self.navTarget end
    -- идёт прокачка профессии — стрелка и линия не уходят на квест (вернуть квесты: «Идти» → задания или «Стоп»)
    if self.cdb and self.cdb.profTrack and not (self.Skills and self.Skills.gatherPaused) then return nil end
    return self.Advisor and self.Advisor.step
end
FG.navTarget = false
function FG:SetNavTarget(t)
    self.navTarget = t or false
    if self.UI and self.UI.UpdateArrow then self.UI:UpdateArrow() end
    if self.Route and self.Route.Refresh then pcall(self.Route.Refresh) end
end

function FG:MapName(m)
    local info = m and C_Map.GetMapInfo and C_Map.GetMapInfo(m)
    return info and FG:TrZone(info.name) or FG.L("map_n", tostring(m))
end

-- Перевести точку (srcMap, x, y) в координаты карты dstMap (через мировые координаты)
function FG:ConvertPos(srcMap, x, y, dstMap)
    if not (srcMap and x and y and dstMap) then return end
    if srcMap == dstMap then return x, y end
    if not (C_Map.GetWorldPosFromMapPos and C_Map.GetMapPosFromWorldPos and CreateVector2D) then return end
    local ok, cont, world = pcall(C_Map.GetWorldPosFromMapPos, srcMap, CreateVector2D(x, y))
    if not ok or not cont or not world then return end
    local ok2, _, pos = pcall(C_Map.GetMapPosFromWorldPos, cont, world, dstMap)
    if not ok2 or not pos then return end
    local nx, ny = pos:GetXY()
    return nx, ny
end

-- Размер карты в ярдах (без привязки к направлению мировых осей)
local sizeCache = {}
function FG:MapSize(m)
    if sizeCache[m] then return sizeCache[m][1], sizeCache[m][2] end
    local w, h
    if C_Map.GetMapWorldSize then
        local ok, a, b = pcall(C_Map.GetMapWorldSize, m)
        if ok and a and a > 0 then w, h = a, b end
    end
    if not w and C_Map.GetWorldPosFromMapPos and CreateVector2D then
        local function wp(x, y)
            local ok, _, v = pcall(C_Map.GetWorldPosFromMapPos, m, CreateVector2D(x, y))
            if ok and v then return v:GetXY() end
        end
        local x1, y1 = wp(0, 0.5); local x2, y2 = wp(1, 0.5)
        local x3, y3 = wp(0.5, 0); local x4, y4 = wp(0.5, 1)
        if x1 and x2 and x3 and x4 then
            w = math.sqrt((x2 - x1) ^ 2 + (y2 - y1) ^ 2)
            h = math.sqrt((x4 - x3) ^ 2 + (y4 - y3) ^ 2)
        end
    end
    if w and w > 0 then sizeCache[m] = { w, h } end
    return w, h
end

---------------------------------------------------------------------------
-- Квесты
---------------------------------------------------------------------------
function FG:IsQuestDone(id)
    if not id then return false end
    if C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted then
        return C_QuestLog.IsQuestFlaggedCompleted(id) and true or false
    end
    if IsQuestFlaggedCompleted then return IsQuestFlaggedCompleted(id) and true or false end
    return false
end

-- Полный обход журнала заданий. Результат в FG.log
function FG:ScanLog()
    local log = {}
    if GetQuestLogTitle and GetNumQuestLogEntries then
        -- классический API
        local n = GetNumQuestLogEntries() or 0
        for i = 1, n do
            local title, level, _, isHeader, _, isComplete, _, questID = GetQuestLogTitle(i)
            if not isHeader and questID and questID > 0 then
                local objs, allDone = {}, true
                local nb = GetNumQuestLeaderBoards and GetNumQuestLeaderBoards(i) or 0
                for j = 1, nb do
                    local text, _, finished = GetQuestLogLeaderBoard(j, i)
                    objs[#objs + 1] = { text = text or "?", done = finished and true or false }
                    if not finished then allDone = false end
                end
                log[questID] = {
                    index = i, title = title, level = level, objs = objs,
                    complete = (isComplete == 1) or (nb > 0 and allDone) or (nb == 0 and isComplete ~= -1),
                    failed = (isComplete == -1),
                }
            end
        end
    elseif C_QuestLog and C_QuestLog.GetNumQuestLogEntries then
        -- современный API
        local n = C_QuestLog.GetNumQuestLogEntries() or 0
        for i = 1, n do
            local info = C_QuestLog.GetInfo(i)
            if info and not info.isHeader and info.questID and info.questID > 0 then
                local objs = {}
                local list = C_QuestLog.GetQuestObjectives and C_QuestLog.GetQuestObjectives(info.questID) or {}
                for _, o in ipairs(list) do objs[#objs + 1] = { text = o.text or "?", done = o.finished and true or false } end
                log[info.questID] = {
                    index = i, title = info.title, level = info.level, objs = objs,
                    complete = C_QuestLog.IsComplete and C_QuestLog.IsComplete(info.questID) or false,
                }
            end
        end
    end
    FG.prevLog = FG.log
    setmetatable(log, FG.LogMT)
    FG.log = log
    return log
end

-- В WoW Forever у части квестов номер в игре не совпадает с номером в базе Questie.
-- Если по номеру из базы квеста в журнале нет — ищем его по названию.
-- Берём только записи журнала, чей игровой номер базе неизвестен (или с другим названием),
-- чтобы одинаковые названия шагов цепочки («Братство Справедливости») не путались.
local function norm(t) return type(t) == "string" and (t:lower():gsub("%s+", " "):gsub("^ ", ""):gsub(" $", "")) or nil end
local logMemo = setmetatable({}, { __mode = "k" })
-- записи журнала, чей игровой номер не совпадает с базой: название -> запись
local function orphans(t)
    local DB = (rawget(_G, "QuestCompassDataLib") or rawget(_G, "LibQuestieDB"))
    local out = {}
    if not (DB and DB.Quest and DB.Quest.name) then return out end
    for gid, e in next, t do
        local ok, own = pcall(DB.Quest.name, gid)
        local n = norm(e.title)
        if n and not (ok and own and norm(own) == n) then out[n] = e end
    end
    return out
end

local function lookup(t, id, orph)
    if not next(orph) then return nil end
    local DB = (rawget(_G, "QuestCompassDataLib") or rawget(_G, "LibQuestieDB"))
    local ok, name = pcall(DB.Quest.name, id)
    local e = ok and name and orph[norm(name)]
    if e then return e end
    local ru = FG.TrQuest and FG:TrQuest(id)
    return ru and orph[norm(ru)] or nil
end
FG.LogMT = {
    __index = function(t, id)
        if type(id) ~= "number" then return nil end
        local m = logMemo[t]
        if not m then m = { orph = orphans(t), ids = {} }; logMemo[t] = m end
        local v = m.ids[id]
        if v == nil then v = lookup(t, id, m.orph) or false; m.ids[id] = v end
        return v or nil
    end,
}

function FG:QuestTitle(id)
    if FG.log[id] then return FG.log[id].title end
    if FG.prevLog and FG.prevLog[id] then return FG.prevLog[id].title end
    if C_QuestLog and C_QuestLog.GetTitleForQuestID then
        local t = C_QuestLog.GetTitleForQuestID(id)
        if t then return t end
    end
    return FG.L("quest_n", tostring(id))
end

---------------------------------------------------------------------------
-- Обновление всего интерфейса (с ограничением частоты)
---------------------------------------------------------------------------
local refreshPending = false
function FG:Refresh()
    if refreshPending then return end
    refreshPending = true
    C_Timer.After(0.1, function()
        refreshPending = false
        if FG.Advisor then FG.Advisor:Recalc() end
        if FG.UI then FG.UI:Update() end
    end)
end

FG:On("QUEST_LOG_UPDATE", function()
    FG:ScanLog()
    FG:Refresh()
end)
FG:On("QUEST_TURNED_IN", function() FG:Refresh() end)
FG:On("PLAYER_LEVEL_UP", function() FG:Refresh() end)
FG:On("ZONE_CHANGED_NEW_AREA", function() FG:Refresh() end)
