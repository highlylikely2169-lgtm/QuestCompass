-- QuestCompass: вкладка «Таланты» — раскладка для прокачки 10–60 и подсказка, куда вложить очко
local _, ns = ...
local FG = ns.FG
local L = FG.L
local T = {}
FG.Talents = T

local S
local page
local W = FG.PAGE_W
local ROW_H, ROWS = 40, 14

local function safe(f, ...) if not f then return nil end local ok, a, b, c, d, e, g = pcall(f, ...) if ok then return a, b, c, d, e, g end end
local function ru() return FG:Lang() == "ru" end

local TREE_RU = {
    Arms = "Оружие", Fury = "Неистовство", Protection = "Защита", Holy = "Свет", Retribution = "Воздаяние",
    ["Beast Mastery"] = "Чувство зверя", Marksmanship = "Стрельба", Survival = "Выживание",
    Assassination = "Ликвидация", Combat = "Бой", Subtlety = "Скрытность", Arcane = "Тайная магия", Fire = "Огонь", Frost = "Лед",
    Discipline = "Послушание", Shadow = "Темная магия", Elemental = "Стихии", Enhancement = "Совершенствование", Restoration = "Исцеление",
    Affliction = "Колдовство", Demonology = "Демонология", Destruction = "Разрушение", Balance = "Баланс", ["Feral Combat"] = "Сила зверя",
}

function T:Class()
    local _, c = UnitClass("player")
    return c
end
function T:Data() return QuestCompassTalents and QuestCompassTalents[T:Class()] end

-- Наборы талантов (как «Основной / Второй» в окне игры); второй открывается с 40 уровня
local SECOND_LEVEL = 40
function T:ActiveGroup()
    local g = (C_SpecializationInfo and C_SpecializationInfo.GetActiveSpecGroup and safe(C_SpecializationInfo.GetActiveSpecGroup))
        or (rawget(_G, "GetActiveTalentGroup") and safe(GetActiveTalentGroup))
    return (tonumber(g) == 2) and 2 or 1
end
function T:SecondUnlocked()
    local n = (C_SpecializationInfo and C_SpecializationInfo.GetNumSpecGroups and safe(C_SpecializationInfo.GetNumSpecGroups))
        or (rawget(_G, "GetNumTalentGroups") and safe(GetNumTalentGroups))
    if (tonumber(n) or 0) >= 2 then return true end
    return (UnitLevel("player") or 1) >= SECOND_LEVEL
end
-- какой набор сейчас открыт в аддоне
function T:Group()
    local g = FG.cdb.talentGroup
    if g == 2 then return T:SecondUnlocked() and 2 or 1 end
    if g == 1 then return 1 end
    return T:ActiveGroup()
end

-- ветка, через которую качаемся (1..3), — своя для каждого набора
function T:Spec()
    local d = T:Data()
    if not d then return nil end
    local second = T:Group() == 2
    local s = FG.cdb[second and "talentTree2" or "talentTree"]
    if s and d[s] then return s end
    if second then
        -- второй набор по умолчанию — другая роль (лечение, если есть), иначе урон
        local first = FG.cdb.talentTree or d.dps or 1
        if d.heal and d.heal ~= first then return d.heal end
        if d.dps and d.dps ~= first then return d.dps end
    end
    local b = FG.BiS and FG.BiS.Spec and safe(FG.BiS.Spec, FG.BiS)
    if b and d[b] and d[d[b]] then return d[b] end
    return d.dps or 1
end

-- таланты игрока: [дерево][ряд][столбец] = { index, name, icon, rank, max, req = { {ряд, столбец}, ... } }
-- На WoW Forever таланты — дерево C_Traits (старые GetTalentInfo пустые), поэтому сначала читаем его.
function T:Read()
    local out = T:ReadTraits()
    if out then return out end
    out = {}
    local nt = rawget(_G, "GetNumTalents")
    local gi = rawget(_G, "GetTalentInfo")
    local pr = rawget(_G, "GetTalentPrereqs")
    for tab = 1, 3 do
        out[tab] = {}
        local n = nt and safe(nt, tab) or 0
        for i = 1, (tonumber(n) or 0) do
            local r = gi and { pcall(gi, tab, i, false, false, T:Group()) } or {}
            if r[1] and type(r[2]) == "string" then
                local tier, col = r[4], r[5]
                if type(tier) == "number" and type(col) == "number" then
                    local req = {}
                    local p = pr and { pcall(pr, tab, i) } or {}
                    local k = 2
                    while p[1] and type(p[k]) == "number" and type(p[k + 1]) == "number" do
                        req[#req + 1] = { p[k], p[k + 1] }
                        k = k + 3
                    end
                    out[tab][tier] = out[tab][tier] or {}
                    out[tab][tier][col] = { index = i, name = r[2], icon = r[3], rank = r[6] or 0, max = r[7] or 0, req = req }
                end
            end
        end
    end
    return out
end

local function spellInfo(id)
    local name, icon
    if C_Spell and C_Spell.GetSpellInfo then
        local i = safe(C_Spell.GetSpellInfo, id)
        if type(i) == "table" then name, icon = i.name, i.iconID end
    end
    if not name and rawget(_G, "GetSpellInfo") then
        local n, _, ic = safe(GetSpellInfo, id)
        name, icon = n, ic
    end
    return name, icon
end

---------------------------------------------------------------------------
-- Дерево C_Traits (WoW Forever): одно дерево, в нём три ветки рядом.
-- Координаты узлов — десятые доли пикселя, 600 между столбцами и рядами;
-- ветки лежат далеко друг от друга (как в ForevermoreClassicUI/Modules/TalentFrame.lua).
---------------------------------------------------------------------------
local NODE_GRID, NODE_SLACK, NUM_COLS, MAX_TIERS = 600, 100, 4, 11
local TREE_SPAN = (NUM_COLS - 1) * NODE_GRID + NODE_SLACK

function T:TraitIDs(group)
    if not (C_Traits and C_Traits.GetTreeNodes and C_Traits.GetNodeInfo) then return nil end
    group = group or T:Group()
    local configID
    -- у каждого набора талантов свой config
    if C_SpecializationInfo and C_SpecializationInfo.GetCombatConfigIDForSpecGroup then
        configID = safe(C_SpecializationInfo.GetCombatConfigIDForSpecGroup, group)
    end
    if not configID and group == T:ActiveGroup() and C_ClassTalents and C_ClassTalents.GetActiveConfigID then
        configID = safe(C_ClassTalents.GetActiveConfigID)
    end
    if not configID then return nil end
    local treeID
    local ci = C_Traits.GetConfigInfo and safe(C_Traits.GetConfigInfo, configID)
    if type(ci) == "table" and ci.treeIDs then treeID = ci.treeIDs[1] end
    if not treeID then
        local tf = rawget(_G, "PlayerSpellsFrame") and PlayerSpellsFrame.TalentsFrame
        if tf and tf.GetTalentTreeID then treeID = safe(tf.GetTalentTreeID, tf) end
    end
    if not treeID then return nil end
    return configID, treeID
end

local function traitDef(configID, info)
    local entryID = (info.activeEntry and info.activeEntry.entryID) or (info.entryIDs and info.entryIDs[1])
    if not entryID then return nil end
    local e = safe(C_Traits.GetEntryInfo, configID, entryID)
    local def = type(e) == "table" and e.definitionID and safe(C_Traits.GetDefinitionInfo, e.definitionID)
    if type(def) ~= "table" then return entryID end
    local spell = def.spellID
    local name, icon = def.overrideName, def.overrideIcon
    if spell and (not name or name == "" or not icon) then
        local n, ic = spellInfo(spell)
        if not name or name == "" then name = n end
        icon = icon or ic
    end
    return entryID, spell, name, icon
end

function T:ReadTraits()
    local configID, treeID = T:TraitIDs()
    if not configID then return nil end
    local ids = safe(C_Traits.GetTreeNodes, treeID)
    if type(ids) ~= "table" or #ids == 0 then return nil end
    local nodes = {}
    for _, nodeID in ipairs(ids) do
        local info = safe(C_Traits.GetNodeInfo, configID, nodeID)
        if type(info) == "table" and info.posX and info.posY and (info.maxRanks or 0) > 0 and info.isVisible ~= false then
            nodes[#nodes + 1] = { id = nodeID, x = info.posX, y = info.posY, info = info }
        end
    end
    if #nodes == 0 then return nil end
    -- ветки: самые большие «пачки» узлов по X, слева направо
    table.sort(nodes, function(a, b) return a.x < b.x end)
    local runs, run = {}, nil
    for _, n in ipairs(nodes) do
        if not run or n.x - run.left > TREE_SPAN then run = { left = n.x, nodes = {} }; runs[#runs + 1] = run end
        table.insert(run.nodes, n)
    end
    table.sort(runs, function(a, b) return #a.nodes > #b.nodes end)
    for i = #runs, 4, -1 do runs[i] = nil end
    table.sort(runs, function(a, b) return a.left < b.left end)
    local top
    for _, r in ipairs(runs) do for _, n in ipairs(r.nodes) do top = math.min(top or n.y, n.y) end end
    local out, cell = { {}, {}, {} }, {}
    for tab, r in ipairs(runs) do
        for _, n in ipairs(r.nodes) do
            local col, tier = math.floor((n.x - r.left) / NODE_GRID + 0.5), math.floor((n.y - top) / NODE_GRID + 0.5)
            local off = math.abs(n.x - r.left - col * NODE_GRID) > NODE_SLACK or math.abs(n.y - top - tier * NODE_GRID) > NODE_SLACK
            if col < NUM_COLS and tier < MAX_TIERS and not off then
                local entryID, spell, name, icon = traitDef(configID, n.info)
                local i = n.info
                local t = {
                    index = n.id, nodeID = n.id, entryID = entryID, spell = spell, name = name, icon = icon,
                    rank = i.ranksPurchased or i.currentRank or 0, max = i.maxRanks or 0, req = {},
                    active = i.activeRank, -- уже принято (rank включает поставленные, но не принятые очки)
                }
                out[tab][tier + 1] = out[tab][tier + 1] or {}
                out[tab][tier + 1][col + 1] = t
                cell[n.id] = { tab = tab, row = tier + 1, col = col + 1, t = t, info = i }
            end
        end
    end
    -- требования из рёбер: условие — верхний узел (часть рёбер в данных смотрит вверх)
    for id, c in pairs(cell) do
        for _, e in ipairs(c.info.visibleEdges or {}) do
            local to = cell[e.targetNode]
            if to and to.tab == c.tab then
                local from = c
                if to.row < from.row then from, to = to, from end
                table.insert(to.t.req, { from.row, from.col })
            end
        end
    end
    -- заголовки веток (название и иконка) — как в окне игры, слева направо
    T.treeInfo = {}
    local gd = C_Traits.GetGroupDisplayInfoByTreeID and safe(C_Traits.GetGroupDisplayInfoByTreeID, treeID)
    if type(gd) == "table" then
        for i, g in ipairs(gd) do T.treeInfo[i] = { name = g.displayName, icon = g.icon } end
    end
    T.configID, T.treeID = configID, treeID
    return out
end

local function treeName(d, tab)
    local en = d.trees and d.trees[tab] or ("#" .. tab)
    if ru() then return TREE_RU[en] or en end
    return en
end

-- фон ветки из окна талантов игры (Interface\TalentFrame\<имя>-TopLeft и т.д.)
local TREE_BG = {
    WARRIOR = { "WarriorArms", "WarriorFury", "WarriorProtection" },
    PALADIN = { "PaladinHoly", "PaladinProtection", "PaladinCombat" },
    HUNTER = { "HunterBeastMastery", "HunterMarksmanship", "HunterSurvival" },
    ROGUE = { "RogueAssassination", "RogueCombat", "RogueSubtlety" },
    MAGE = { "MageArcane", "MageFire", "MageFrost" },
    PRIEST = { "PriestDiscipline", "PriestHoly", "PriestShadow" },
    SHAMAN = { "ShamanElementalCombat", "ShamanEnhancement", "ShamanRestoration" },
    WARLOCK = { "WarlockCurses", "WarlockSummoning", "WarlockDestruction" },
    DRUID = { "DruidBalance", "DruidFeralCombat", "DruidRestoration" },
}
local function treeBg(tab)
    local gi = rawget(_G, "GetTalentTabInfo")
    if gi then
        local r = { pcall(gi, tab) }
        if r[1] then
            -- первая строка — название ветки, имя фона — слово вида «PriestHoly» без пробелов и слэшей
            local name
            for i = 2, #r do
                local v = r[i]
                if type(v) == "string" then
                    if not name then name = v
                    elseif not v:find("[%s\\/]") and v:find("^%u%l+%u") then return v end
                end
            end
        end
    end
    local b = TREE_BG[T:Class()]
    return b and b[tab]
end

-- Раскладка в данных собрана по классическим деревьям, а на сервере таланты переработаны
-- (другие ранги, места, часть талантов убрана). Поэтому порядок сверяется с деревом из игры:
-- талант ищется по названию, ранг не выше настоящего, соблюдаются ряды (5 очков на ряд) и
-- требования; лишние очки уходят в другие таланты раскладки, затем в доступные таланты ветки.
local TIER_POINTS = 5
local function key3(tab, row, col) return tab .. ":" .. row .. ":" .. col end

function T:Order()
    local d = T:Data()
    local spec = T:Spec()
    local order = d and spec and d[spec]
    if not order then return {}, false end
    local have = T:Read()
    local live = false
    for tab = 1, 3 do if next(have[tab]) then live = true end end
    if not live then
        local out = {}
        for _, e in ipairs(order) do out[#out + 1] = { tab = e[1], row = e[2], col = e[3], spell = e[4] } end
        return out, false
    end
    -- таланты клиента по названию
    local byName, byId = {}, {}
    for tab = 1, 3 do
        for row, r in pairs(have[tab]) do
            for col, t in pairs(r) do
                local h = { tab = tab, row = row, col = col, info = t }
                if t.name and not byName[t.name] then byName[t.name] = h end
                if t.spell then byId[t.spell] = h end
            end
        end
    end
    local fixed = false
    local pending = {}
    for _, e in ipairs(order) do
        local name = spellInfo(e[4])
        local hit = byId[e[4]] or (name and byName[name])
        if not hit and not name then
            local t = have[e[1]][e[2]] and have[e[1]][e[2]][e[3]]
            if t then hit = { tab = e[1], row = e[2], col = e[3], info = t } end
        end
        if hit then
            if hit.tab ~= e[1] or hit.row ~= e[2] or hit.col ~= e[3] then fixed = true end
            pending[#pending + 1] = { tab = hit.tab, row = hit.row, col = hit.col, spell = e[4], info = hit.info }
        else
            fixed = true -- такого таланта на сервере нет
        end
    end
    local rank, spent = {}, { 0, 0, 0 }
    local function maxOf(p) return (p.info and p.info.max and p.info.max > 0) and p.info.max or 5 end
    local function canTake(p)
        if (rank[key3(p.tab, p.row, p.col)] or 0) >= maxOf(p) then return false end
        if spent[p.tab] < (p.row - 1) * TIER_POINTS then return false end
        for _, q in ipairs(p.info and p.info.req or {}) do
            local t = have[p.tab][q[1]] and have[p.tab][q[1]][q[2]]
            if t and (rank[key3(p.tab, q[1], q[2])] or 0) < (t.max or 1) then return false end
        end
        return true
    end
    -- запасные таланты: сначала из раскладки, потом остальные (ветка раскладки первой, нижние ряды раньше)
    local spare, seen = {}, {}
    for _, p in ipairs(pending) do
        local k = key3(p.tab, p.row, p.col)
        if not seen[k] then seen[k] = true; spare[#spare + 1] = p end
    end
    local rest = {}
    for tab = 1, 3 do
        for row, r in pairs(have[tab]) do
            for col, t in pairs(r) do
                if not seen[key3(tab, row, col)] then rest[#rest + 1] = { tab = tab, row = row, col = col, info = t } end
            end
        end
    end
    table.sort(rest, function(a, b)
        local pa, pb = a.tab == spec and 0 or 1, b.tab == spec and 0 or 1
        if pa ~= pb then return pa < pb end
        if a.tab ~= b.tab then return a.tab < b.tab end
        if a.row ~= b.row then return a.row < b.row end
        return a.col < b.col
    end)
    for _, p in ipairs(rest) do spare[#spare + 1] = p end
    local out = {}
    for _ = 1, #order do
        local pick
        local i = 1
        while i <= #pending do
            local p = pending[i]
            if (rank[key3(p.tab, p.row, p.col)] or 0) >= maxOf(p) then
                table.remove(pending, i); fixed = true -- рангов на сервере меньше
            elseif canTake(p) then
                pick = table.remove(pending, i)
                if i > 1 then fixed = true end
                break
            else
                i = i + 1
            end
        end
        if not pick then
            for _, p in ipairs(spare) do if canTake(p) then pick = p; fixed = true break end end
        end
        if not pick then break end
        local k = key3(pick.tab, pick.row, pick.col)
        rank[k] = (rank[k] or 0) + 1
        spent[pick.tab] = spent[pick.tab] + 1
        out[#out + 1] = { tab = pick.tab, row = pick.row, col = pick.col, spell = pick.spell, info = pick.info }
    end
    return out, fixed
end

-- раскладка, сгруппированная по талантам: { tab, row, col, spell, from, to (уровни), need (ранг после группы) }
function T:Groups()
    local order, fixed = T:Order()
    T.fixed = fixed
    local groups, cum = {}, {}
    for i, e in ipairs(order) do
        local key = key3(e.tab, e.row, e.col)
        cum[key] = (cum[key] or 0) + 1
        local last = groups[#groups]
        if last and last.key == key then
            last.to = 9 + i; last.need = cum[key]
        else
            groups[#groups + 1] = { key = key, tab = e.tab, row = e.row, col = e.col, spell = e.spell, from = 9 + i, to = 9 + i, need = cum[key] }
        end
    end
    return groups
end

-- /qc talents: выгрузить дерево талантов сервера в QuestCompassDB.talentDump (для правки раскладок)
function T:Dump()
    local have = T:Read()
    local out = { class = T:Class(), traits = T.configID ~= nil, trees = {} }
    local n = 0
    for tab = 1, 3 do
        local tr = { talents = {} }
        for row, r in pairs(have[tab]) do
            for col, t in pairs(r) do
                table.insert(tr.talents, { row = row, col = col, name = t.name, max = t.max, rank = t.rank, icon = t.icon,
                    spell = t.spell, nodeID = t.nodeID, req = t.req })
                n = n + 1
            end
        end
        table.sort(tr.talents, function(a, b) if a.row ~= b.row then return a.row < b.row end return a.col < b.col end)
        out.trees[tab] = tr
    end
    FG.db.talentDump = FG.db.talentDump or {}
    FG.db.talentDump[out.class] = out
    FG:Print(L("tal_dumped", n))
end

local function freePoints()
    local configID, treeID = T:TraitIDs()
    if configID and C_Traits.GetTreeCurrencyInfo then
        local c = safe(C_Traits.GetTreeCurrencyInfo, configID, treeID, false)
        if type(c) == "table" and c[1] and type(c[1].quantity) == "number" then return c[1].quantity end
    end
    local f = rawget(_G, "UnitCharacterPoints")
    local n = f and safe(f, "player")
    if type(n) ~= "number" then
        local g = rawget(_G, "GetUnspentTalentPoints")
        n = g and safe(g) or 0
    end
    return tonumber(n) or 0
end

-- состояние: какие группы выполнены, какая следующая
function T:State()
    local groups = T:Groups()
    local have = T:Read()
    local next
    for _, g in ipairs(groups) do
        local t = have[g.tab] and have[g.tab][g.row] and have[g.tab][g.row][g.col]
        g.info = t
        g.rank = t and t.rank or 0
        g.done = g.rank >= g.need
        if not g.done and not next then next = g end
    end
    return groups, next, have
end

function T:Learn()
    local _, nx, have = T:State()
    if not nx or freePoints() <= 0 then return end
    local t = nx.info
    if not t then return end
    if t.nodeID then
        T:Stage(t.nodeID, true)
    else
        local lt = rawget(_G, "LearnTalent")
        if lt then pcall(lt, nx.tab, t.index) end
        C_Timer.After(0.3, function() T.Refresh() end)
    end
end

-- Очки сначала ставятся (как в окне талантов), потом «Принять» или «Отмена»
function T:Stage(nodeID, add)
    if not (T.configID and C_Traits) then return end
    local f = add and C_Traits.PurchaseRank or C_Traits.RefundRank
    if f then safe(f, T.configID, nodeID) end
    T.Refresh(); C_Timer.After(0.2, function() T.Refresh() end)
end
function T:HasStaged()
    local configID = T:TraitIDs()
    if not (configID and C_Traits.ConfigHasStagedChanges) then return false end
    return safe(C_Traits.ConfigHasStagedChanges, configID) and true or false
end
function T:Commit()
    if T.configID and C_Traits.CommitConfig then safe(C_Traits.CommitConfig, T.configID) end
    C_Timer.After(0.3, function() T.Refresh() end)
end
function T:Rollback()
    if T.configID and C_Traits.RollbackConfig then safe(C_Traits.RollbackConfig, T.configID) end
    T.Refresh(); C_Timer.After(0.2, function() T.Refresh() end)
end

---------------------------------------------------------------------------
-- Страница
---------------------------------------------------------------------------
local function groupName(g)
    local name, icon
    if g.info and g.info.name then name, icon = g.info.name, g.info.icon
    else name, icon = spellInfo(g.spell) end
    -- режим EN: английское название (клиент может быть русским)
    if not ru() and QuestCompassTalentEN and QuestCompassTalentEN[g.spell] then name = QuestCompassTalentEN[g.spell] end
    return name, icon
end

local function treeMode() return FG.cdb.talentView ~= "list" end

-- название ветки в заголовке: как в окне игры («Shadow Magic»), в режиме RU — по-русски
local function headName(d, tab)
    -- клиент может быть русским, поэтому в режиме EN — название из данных аддона
    local ti = T.treeInfo and T.treeInfo[tab]
    if ru() and ti and ti.name and ti.name ~= "" then return ti.name end
    return treeName(d, tab)
end

---------------------------------------------------------------------------
-- Три ветки рядом, как в окне талантов игры; ранги — вкачано / нужно по раскладке
---------------------------------------------------------------------------
local WHITE = "Interface\\Buttons\\WHITE8x8"

local function frameBorder(f, r, g, b, a, w)
    for _, p in ipairs({ { "TOPLEFT", "TOPRIGHT", true }, { "BOTTOMLEFT", "BOTTOMRIGHT", true }, { "TOPLEFT", "BOTTOMLEFT" }, { "TOPRIGHT", "BOTTOMRIGHT" } }) do
        local t = f:CreateTexture(nil, "OVERLAY")
        t:SetTexture(WHITE); t:SetVertexColor(r, g, b, a)
        t:SetPoint(p[1]); t:SetPoint(p[2])
        if p[3] then t:SetHeight(w) else t:SetWidth(w) end
    end
end

local function lineTex(col, i)
    local t = col.lines[i]
    if not t then
        t = col.grid:CreateTexture(nil, "BORDER")
        t:SetTexture(WHITE)
        col.lines[i] = t
    end
    return t
end

local function cellTip(self)
    local c = self.data
    if not c then return end
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    local ok = c.info and not c.info.nodeID and GameTooltip.SetTalent and pcall(GameTooltip.SetTalent, GameTooltip, c.tab, c.info.index)
    local sp = (c.info and c.info.spell) or c.spell
    if not ok and sp and GameTooltip.SetSpellByID then pcall(GameTooltip.SetSpellByID, GameTooltip, sp) end
    if c.plan > 0 then
        GameTooltip:AddLine(L("tal_have", c.rank, c.max), 1, 1, 1, true)
        GameTooltip:AddLine(L("tal_plan", c.plan, c.max), 1, 0.82, 0, true)
        for _, g in ipairs(c.groups or {}) do
            GameTooltip:AddLine(L("tal_levels", g.from, g.to, g.need), 0.4, 0.88, 0.48, true)
        end
    else
        GameTooltip:AddLine(L("tal_notused"), 0.6, 0.6, 0.6, true)
    end
    if c.info and c.info.nodeID then GameTooltip:AddLine(L("tal_clickhint"), 0.55, 0.75, 1, true) end
    GameTooltip:Show()
end

local function cellFrame(col, i)
    local c = col.cells[i]
    if c then return c end
    c = CreateFrame("Button", nil, col.grid)
    c.icon = c:CreateTexture(nil, "ARTWORK")
    c.icon:SetAllPoints(); c.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    c.edge = {}
    -- рамка вокруг иконки: цвет показывает, взят ли талант по раскладке
    for k, p in ipairs({
        { "TOPLEFT", -1, 1, "TOPRIGHT", 1, 1, true }, { "BOTTOMLEFT", -1, -1, "BOTTOMRIGHT", 1, -1, true },
        { "TOPLEFT", -1, 1, "BOTTOMLEFT", -1, -1 }, { "TOPRIGHT", 1, 1, "BOTTOMRIGHT", 1, -1 },
    }) do
        local t = c:CreateTexture(nil, "OVERLAY")
        t:SetTexture(WHITE)
        t:SetPoint(p[1], p[2], p[3]); t:SetPoint(p[4], p[5], p[6])
        if p[7] then t:SetHeight(2) else t:SetWidth(2) end
        c.edge[k] = t
    end
    c.glow = c:CreateTexture(nil, "OVERLAY", nil, 1)
    c.glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    c.glow:SetBlendMode("ADD"); c.glow:SetPoint("CENTER")
    -- следующий талант пульсирует
    c.pulse = c.glow:CreateAnimationGroup()
    local a = c.pulse:CreateAnimation("Alpha")
    a:SetFromAlpha(1); a:SetToAlpha(0.25); a:SetDuration(0.7)
    c.pulse:SetLooping("BOUNCE")
    c.badge = CreateFrame("Frame", nil, c)
    c.badge:SetFrameLevel(c:GetFrameLevel() + 2)
    c.badge:SetPoint("BOTTOMRIGHT", c, "BOTTOMRIGHT", 3, -3) -- внутри клетки, чтобы край сетки не обрезал
    c.badge.bg = c.badge:CreateTexture(nil, "BACKGROUND")
    c.badge.bg:SetTexture(WHITE); c.badge.bg:SetVertexColor(0, 0, 0, 0.85); c.badge.bg:SetAllPoints()
    c.badge.text = S:NoInk(c.badge:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"))
    c.badge.text:SetPoint("CENTER", 0, 0)
    c:SetScript("OnEnter", cellTip)
    c:SetScript("OnLeave", function() GameTooltip:Hide() end)
    -- ЛКМ — поставить очко, ПКМ — убрать поставленное (принимается кнопкой «Принять»)
    c:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    c:SetScript("OnClick", function(self, btn)
        local d = self.data
        if not (d and d.info and d.info.nodeID) then return end
        T:Stage(d.info.nodeID, btn ~= "RightButton")
        if GameTooltip:IsOwned(self) then cellTip(self) end
    end)
    col.cells[i] = c
    return c
end

-- одна ветка: заголовок (иконка, название, очки) и сетка 4 столбца на фоне ветки
local HEAD_H = 32
local function drawTree(col, tab, d, groups, nx, have, x, top, cw, gh, rows, spent, goal)
    -- размеры клеток под ширину ветки и высоту страницы; сетка не выше, чем нужно рядам
    -- всё должно влезть: и по ширине (4 столбца + место под значок ранга), и по высоте (все ряды)
    local stepX = math.floor((cw - 12) / 4)
    local maxY = math.floor((gh - 12) / rows)
    local icon = math.max(18, math.min(44, stepX - 8, maxY - 8))
    local stepY = math.min(maxY, math.floor(icon * 1.4))
    gh = math.min(gh, rows * stepY + 12)
    col:ClearAllPoints(); col:SetPoint("TOPLEFT", page, "TOPLEFT", x, -top); col:SetSize(cw, gh + HEAD_H)
    -- заголовок
    local ti = T.treeInfo and T.treeInfo[tab]
    local hicon = ti and ti.icon
    if not hicon then
        for _, r in pairs(have[tab] or {}) do for _, t in pairs(r) do hicon = hicon or t.icon end end
    end
    col.headIcon:SetTexture(hicon or "Interface\\Icons\\INV_Misc_QuestionMark")
    col.headName:SetText(headName(d, tab))
    col.headCount:SetText(spent[tab] .. "|cff9aa0a8/" .. goal[tab] .. "|r")
    col.headSel:SetShown(tab == T:Spec())
    -- раскладка по этой ветке: итоговый ранг и уровни
    local plan, byKey = {}, {}
    for _, gr in ipairs(groups) do
        if gr.tab == tab then
            local k = gr.row .. ":" .. gr.col
            plan[k] = math.max(plan[k] or 0, gr.need)
            byKey[k] = byKey[k] or {}
            table.insert(byKey[k], gr)
        end
    end
    -- клетки: все таланты ветки из игры + таланты раскладки (если игра их не отдала)
    local cells, seen = {}, {}
    for tier, r in pairs(have[tab] or {}) do
        for c, t in pairs(r) do
            local k = tier .. ":" .. c
            seen[k] = true
            cells[#cells + 1] = { tab = tab, row = tier, col = c, info = t, key = k }
        end
    end
    for k, list in pairs(byKey) do
        if not seen[k] then
            local gr = list[1]
            cells[#cells + 1] = { tab = tab, row = gr.row, col = gr.col, spell = gr.spell, key = k }
        end
    end
    local g = col.grid
    -- фон ветки: 4 куска 256+64 × 256+128, как в окне талантов
    local bg = treeBg(tab)
    if bg then
        local base = "Interface\\TalentFrame\\" .. bg
        -- картинка занимает 296×332 из 320×384 (справа и снизу пусто) — растягиваем видимую часть на всю сетку
        local tw, tht = cw * 320 / 296, gh * 384 / 332
        local lw, th = tw * 0.8, tht * 2 / 3
        g.tl:SetTexture(base .. "-TopLeft"); g.tl:SetSize(lw, th)
        g.tr:SetTexture(base .. "-TopRight"); g.tr:SetSize(tw - lw, th)
        g.bl:SetTexture(base .. "-BottomLeft"); g.bl:SetSize(lw, tht - th)
        g.br:SetTexture(base .. "-BottomRight"); g.br:SetSize(tw - lw, tht - th)
        g.tr:ClearAllPoints(); g.tr:SetPoint("TOPLEFT", g.tl, "TOPRIGHT")
        g.bl:ClearAllPoints(); g.bl:SetPoint("TOPLEFT", g.tl, "BOTTOMLEFT")
        g.br:ClearAllPoints(); g.br:SetPoint("TOPLEFT", g.tl, "BOTTOMRIGHT")
        for _, t in ipairs({ g.tl, g.tr, g.bl, g.br }) do t:Show() end
    else
        for _, t in ipairs({ g.tl, g.tr, g.bl, g.br }) do t:Hide() end
    end
    local padX = (cw - stepX * 4) / 2
    local function cx(c) return padX + (c - 0.5) * stepX end
    local function cy(r) return -(6 + (r - 0.5) * stepY) end
    -- мелкий шрифт значка, чтобы ранги не наезжали на соседние иконки
    local small = icon < 32
    local bw = small and 22 or 28
    for i, c in ipairs(cells) do
        local f = cellFrame(col, i)
        c.plan = plan[c.key] or 0
        c.groups = byKey[c.key]
        c.rank = c.info and c.info.rank or 0
        c.max = (c.info and c.info.max and c.info.max > 0) and c.info.max or c.plan
        local tex
        if c.info and c.info.icon then tex = c.info.icon else local _, ic = spellInfo(c.spell) tex = ic end
        f.data = c
        f:SetSize(icon, icon)
        f:ClearAllPoints(); f:SetPoint("CENTER", g, "TOPLEFT", cx(c.col), cy(c.row))
        f.icon:SetTexture(tex or "Interface\\Icons\\INV_Misc_QuestionMark")
        local isNext = (nx and nx.tab == tab and nx.row == c.row and nx.col == c.col) and true or false
        f.glow:SetSize(icon * 1.9, icon * 1.9)
        f.glow:SetShown(isNext)
        if isNext then f.pulse:Play() else f.pulse:Stop() end
        f.badge:SetSize(bw, small and 11 or 13)
        if f.badge.small ~= small then
            pcall(f.badge.text.SetFont, f.badge.text, "Fonts\\FRIZQT___CYR.TTF", small and 9 or 11, "")
            f.badge.small = small
        end
        -- цвета (см. легенду под деревьями):
        --   зелёный — взято сколько нужно; золотой с пульсом — следующий; тёмно-золотой — по плану позже;
        --   серый без цифр — в раскладку не входит; голубой — поставлено, но не принято
        local er, eg, eb, ea
        f.badge:Show()
        if c.plan > 0 then
            f.badge.text:SetText(math.min(c.rank, c.plan) .. "/" .. c.plan)
            f.icon:SetDesaturated(false)
            if c.rank >= c.plan then
                f.icon:SetAlpha(1)
                f.badge.text:SetTextColor(0.4, 1, 0.4); er, eg, eb, ea = 0.25, 0.9, 0.3, 1
            elseif isNext then
                f.icon:SetAlpha(1)
                f.badge.text:SetTextColor(1, 0.9, 0.2); er, eg, eb, ea = 1, 0.85, 0.1, 1
            else
                f.icon:SetAlpha(0.8)
                f.badge.text:SetTextColor(0.85, 0.7, 0.35); er, eg, eb, ea = 0.6, 0.48, 0.2, 1
            end
        else
            -- не нужно по раскладке: блёкло, без рамки; цифра — только если туда уже вложено
            f.icon:SetDesaturated(true); f.icon:SetAlpha(c.rank > 0 and 0.8 or 0.3)
            f.badge.text:SetText(c.rank .. "/" .. c.max)
            f.badge.text:SetTextColor(0.6, 0.6, 0.6)
            f.badge:SetShown(c.rank > 0)
            er, eg, eb, ea = 0, 0, 0, 0
        end
        -- поставлено, но ещё не принято — голубым
        if c.info and c.info.active and c.rank > c.info.active then
            f.icon:SetAlpha(1)
            f.badge.text:SetTextColor(0.45, 0.8, 1); er, eg, eb, ea = 0.45, 0.8, 1, 1
        end
        for _, t in ipairs(f.edge) do t:SetVertexColor(er, eg, eb, ea) end
        f:Show()
    end
    for i = #cells + 1, #col.cells do col.cells[i]:Hide(); col.cells[i].data = nil end
    -- связи «требует»: линия от таланта-условия к зависимому
    local nl = 0
    local function seg(x1, y1, x2, y2, lit)
        nl = nl + 1
        local t = lineTex(col, nl)
        t:ClearAllPoints()
        if x1 == x2 then
            t:SetPoint("TOP", g, "TOPLEFT", x1, math.max(y1, y2)); t:SetSize(3, math.abs(y1 - y2))
        else
            t:SetPoint("LEFT", g, "TOPLEFT", math.min(x1, x2), y1); t:SetSize(math.abs(x1 - x2), 3)
        end
        if lit then t:SetVertexColor(1, 0.82, 0, 0.95) else t:SetVertexColor(0.45, 0.45, 0.45, 0.7) end
        t:Show()
    end
    for _, c in ipairs(cells) do
        for _, q in ipairs(c.info and c.info.req or {}) do
            local pt, pc = q[1], q[2]
            local lit = c.plan > 0
            local x1, y1, x2, y2 = cx(pc), cy(pt), cx(c.col), cy(c.row)
            local half = icon / 2
            if pc == c.col then
                seg(x1, y1 - half, x2, y2 + half, lit)
            elseif pt == c.row then
                if pc < c.col then seg(x1 + half, y1, x2 - half, y2, lit) else seg(x2 + half, y1, x1 - half, y2, lit) end
            else
                seg(pc < c.col and x1 + half or x1 - half, y1, x2, y1, lit)
                seg(x2, y1, x2, y2 + half, lit)
            end
        end
    end
    for i = nl + 1, #col.lines do col.lines[i]:Hide() end
    col:Show()
end

-- вкладки «Основной / Второй»: галочка — активный набор, замок — второй до 40 уровня
local function refreshGroupTabs()
    local cur, active, open = T:Group(), T:ActiveGroup(), T:SecondUnlocked()
    for g = 1, 2 do
        local b = page.gtabs[g]
        local txt = L(g == 1 and "tal_primary" or "tal_secondary")
        if g == active then txt = txt .. " |TInterface\\RaidFrame\\ReadyCheck-Ready:14|t" end
        if g == 2 and not open then txt = txt .. " |cff9aa0a8" .. SECOND_LEVEL .. "+|r" end
        b.label:SetText(txt)
        b.sel:SetShown(g == cur)
        if b.qpBox then
            if g == cur then b.qpBox.border:SetColor(1, 0.82, 0, 0.9) else b.qpBox.border:SetColor(0.45, 0.35, 0.2, 0.8) end
        end
        b.label:SetAlpha((g == 2 and not open) and 0.6 or 1)
    end
end

local function refresh()
    if not page or not page:IsVisible() then return end
    local d = T:Data()
    local cname = L("class_" .. tostring(T:Class()))
    page.title:SetText(L("tal_title", cname))
    refreshGroupTabs()
    if page.spec then page.spec:Refresh() end
    if not d then
        page.nextName:SetText(L("tal_nodata")); page.nextIcon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
        for i = 1, ROWS do page.rows[i]:Hide() end
        for t = 1, 3 do page.cols[t]:Hide(); page.tabs[t]:Hide() end
        page.viewBtn:Hide()
        page.accept:Hide(); page.cancel:Hide(); page.unspent:Hide(); page.legend:Hide()
        return
    end
    local tree = treeMode()
    page.viewBtn:Show()
    page.viewBtn.label:SetText(L(tree and "tal_view_list" or "tal_view_tree"))
    local groups, nx, have = T:State()
    local free = freePoints()
    local lvl = UnitLevel("player") or 1
    -- очки: сейчас / по раскладке, и поставленные, но не принятые
    local spent, goal, staged = { 0, 0, 0 }, { 0, 0, 0 }, 0
    for tab = 1, 3 do
        for _, r in pairs(have[tab] or {}) do
            for _, t in pairs(r) do
                spent[tab] = spent[tab] + (t.rank or 0)
                if t.active and t.rank > t.active then staged = staged + (t.rank - t.active) end
            end
        end
    end
    for _, g in ipairs(groups) do goal[g.tab] = goal[g.tab] + (g.to - g.from + 1) end
    -- окошко «Свободно очков» и «Принять изменения» / «Отмена»
    page.unspent:Show()
    page.unspent.num:SetText(free)
    if free > 0 then page.unspent.num:SetTextColor(0.4, 1, 0.4) else page.unspent.num:SetTextColor(1, 0.82, 0) end
    page.unspent.staged:SetText(staged > 0 and ("|cff3399ff" .. L("tal_staged", staged) .. "|r") or "")
    local hasStaged = staged > 0 or T:HasStaged()
    page.accept:Show(); page.accept:SetEnabled(hasStaged)
    page.cancel:SetShown(hasStaged)
    -- карточка «следующий талант»
    if lvl < 10 then
        page.nextIcon:SetTexture("Interface\\Icons\\INV_Misc_Book_07")
        page.nextName:SetText(L("tal_from10"))
        page.nextSub:SetText("")
        page.learn:Hide()
    elseif nx then
        local nm, ic = groupName(nx)
        page.nextIcon:SetTexture(ic or "Interface\\Icons\\INV_Misc_QuestionMark")
        page.nextName:SetText((nm or "?") .. "  |cffffd100" .. (nx.rank + 1) .. "/" .. ((nx.info and nx.info.max) or nx.need) .. "|r")
        page.nextSub:SetText(L("tal_where", headName(d, nx.tab), nx.row))
        page.learn:SetShown(free > 0)
    else
        page.nextIcon:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready")
        page.nextName:SetText(L("tal_alldone"))
        page.nextSub:SetText("")
        page.learn:Hide()
    end
    local pw, ph = page:GetWidth(), page:GetHeight()
    if type(pw) ~= "number" or pw <= 0 then pw = W end
    if type(ph) ~= "number" or ph <= 0 then ph = 600 end
    if tree then
        for i = 1, ROWS do page.rows[i]:Hide(); page.rows[i].group = nil end
        for t = 1, 3 do page.tabs[t]:Hide() end
        if page.sb then page.sb:Hide() end
        page.scrollTo = nil
        -- три ветки рядом
        local top, bottom, gap = 176, 70, 4
        local cw = math.floor((pw - 28 - gap * 2) / 3)
        local gh = math.max(120, ph - top - HEAD_H - bottom)
        local rows = 7
        for tab = 1, 3 do for tier in pairs(have[tab] or {}) do rows = math.max(rows, tier) end end
        for _, g in ipairs(groups) do rows = math.max(rows, g.row) end
        for tab = 1, 3 do
            drawTree(page.cols[tab], tab, d, groups, nx, have, 14 + (tab - 1) * (cw + gap), top, cw, gh, rows, spent, goal)
        end
        page.legend:Show()
        return
    end
    for t = 1, 3 do page.cols[t]:Hide() end
    page.legend:Hide()
    -- список: строка веток (очки сейчас / по раскладке) и порядок по уровням
    for tab = 1, 3 do
        local b = page.tabs[tab]
        b.label:SetText(headName(d, tab) .. " |cffffd100" .. spent[tab] .. "|r|cff9aa0a8/" .. goal[tab] .. "|r")
        b:Show()
    end
    local top = 196
    local vis = math.max(4, math.min(ROWS, math.floor((ph - top - 44) / ROW_H)))
    if page.scrollTo then
        page.offset = 0
        for i, g in ipairs(groups) do if not g.done then page.offset = math.max(0, i - 3) break end end
        page.scrollTo = nil
    end
    page.offset = math.max(0, math.min(page.offset or 0, #groups - vis))
    if page.sb then
        page.sb:ClearAllPoints()
        page.sb:SetPoint("TOPRIGHT", page, "TOPRIGHT", -3, -top)
        page.sb:SetHeight(vis * ROW_H - 4)
        page.sb:Update(page.offset, #groups, vis)
    end
    for i = 1, ROWS do
        local r = page.rows[i]
        local g = i <= vis and groups[i + page.offset]
        if g then
            r.group = g
            r:ClearAllPoints(); r:SetPoint("TOPLEFT", 12, -top - (i - 1) * ROW_H)
            local nm, ic = groupName(g)
            r.lvl:SetText(g.from == g.to and tostring(g.from) or (g.from .. "–" .. g.to))
            r.icon:SetTexture(ic or "Interface\\Icons\\INV_Misc_QuestionMark")
            r.name:SetText(nm or "?")
            local mx = (g.info and g.info.max) or g.need
            r.rank:SetText(math.min(g.rank, g.need) .. "/" .. g.need .. (mx ~= g.need and ("|cff9aa0a8 (" .. L("tal_of") .. " " .. mx .. ")|r") or ""))
            r.tree:SetText(headName(d, g.tab))
            r.cur:Hide(); r.check:Hide(); r.icon:SetDesaturated(false); r.name:SetAlpha(1)
            if g.done then
                r.check:Show(); r.icon:SetDesaturated(true); r.name:SetAlpha(0.55); r.lvl:SetTextColor(0.55, 0.57, 0.6)
                r.rank:SetTextColor(0.4, 0.88, 0.48)
            elseif g == nx then
                r.cur:Show(); r.lvl:SetTextColor(0.4, 0.88, 0.48); r.rank:SetTextColor(1, 0.82, 0)
            else
                r.lvl:SetTextColor(1, 0.82, 0); r.rank:SetTextColor(0.85, 0.85, 0.85)
                if g.from > lvl then r.name:SetAlpha(0.8) end
            end
            r:Show()
        else
            r.group = nil
            r:Hide()
        end
    end
end
T.Refresh = refresh

function T:BuildPage(parent)
    if page then return end
    S = FG.Style
    page = CreateFrame("Frame", "QuestCompassTalentsPage", parent)
    page:SetAllPoints(parent)
    page.spec, page.offset, page.scrollTo, page.sb = false, 0, true, false
    page:HookScript("OnShow", function() page.scrollTo = true; refresh() end)
    page.title = S:Text(page, "title", S.c.accent)
    page.title:SetPoint("TOPLEFT", 16, -14)
    -- кнопка «Список / Дерево»
    page.viewBtn = S:Button(page, " ", 84, 22, function()
        FG.cdb.talentView = treeMode() and "list" or "tree"
        page.scrollTo = true; refresh()
    end, { raw = true })
    page.viewBtn:SetPoint("TOPRIGHT", -14, -12)
    -- вкладки наборов «Основной / Второй» (как Primary / Secondary в окне игры)
    page.gtabs = {}
    for g = 1, 2 do
        local b = CreateFrame("Button", nil, page)
        b:SetSize(112, 24)
        b:SetPoint("TOPLEFT", 16 + (g - 1) * 118, -42)
        S:Box(b, 5, { 0.1, 0.09, 0.05, 0.9 }, { 0.45, 0.35, 0.2, 0.8 })
        b.sel = S:GoldBar(b, 0.5); b.sel:Hide()
        b.label = S:Text(b, "label", S.c.text)
        b.label:SetPoint("CENTER", 0, 0); b.label:SetWordWrap(false)
        b:SetScript("OnClick", function()
            if g == 2 and not T:SecondUnlocked() then FG:Print(L("tal_second_locked", SECOND_LEVEL)) return end
            FG.cdb.talentGroup = g; page.scrollTo = true; refresh()
        end)
        b:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
            GameTooltip:AddLine(L(g == 1 and "tal_primary" or "tal_secondary"), 1, 0.82, 0)
            if g == 2 and not T:SecondUnlocked() then GameTooltip:AddLine(L("tal_second_locked", SECOND_LEVEL), 1, 1, 1, true)
            elseif g ~= T:ActiveGroup() then GameTooltip:AddLine(L("tal_inactive"), 1, 1, 1, true) end
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        page.gtabs[g] = b
    end
    -- «Свободно очков» — окошко с числом, как Unspent Talents
    local un = CreateFrame("Frame", nil, page)
    un:SetSize(34, 28); un:SetPoint("TOPRIGHT", -14, -40)
    un.qcNoInk = true
    local ubg = un:CreateTexture(nil, "BACKGROUND")
    ubg:SetTexture(WHITE); ubg:SetVertexColor(0.06, 0.05, 0.04, 0.95); ubg:SetAllPoints()
    frameBorder(un, 0.5, 0.4, 0.2, 1, 1)
    un.num = S:NoInk(un:CreateFontString(nil, "OVERLAY"))
    un.num:SetFontObject(S.font.badge); un.num:SetPoint("CENTER", 0, 0)
    -- подписи слева от окошка (дочерние, чтобы прятались вместе с ним)
    un.label = S:Text(un, "small", S.c.text)
    un.label:SetPoint("RIGHT", un, "LEFT", -6, 5); un.label:SetJustifyH("RIGHT")
    FG:Localize(un.label, "tal_unspent")
    un.staged = S:Text(un, "small", S.c.text)
    un.staged:SetPoint("TOPRIGHT", un.label, "BOTTOMRIGHT", 0, -1); un.staged:SetJustifyH("RIGHT")
    un:Hide()
    page.unspent = un
    -- выбор раскладки: через какую ветку качаться (для открытого набора)
    local d0 = T:Data()
    if d0 then
        local items = {}
        for t = 1, 3 do items[t] = { t, treeName(d0, t) } end
        local seg = S:Segmented(page, items, W - 32, 24,
            function() return T:Spec() end,
            function(v) FG.cdb[T:Group() == 2 and "talentTree2" or "talentTree"] = v; page.scrollTo = true; refresh() end,
            { raw = true, tip = "tal_build_tip" })
        seg:SetPoint("TOPLEFT", 16, -72)
        page.spec = seg
        FG:OnLanguageChanged(function()
            for t = 1, 3 do local b = seg.buttons and seg.buttons[t] if b and b.label then b.label:SetText(treeName(d0, t)) end end
        end)
    end
    -- карточка «следующий талант»
    local card = CreateFrame("Frame", nil, page)
    card:SetPoint("TOPLEFT", 12, -102); card:SetPoint("TOPRIGHT", -12, -102); card:SetHeight(66)
    S:Box(card, 6, { 0.1, 0.09, 0.05, 0.9 }, { 1, 0.82, 0, 0.45 })
    local cap = S:Text(card, "small", S.c.accent)
    cap:SetPoint("TOPLEFT", 12, -6)
    FG:Localize(cap, "tal_next")
    page.nextIcon = card:CreateTexture(nil, "ARTWORK")
    page.nextIcon:SetSize(34, 34); page.nextIcon:SetPoint("TOPLEFT", 12, -24)
    page.nextIcon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    page.nextName = S:Text(card, "label", S.c.text)
    page.nextName:SetPoint("TOPLEFT", page.nextIcon, "TOPRIGHT", 10, -1); page.nextName:SetPoint("RIGHT", -112, 0)
    page.nextName:SetWordWrap(false)
    page.nextSub = S:Text(card, "small", S.c.muted)
    page.nextSub:SetPoint("BOTTOMLEFT", page.nextIcon, "BOTTOMRIGHT", 10, 1); page.nextSub:SetPoint("RIGHT", -112, 0)
    page.learn = S:Button(card, "tal_learn", 92, 26, function() T:Learn() end, { font = "label", primary = true })
    page.learn:SetPoint("RIGHT", -12, -8)
    page.learn:Hide()
    -- три ветки: заголовок + сетка на фоне ветки (надписи на тёмном фоне светлые)
    page.cols = {}
    for t = 1, 3 do
        local col = CreateFrame("Frame", nil, page)
        col.headSel = S:GoldBar(col, 0.4); col.headSel:ClearAllPoints()
        col.headSel:SetPoint("TOPLEFT"); col.headSel:SetPoint("TOPRIGHT"); col.headSel:SetHeight(HEAD_H - 4)
        col.headIcon = col:CreateTexture(nil, "ARTWORK")
        col.headIcon:SetSize(24, 24); col.headIcon:SetPoint("TOPLEFT", 4, -2)
        col.headIcon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        col.headCount = S:Text(col, "label", S.c.text)
        col.headCount:SetPoint("TOPRIGHT", -4, -7); col.headCount:SetJustifyH("RIGHT")
        col.headName = S:Text(col, "label", S.c.accent)
        col.headName:SetPoint("LEFT", col.headIcon, "RIGHT", 6, 0); col.headName:SetPoint("RIGHT", col.headCount, "LEFT", -4, 0)
        col.headName:SetWordWrap(false)
        local g = CreateFrame("Frame", nil, col)
        g:SetPoint("TOPLEFT", 0, -HEAD_H); g:SetPoint("BOTTOMRIGHT")
        g.qcNoInk = true
        g.shade = g:CreateTexture(nil, "BACKGROUND", nil, -2)
        g.shade:SetTexture(WHITE); g.shade:SetVertexColor(0.06, 0.05, 0.04, 0.95); g.shade:SetAllPoints()
        -- фон ветки — в отдельном фрейме, обрезанном по краям сетки
        g:SetClipsChildren(true)
        g.art = CreateFrame("Frame", nil, g)
        g.art:SetAllPoints(); g.art:SetFrameLevel(g:GetFrameLevel())
        g.tl = g.art:CreateTexture(nil, "BACKGROUND"); g.tl:SetPoint("TOPLEFT")
        g.tr = g.art:CreateTexture(nil, "BACKGROUND")
        g.bl = g.art:CreateTexture(nil, "BACKGROUND")
        g.br = g.art:CreateTexture(nil, "BACKGROUND")
        frameBorder(g, 0.27, 0.17, 0.09, 1, 2)
        col.grid, col.cells, col.lines = g, {}, {}
        col:Hide()
        page.cols[t] = col
    end
    -- список: строка «Ветка очки/цель» над порядком по уровням
    page.tabs = {}
    local tw = (W - 32) / 3
    for t = 1, 3 do
        local b = CreateFrame("Frame", nil, page)
        b:SetSize(tw, 18)
        b:SetPoint("TOPLEFT", 16 + (t - 1) * tw, -174)
        b.label = S:Text(b, "small", S.c.text)
        b.label:SetPoint("CENTER", 0, 0); b.label:SetWordWrap(false)
        b:Hide()
        page.tabs[t] = b
    end
    -- низ: «Принять изменения» / «Отмена»
    page.accept = S:Button(page, "tal_accept", 170, 24, function() T:Commit() end, { font = "label", primary = true })
    page.accept:SetPoint("BOTTOM", 0, 10)
    page.cancel = S:Button(page, "tal_cancel", 80, 24, function() T:Rollback() end)
    page.cancel:SetPoint("LEFT", page.accept, "RIGHT", 6, 0)
    page.accept:Hide(); page.cancel:Hide()
    -- легенда цветов под деревьями
    local lg = CreateFrame("Frame", nil, page)
    lg:SetSize(W, 16); lg:SetPoint("BOTTOM", 0, 44)
    local items = {
        { "tal_lg_done", 0.25, 0.9, 0.3 }, { "tal_lg_next", 1, 0.85, 0.1 }, { "tal_lg_plan", 0.6, 0.48, 0.2 },
        { "tal_lg_staged", 0.45, 0.8, 1 }, { "tal_lg_skip", 0.45, 0.45, 0.45 },
    }
    local prev
    lg.parts = {}
    for _, it in ipairs(items) do
        local sw = lg:CreateTexture(nil, "ARTWORK")
        sw:SetTexture(WHITE); sw:SetVertexColor(it[2], it[3], it[4], 1); sw:SetSize(10, 10)
        if prev then sw:SetPoint("LEFT", prev, "RIGHT", 10, 0) else sw:SetPoint("LEFT", 0, 0) end
        local tx = S:Text(lg, "small", S.c.text)
        tx:SetPoint("LEFT", sw, "RIGHT", 4, 0); tx:SetWordWrap(false)
        FG:Localize(tx, it[1])
        prev = tx
        lg.parts[#lg.parts + 1] = tx
    end
    -- по центру: ширина зависит от длины подписей
    lg:SetScript("OnShow", function(self)
        local w = 0
        for _, tx in ipairs(self.parts) do w = w + (tx:GetStringWidth() or 40) + 24 end
        self:SetWidth(w)
    end)
    lg:Hide()
    page.legend = lg

    page.rows = {}
    for i = 1, ROWS do
        local r = CreateFrame("Button", nil, page)
        r:SetSize(W - 30, ROW_H - 4)
        r.cur = S:GoldBar(r, 0.45); r.cur:Hide()
        r.hl = S:GoldBar(r, 0.2); r.hl:Hide()
        r.lvl = S:Text(r, "small", S.c.accent)
        r.lvl:SetPoint("LEFT", 2, 0); r.lvl:SetWidth(52); r.lvl:SetJustifyH("CENTER")
        r.icon = r:CreateTexture(nil, "ARTWORK")
        r.icon:SetSize(28, 28); r.icon:SetPoint("LEFT", 56, 0)
        r.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        r.check = r:CreateTexture(nil, "OVERLAY")
        r.check:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready")
        r.check:SetSize(14, 14); r.check:SetPoint("BOTTOMRIGHT", r.icon, "BOTTOMRIGHT", 3, -3); r.check:Hide()
        r.rank = S:Text(r, "label", S.c.text)
        r.rank:SetPoint("TOPRIGHT", -6, -2); r.rank:SetJustifyH("RIGHT")
        r.name = S:Text(r, "label", S.c.text)
        r.name:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 8, 1); r.name:SetPoint("RIGHT", r.rank, "LEFT", -6, 0)
        r.name:SetWordWrap(false)
        r.tree = S:Text(r, "small", S.c.muted)
        r.tree:SetPoint("BOTTOMLEFT", r.icon, "BOTTOMRIGHT", 8, -1)
        r:SetScript("OnEnter", function(self)
            self.hl:Show()
            local g = self.group
            if not g then return end
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            local ok = g.info and not g.info.nodeID and GameTooltip.SetTalent and pcall(GameTooltip.SetTalent, GameTooltip, g.tab, g.info.index)
            local sp = (g.info and g.info.spell) or g.spell
            if not ok and sp and GameTooltip.SetSpellByID then pcall(GameTooltip.SetSpellByID, GameTooltip, sp) end
            GameTooltip:AddLine(L("tal_levels", g.from, g.to, g.need), 0.4, 0.88, 0.48, true)
            GameTooltip:Show()
        end)
        r:SetScript("OnLeave", function(self) self.hl:Hide(); GameTooltip:Hide() end)
        page.rows[i] = r
    end
    page:EnableMouseWheel(true)
    page:SetScript("OnMouseWheel", function(_, dl) if treeMode() then return end page.offset = (page.offset or 0) - dl * 2; refresh() end)
    page.sb = S:ScrollBar(page, function(off) page.offset = off; refresh() end)
    page:SetScript("OnSizeChanged", function() refresh() end)
    FG:OnLanguageChanged(refresh)
end

---------------------------------------------------------------------------
-- Подсказка в чате, когда появилось новое очко
---------------------------------------------------------------------------
local lastFree = -1
local function announce()
    if not QuestCompassTalents then return end
    local free = freePoints()
    if free > 0 and free ~= lastFree then
        local d = T:Data()
        local _, nx = T:State()
        if d and nx then
            local nm = groupName(nx)
            FG:Print(L("tal_chat", free, nm or "?", treeName(d, nx.tab)))
        end
    end
    lastFree = free
end
local pend
local function soon()
    if pend then return end
    pend = true
    C_Timer.After(0.5, function() pend = nil; refresh(); pcall(announce) end)
end
FG:On("CHARACTER_POINTS_CHANGED", soon)
FG:On("PLAYER_TALENT_UPDATE", soon)
FG:On("TRAIT_CONFIG_UPDATED", soon)
FG:On("TRAIT_NODE_CHANGED", soon)
FG:On("ACTIVE_COMBAT_CONFIG_CHANGED", soon)
FG:On("PLAYER_LEVEL_UP", function() C_Timer.After(1.5, soon) end)
FG:On("PLAYER_ENTERING_WORLD", function() C_Timer.After(4, soon) end)
