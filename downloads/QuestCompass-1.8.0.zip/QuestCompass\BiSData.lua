-- Сгенерировано: списки BiS до рейдов (Icy Veins, WoW Classic), ID проверены по базе Questie
QuestCompassBiS = {
  WARRIOR = {
    dps = { head = 12640, neck = 15411, shoulder = 20683, back = 21187, chest = 11726, wrist = 19578, hands = 14551, waist = 20204, legs = 22385, feet = 20208, ring1 = 19325, ring2 = 21182, trinket1 = 21180, trinket2 = 20130, mh = 11684, oh = 19169, ranged = 19107 },
  },
  PALADIN = {
    heal = { head = 18490, neck = 18723, shoulder = 18681, back = 18510, chest = 13346, wrist = 18459, hands = 18527, waist = 19162, legs = 18386, feet = 16472, ring1 = 16058, ring2 = 18103, trinket1 = 22268, trinket2 = 12930, mh = 23454, oh = 19312, ranged = 23201 },
    dps = { head = 13404, neck = 15411, shoulder = 12927, back = 13340, chest = 11726, wrist = 12936, hands = 13957, waist = 13959, legs = 14554, feet = 14616, ring1 = 12548, ring2 = 13098, trinket1 = 11815, trinket2 = 13965, mh = 12784 },
  },
  HUNTER = {
    dps = { head = 18421, neck = 15411, shoulder = 12927, back = 13340, chest = 11726, wrist = 18375, hands = 15063, waist = 18393, legs = 15062, feet = 13967, ring1 = 18500, ring2 = 17713, trinket1 = 18473, trinket2 = 13965, mh = 18520, ranged = 18738 },
  },
  ROGUE = {
    dps = { head = 22005, neck = 15411, shoulder = 22008, back = 13340, chest = 22009, wrist = 22004, hands = 15063, waist = 22002, legs = 15062, feet = 22003, ring1 = 18500, ring2 = 17713, trinket1 = 11815, trinket2 = 13965, mh = 12940, oh = 12783, ranged = 12651 },
  },
  PRIEST = {
    heal = { head = 13102, neck = 18723, shoulder = 18681, back = 18510, chest = 14154, wrist = 11766, hands = 10787, waist = 18327, legs = 11841, feet = 18507, ring1 = 16058, ring2 = 18103, trinket1 = 18469, trinket2 = 22268, mh = 23454, oh = 19312, ranged = 16997 },
    dps = { head = 10504, neck = 18691, shoulder = 14112, back = 13386, chest = 14136, wrist = 11766, hands = 18407, waist = 11662, legs = 13170, feet = 18735, ring1 = 13001, ring2 = 12543, trinket1 = 12930, trinket2 = 18371, mh = 13349, oh = 10796, ranged = 13396 },
  },
  SHAMAN = {
    heal = { head = 18490, neck = 20685, shoulder = 22234, back = 18510, chest = 13346, wrist = 13969, hands = 18527, waist = 19162, legs = 18386, feet = 22247, ring1 = 22681, ring2 = 16058, trinket1 = 22268, trinket2 = 11819, mh = 20069, oh = 19312, ranged = 23200 },
  },
  MAGE = {
    dps = { head = 22267, neck = 22403, shoulder = 23264, back = 20697, chest = 19682, wrist = 21186, hands = 22870, waist = 11662, legs = 19683, feet = 19684, ring1 = 22339, ring2 = 21190, trinket1 = 22678, trinket2 = 12930, mh = 18874, oh = 19311 },
  },
  WARLOCK = {
    dps = { head = 22267, neck = 22403, shoulder = 20686, back = 20697, chest = 19682, wrist = 21186, hands = 10787, waist = 11662, legs = 19683, feet = 19684, ring1 = 22339, ring2 = 22433, trinket1 = 12930, trinket2 = 13968, mh = 22688, oh = 22329, ranged = 13396 },
  },
  DRUID = {
    heal = { head = 10504, neck = 18723, shoulder = 15061, back = 18510, chest = 13346, wrist = 18525, hands = 10787, waist = 14553, legs = 18386, feet = 13954, ring1 = 16058, ring2 = 22334, trinket1 = 18470, trinket2 = 18371, mh = 22406, oh = 19312, ranged = 22398 },
    dps = { head = 13404, neck = 15411, shoulder = 12927, back = 13340, chest = 14637, wrist = 19146, hands = 15063, waist = 18505, legs = 15062, feet = 16711, ring1 = 18500, ring2 = 17713, trinket1 = 11815, trinket2 = 13965, mh = 9449, ranged = 23198 },
  },
}
