-- QuestCompass_Data: своё имя для базы, чтобы QuestCompass брал именно её,
-- даже если рядом установлен другой QuestieDB (он перезапишет общий LibQuestieDB).
local _, lib = ...
_G.QuestCompassDataLib = lib
