-- QuestCompass: интерфейс — панель шагов, стрелка, точка на карте, опыт в час, команды
local _, ns = ...
local FG = ns.FG
local G = FG.Advisor
local S = FG.Style
local L = FG.L
local UI = {}
FG.UI = UI

local ARRIVE_YARDS = 12

---------------------------------------------------------------------------
-- Расстояние и направление до цели
---------------------------------------------------------------------------
-- Возвращает: дистанция (ярды), угол поворота стрелки, или nil + название зоны, куда идти
function UI:Navigate(s)
    if not s or not s.m or not s.x then return end
    -- маршрут с поворотами: ведём к ближайшей точке пути, а не к цели напрямую
    local wp = FG.Travel and FG.Travel:NextWaypoint(s)
    if wp then s = wp end
    local pm, px, py = FG:GetPlayerPos()
    if not px then return end
    local m, tx, ty, ax, ay = pm, nil, nil, px, py
    tx, ty = FG:ConvertPos(s.m, s.x, s.y, pm)
    if not tx then
        -- пробуем наоборот: игрока в координаты карты цели
        ax, ay = FG:ConvertPos(pm, px, py, s.m)
        if not ax then return nil, nil, FG:MapName(s.m) end
        m, tx, ty = s.m, s.x, s.y
    end
    local w, h = FG:MapSize(m)
    if not w then return nil, nil, FG:MapName(s.m) end
    local dx, dy = (tx - ax) * w, (ty - ay) * h
    local dist = math.sqrt(dx * dx + dy * dy)
    local facing = GetPlayerFacing and GetPlayerFacing()
    local angle
    if facing then angle = math.atan2(-dx, -dy) - facing end
    return dist, angle, nil, dx, -dy -- последние два: смещение до цели в ярдах (восток, север)
end

---------------------------------------------------------------------------
-- Панель шагов
---------------------------------------------------------------------------
local panel

local function savePos(frame, key)
    local p, _, rp, x, y = frame:GetPoint()
    FG.db[key] = { p, rp, x, y }
end

local PW = 380 -- ширина панели
local PANEL_H = 520 -- высота панели (постоянная)

-- крупный игровой шрифт для блока подземелья
local FRIZ = "Fonts\\FRIZQT___CYR.TTF"
local function big(fs, size)
    pcall(fs.SetFont, fs, FRIZ, size, "")
    fs:SetShadowOffset(1, -1); fs:SetShadowColor(0, 0, 0, 1)
    return fs
end

local function createPanel()
    panel = CreateFrame("Frame", "QuestCompassPanel", UIParent)
    panel.qcRoot = true
    UI.panel = panel
    panel:SetSize(PW, 120)
    local p = FG.db.panelPos
    panel:SetPoint(p[1], UIParent, p[2], p[3], p[4])
    panel:SetMovable(true)
    panel:EnableMouse(true)
    panel:RegisterForDrag("LeftButton")
    panel:SetClampedToScreen(true)
    panel:SetScript("OnDragStart", panel.StartMoving)
    panel:SetScript("OnDragStop", function(f) f:StopMovingOrSizing(); savePos(f, "panelPos") end)
    S:Window(panel, { glowHeight = 34, header = 34 })
    -- фон полупрозрачный, как у списка заданий Questie
    if S:IsPaper() then
        -- пергамент: фон уже задан
    elseif panel.SetBackdropColor then panel:SetBackdropColor(0, 0, 0, 0.55)
    elseif panel.qpBox and panel.qpBox.fill then panel.qpBox.fill:SetColor(0, 0, 0, 0.55) end

    -- шапка: логотип, название, счётчик журнала, крестик
    panel.logo = S.Tex(panel, "ARTWORK", { 1, 1, 1, 1 }, 0, S.media.logo)
    panel.logo:SetSize(16, 16)
    panel.logo:SetPoint("TOPLEFT", 12, -9)
    panel.title = S:Text(panel, "head", S.c.text)
    panel.title:SetPoint("LEFT", panel.logo, "RIGHT", 6, 0)
    panel.title:SetText("QUEST|cff" .. S.hex.accent .. "COMPASS|r")
    panel.count = S:Text(panel, "small", S.c.muted)
    panel.count:SetPoint("RIGHT", panel, "TOPRIGHT", -34, -17)
    panel.count:SetJustifyH("RIGHT")
    local close = S:Close(panel, function() UI:Toggle(false) end)
    close:SetPoint("TOPRIGHT", -7, -6)
    -- шапка без названия и счётчика журнала — только язык и крестик
    panel.logo:Hide(); panel.title:Hide(); panel.count:Hide()
    local lang = S:Segmented(panel, { { "ru", "RU" }, { "en", "EN" } }, 70, 22,
        function() return FG:Lang() end,
        function(v) FG:SetLanguage(v) end,
        { raw = true, tip = "tip_lang" })
    lang:SetPoint("RIGHT", close, "LEFT", -6, 0)
    FG:OnLanguageChanged(function() lang:Refresh() end)
    lang.qcNoInk = true

    -- текущее задание: значок + текст + расстояние
    panel.badge = S:Badge(panel, 30)
    panel.badge:SetPoint("TOPLEFT", 12, -36)
    panel.dist = S:Pill(panel)
    panel.dist:SetPoint("TOPRIGHT", -12, -42)
    panel.step = S:Text(panel, "body", S.c.text)
    panel.step:SetPoint("TOPLEFT", 52, -36)
    panel.step:SetWidth(PW - 52 - 70)

    panel.objs = S:Text(panel, "small", S.c.text)
    panel.objs:SetWidth(PW - 64)
    if panel.objs.SetSpacing then panel.objs:SetSpacing(2) end

    -- нажатие на текущее задание — показать/скрыть подробности
    panel.stepBtn = CreateFrame("Button", nil, panel)
    panel.stepBtn:SetPoint("TOPLEFT", 10, -34)
    panel.stepBtn:SetPoint("TOPRIGHT", -10, -34)
    panel.stepBtn:SetHeight(40)
    panel.stepBtn:RegisterForDrag("LeftButton")
    panel.stepBtn:SetScript("OnDragStart", function() panel:StartMoving() end)
    panel.stepBtn:SetScript("OnDragStop", function() panel:StopMovingOrSizing(); savePos(panel, "panelPos") end)
    panel.stepBtn.hl = S:Rounded(panel.stepBtn, 6, { 1, 1, 1, 0.04 }, "BACKGROUND", 3, 0)
    panel.stepBtn.hl:Hide()
    panel.stepBtn:SetScript("OnEnter", function(b) b.hl:Show() end)
    panel.stepBtn:SetScript("OnLeave", function(b) b.hl:Hide() end)
    panel.stepBtn:SetScript("OnClick", function() UI.stepOpen = not UI.stepOpen; UI:Update() end)
    S:Tip(panel.stepBtn, nil, "tip_details")
    panel.drows = {}

    -- блок подземелья в стиле окон Blizzard: три чёрные рамки —
    -- название подземелья, список квестов, описание выбранного квеста
    local function box()
        local f = CreateFrame("Frame", nil, panel, BackdropTemplateMixin and "BackdropTemplate" or nil)
        if S:IsPaper() then
            S:Backdrop(f, 0.92)
        elseif f.SetBackdrop then
            f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
            f:SetBackdropColor(0, 0, 0, 0.92)
            f:SetBackdropBorderColor(0.62, 0.62, 0.62, 1)
        else
            S:Box(f, 4, { 0, 0, 0, 0.92 }, { 0.5, 0.5, 0.5, 1 })
        end
        f:Hide()
        return f
    end
    -- область списка с прокруткой: панель всегда одного размера и не «прыгает»
    panel.scroll = CreateFrame("ScrollFrame", nil, panel)
    panel.content = CreateFrame("Frame", nil, panel.scroll)
    panel.content:SetSize(PW, 10)
    panel.scroll:SetScrollChild(panel.content)
    panel.scroll:EnableMouseWheel(true)
    panel.scroll:SetScript("OnMouseWheel", function(sf, delta)
        local maxS = math.max(0, panel.content:GetHeight() - sf:GetHeight())
        local v = math.max(0, math.min(maxS, (sf:GetVerticalScroll() or 0) - delta * 40))
        sf:SetVerticalScroll(v)
    end)
    panel.dboxA, panel.dboxB, panel.dboxC = box(), box(), box()
    panel.dboxA:SetParent(panel.content)
    -- шапка: золотая полоса с названием подземелья
    local A = panel.dboxA
    A:SetHeight(32)
    A.bar = A:CreateTexture(nil, "ARTWORK")
    A.bar:SetTexture("Interface\\QuestFrame\\UI-QuestLogTitleHighlight")
    A.bar:SetBlendMode("ADD")
    A.bar:SetVertexColor(1, 0.75, 0, 0.85)
    A.bar:SetPoint("TOPLEFT", 4, -4); A.bar:SetPoint("BOTTOMRIGHT", -4, 4)
    A.bar:SetVertexColor(1, 0.75, 0, 0.35) -- лёгкое золото: заголовок подземелья
    -- шапка подземелья без рамки: название и тонкая бронзовая линия снизу
    if A.SetBackdrop then pcall(A.SetBackdrop, A, nil) end
    A.bar:Hide()
    A.under = A:CreateTexture(nil, "ARTWORK")
    A.under:SetColorTexture(0.6, 0.44, 0.22, 0.7)
    A.under:SetHeight(1); A.under:SetPoint("BOTTOMLEFT", 2, 0); A.under:SetPoint("BOTTOMRIGHT", -2, 0)
    A.name = big(A:CreateFontString(nil, "OVERLAY", "GameFontNormal"), 15)
    A.name:SetPoint("LEFT", 8, 0); A.name:SetJustifyH("LEFT")
    A.prog = big(A:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"), 13)
    A.prog:SetPoint("RIGHT", -26, 0)
    -- метка «BiS: N» — твои BiS-вещи, которые падают в этом подземелье
    A.bis = CreateFrame("Button", nil, A)
    A.bis:SetSize(56, 20); A.bis:SetPoint("RIGHT", A.prog, "LEFT", -8, 0)
    A.bis.text = big(A.bis:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"), 12)
    A.bis.text:SetPoint("RIGHT"); A.bis.text:SetTextColor(0.75, 0.5, 1)
    A.bis:SetScript("OnEnter", function(self)
        local dg = G.dungeon
        if not (dg and FG.BiS) then return end
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOMRIGHT")
        GameTooltip:AddLine(L("bis_here_tip"), 1, 0.82, 0)
        for _, l in ipairs(FG.BiS:DungeonLines(dg.key)) do GameTooltip:AddLine(l, 1, 1, 1) end
        GameTooltip:AddLine(L("bis_here_click"), 0.4, 0.88, 0.48)
        GameTooltip:Show()
    end)
    A.bis:SetScript("OnLeave", function() GameTooltip:Hide() end)
    A.bis:SetScript("OnClick", function() if FG.BiS then FG.BiS:Toggle() end end)
    A.name:SetPoint("RIGHT", A.bis, "LEFT", -4, 0); A.name:SetWordWrap(false)
    panel.dexit = S:Close(A, function() G:SetDungeon(nil) end)
    panel.dexit:SetSize(18, 18)
    panel.dexit:SetPoint("RIGHT", -4, 0)
    S:Tip(panel.dexit, nil, "tip_dungeon_exit")
    -- описание
    local C = panel.dboxC
    C.text = big(C:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"), 13)
    C.text:SetPoint("TOPLEFT", 9, -8)
    C.text:SetWidth(PW - 24 - 18)
    C.text:SetJustifyH("LEFT")
    if C.text.SetSpacing then C.text:SetSpacing(2) end

    -- полоска уровня, как в игре: фиолетовая — сколько опыта уже есть,
    -- светлая часть после неё — сколько добавит выбранный квест
    panel.bar = CreateFrame("Frame", nil, panel)
    panel.bar:SetHeight(18)
    panel.bar:SetPoint("BOTTOMLEFT", 12, 40)
    panel.bar:SetPoint("BOTTOMRIGHT", -12, 40)
    S:Backdrop(panel.bar, 0.85)
    local BW = PW - 24 - 8
    panel.bar.inner = CreateFrame("Frame", nil, panel.bar)
    panel.bar.inner:SetPoint("TOPLEFT", 4, -4); panel.bar.inner:SetPoint("BOTTOMRIGHT", -4, 4)
    local function barTex(r, g, b, a, layer)
        local t = panel.bar.inner:CreateTexture(nil, layer or "ARTWORK")
        t:SetTexture("Interface\\TargetingFrame\\UI-StatusBar")
        t:SetVertexColor(r, g, b, a or 1)
        t:SetPoint("TOP"); t:SetPoint("BOTTOM")
        return t
    end
    panel.bar.fill = barTex(0.58, 0.0, 0.55, 1)
    panel.bar.fill:SetPoint("LEFT")
    panel.bar.gain = barTex(0.85, 0.55, 1.0, 0.55, "BORDER")
    -- надпись — на отдельном слое поверх заливки, иначе полная полоса её закрывает
    panel.bar.top = CreateFrame("Frame", nil, panel.bar)
    panel.bar.top:SetAllPoints()
    panel.bar.top:SetFrameLevel(panel.bar.inner:GetFrameLevel() + 5)
    panel.bar.text = panel.bar.top:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    panel.bar.text:SetPoint("CENTER", 0, 0)
    panel.bar.text:SetWidth(BW - 6)
    panel.bar.text:SetWordWrap(false)
    pcall(panel.bar.text.SetFont, panel.bar.text, "Fonts\\FRIZQT___CYR.TTF", 11, "OUTLINE")
    panel.bar.shown = nil -- текущая (анимированная) доля
    panel.bar.target = 0
    panel.bar:SetScript("OnUpdate", function(b, dt)
        if not b.shown then b.shown = b.target end
        local d = b.target - b.shown
        if math.abs(d) < 0.001 then b.shown = b.target else b.shown = b.shown + d * math.min(1, dt * 4) end
        local w = math.max(1, BW * b.shown)
        b.fill:SetWidth(w)
        local gw = BW * (b.gainFrac or 0)
        if gw >= 1 then
            b.gain:ClearAllPoints(); b.gain:SetPoint("TOP"); b.gain:SetPoint("BOTTOM")
            b.gain:SetPoint("LEFT", b.fill, "RIGHT", 0, 0)
            b.gain:SetWidth(math.min(gw, BW - w)); b.gain:Show()
        else
            b.gain:Hide()
        end
    end)

    local bw = (PW - 24 - 12) / 3
    panel.bBack = S:Button(panel, "btn_back", bw, 24, function() G:Back() end, { tip = "tip_back" })
    panel.bSkip = S:Button(panel, "btn_skip", bw, 24, function() G:Skip() end, { tip = "tip_skip" })
    panel.bDone = S:Button(panel, "btn_next", bw, 24, function() G:Next() end, { primary = true, tip = "tip_next" })
    panel.bBack:SetPoint("BOTTOMLEFT", 12, 10)
    panel.bSkip:SetPoint("LEFT", panel.bBack, "RIGHT", 6, 0)
    panel.bDone:SetPoint("LEFT", panel.bSkip, "RIGHT", 6, 0)

    if not FG.db.panelShown then panel:Hide() end
end

function UI:Toggle(show)
    if show == nil then show = not panel:IsShown() end
    FG.db.panelShown = show
    if show then panel:Show() else panel:Hide() end
    UI:Update()
end

local function objectivesText(s)
    if not s or not s.q then return "" end
    local q = FG.log[s.q]
    if not q or s.k ~= "d" then return "" end
    local lines = {}
    for _, o in ipairs(q.objs) do
        lines[#lines + 1] = (o.done and "|TInterface\\RaidFrame\\ReadyCheck-Ready:12:12|t |cff66e07a" or "|cffc8ccd2-  ") .. G:TrObjective(s.q, o.text) .. "|r"
    end
    return table.concat(lines, "\n")
end

-- Строка квеста в списке подземелья (как в окнах Blizzard): жёлтое название,
-- выбранный — золотая полоса, справа значок-монетка
-- Квест в списке подземелья — как в журнале заданий игры:
-- тёмная полоса-заголовок с «+/−», а под ней (если раскрыт) значок, [уровень] название,
-- опыт, галочка «готово» и что нужно сделать
local HEAD_H = 24
local function plusTex(open) return open and "Interface\\Buttons\\UI-MinusButton-Up" or "Interface\\Buttons\\UI-PlusButton-Up" end

local function diffColor(ql)
    if GetQuestDifficultyColor and ql and ql > 0 then
        local ok, c = pcall(GetQuestDifficultyColor, ql)
        if ok and type(c) == "table" and c.r then return c.r, c.g, c.b end
    end
    local d = (ql or 0) - (UnitLevel("player") or 1)
    if d >= 5 then return 1, 0.1, 0.1 elseif d >= 3 then return 1, 0.5, 0.25
    elseif d >= -2 then return 1, 1, 0 elseif d >= -8 then return 0.25, 0.75, 0.25 end
    return 0.5, 0.5, 0.5
end

function UI:MakeRow(i)
    local row = CreateFrame("Frame", nil, panel.content)
    -- заголовок
    local h = CreateFrame("Button", nil, row)
    h:SetHeight(HEAD_H)
    h:SetPoint("TOPLEFT"); h:SetPoint("TOPRIGHT")
    -- без рамок: только тонкая линия-разделитель снизу — список выглядит легче
    h.line = h:CreateTexture(nil, "BACKGROUND")
    h.line:SetColorTexture(0.35, 0.22, 0.1, 0.22)
    h.line:SetHeight(1); h.line:SetPoint("BOTTOMLEFT", 4, 0); h.line:SetPoint("BOTTOMRIGHT", -4, 0)
    h.hl = S:GoldBar(h, 0.25); h.hl:Hide()
    -- квест, к которому сейчас ведёт подсказка (даже если строка свёрнута)
    h.sel = S:GoldBar(h, 0.45); h.sel:Hide()
    h.name = big(h:CreateFontString(nil, "OVERLAY", "GameFontNormal"), 14)
    h.name:SetPoint("LEFT", 8, 0); h.name:SetPoint("RIGHT", -28, 0)
    h.name:SetJustifyH("LEFT"); h.name:SetWordWrap(false)
    h.pm = h:CreateTexture(nil, "OVERLAY")
    h.pm:SetSize(14, 14); h.pm:SetPoint("RIGHT", -6, 0)
    h.pm:SetDesaturated(true); h.pm:SetAlpha(0.45)
    -- цепочка: голубая полоска слева и метка «цепочка 2/5» справа
    h.bar = h:CreateTexture(nil, "OVERLAY")
    h.bar:SetTexture("Interface\\Buttons\\WHITE8x8")
    h.bar:SetVertexColor(0.3, 0.55, 0.75, 0.45)
    h.bar:SetWidth(2); h.bar:SetPoint("TOPLEFT", 2, -2); h.bar:SetPoint("BOTTOMLEFT", 2, 2)
    h.bar:Hide()
    -- взят ли квест: значок слева и надпись справа
    h.st = h:CreateTexture(nil, "OVERLAY")
    h.st:SetSize(14, 14); h.st:SetPoint("LEFT", 8, 0)
    h.taken = h:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    h.taken:SetPoint("RIGHT", h.pm, "LEFT", -6, 0)
    h.chain = h:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    h.chain:SetPoint("RIGHT", h.taken, "LEFT", -6, 0)
    h.chain:SetTextColor(0.42, 0.42, 0.42)
    h.chain:Hide()
    h:SetScript("OnEnter", function(b) b.hl:Show(); b.pm:SetAlpha(0.9) end)
    h:SetScript("OnLeave", function(b) b.hl:Hide(); b.pm:SetAlpha(0.45) end)
    h:RegisterForDrag("LeftButton")
    h:SetScript("OnDragStart", function() panel:StartMoving() end)
    h:SetScript("OnDragStop", function() panel:StopMovingOrSizing(); savePos(panel, "panelPos") end)
    h:SetScript("OnClick", function()
        if row.done then return end -- выполненный квест: ничего не делаем
        -- «−» сворачивает квест, «+» раскрывает (и ведёт по нему)
        if row.isOpen then G:FocusDungeonQuest("none")
        else G:FocusDungeonQuest(row.key) end
    end)
    S:Tip(h, nil, "tip_dq_row")
    row.head = h
    -- тело
    local b = CreateFrame("Frame", nil, row)
    b:SetPoint("TOPLEFT", h, "BOTTOMLEFT", 0, -2); b:SetPoint("TOPRIGHT", h, "BOTTOMRIGHT", 0, -2)
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetSize(20, 20); b.icon:SetPoint("TOPLEFT", 4, -2)
    b.check = CreateFrame("CheckButton", nil, b)
    b.check:SetSize(20, 20); b.check:SetPoint("TOPRIGHT", -4, -1)
    b.check:SetNormalTexture("Interface\\Buttons\\UI-CheckBox-Up")
    b.check:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check")
    b.check:EnableMouse(false)
    b.title = big(b:CreateFontString(nil, "OVERLAY", "GameFontNormal"), 14)
    b.title:SetPoint("TOPLEFT", b.icon, "TOPRIGHT", 6, -2)
    b.title:SetPoint("RIGHT", b.check, "LEFT", -6, 0)
    b.title:SetJustifyH("LEFT"); b.title:SetWordWrap(true)
    b.text = big(b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"), 13)
    b.text:SetPoint("TOPLEFT", b.title, "BOTTOMLEFT", 0, -4)
    b.text:SetPoint("RIGHT", b, "RIGHT", -8, 0)
    b.text:SetJustifyH("LEFT")
    if b.text.SetSpacing then b.text:SetSpacing(2) end
    row.body = b
    panel.drows[i] = row
    return row
end

local function stripColors(t) return (t:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")) end

function UI:Update()
    if not panel then return end
    local n = 0
    for _ in pairs(FG.log) do n = n + 1 end
    panel.count:SetText(L("log_count", n))
    local s = G.step
    if not G.ready or not s then
        panel.badge:SetKind("n")
        panel.dist:Hide()
        panel.step:SetText(G.status ~= "" and G.status or L("searching"))
        panel.step:SetWidth(PW - 52 - 70)
        panel.objs:SetText("")
    else
        panel.badge:SetKind(s.k)
        local txt = G:Describe(s)
        if s.m and s.dist and s.dist >= 1e6 then txt = txt .. "\n|cffffa94d" .. L("far", FG:MapName(s.m)) .. "|r" end
        panel.step:SetText(txt)
        if s.dist and s.dist < 1e6 then
            panel.dist:SetValue(L("yards", math.floor(s.dist)), S.c.accent)
            panel.step:SetWidth(PW - 52 - 70)
        else
            panel.dist:Hide()
            panel.step:SetWidth(PW - 52 - 70)
        end
        local det = ""
        if UI.stepOpen then
            if s.dungeon and G.dungeon and s.k ~= "e" then
                for _, dq in ipairs(G.dungeon.quests) do
                    if (dq.manual and dq.def.title == (s.mt or s.t)) or (not dq.manual and dq.id == s.q) then
                        det = G:QuestDetails(dq.id, dq) break
                    end
                end
            end
            if det == "" and s.q and s.q > 0 then det = G:QuestDetails(s.q) end
        end
        local rt = FG.Travel and FG.Travel:Describe(s)
        if rt then det = "|cffffd100" .. rt .. "|r" .. (det ~= "" and ("\n" .. det) or "") end
        if FG.Travel and FG.Travel:IsRecording() then
            det = "|cffff6b6b" .. L("rec_status", FG.Travel:RecordCount()) .. "|r" .. (det ~= "" and ("\n" .. det) or "")
        end
        if det ~= "" then
            if not UI.stepOpen then
                local o = objectivesText(s)
                if o ~= "" then det = det .. "\n" .. o end
            end
            panel.objs:SetText(det)
        else
            local o = objectivesText(s)
            panel.objs:SetText(o)
        end
    end
    -- раскладка по высоте: верхняя часть всегда одной высоты (TOP_H),
    -- длинный текст обрезается, поэтому табличка не дёргается
    local TOP_H = 136
    -- без режима подземелья панель компактная: только задание, высота по тексту
    local compact = not G.dungeon
    if panel.step.SetMaxLines then pcall(panel.step.SetMaxLines, panel.step, 3) end
    local y = 36 + math.max(30, math.min(panel.step:GetStringHeight(), 58))
    local avail = TOP_H - 12 - (y + 6)
    local lines = math.max(0, math.floor(avail / 16))
    if compact then lines = 10 end
    if panel.objs.SetMaxLines then pcall(panel.objs.SetMaxLines, panel.objs, math.max(1, lines)) end
    if (panel.objs:GetText() or "") ~= "" and lines > 0 then
        panel.objs:ClearAllPoints(); panel.objs:SetPoint("TOPLEFT", 52, -(y + 6))
        panel.objs:Show()
    else
        panel.objs:Hide()
    end
    if compact then
        local oh = panel.objs:IsShown() and ((panel.objs:GetStringHeight() or 0) + 6) or 0
        if type(oh) ~= "number" then oh = 0 end
        TOP_H = math.max(80, y + oh + 14)
    end
    panel.stepBtn:SetHeight(TOP_H - 34 - 8)
    if G.ready and G.step then panel.stepBtn:Show() else panel.stepBtn:Hide() end
    -- всё ниже — в прокручиваемой области фиксированной высоты
    local top = TOP_H
    y = 0

    -- режим подземелья: три рамки — название, список квестов, описание выбранного
    local dg = G.dungeon
    local A, B, C = panel.dboxA, panel.dboxB, panel.dboxC
    if dg then
        local lvl = (dg.minL and dg.maxL) and ("  |cffb0b0b0" .. dg.minL .. (dg.maxL ~= dg.minL and ("–" .. dg.maxL) or "") .. "|r") or ""
        A.name:SetText(G:DungeonName(dg) .. lvl)
        local sum = G.dungeonSummary or { done = 0, total = #dg.quests }
        A.prog:SetText(sum.done .. "/" .. sum.total)
        local nb = 0
        if FG.BiS then local ok, list = pcall(FG.BiS.DungeonItems, FG.BiS, dg.key) if ok and list then nb = #list end end
        if nb > 0 then A.bis.text:SetText("BiS: " .. nb); A.bis:Show() else A.bis:Hide() end
        A:ClearAllPoints(); A:SetPoint("TOPLEFT", 12, -y); A:SetPoint("TOPRIGHT", -12, -y); A:Show()
        y = y + 32 + 6

        local open, done = {}, {}
        for _, q in ipairs(dg.quests) do
            local line, state = G:DungeonLine(q)
            local item = { q = q, line = line, state = state }
            if state == "done" then done[#done + 1] = item else open[#open + 1] = item end
        end
        for _, it in ipairs(done) do open[#open + 1] = it end
        -- выбран один квест: выбранный игроком или тот, к которому ведёт подсказка
        local openKey = FG.cdb.dqFocus
        if openKey == "none" then openKey = false end -- игрок свернул все квесты
        if openKey == nil and G.step then openKey = G.step.fk end
        if openKey == "e" or openKey == nil then
            for _, it in ipairs(open) do
                if it.state == "active" or it.state == "turnin" then openKey = G:DungeonKey(it.q) break end
            end
        end
        local selItem
        B:Hide(); C:Hide()
        for i, it in ipairs(open) do
            local row = panel.drows[i] or UI:MakeRow(i)
            local key = G:DungeonKey(it.q)
            local isOpen = (key == openKey) and it.state ~= "done"
            if isOpen then selItem = it end
            row.key, row.isOpen = key, isOpen
            row.done = (it.state == "done")
            local h, body = row.head, row.body
            local title = G:DungeonTitle(it.q)
            h.name:SetText(title)
            -- квест-цепочка выделяется полоской и меткой с шагом
            local cs, ct = G:ChainInfo(it.q)
            local tk = (it.state ~= "done") and G:TakenState(it.q) or nil
            -- значок: «?» жёлтый — можно сдать, «?» серый — взят, «!» — ещё не взят
            if it.state == "done" then
                h.st:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready"); h.st:SetDesaturated(true)
            elseif tk then
                h.st:SetTexture("Interface\\GossipFrame\\ActiveQuestIcon"); h.st:SetDesaturated(tk ~= "turnin")
            else
                h.st:SetTexture("Interface\\GossipFrame\\AvailableQuestIcon"); h.st:SetDesaturated(it.state == "level")
            end
            h.st:ClearAllPoints(); h.st:SetPoint("LEFT", cs and 10 or 7, 0)
            local inside = not tk and it.state ~= "done" and G:StartsInside(it.q)
            if tk == "turnin" then h.taken:SetText(L("tk_turnin")); h.taken:SetTextColor(0.15, 0.45, 0.1)
            elseif tk then h.taken:SetText(L("tk_active")); h.taken:SetTextColor(0.42, 0.42, 0.42)
            elseif inside then h.taken:SetText(L("tk_inside")); h.taken:SetTextColor(0.42, 0.42, 0.42)
            else h.taken:SetText("") end
            tk = tk or (inside and "inside") or nil
            h.name:ClearAllPoints(); h.name:SetPoint("LEFT", h.st, "RIGHT", 4, 0)
            if cs then
                h.chain:SetText(L("chain_tag", cs, ct))
                h.chain:SetTextColor(0.42, 0.42, 0.42)
                h.chain:Show(); h.bar:Show()
                h.name:SetPoint("RIGHT", h.chain, "LEFT", -6, 0)
            else
                h.chain:Hide(); h.bar:Hide()
                if tk then h.name:SetPoint("RIGHT", h.taken, "LEFT", -6, 0)
                else h.name:SetPoint("RIGHT", -28, 0) end
            end
            -- выполненные — бледные, открытые — тёмные чернила, без лишнего цвета
            if it.state == "done" then h.name:SetTextColor(0.5, 0.5, 0.5); row:SetAlpha(0.55)
            else h.name:SetTextColor(0.2, 0.13, 0.07); row:SetAlpha(1) end
            h.pm:SetTexture(plusTex(isOpen))
            if G.step and G.step.fk == key and it.state ~= "done" then h.sel:Show() else h.sel:Hide() end
            if row.done then h.pm:Hide() else h.pm:Show() end
            local rh = HEAD_H
            if isOpen then
                -- значок: «!» взять, «?» сдать, серый «?» — в работе
                local st = it.state
                if st == "turnin" then body.icon:SetTexture("Interface\\GossipFrame\\ActiveQuestIcon"); body.icon:SetDesaturated(false)
                elseif st == "active" then body.icon:SetTexture("Interface\\GossipFrame\\ActiveQuestIcon"); body.icon:SetDesaturated(true)
                else body.icon:SetTexture("Interface\\GossipFrame\\AvailableQuestIcon"); body.icon:SetDesaturated(st ~= "available") end
                body.check:SetChecked(st == "turnin")
                local r, g, bb = diffColor(it.q.ql)
                local lvl = (it.q.ql and it.q.ql > 0) and ("[" .. it.q.ql .. "] ") or ""
                body.title:SetText(lvl .. title)
                body.title:SetTextColor(r, g, bb)
                -- что сделать: опыт, цели, задание, где взять и кому сдать
                -- карточка: где взять, что сделать, кому сдать; для цепочки — все шаги
                local ok, det = pcall(G.QuestCard, G, it.q)
                if not ok or not det then det = "" end
                local xp = stripColors(G:DungeonXp(it.q) or ""):gsub("^%s+", "")
                local tag = ""
                if st == "level" then tag = "   |cffd06060" .. L("st_level", it.q.rl or 0) .. "|r"
                elseif st == "turnin" or st == "done" then tag = "   |cff9a9a9a" .. (L("st_" .. st) or "") .. "|r" end
                local head = (xp ~= "" and ("|cffffd166" .. xp .. "|r") or "") .. tag
                body.text:SetText(head .. ((head ~= "" and det ~= "") and "\n" or "") .. det)
                local bh = 6 + body.title:GetStringHeight() + 4 + body.text:GetStringHeight() + 8
                body:SetHeight(bh); body:Show()
                rh = rh + 2 + bh
            else
                body:Hide()
            end
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", 12, -y); row:SetPoint("TOPRIGHT", -12, -y)
            row:SetHeight(rh); row:Show()
            y = y + rh + 1
        end
        for i = #open + 1, #panel.drows do panel.drows[i]:Hide() end
        UI.selQuest = selItem and selItem.q or nil
        y = y + 4
    else
        A:Hide(); B:Hide(); C:Hide()
        for _, r in ipairs(panel.drows) do r:Hide() end
    end
    panel.content:SetHeight(math.max(10, y))
    panel.scroll:ClearAllPoints()
    panel.scroll:SetPoint("TOPLEFT", 0, -top)
    panel.scroll:SetPoint("BOTTOMRIGHT", 0, 66)
    local maxS = math.max(0, y - (PANEL_H - top - 66))
    if (panel.scroll:GetVerticalScroll() or 0) > maxS then panel.scroll:SetVerticalScroll(maxS) end

    -- полоска прогресса выбранного квеста (сколько целей уже выполнено)
    local b = panel.bar
    local title, entry
    if G.dungeon and UI.selQuest then
        local q = UI.selQuest
        title = G:DungeonTitle(q)
        if q.manual then
            local _, _, _, e = G:ManualState(q)
            entry = e
        else
            entry = FG.log[q.id]
        end
    elseif s and s.q and s.q > 0 and s.k ~= "e" then
        title = s.t
        entry = FG.log[s.q]
    end
    local frac, txt = 0, ""
    if title then
        if not entry then
            txt = L("qbar_notaken", title)
        elseif entry.complete then
            frac, txt = 1, L("qbar_done", title)
        else
            local have, need = 0, 0
            for _, o in ipairs(entry.objs or {}) do
                local a, n = (o.text or ""):match("(%d+)%s*/%s*(%d+)")
                a, n = tonumber(a), tonumber(n)
                if a and n and n > 0 then
                    have = have + math.min(a, n); need = need + n
                else
                    need = need + 1; if o.done then have = have + 1 end
                end
            end
            frac = (need > 0) and (have / need) or 0
            txt = L("qbar_progress", title, math.floor(frac * 100 + 0.5))
        end
    end
    if b.target and frac < b.target - 0.5 then b.shown = 0 end -- другой квест: заполняем заново
    b.target = frac
    b.gainFrac = 0
    if frac >= 1 then b.fill:SetVertexColor(0.2, 0.8, 0.2) else b.fill:SetVertexColor(0.58, 0.0, 0.55) end
    b.text:SetText(txt)
    if title then b:Show() else b:Hide() end
    -- высота: компактная — задание + полоска + кнопки; в подземелье — постоянная
    if compact then
        panel:SetHeight(TOP_H + (title and 66 or 44))
        panel.scroll:Hide()
    else
        panel:SetHeight(PANEL_H)
        panel.scroll:Show()
    end

    S:SkinTree(panel)
    panel.bSkip:SetEnabled(s ~= nil)
    panel.bDone:SetEnabled(#G.suggestions > 1)
end

---------------------------------------------------------------------------
-- Стрелка
---------------------------------------------------------------------------
local arrow

local function createArrow()
    arrow = CreateFrame("Frame", "QuestCompassArrow", UIParent)
    arrow:SetSize(90, 80)
    local p = FG.db.arrowPos
    arrow:SetPoint(p[1], UIParent, p[2], p[3], p[4])
    arrow:SetMovable(true)
    arrow:EnableMouse(true)
    arrow:RegisterForDrag("LeftButton")
    arrow:SetClampedToScreen(true)
    arrow:SetScript("OnDragStart", arrow.StartMoving)
    arrow:SetScript("OnDragStop", function(f) f:StopMovingOrSizing(); savePos(f, "arrowPos") end)

    arrow.glow = S.Tex(arrow, "BACKGROUND", { S.c.accent[1], S.c.accent[2], S.c.accent[3], 0.28 }, 0, S.media.glow)
    arrow.glow:SetSize(84, 84)
    arrow.glow:SetPoint("CENTER", arrow, "TOP", 0, -26)
    arrow.tex = arrow:CreateTexture(nil, "ARTWORK")
    arrow.tex:SetTexture(S.media.arrow)
    arrow.tex:SetVertexColor(S.c.accent[1], S.c.accent[2], S.c.accent[3])
    arrow.tex:SetSize(46, 46)
    arrow.tex:SetPoint("CENTER", arrow, "TOP", 0, -26)
    arrow.pill = S:Pill(arrow)
    arrow.pill:SetPoint("TOP", arrow, "TOP", 0, -54)

    arrow.check = arrow:CreateTexture(nil, "ARTWORK")
    arrow.check:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready")
    arrow.check:SetSize(36, 36)
    arrow.check:SetPoint("TOP", 0, -8)
    arrow.check:Hide()

    -- совместимость: f.text:SetText(...) теперь пишет в плашку
    arrow.text = { SetText = function(_, t) arrow.pill:SetValue(t, arrow.pillColor) end }

    local elapsed = 0
    arrow:SetScript("OnUpdate", function(f, dt)
        elapsed = elapsed + dt
        if elapsed < 0.05 then return end
        elapsed = 0
        local s = FG:NavStep()
        local dist, angle, zone = UI:Navigate(s)
        if zone then
            f.tex:Hide(); f.check:Hide()
            f.text:SetText(L("go_to", zone))
            return
        end
        if not dist then f.tex:Hide(); f.check:Hide(); f.text:SetText(""); return end
        local near = dist <= 40
        local c = near and S.c.green or S.c.accent
        f.pillColor = c
        f.tex:SetVertexColor(c[1], c[2], c[3])
        f.glow:SetVertexColor(c[1], c[2], c[3], 0.28)
        if dist <= ARRIVE_YARDS then
            f.tex:Hide(); f.check:Show()
            f.text:SetText(L("arrived"))
            -- своя цель достигнута — через пару секунд возвращаемся к подсказке
            local nt = FG.navTarget
            -- цель профессии (аукцион, торговец, учитель) не сбрасываем: её снимет сама профессия, когда цель не нужна
            if nt and s == nt and not nt.gather then
                nt.arrived = nt.arrived or GetTime()
                if GetTime() - nt.arrived > 3 then FG:SetNavTarget(nil) end
            end
            return
        end
        f.check:Hide()
        if angle then f.tex:Show(); f.tex:SetRotation(angle) else f.tex:Hide() end
        f.text:SetText(L("yards", math.floor(dist + 0.5)))
    end)
end

function UI:UpdateArrow()
    if not arrow then return end
    local st = FG:NavStep()
    local show = FG.db.showArrow and st and st.m and st.x
    if show then arrow:Show() else arrow:Hide() end
end

---------------------------------------------------------------------------
-- Точка на карте мира
---------------------------------------------------------------------------
local pin

local function updatePin()
    if not pin or not WorldMapFrame or not WorldMapFrame:IsShown() then return end
    local s = FG:NavStep()
    if not FG.db.showMapPin or not s or not s.m or not s.x then pin:Hide() return end
    local mapID = WorldMapFrame.GetMapID and WorldMapFrame:GetMapID()
    local x, y = FG:ConvertPos(s.m, s.x, s.y, mapID)
    if not x or x < 0 or x > 1 or y < 0 or y > 1 then pin:Hide() return end
    local canvas = WorldMapFrame:GetCanvas()
    if pin:GetParent() ~= canvas then pin:SetParent(canvas) end
    -- поверх карты и значков Questie (они от 2016)
    if pin.SetFixedFrameLevel then pin:SetFixedFrameLevel(false) end
    pin:SetFrameLevel(2005) -- под значками Questie: их подсказки при наведении видны
    if pin.SetFixedFrameLevel then pin:SetFixedFrameLevel(true) end
    pin:ClearAllPoints()
    pin:SetPoint("CENTER", canvas, "TOPLEFT", x * canvas:GetWidth(), -y * canvas:GetHeight())
    local scale = WorldMapFrame.GetCanvasScale and WorldMapFrame:GetCanvasScale() or 1
    if not scale or scale <= 0 then scale = 1 end
    pin:SetSize(14 / scale, 14 / scale)
    pin:Show()
end

local function createPin()
    if not (WorldMapFrame and WorldMapFrame.GetCanvas) then return end
    pin = CreateFrame("Frame", nil, WorldMapFrame:GetCanvas())
    pin.tex = pin:CreateTexture(nil, "OVERLAY")
    pin.tex:SetAllPoints()
    pin.tex:SetTexture(S.media.pin)                  -- бирюзовое кольцо с тёмной обводкой
    pin.tex:SetVertexColor(S.c.accent[1], S.c.accent[2], S.c.accent[3])
    -- расходящаяся «волна» вокруг метки
    pin.wave = pin:CreateTexture(nil, "ARTWORK")
    pin.wave:SetTexture(S.media.ring)
    pin.wave:SetVertexColor(S.c.accent[1], S.c.accent[2], S.c.accent[3], 0.9)
    pin.wave:SetAllPoints()
    if pin.CreateAnimationGroup then pcall(function()
        local ag = pin:CreateAnimationGroup()
        ag:SetLooping("REPEAT")
        local sc = ag:CreateAnimation("Scale")
        sc:SetTarget(pin.wave)
        if sc.SetScaleFrom then sc:SetScaleFrom(1, 1); sc:SetScaleTo(1.8, 1.8) else sc:SetScale(1.8, 1.8) end
        sc:SetDuration(1.4)
        local al = ag:CreateAnimation("Alpha")
        al:SetTarget(pin.wave)
        al:SetFromAlpha(0.9); al:SetToAlpha(0); al:SetDuration(1.4)
        pin:SetScript("OnShow", function() ag:Play() end)
        pin.anim = ag
    end) end
    pin:EnableMouse(true)
    pin:SetScript("OnEnter", function(f)
        GameTooltip:SetOwner(f, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Quest|cff" .. S.hex.accent .. "Compass|r")
        local nt = FG.navTarget
        GameTooltip:AddLine(nt and (nt.t or "") or G:Describe(G.step), 1, 1, 1, true)
        GameTooltip:Show()
    end)
    pin:SetScript("OnLeave", function() GameTooltip:Hide() end)
    pin:Hide()

    local ticker = CreateFrame("Frame", nil, WorldMapFrame)
    local t = 0
    ticker:SetScript("OnUpdate", function(_, dt)
        t = t + dt
        if t < 0.2 then return end
        t = 0
        updatePin()
    end)
    if WorldMapFrame.OnMapChanged then hooksecurefunc(WorldMapFrame, "OnMapChanged", updatePin) end
end

---------------------------------------------------------------------------
-- Запуск
---------------------------------------------------------------------------
local baseUpdate = UI.Update
function UI:Update()
    baseUpdate(self)
    self:UpdateArrow()
    updatePin()
end

FG:OnInit(function()
    createPanel()
    createArrow()
    createPin()
    UI:Update()
end)

-- Опыт/час обновляем раз в 30 секунд, даже если ничего не происходит
C_Timer.NewTicker(30, function() if panel and panel:IsShown() then UI:Update() end end)

---------------------------------------------------------------------------
-- Команды
---------------------------------------------------------------------------
local function onoff(v) return v and ("|cff66e07a" .. L("on") .. "|r") or ("|cffff6b6b" .. L("off") .. "|r") end

SLASH_QUESTCOMPASS1 = "/qc"
SLASH_QUESTCOMPASS2 = "/questcompass"
SlashCmdList.QUESTCOMPASS = function(msg)
    msg = msg or ""
    local cmd, arg = msg:match("^%s*(%S*)%s*(%S*)")
    cmd = (cmd or ""):lower(); arg = (arg or ""):lower()
    local db = FG.db
    if cmd == "" then UI:Toggle()
    elseif cmd == "help" then for _, l in ipairs(L("help")) do print(l) end
    elseif cmd == "menu" or cmd == "config" then FG.Menu:Toggle()
    elseif cmd == "lang" or cmd == "language" then
        if arg ~= "ru" and arg ~= "en" then arg = (FG:Lang() == "ru") and "en" or "ru" end
        FG:SetLanguage(arg)
        FG:Print(L("lang_set"))
    elseif cmd == "debug" then
        local pm, px, py = FG:GetPlayerPos()
        FG:Print(L("debug_you", FG:MapName(pm), tostring(pm), (px or 0) * 100, (py or 0) * 100))
        local st = G.step
        if st and st.m then
            local tx, ty = FG:ConvertPos(st.m, st.x, st.y, pm)
            local dist = UI:Navigate(st)
            FG:Print(L("debug_target", G:Describe(st), FG:MapName(st.m), tostring(st.m), st.x * 100, st.y * 100,
                tx and string.format("%.1f, %.1f", tx * 100, ty * 100) or L("none"),
                tostring(dist and math.floor(dist) or "?")))
        end
        if FG.Route and FG.Route.Debug then FG.Route.Debug() end
    elseif cmd == "raid" then FG.Menu:ShowDungeonPicker("raid")
    elseif cmd == "dungeon" or cmd == "dung" then
        if arg == "off" then G:SetDungeon(nil) else FG.Menu:ShowDungeonPicker() end
    elseif cmd == "taxi" then FG.Travel.OnTaxiOpen()
    elseif cmd == "rec" or cmd == "record" then FG.Travel:ToggleRecording()
    elseif cmd == "paths" and arg == "clear" then FG.Travel:ClearPaths()
    elseif cmd == "skip" then G:Skip()
    elseif cmd == "back" then G:Back()
    elseif cmd == "next" then G:Next()
    elseif cmd == "unskip" then G:ResetIgnored()
    elseif cmd == "auto" then db.autoAccept = not db.autoAccept; FG:Print(L("state_auto", onoff(db.autoAccept)))
    elseif cmd == "talents" then if FG.Talents and FG.Talents.Dump then FG.Talents:Dump() end
    elseif cmd == "frdebug" then if FG.Frames and FG.Frames.Debug then FG.Frames:Debug() end
    elseif cmd == "skills" then if FG.Skills and FG.Skills.Debug then FG.Skills:Debug() end
    elseif cmd == "aqdebug" then db.debugAQ = not db.debugAQ; FG:Print("AQ debug " .. onoff(db.debugAQ))
    elseif cmd == "turnin" then db.autoTurnIn = not db.autoTurnIn; FG:Print(L("state_turnin", onoff(db.autoTurnIn)))
    elseif cmd == "arrow" then db.showArrow = not db.showArrow; FG:Print(L("state_arrow", onoff(db.showArrow))); FG:Refresh()
    elseif cmd == "pin" then db.showMapPin = not db.showMapPin; FG:Print(L("state_pin", onoff(db.showMapPin))); FG:Refresh()
    else FG:Print(L("unknown_cmd")) end
end
