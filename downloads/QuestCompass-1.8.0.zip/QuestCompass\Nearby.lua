-- QuestCompass: вкладка «Спутник» — что полезного рядом (учителя, полёты, таверна, банк, ремонт...)
local _, ns = ...
local FG = ns.FG
local L = FG.L
local N = {}
FG.Nearby = N

local S
local page
local W = FG.PAGE_W
local ROW_H = 46
local MAXROWS = 12

local function safe(f, ...) if not f then return nil end local ok, a, b, c = pcall(f, ...) if ok then return a, b, c end end

local CLASS_EN = { WARRIOR = "Warrior", PALADIN = "Paladin", HUNTER = "Hunter", ROGUE = "Rogue", PRIEST = "Priest",
    SHAMAN = "Shaman", MAGE = "Mage", WARLOCK = "Warlock", DRUID = "Druid" }
-- подписи NPC учителей профессий (англ. база): ключ профессии -> слова
local PROF_WORDS = {
    alchemy = { "Alchemy", "Alchemist" }, blacksmithing = { "Blacksmithing", "Blacksmith", "Armorsmith", "Weaponsmith Trainer" },
    enchanting = { "Enchanting", "Enchanter" }, engineering = { "Engineering", "Engineer" }, herbalism = { "Herbalism", "Herbalist" },
    leatherworking = { "Leatherworking", "Leatherworker" }, mining = { "Mining", "Miner" }, skinning = { "Skinning", "Skinner" },
    tailoring = { "Tailoring", "Tailor" }, cooking = { "Cooking", "Cook", "Chef" }, firstaid = { "First Aid", "Physician", "Surgeon" },
    fishing = { "Fishing", "Fisherman", "Angler" },
}

local function has(sub, list) for _, w in ipairs(list) do if sub:find(w, 1, true) then return true end end end
local function eq(sub, list) for _, w in ipairs(list) do if sub == w then return true end end end

-- категории: key, иконка, функция проверки подписи NPC
local function categories()
    local _, cls = UnitClass("player")
    local cen = CLASS_EN[cls or ""] or ""
    local horde = (FG.cdb.faction or (UnitFactionGroup and UnitFactionGroup("player"))) == "Horde"
    local cats = {
        { key = "class", icon = "Interface\\Icons\\ClassIcon_" .. cen, fallback = "Interface\\Icons\\INV_Misc_Book_09",
          test = function(s) return s == cen .. " Trainer" end },
        { key = "flight", icon = horde and "Interface\\Icons\\Ability_Mount_Wyvern_01" or "Interface\\Icons\\Ability_Mount_Gryphon_01",
          test = function(s) return eq(s, { "Gryphon Master", "Wind Rider Master", "Hippogryph Master", "Flight Master", "Bat Handler" }) end },
        { key = "inn", icon = "Interface\\Icons\\INV_Misc_Rune_01", test = function(s) return s == "Innkeeper" end },
        { key = "repair", icon = "Interface\\Icons\\INV_Hammer_20",
          test = function(s) return not s:find("Supplies", 1, true) and has(s, { "Armor", "Armorer", "Weapon", "Shieldsmith", "Blacksmith" }) and not s:find("Trainer", 1, true) and not s:find("Journeyman", 1, true) and not s:find("Expert", 1, true) and not s:find("Artisan", 1, true) and not s:find("Master", 1, true) end },
        { key = "food", icon = "Interface\\Icons\\INV_Drink_07",
          test = function(s) return eq(s, { "Food & Drink", "Butcher", "Baker", "Fruit Vendor", "Bartender", "Mushroom Vendor", "Cheese Vendor", "Food and Drink" }) end },
        { key = "general", icon = "Interface\\Icons\\INV_Misc_Bag_08",
          test = function(s) return eq(s, { "General Goods", "General Supplies", "General Goods Vendor", "Trade Supplies", "Trade Goods" }) end },
        { key = "bank", icon = "Interface\\Icons\\INV_Misc_Coin_02", test = function(s) return s == "Banker" end },
        { key = "auction", icon = "Interface\\Icons\\INV_Misc_Note_02", test = function(s) return s == "Auctioneer" end },
    }
    if cls == "HUNTER" then
        cats[#cats + 1] = { key = "stable", icon = "Interface\\Icons\\Ability_Hunter_BeastTaming", test = function(s) return s == "Stable Master" end }
        cats[#cats + 1] = { key = "pettrainer", icon = "Interface\\Icons\\Ability_Hunter_BeastCall", test = function(s) return s == "Pet Trainer" end }
    end
    if cls == "PRIEST" or cls == "MAGE" or cls == "PALADIN" or cls == "SHAMAN" or cls == "DRUID" or cls == "WARLOCK" then
        cats[#cats + 1] = { key = "reagent", icon = "Interface\\Icons\\INV_Misc_Rune_06",
            test = function(s) return eq(s, { "Reagent Vendor", "Reagents", "Reagent Supplier" }) end }
    end
    -- учителя изученных профессий
    local lv = FG.Skills and FG.Skills.Levels and safe(FG.Skills.Levels, FG.Skills) or {}
    for _, p in ipairs(QuestCompassProf or {}) do
        if lv[p.key] then
            local words = PROF_WORDS[p.key] or { p.en }
            cats[#cats + 1] = { key = "prof", prof = p, icon = p.icon,
                test = function(s)
                    if s:find("Supplies", 1, true) then return false end
                    if not (s:find("Trainer", 1, true) or s:find("Journeyman", 1, true) or s:find("Expert", 1, true)
                        or s:find("Artisan", 1, true) or s:find("Master", 1, true)) then return false end
                    return has(s, words)
                end }
        end
    end
    return cats
end

-- все NPC с подписью (подзаголовком) — собираем один раз
local subIndex
local function buildIndex()
    if subIndex then return subIndex end
    subIndex = {}
    local D = (rawget(_G, "QuestCompassDataLib") or rawget(_G, "LibQuestieDB"))
    if not (D and D.Npc and D.Npc.GetRaw) then return subIndex end
    for id = 1, 30000 do
        local ok, sub = pcall(D.Npc.GetRaw, id, "subName")
        if not (ok and type(sub) == "string" and sub ~= "") then
            -- у аукционистов и части хозяев таверн нет подписи — узнаём по имени
            local ok2, nm = pcall(D.Npc.GetRaw, id, "name")
            sub = nil
            if ok2 and type(nm) == "string" then
                if nm:find("^Auctioneer ") then sub = "Auctioneer"
                elseif nm:find("^Innkeeper ") then sub = "Innkeeper"
                elseif nm:find("^Banker ") then sub = "Banker" end
            end
        end
        if type(sub) == "string" and sub ~= "" then subIndex[#subIndex + 1] = { id = id, sub = sub } end
    end
    return subIndex
end

local function friendly(id)
    local D = (rawget(_G, "QuestCompassDataLib") or rawget(_G, "LibQuestieDB"))
    local fr = D and safe(D.Npc.GetRaw, id, "friendlyToFaction")
    if not fr or fr == "AH" then return true end
    local me = ((FG.cdb.faction or (UnitFactionGroup and UnitFactionGroup("player"))) == "Horde") and "H" or "A"
    return fr == me
end

-- для категории: ближайшие NPC { id, name, dist, point }
local function nearestFor(cat, pm, px, py, w, h)
    local A = FG.Advisor
    local out = {}
    for _, e in ipairs(buildIndex()) do
        if cat.test(e.sub) and friendly(e.id) then
            local pts = A.SpawnPoints and A.SpawnPoints("n", e.id) or {}
            if #pts > 0 then
                local d, p = A.Nearest(pts, pm, px, py, w, h)
                if d and p then out[#out + 1] = { id = e.id, dist = d, p = p, sub = e.sub } end
            end
        end
    end
    table.sort(out, function(a, b) return a.dist < b.dist end)
    return out
end

local function npcName(id)
    return FG:TrNpc(id, FG:EnName("Npc", id)) or FG:EnName("Npc", id) or ("#" .. id)
end
N.NpcName = npcName

-- ближайший дружественный NPC: по списку ID или по проверке подписи; { id, dist, p, name }
function N:NearestNpc(test, ids)
    local A = FG.Advisor
    if not (A and A.SpawnPoints and A.Nearest) then return end
    local pm, px, py = FG:GetPlayerPos()
    if not px then return end
    local w, h = FG:MapSize(pm)
    if not w then return end
    local best
    local function try(id)
        if not friendly(id) then return end
        local pts = A.SpawnPoints("n", id) or {}
        if #pts == 0 then return end
        local d, p = A.Nearest(pts, pm, px, py, w, h)
        if d and p and (not best or d < best.dist) then best = { id = id, dist = d, p = p } end
    end
    if ids then for _, id in ipairs(ids) do try(id) end
    else for _, e in ipairs(buildIndex()) do if test(e.sub) then try(e.id) end end end
    if best then best.name = npcName(best.id) end
    return best
end
-- проверки подписей для поиска: учитель профессии, аукционист
function N.ProfTest(key)
    local words = PROF_WORDS[key] or { key }
    return function(s)
        if s:find("Supplies", 1, true) then return false end
        if not (s:find("Trainer", 1, true) or s:find("Journeyman", 1, true) or s:find("Expert", 1, true)
            or s:find("Artisan", 1, true) or s:find("Master", 1, true)) then return false end
        return has(s, words)
    end
end
function N.AuctionTest(s) return s == "Auctioneer" end

local function distText(d)
    if not d or d >= 1e6 then return L("nb_far") end
    if d >= 1000 then return string.format("%.1f", d / 1000) .. " " .. L("nb_kyd") end
    return L("yards", math.floor(d + 0.5))
end

local function goTo(item)
    if not item or not item.p then return end
    local p = item.p
    FG:SetNavTarget({ m = p[1], x = p[2], y = p[3], t = npcName(item.id), k = "n", nearby = true, sub = item.cat })
    N.Refresh()
    N:ShowMap()
end


---------------------------------------------------------------------------
-- Своя карта: правая часть меню с картой зоны, игроком и целью
---------------------------------------------------------------------------
-- карта и описание — в общем окне «Идти» (GoWindow.lua)
function N:ShowMap() if FG.navTarget and FG.Go then FG.Go:Open("nearby") end end
function N:HideMap() if FG.Go and FG.Go.mode == "nearby" then FG.Go:Close() end end
function N:ToggleMap() if FG.Go and FG.Go:IsShown() and FG.Go.mode == "nearby" then FG.Go:Close() else N:ShowMap() end end

---------------------------------------------------------------------------
-- Страница
---------------------------------------------------------------------------
local lastCalc = 0
local function refresh(force)
    if not page or not page:IsVisible() then return end
    local now = GetTime and GetTime() or 0
    if not force and now - lastCalc < 2 then return end
    lastCalc = now
    local pm, px, py = FG:GetPlayerPos()
    page.where:SetText(pm and L("nb_here", FG:MapName(pm)) or "")
    local nt = FG.navTarget
    if nt and nt.nearby then
        page.target:SetText(L("nb_target", nt.t or "?")); page.clear:Show(); page.mapBtn:Show()
        page.target:SetPoint("RIGHT", -210, 0)
    else
        page.target:SetText(L("nb_hint")); page.clear:Hide(); page.mapBtn:Hide()
        page.target:SetPoint("RIGHT", -16, 0)
    end
    local cats = categories()
    local w, h
    if pm then w, h = FG:MapSize(pm) end
    for i = 1, MAXROWS do
        local r = page.rows[i]
        local cat = cats[i]
        if cat then
            r.cat = cat
            r.icon:SetTexture(cat.icon)
            if not r.icon:GetTexture() and cat.fallback then r.icon:SetTexture(cat.fallback) end
            r.title:SetText(cat.prof and L("nb_cat_prof", FG:Lang() == "ru" and cat.prof.ru or cat.prof.en) or L("nb_cat_" .. cat.key))
            local list = (pm and px and w and h) and nearestFor(cat, pm, px, py, w, h) or {}
            r.list = list
            for _, it in ipairs(list) do it.cat = r.title:GetText() end
            local best = list[1]
            if best then
                local zn
                local D = (rawget(_G, "QuestCompassDataLib") or rawget(_G, "LibQuestieDB"))
                local z = D and safe(D.Npc.GetRaw, best.id, "zoneID")
                if z and C_Map and C_Map.GetAreaInfo then local an = safe(C_Map.GetAreaInfo, z) if an then zn = FG:TrZone(an) end end
                r.name:SetText(npcName(best.id))
                r.sub:SetText(distText(best.dist) .. (zn and ("  |cff9aa0a8" .. zn .. "|r") or ""))
                r.go:Show()
            else
                r.name:SetText("|cff9aa0a8" .. L("nb_none") .. "|r")
                r.sub:SetText("")
                r.go:Hide()
            end
            r:Show()
        else
            r:Hide()
        end
    end
end
N.Refresh = function() refresh(true) end

function N:BuildPage(parent)
    if page then return end
    S = FG.Style
    page = CreateFrame("Frame", "QuestCompassNearbyPage", parent)
    page:SetAllPoints(parent)
    page:HookScript("OnShow", function() refresh(true) end)
    local title = S:Text(page, "title", S.c.accent)
    title:SetPoint("TOPLEFT", 16, -14)
    FG:Localize(title, "nb_title")
    page.where = S:Text(page, "small", S.c.muted)
    page.where:SetPoint("TOPLEFT", 16, -40); page.where:SetPoint("RIGHT", -16, 0)
    page.where:SetWordWrap(false)
    page.target = S:Text(page, "small", S.c.text)
    page.target:SetPoint("TOPLEFT", 16, -60); page.target:SetPoint("RIGHT", -110, 0)
    page.target:SetWordWrap(false)
    page.clear = S:Button(page, "nb_clear", 90, 20, function() FG:SetNavTarget(nil); N:HideMap(); refresh(true) end, { font = "small" })
    page.clear:SetPoint("TOPRIGHT", -16, -56)
    page.clear:Hide()
    page.mapBtn = S:Button(page, "nb_map", 90, 20, function() N:ToggleMap() end, { font = "small" })
    page.mapBtn:SetPoint("RIGHT", page.clear, "LEFT", -6, 0)
    page.mapBtn:Hide()
    page.rows = {}
    for i = 1, MAXROWS do
        local r = CreateFrame("Button", nil, page)
        r:SetSize(W - 24, ROW_H - 4)
        r:SetPoint("TOPLEFT", 12, -82 - (i - 1) * ROW_H)
        S:Box(r, 5, { 0.09, 0.09, 0.1, 0.85 }, { 1, 1, 1, 0.08 })
        r.hl = S:GoldBar(r, 0.2); r.hl:Hide()
        r.icon = r:CreateTexture(nil, "ARTWORK")
        r.icon:SetSize(30, 30); r.icon:SetPoint("LEFT", 6, 0)
        r.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        r.title = S:Text(r, "small", S.c.accent)
        r.title:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 8, 1); r.title:SetWidth(120); r.title:SetWordWrap(false)
        r.name = S:Text(r, "label", S.c.text)
        r.name:SetPoint("BOTTOMLEFT", r.icon, "BOTTOMRIGHT", 8, -1); r.name:SetPoint("RIGHT", -96, 0)
        r.name:SetWordWrap(false)
        r.sub = S:Text(r, "small", S.c.muted)
        r.sub:SetPoint("TOPLEFT", r.title, "TOPRIGHT", 6, 0); r.sub:SetPoint("RIGHT", -96, 0)
        r.sub:SetJustifyH("RIGHT"); r.sub:SetWordWrap(false)
        r.go = FG.Go:Button(r, 80, 24, function() goTo(r.list and r.list[1]) end)
        r.go:SetPoint("RIGHT", -8, 0)
        r:SetScript("OnClick", function(self) goTo(self.list and self.list[1]) end)
        r:SetScript("OnEnter", function(self)
            self.hl:Show()
            if not self.list or #self.list == 0 then return end
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine(self.title:GetText() or "", 1, 0.82, 0)
            for k = 1, math.min(6, #self.list) do
                local it = self.list[k]
                GameTooltip:AddDoubleLine(npcName(it.id), distText(it.dist), 1, 1, 1, 0.8, 0.8, 0.8)
            end
            GameTooltip:AddLine(L("nb_click"), 0.4, 0.88, 0.48, true)
            GameTooltip:Show()
        end)
        r:SetScript("OnLeave", function(self) self.hl:Hide(); GameTooltip:Hide() end)
        page.rows[i] = r
    end
    -- расстояния обновляются, пока вкладка открыта
    page:SetScript("OnUpdate", function() refresh(false) end)
    FG:OnLanguageChanged(function() refresh(true) end)
end

---------------------------------------------------------------------------
-- Пока стрелка ведёт к NPC («Вести») и персонаж бежит, меню полупрозрачное,
-- чтобы видеть дорогу; остановился или навёл мышь — снова непрозрачное
---------------------------------------------------------------------------
local FADE = 0.45
local fader = CreateFrame("Frame")
local cur = 1
fader:SetScript("OnUpdate", function(_, dt)
    local menu = rawget(_G, "QuestCompassMenu")
    if not menu or not menu:IsShown() then cur = 1 return end
    local want = 1
    local nt = FG.navTarget
    if nt and nt.nearby then
        -- прозрачное только пока персонаж бежит к цели; мышь над окном — всегда непрозрачное
        local speed = GetUnitSpeed and GetUnitSpeed("player") or 0
        local over = (menu.IsMouseOver and menu:IsMouseOver())
            or (FG.Menu.shell and FG.Menu.shell:IsShown() and FG.Menu.shell.IsMouseOver and FG.Menu.shell:IsMouseOver())
        if speed and speed > 0 and not over then want = FADE end
    end
    if math.abs(cur - want) < 0.01 then
        if cur == want then return end
        cur = want
    else
        cur = cur + (want - cur) * math.min(1, dt * 8)
    end
    menu:SetAlpha(cur)
    if FG.Menu.shell then FG.Menu.shell:SetAlpha(cur) end
end)
