-- QuestCompass: «мозг» подсказок.
-- Берёт данные из своей базы QuestCompass_Data (основана на QuestieDB): где квестодатели,
-- где цели квестов, кому сдавать — и сам решает, что выгоднее сделать дальше.
local _, ns = ...
local FG = ns.FG
local A = {}
FG.Advisor = A

A.ready = false
A.status = ""
A.suggestions = {}
A.step = nil

local completed = {}      -- выполненные квесты персонажа
local candidates = {}     -- квесты, подходящие по расе/классу: { id, rl, ql }
local zoneToMap = {}      -- AreaID -> UiMapID
local pointCache = {}     -- "n123" / "o456" -> { {m, x, y}, ... }
local itemSources = {}    -- itemId -> { "n1", "o2", ... }
local doableCache = {}
local xpDB

local DB -- LibQuestieDB

---------------------------------------------------------------------------
-- Вспомогательное
---------------------------------------------------------------------------
local function safe(fn, ...)
    local ok, a = pcall(fn, ...)
    if ok then return a end
end

local function hasFlag(mask, flag)
    return (not mask) or mask == 0 or (mask % (2 * flag)) >= flag
end

local playerRaceFlag, playerClassFlag, playerFaction, isSkyborne
local skyborne = { [95] = 4294967296, [96] = 8589934592 }

local function initPlayer()
    local raceId = select(3, UnitRace("player")) or 1
    isSkyborne = skyborne[raceId] ~= nil
    playerRaceFlag = skyborne[raceId] or 2 ^ (raceId - 1)
    playerClassFlag = 2 ^ ((select(3, UnitClass("player")) or 1) - 1)
    playerFaction = FG.cdb.faction or UnitFactionGroup("player")
end

local factionBits = {
    Alliance = { 1, 4, 8, 64, 4294967296 },
    Horde = { 2, 16, 32, 128, 8589934592 },
}

-- Выбрана в меню другая фракция, чем у персонажа?
local function factionOverride()
    local f = FG.cdb.faction
    return f and f ~= UnitFactionGroup("player")
end

local function raceOK(mask)
    if not mask or mask == 0 then return true end
    if factionOverride() then
        for _, b in ipairs(factionBits[playerFaction] or {}) do
            if hasFlag(mask, b) then return true end
        end
        return false
    end
    if isSkyborne then
        if mask == 77 then return playerFaction == "Alliance" end
        if mask == 178 then return playerFaction == "Horde" end
    end
    return hasFlag(mask, playerRaceFlag)
end

local function greenRange()
    if UnitQuestTrivialLevelRange then
        local r = safe(UnitQuestTrivialLevelRange, "player")
        if r then return r end
    end
    if GetQuestGreenRange then
        local r = safe(GetQuestGreenRange, "player") or safe(GetQuestGreenRange)
        if r then return r end
    end
    local lvl = UnitLevel("player")
    if lvl <= 5 then return 5 elseif lvl <= 39 then return math.floor(lvl / 10) + 5 end
    return math.floor(lvl / 5) + 1
end

function A:IsTrivial(ql)
    if not ql or ql <= 0 then return false end
    return (UnitLevel("player") - ql) > greenRange()
end

function A:IsCompleted(id) return completed[id] or FG:IsQuestDone(id) end

---------------------------------------------------------------------------
-- Карты: перевод координат базы (AreaID, 0-100) в координаты карты игрока
---------------------------------------------------------------------------
local function loadMapTable(v)
    if type(v) == "table" then return v end
    if type(v) == "string" then
        local f = loadstring(v)
        if f then
            local ok, t = pcall(f)
            if ok and type(t) == "table" then return t end
        end
    end
    return {}
end

local transforms = {} -- "src>dst" -> {ax, bx, ay, by} или false
local function transform(src, dst)
    if src == dst then return 1, 0, 1, 0 end
    local key = src .. ">" .. dst
    local t = transforms[key]
    if t == nil then
        t = false
        if C_Map.GetWorldPosFromMapPos and C_Map.GetMapPosFromWorldPos and CreateVector2D then
            local function conv(x, y)
                local ok, cont, world = pcall(C_Map.GetWorldPosFromMapPos, src, CreateVector2D(x, y))
                if not ok or not cont or not world then return end
                local ok2, _, pos = pcall(C_Map.GetMapPosFromWorldPos, cont, world, dst)
                if not ok2 or not pos then return end
                return pos:GetXY()
            end
            local x0, y0 = conv(0, 0)
            local x1, y1 = conv(1, 1)
            if x0 and x1 then t = { x1 - x0, x0, y1 - y0, y0 } end
        end
        transforms[key] = t
    end
    if t then return t[1], t[2], t[3], t[4] end
end

-- Точки спавна сущности: { {uiMap, x, y}, ... }  (x, y в долях 0..1)
local function spawnPoints(kind, id)
    local key = kind .. id
    local pts = pointCache[key]
    if pts then return pts end
    pts = {}
    local entity = (kind == "n") and DB.Npc or DB.Object
    local name = safe(entity.name, id)
    if kind == "n" then name = FG:TrNpc(id, name) else name = FG:TrObject(id, name) end
    local spawns = safe(entity.spawns, id)
    if type(spawns) == "table" then
        for area, list in pairs(spawns) do
            local m = zoneToMap[area]
            if m and m > 0 and type(list) == "table" then
                for _, c in ipairs(list) do
                    if c[1] and c[1] >= 0 and c[2] and c[2] >= 0 then
                        pts[#pts + 1] = { m, c[1] / 100, c[2] / 100, name }
                    end
                end
            end
        end
    end
    pointCache[key] = pts
    return pts
end

local function listPoints(spawnList)
    local pts = {}
    if type(spawnList) ~= "table" then return pts end
    for area, list in pairs(spawnList) do
        local m = zoneToMap[area]
        if m and m > 0 and type(list) == "table" then
            for _, c in ipairs(list) do
                if c[1] and c[1] >= 0 then pts[#pts + 1] = { m, c[1] / 100, c[2] / 100 } end
            end
        end
    end
    return pts
end

-- Ближайшая точка: дистанция (ярды), точка
local FAR = 1e6
local function nearest(points, pm, px, py, w, h)
    local best, bestD = nil, nil
    local otherMaps = {}
    for _, p in ipairs(points) do
        local m, x, y = p[1], p[2], p[3]
        local d
        if m == pm then
            local dx, dy = (x - px) * w, (y - py) * h
            d = math.sqrt(dx * dx + dy * dy)
        elseif not otherMaps[m] then
            local ax, bx, ay, by = transform(m, pm)
            if ax then
                local cx, cy = ax * x + bx, ay * y + by
                local dx, dy = (cx - px) * w, (cy - py) * h
                d = math.sqrt(dx * dx + dy * dy)
            else
                otherMaps[m] = true -- другой континент: только как запасной вариант
                d = FAR + m
            end
        end
        if d and (not bestD or d < bestD) then best, bestD = p, d end
    end
    return bestD, best
end

A.SpawnPoints = spawnPoints
A.Nearest = nearest

-- Расстояние от игрока до точки (ярды)
local function distTo(p, pm, px, py, w, h)
    local m, x, y = p[1], p[2], p[3]
    if m ~= pm then
        local ax, bx, ay, by = transform(m, pm)
        if not ax then return FAR + m end
        x, y = ax * x + bx, ay * y + by
    end
    local dx, dy = (x - px) * w, (y - py) * h
    return math.sqrt(dx * dx + dy * dy)
end

local lastTarget = {} -- ключ подсказки -> выбранная ранее точка

-- Выбор цели с «липкостью»: не прыгаем между точками, пока прежняя не стала заметно хуже.
-- cluster = true: для мобов и предметов ведём в центр ближайшего скопления точек, а не к одной.
local function choose(key, points, pm, px, py, w, h, cluster)
    local d, p = nearest(points, pm, px, py, w, h)
    if not p then return end
    if cluster and d < FAR then
        local R = 90 -- ярдов: точки ближе этого считаем одним местом
        local sx, sy, n = 0, 0, 0
        local pw, ph = FG:MapSize(p[1])
        pw, ph = pw or w, ph or h
        for _, q in ipairs(points) do
            if q[1] == p[1] then
                local dx, dy = (q[2] - p[2]) * pw, (q[3] - p[3]) * ph
                if dx * dx + dy * dy <= R * R then sx, sy, n = sx + q[2], sy + q[3], n + 1 end
            end
        end
        if n > 1 then
            p = { p[1], sx / n, sy / n, p[4] }
            d = distTo(p, pm, px, py, w, h)
        end
    end
    local prev = lastTarget[key]
    if prev and prev[1] then
        local dPrev = distTo(prev, pm, px, py, w, h)
        if dPrev < FAR and dPrev <= d * 1.35 + 15 then return dPrev, prev end
    end
    lastTarget[key] = p
    return d, p
end

---------------------------------------------------------------------------
-- Доступность квеста
---------------------------------------------------------------------------
local QuestieDBModule
local function questieDoable(id)
    if not QuestieDBModule then
        if not (Questie and Questie.API and Questie.API.isReady and QuestieLoader) then return nil end
        QuestieDBModule = safe(QuestieLoader.ImportModule, QuestieLoader, "QuestieDB") or false
    end
    if not QuestieDBModule or not QuestieDBModule.IsDoable then return nil end
    local ok, r = pcall(QuestieDBModule.IsDoable, id)
    if ok then return r and true or false end
    return nil
end

local function anyDone(list)
    if type(list) ~= "table" then return false end
    for _, q in ipairs(list) do if completed[q] or FG.log[q] then return true end end
    return false
end

local function ownDoable(id)
    local Q = DB.Quest
    if completed[id] or FG.log[id] then return false end
    if not raceOK(Q.requiredRaces(id)) or not hasFlag(Q.requiredClasses(id), playerClassFlag) then return false end
    if Q.requiredSkill(id) or Q.requiredMinRep(id) or Q.requiredMaxRep(id) or Q.requiredRanks(id) then return false end
    if (Q.requiredSpell(id) or 0) ~= 0 or (Q.requiredSpecialization(id) or 0) ~= 0 then return false end
    local maxLvl = Q.requiredMaxLevel(id) or 0
    if maxLvl > 0 and UnitLevel("player") > maxLvl then return false end
    local single = Q.preQuestSingle(id)
    if single and #single > 0 then
        local ok = false
        for _, p in ipairs(single) do if completed[p] then ok = true break end end
        if not ok then return false end
    end
    local group = Q.preQuestGroup(id)
    if group then
        for _, p in ipairs(group) do
            if not completed[math.abs(p)] then
                local excl = p > 0 and Q.exclusiveTo(p)
                local alt = false
                if excl then for _, e in ipairs(excl) do if completed[e] then alt = true end end end
                if not alt then return false end
            end
        end
    end
    local parent = Q.parentQuest(id) or 0
    if parent ~= 0 and not FG.log[parent] then return false end
    local nextQ = Q.nextQuestInChain(id) or 0
    if nextQ ~= 0 and (completed[nextQ] or FG.log[nextQ]) then return false end
    if anyDone(Q.exclusiveTo(id)) then return false end
    return true
end

function A:IsDoable(id)
    local c = doableCache[id]
    if c ~= nil then return c end
    local r = nil
    if not factionOverride() then r = questieDoable(id) end
    if r == nil then r = safe(ownDoable, id) or false end
    if completed[id] or FG.log[id] then r = false end
    doableCache[id] = r
    return r
end

---------------------------------------------------------------------------
-- Опыт за квест (примерно, по таблице QuestieDB)
---------------------------------------------------------------------------
local function questXP(id, ql)
    local row = xpDB and xpDB[id]
    if not row then return 0 end
    local lvl, xp = row[1] or ql, row[2] or 0
    local diff = UnitLevel("player") - (lvl or 0)
    if diff > 5 then xp = xp * math.max(0.1, 1 - 0.2 * (diff - 5)) end
    return xp
end

---------------------------------------------------------------------------
-- Цели квеста из журнала
---------------------------------------------------------------------------
local function objectiveDone(entry, name)
    if not name or name == "" then return false end
    for _, o in ipairs(entry.objs) do
        if o.text and o.text:find(name, 1, true) then return o.done end
    end
    return false
end

local function addAll(dst, src) for _, p in ipairs(src) do dst[#dst + 1] = p end end

local function itemPoints(itemId)
    local src = itemSources[itemId]
    if not src then
        src = {}
        local npcs = safe(DB.Item.npcDrops, itemId) or {}
        for i = 1, math.min(#npcs, 12) do src[#src + 1] = "n" .. npcs[i] end
        local objs = safe(DB.Item.objectDrops, itemId) or {}
        for i = 1, math.min(#objs, 12) do src[#src + 1] = "o" .. objs[i] end
        itemSources[itemId] = src
    end
    local pts = {}
    for _, key in ipairs(src) do
        addAll(pts, spawnPoints(key:sub(1, 1), tonumber(key:sub(2))))
    end
    return pts
end

-- Кто/что роняет предмет (до 3 названий)
local function itemSourceNames(itemId)
    local names, seen = {}, {}
    for _, n in ipairs(safe(DB.Item.npcDrops, itemId) or {}) do
        local nm = FG:TrNpc(n, safe(DB.Npc.name, n))
        if nm and not seen[nm] then seen[nm] = true; names[#names + 1] = nm end
        if #names >= 3 then break end
    end
    if #names < 3 then
        for _, o in ipairs(safe(DB.Item.objectDrops, itemId) or {}) do
            local nm = FG:TrObject(o, safe(DB.Object.name, o))
            if nm and not seen[nm] then seen[nm] = true; names[#names + 1] = nm end
            if #names >= 3 then break end
        end
    end
    if #names == 0 then return nil end
    return table.concat(names, ", ")
end
A.ItemSourceNames = itemSourceNames

-- Список невыполненных целей: { {label=, points=}, ... }
function A:ObjectiveTargets(id, entry)
    local out = {}
    local objs = safe(DB.Quest.objectives, id) or {}
    for _, o in ipairs(objs[1] or {}) do -- убить
        local name = safe(DB.Npc.name, o[1])
        if not objectiveDone(entry, o[2] or name) and not objectiveDone(entry, name) then
            out[#out + 1] = { label = (o[2] or FG:TrNpc(o[1], name) or "?"), points = spawnPoints("n", o[1]) }
        end
    end
    for _, o in ipairs(objs[2] or {}) do -- использовать объект
        local name = safe(DB.Object.name, o[1])
        if not objectiveDone(entry, o[2] or name) and not objectiveDone(entry, name) then
            out[#out + 1] = { label = (o[2] or FG:TrObject(o[1], name) or "?"), points = spawnPoints("o", o[1]) }
        end
    end
    for _, o in ipairs(objs[3] or {}) do -- собрать предмет
        local name = safe(DB.Item.name, o[1])
        if not objectiveDone(entry, name) then
            out[#out + 1] = { label = (FG:TrItem(o[1], name) or "?"), points = itemPoints(o[1]), src = itemSourceNames(o[1]) }
        end
    end
    for _, o in ipairs(objs[5] or {}) do -- засчитываемые убийства
        local name = o[3] or safe(DB.Npc.name, o[2])
        if not objectiveDone(entry, name) then
            local pts = {}
            for _, n in ipairs(o[1] or {}) do addAll(pts, spawnPoints("n", n)) end
            out[#out + 1] = { label = (o[3] and name) or FG:TrNpc(o[2], name) or "?", points = pts }
        end
    end
    local trig = safe(DB.Quest.triggerEnd, id) -- исследовать место
    if type(trig) == "table" and trig[2] then
        out[#out + 1] = { label = trig[1] or FG.L("explore"), points = listPoints(trig[2]) }
    end
    return out
end

local function finisherPoints(id)
    local fin = safe(DB.Quest.finishedBy, id) or {}
    local pts, name = {}, nil
    for _, n in ipairs(fin[1] or {}) do
        addAll(pts, spawnPoints("n", n))
        name = name or FG:TrNpc(n, safe(DB.Npc.name, n))
    end
    for _, o in ipairs(fin[2] or {}) do
        addAll(pts, spawnPoints("o", o))
        name = name or FG:TrObject(o, safe(DB.Object.name, o))
    end
    return pts, name
end

---------------------------------------------------------------------------
-- Подбор подсказок
---------------------------------------------------------------------------
local function questLevel(id)
    local ql = safe(DB.Quest.questLevel, id) or 0
    if ql <= 0 then ql = UnitLevel("player") end
    return ql
end

local function friendly(npcId)
    local f = safe(DB.Npc.friendlyToFaction, npcId)
    if not f then return true end
    if playerFaction == "Alliance" then return f:find("A") ~= nil end
    if playerFaction == "Horde" then return f:find("H") ~= nil end
    return true
end

-- Элитные цели — обычно групповые квесты, соло их не советуем
local eliteCache = {}
local function hasEliteTarget(id)
    local c = eliteCache[id]
    if c ~= nil then return c end
    c = false
    local objs = safe(DB.Quest.objectives, id) or {}
    for _, o in ipairs(objs[1] or {}) do
        local rank = safe(DB.Npc.rank, o[1]) or 0
        if rank > 0 then c = true end
    end
    eliteCache[id] = c
    return c
end

-- Где берётся квест: точки и имя квестодателя
local starterCache = {}
local function starterPoints(id)
    local c = starterCache[id]
    if c then return c[1], c[2] end
    local st = safe(DB.Quest.startedBy, id) or {}
    local pts, npc = {}, nil
    for _, n in ipairs(st[1] or {}) do
        if friendly(n) then
            addAll(pts, spawnPoints("n", n))
            npc = npc or FG:TrNpc(n, safe(DB.Npc.name, n))
        end
    end
    for _, o in ipairs(st[2] or {}) do
        addAll(pts, spawnPoints("o", o))
        npc = npc or FG:TrObject(o, safe(DB.Object.name, o))
    end
    starterCache[id] = { pts, npc }
    return pts, npc
end

local nativeQuestPoints
local zoneDataCache = {}
local dungeonZones = {}

-- Квесты журнала, которые сама игра отмечает на карте (C_QuestLog.GetQuestsOnMap)
nativeQuestPoints = function(pm)
    local res = {}
    if not (C_QuestLog and C_QuestLog.GetQuestsOnMap and pm) then return res end
    local ok, list = pcall(C_QuestLog.GetQuestsOnMap, pm)
    if not ok or type(list) ~= "table" then return res end
    for _, q in ipairs(list) do
        if q.questID and q.x and q.y and (q.x > 0 or q.y > 0) then
            res[q.questID] = { pm, q.x, q.y }
        end
    end
    return res
end

---------------------------------------------------------------------------
-- Стоит ли брать квест: его цели (или место сдачи) недалеко от квестодателя
---------------------------------------------------------------------------
local WORTH_YARDS = 1100   -- цели дальше этого от квестодателя — квест не берём
local HUB_YARDS = 160      -- радиус «точки с квестодателями»: всё в нём собираем сразу
local worthCache = {}

function A:KnowsQuest(id)
    return DB and DB.Quest and id and safe(DB.Quest.Exists, id) and true or false
end

function A:Worth(id)
    local c = worthCache[id]
    if c ~= nil then return c end
    local ok = true
    local sp = starterPoints(id)
    local s0 = sp[1]
    if s0 then
        local w, h = FG:MapSize(s0[1])
        w, h = w or 1000, h or 667
        local pts = {}
        for _, obj in ipairs(self:ObjectiveTargets(id, { objs = {} })) do addAll(pts, obj.points) end
        local hasObjectives = #pts > 0
        if not hasObjectives then pts = finisherPoints(id) end
        if #pts > 0 then
            local d = nearest(pts, s0[1], s0[2], s0[3], w, h)
            if not d or d >= FAR then
                ok = false                                  -- другой континент
            elseif hasObjectives and d > WORTH_YARDS then
                ok = false                                  -- бегать слишком далеко
            end
        end
    end
    worthCache[id] = ok
    return ok
end

---------------------------------------------------------------------------
-- Маршрут по опыту: сколько секунд уйдёт на квест и сколько опыта он даст
---------------------------------------------------------------------------
local planCache = {}
local SEC_PER_UNIT = 16      -- примерно секунд на одно убийство / предмет
local SEC_PER_GROUP = 95     -- цель квеста, у которой ещё не знаем количество

local function runSpeed()
    local lvl = UnitLevel("player") or 1
    return (lvl >= 40) and 10.5 or 7 -- ярдов в секунду (на маунте с 40-го)
end

-- Типичный опыт за квест по его уровню (по таблице Questie) — для квестов без данных
local XP_CURVE = { {1, 40}, {5, 335}, {10, 780}, {15, 1050}, {20, 1450}, {25, 2000}, {30, 2450},
    {35, 2800}, {40, 3150}, {45, 3900}, {50, 4700}, {55, 5450}, {60, 6600} }
local function xpEstimate(lvl)
    lvl = lvl or 1
    for i = 2, #XP_CURVE do
        local a, b = XP_CURVE[i - 1], XP_CURVE[i]
        if lvl <= b[1] then
            local t = (lvl - a[1]) / (b[1] - a[1])
            return a[2] + (b[2] - a[2]) * math.max(0, t)
        end
    end
    return XP_CURVE[#XP_CURVE][2]
end

-- Опыт за квест с учётом разницы уровней (если в базе нет — оценка по уровню)
local function xpFor(id, ql)
    local row = xpDB and xpDB[id]
    local lvl = (row and row[1]) or ql or UnitLevel("player")
    local xp = (row and row[2]) or xpEstimate(lvl)
    local diff = UnitLevel("player") - (lvl or 0)
    if diff > 5 then xp = xp * math.max(0.1, 1 - 0.2 * (diff - 5)) end
    return math.max(xp, 1)
end

-- Постоянная часть пути квеста: квестодатель » цели » сдача (ярды) и число целей
local function questPlan(id)
    local c = planCache[id]
    if c then return c end
    c = { g2o = 0, o2f = 0, groups = 0 }
    local sp = starterPoints(id)
    local objs = A:ObjectiveTargets(id, { objs = {} })
    c.groups = #objs
    local fin = finisherPoints(id)
    local from = sp[1]
    if from then
        local w, h = FG:MapSize(from[1]); w, h = w or 1000, h or 667
        local ptsAll = {}
        for _, o in ipairs(objs) do addAll(ptsAll, o.points) end
        if #ptsAll > 0 then
            local d, p = nearest(ptsAll, from[1], from[2], from[3], w, h)
            if d and d < FAR then c.g2o = d; c.obj = p end
        end
        local o = c.obj or from
        local w2, h2 = FG:MapSize(o[1]); w2, h2 = w2 or w, h2 or h
        local d2 = nearest(fin, o[1], o[2], o[3], w2, h2)
        if d2 and d2 < FAR then c.o2f = d2 end
    end
    planCache[id] = c
    return c
end

-- Сколько секунд работы осталось по целям квеста из журнала
local function workLeft(entry, groups)
    if not entry then return (groups or 0) * SEC_PER_GROUP + 10 end
    if entry.complete then return 0 end
    local t, any = 0, false
    for _, o in ipairs(entry.objs or {}) do
        if not o.done then
            local have, need = (o.text or ""):match("(%d+)%s*/%s*(%d+)")
            if have then t = t + math.max(0, tonumber(need) - tonumber(have)) * SEC_PER_UNIT
            else t = t + 40 end
            any = true
        end
    end
    if not any then t = 30 end
    return t
end
A.XpFor = xpFor

-- Опыт для показа: число и признак «примерно» (если в базе нет точного значения)
local function fmtNum(n)
    local str = tostring(math.floor(n + 0.5))
    local out = str:reverse():gsub("(%d%d%d)", "%1 "):reverse()
    return (out:gsub("^ ", ""))
end
-- Опыт за квест числом (nil — неизвестно): для полоски уровня
function A:XpValue(id, ql, def)
    if def then
        local lvl = def.ql or ql or UnitLevel("player")
        local xp = def.xp or xpEstimate(lvl)
        local diff = UnitLevel("player") - lvl
        if diff > 5 then xp = xp * math.max(0.1, 1 - 0.2 * (diff - 5)) end
        return xp
    elseif id and id > 0 then
        return xpFor(id, ql or (FG.log[id] and FG.log[id].level))
    end
end

function A:XpText(id, ql, def)
    do return "" end -- опыт за квест не показываем (по просьбе); XpValue остаётся для выбора маршрута
    local xp, approx
    if def then
        local lvl = def.ql or ql or UnitLevel("player")
        xp = def.xp or xpEstimate(lvl)
        approx = not def.xp
        local diff = UnitLevel("player") - lvl
        if diff > 5 then xp = xp * math.max(0.1, 1 - 0.2 * (diff - 5)) end
    elseif id and id > 0 then
        approx = not (xpDB and xpDB[id])
        xp = xpFor(id, ql or (FG.log[id] and FG.log[id].level))
    else
        return ""
    end
    return " |cffffd166" .. (approx and "~" or "") .. FG.L("xp_fmt", fmtNum(xp)) .. "|r"
end

function A:Recalc()
    if not self.ready then return end
    if FG.cdb.dungeon and self.dungeonByKey and self.dungeonByKey[FG.cdb.dungeon] then
        return self:RecalcDungeon(self.dungeonByKey[FG.cdb.dungeon])
    end
    self.dungeon = nil
    local pm, px, py = FG:GetPlayerPos()
    if not px then
        self.status = FG.L("no_pos")
        return
    end
    local w, h = FG:MapSize(pm)
    if not w then w, h = 1000, 667 end
    local level = UnitLevel("player")
    local xpMax = math.max(UnitXPMax("player") or 1, 1)
    local ignored = FG.cdb.ignored
    local lmin, lmax = FG.cdb.levelMin or 1, FG.cdb.levelMax or 60
    local list = {}

    local function bonus(id, ql)
        return 1 - math.min(0.5, questXP(id, ql) / xpMax * 2) -- выгодные по опыту квесты «ближе» до 50%
    end
    -- режим «по опыту»: оценка = секунды на квест / опыт (меньше — выгоднее)
    local xpMode = FG.db.route ~= "near"
    local speed = runSpeed()
    local function xpScore(kind, id, ql, d, entry)
        local xp = xpFor(id, ql)
        local plan = questPlan(id)
        local sec = (d or 0) / speed
        if kind == "t" then sec = sec + 5
        elseif kind == "d" then sec = sec + workLeft(entry, plan.groups) + plan.o2f / speed
        else sec = sec + (plan.g2o + plan.o2f) / speed + workLeft(nil, plan.groups) end
        return sec / xp * 1000
    end

    -- метки квестов от самой игры (для квестов, которых нет в базе Questie)
    local native = nativeQuestPoints(pm)

    -- 1) квесты в журнале: сдать или выполнить
    for id, entry in pairs(FG.log) do
        if not ignored[id] and not entry.failed then
            local ql = entry.level or level
            local found = false
            if entry.complete then
                local pts, npc = finisherPoints(id)
                local d, p = choose("t" .. id, pts, pm, px, py, w, h, false)
                if p then
                    found = true
                    list[#list + 1] = { k = "t", q = id, t = A:QuestTitle(id, entry.title), npc = p[4] or npc, m = p[1], x = p[2], y = p[3],
                        -- сдаём сразу, если NPC рядом; иначе по пути
                        dist = d, score = xpMode and xpScore("t", id, ql, d, entry) or ((d <= HUB_YARDS) and (d * 0.3) or (d * 0.9 * bonus(id, ql))) }
                end
            else
                for _, obj in ipairs(self:ObjectiveTargets(id, entry)) do
                    local d, p = choose("d" .. id .. obj.label, obj.points, pm, px, py, w, h, true)
                    if p then
                        found = true
                        list[#list + 1] = { k = "d", q = id, t = A:QuestTitle(id, entry.title), obj = obj.label, m = p[1], x = p[2], y = p[3],
                            dist = d, score = xpMode and xpScore("d", id, ql, d, entry) or (d * bonus(id, ql)) }
                    end
                end
            end
            if not found then
                -- в базе нет — берём метку игры, а если и её нет, показываем квест без стрелки
                local np = native[id]
                local k = entry.complete and "t" or "d"
                if np then
                    local d = distTo(np, pm, px, py, w, h)
                    list[#list + 1] = { k = k, q = id, t = A:QuestTitle(id, entry.title), obj = entry.complete and nil or FG.L("native_obj"),
                        m = np[1], x = np[2], y = np[3], dist = d, score = d * 0.9, native = true }
                else
                    list[#list + 1] = { k = k, q = id, t = A:QuestTitle(id, entry.title), obj = (not entry.complete) and FG.L("unknown_place") or nil,
                        dist = FAR * 3, score = FAR * 3, nodata = true }
                end
            end
        end
    end

    -- 2) новые квесты рядом (если в журнале есть место)
    local logCount = 0
    for _ in pairs(FG.log) do logCount = logCount + 1 end
    if logCount < 20 then
        for _, c in ipairs(candidates) do
            local id = c.id
            if c.rl <= level and c.ql <= level + 2 and not ignored[id] and not self:IsTrivial(c.ql)
                and c.ql >= lmin and c.ql <= lmax
                and not dungeonZones[c.zone or 0] and self:IsDoable(id) and not hasEliteTarget(id)
                and self:Worth(id) then
                local pts, npc = starterPoints(id)
                local d, p = choose("a" .. id, pts, pm, px, py, w, h, false)
                if p and d < FAR then -- квесты на другом континенте не предлагаем
                    local sc
                    if xpMode then
                        sc = xpScore("a", id, c.ql, d)
                        if d <= HUB_YARDS then sc = sc * 0.2 end -- в точке с квестодателями берём всё выгодное сразу
                    else
                        -- в точке с квестодателями сначала собираем всё; дальние — после выполнения
                        sc = (d <= HUB_YARDS) and (d * 0.25) or (d * 1.4 * bonus(id, c.ql))
                    end
                    list[#list + 1] = { k = "a", q = id, t = (FG:TrQuest(id)) or safe(DB.Quest.name, id), npc = npc or p[4], ql = c.ql,
                        m = p[1], x = p[2], y = p[3], dist = d, score = sc, eff = xpMode and xpScore("a", id, c.ql, d) or nil }
                end
            end
        end
    end

    -- по опыту: невыгодные новые квесты (в 2+ раза хуже лучшего) не предлагаем
    if xpMode then
        -- эталон — «типичный хороший» квест рядом (40-й перцентиль), а не самый лучший:
        -- иначе короткий квест «поговорить» отсекал бы всё остальное
        local effs = {}
        for _, s in ipairs(list) do if s.eff then effs[#effs + 1] = s.eff end end
        if #effs >= 4 then
            table.sort(effs)
            local ref = effs[math.max(1, math.floor(#effs * 0.4 + 0.5))]
            local keep = {}
            for _, s in ipairs(list) do
                if not s.eff or s.eff <= ref * 2.5 then keep[#keep + 1] = s end
            end
            list = keep
        end
        A.lastEffs = effs
    end
    table.sort(list, function(a, b) return a.score < b.score end)
    -- убираем дубли (один квест — одна строка, кроме целей)
    local out, seen = {}, {}
    for _, s in ipairs(list) do
        local key = s.k .. s.q .. (s.obj or "")
        if not seen[key] then
            seen[key] = true
            out[#out + 1] = s
            if #out >= 8 then break end
        end
    end
    self.suggestions = out

    -- закреплённая подсказка (кнопка «Другое») остаётся, пока актуальна
    self.step = nil
    if self.pinned then
        for _, s in ipairs(out) do
            if (s.k .. s.q .. (s.obj or "")) == self.pinned then self.step = s break end
        end
        if not self.step then self.pinned = nil end
    end
    self.step = self.step or out[1]
    if #out == 0 then
        local zoneHasData = zoneDataCache[pm]
        if zoneHasData == nil then
            zoneHasData = false
            for _, c in ipairs(candidates) do
                for _, p in ipairs(starterPoints(c.id)) do if p[1] == pm then zoneHasData = true break end end
                if zoneHasData then break end
            end
            zoneDataCache[pm] = zoneHasData
        end
        if zoneHasData then
            self.status = FG.L("none_near")
        else
            self.status = FG.L("zone_missing", FG:MapName(pm))
        end
        if level < lmin or level > lmax + 5 then
            self.status = self.status .. "\n" .. FG.L("range_note", lmin, lmax, level)
        end
    end
end

function A:Upcoming(count)
    local res = {}
    for _, s in ipairs(self.suggestions) do
        if s ~= self.step then res[#res + 1] = s end
        if #res >= count then break end
    end
    return res
end

-- Кнопка «Другое»: следующая подсказка из списка
function A:Next()
    if #self.suggestions < 2 then return end
    local idx = 1
    for i, s in ipairs(self.suggestions) do if s == self.step then idx = i end end
    local s = self.suggestions[idx % #self.suggestions + 1]
    self.pinned = s.k .. s.q .. (s.obj or "")
    self.step = s
    FG:Refresh(true)
end

-- Кнопка «Пропустить»: больше не предлагать этот квест на этом персонаже
function A:Skip()
    local s = self.step
    if not s then return end
    FG.cdb.ignored[s.q] = true
    table.insert(FG.cdb.ignoredOrder, s.q)
    FG:Print(FG.L("skipped", tostring(s.t or s.q)))
    self.pinned = nil
    FG:Refresh(true)
end

function A:Back()
    local order = FG.cdb.ignoredOrder
    local id = table.remove(order)
    if not id then FG:Print(FG.L("no_skipped")) return end
    FG.cdb.ignored[id] = nil
    FG:Print(FG.L("unskipped", tostring(safe(DB and DB.Quest.name, id) or id)))
    FG:Refresh(true)
end

function A:ResetIgnored()
    FG.cdb.ignored, FG.cdb.ignoredOrder = {}, {}
    FG:Print(FG.L("skip_cleared"))
    FG:Refresh(true)
end

function A:Describe(s)
    if not s then return "" end
    local q = s.t or FG.L("quest_n", tostring(s.q))
    local xpt = ""
    if s.k ~= "e" and not s.chainFor then
        local def = s.mt and self:ManualDef(s.mt)
        xpt = self:XpText(s.q, s.ql, def)
    end
    if s.k == "a" then
        local lvl = s.ql and (" |cff8a909a[" .. s.ql .. "]|r") or ""
        local cf = s.chainFor and ("\n|cffffa94d" .. s.chainFor .. "|r") or ""
        return "|cffffd100" .. FG.L("d_take") .. ":|r " .. q .. lvl .. xpt .. (s.npc and (" |cff8a909a— " .. s.npc .. "|r") or "") .. cf
    end
    local note = ""
    if s.nodata then note = "\n|cff8a909a" .. FG.L("nodata_note") .. "|r"
    elseif s.native then note = " |cff8a909a" .. FG.L("native_note") .. "|r" end
    if s.chainFor then note = note .. "\n|cffffa94d" .. s.chainFor .. "|r" end
    if s.k == "e" then
        return "|cffffd100" .. FG.L("dq_enter") .. ":|r " .. q .. (s.chainFor and ("\n|cffffa94d" .. s.chainFor .. "|r") or "")
    end
    if s.k == "d" then
        local src = s.src and ("\n|cffc8ccd2" .. FG.L("dq_drops", s.src) .. "|r") or ""
        return "|cffffd100" .. FG.L("d_do") .. ":|r " .. (s.obj or "") .. " |cff8a909a(" .. q .. ")|r" .. xpt .. src .. note
    elseif s.k == "t" then
        return "|cff66e07a" .. FG.L("d_turn") .. ":|r " .. q .. xpt .. (s.npc and (" |cff8a909a— " .. s.npc .. "|r") or "") .. note
    end
    return q
end

---------------------------------------------------------------------------
-- Запуск: подготовка списка квестов кусками, чтобы игра не подвисала
---------------------------------------------------------------------------
local function loadCompleted()
    A.titlesDirty = true
    completed = {}
    if C_QuestLog and C_QuestLog.GetAllCompletedQuestIDs then
        for _, id in ipairs(C_QuestLog.GetAllCompletedQuestIDs() or {}) do completed[id] = true end
    elseif GetQuestsCompleted then
        local t = {}
        local r = GetQuestsCompleted(t) or t
        for id, v in pairs(r) do if v then completed[id] = true end end
    end
end

local function buildCandidates(done)
    local ids = safe(DB.Quest.GetAllIds) or {}
    local i, total = 1, #ids
    candidates = {}
    local function chunk()
        local stop = math.min(i + 250, total)
        for j = i, stop do
            local id = ids[j]
            local ok = pcall(function()
                local Q = DB.Quest
                if raceOK(Q.requiredRaces(id)) and hasFlag(Q.requiredClasses(id), playerClassFlag) then
                    local st = Q.startedBy(id)
                    if st and ((st[1] and #st[1] > 0) or (st[2] and #st[2] > 0)) then
                        local rl = Q.requiredLevel(id) or 0
                        local ql = Q.questLevel(id) or 0
                        if ql <= 0 then ql = math.max(rl, 1) end
                        candidates[#candidates + 1] = { id = id, rl = rl, ql = ql, zone = Q.zoneOrSort(id) }
                    end
                end
            end)
            if not ok then end -- битая запись — пропускаем
        end
        i = stop + 1
        A.status = FG.L("preparing", math.floor(i / math.max(total, 1) * 100))
        if FG.UI then FG.UI:Update() end
        if i <= total then C_Timer.After(0, chunk) else done() end
    end
    chunk()
end

-- Меню: фракция и диапазон уровней поменялись — пересобираем базу
function A:ApplyFilters()
    if not DB or not DB.Quest then FG:Refresh() return end
    initPlayer()
    doableCache, starterCache = {}, {}
    self.ready = false
    self.pinned = nil
    buildCandidates(function()
        A.ready = true
        A.status = ""
        pcall(A.BuildDungeons, A) -- квесты подземелий тоже зависят от фракции
        FG:Refresh(true)
    end)
end

function A:Init()
    initPlayer()
    loadCompleted()
    DB = (rawget(_G, "QuestCompassDataLib") or rawget(_G, "LibQuestieDB"))
    if not DB or not DB.Quest then
        self.status = "|cffff6b6b" .. FG.L("no_db") .. "|r\n" .. FG.L("no_db_help")
        FG:Print(FG.L("no_db_chat"))
        A.noDB = true
        FG:OnLanguageChanged(function() if A.noDB then A.status = "|cffff6b6b" .. FG.L("no_db") .. "|r\n" .. FG.L("no_db_help") end end)
        return
    end
    if DB.RequireContract then
        local ok, msg = DB.RequireContract(1)
        if not ok then self.status = FG.L("db_incompat", tostring(msg)) return end
    end
    -- названия на языке клиента
    local loc = GetLocale and GetLocale()
    if loc and loc ~= "enUS" and loc ~= "enGB" and DB.l10n and DB.l10n.currentLocale ~= loc and DB.l10n.SetLocale then
        pcall(DB.l10n.SetLocale, loc)
    end
    local zdb = DB.Support and safe(DB.Support.Get, "ZoneDB")
    if zdb and zdb.private then
        zoneToMap = loadMapTable(zdb.private.areaIdToUiMapId)
        for k, v in pairs(loadMapTable(zdb.private.areaIdToUiMapIdOverride)) do zoneToMap[k] = v end
        local dungeons = zdb.private.dungeons
        if type(dungeons) == "string" then dungeons = loadMapTable(dungeons) end
        A.rawDungeons = type(dungeons) == "table" and dungeons or {}
        if type(dungeons) == "table" then
            for area, d in pairs(dungeons) do
                dungeonZones[area] = true
                if type(d[2]) == "table" then for _, alt in ipairs(d[2]) do dungeonZones[alt] = true end end
            end
        end
    end
    local qxp = DB.Support and safe(DB.Support.Get, "QuestXP")
    xpDB = qxp and qxp.db
    buildCandidates(function()
        A.ready = true
        A.status = ""
        pcall(A.BuildDungeons, A)
        FG:Print(FG.L("db_ready", #candidates))
        FG:Refresh(true)
    end)
end

-- Смена языка: названия NPC в кэше точек нужно перечитать
FG:OnLanguageChanged(function()
    for k in pairs(pointCache) do pointCache[k] = nil end
    for k in pairs(starterCache) do starterCache[k] = nil end
end)

-- Перевод строки цели из журнала (английский клиент): подставляем русские названия
function A:TrObjective(qid, text)
    if not text or FG:Lang() ~= "ru" then return text end
    local objs = qid and qid > 0 and safe(DB.Quest.objectives, qid)
    if type(objs) ~= "table" then objs = {} end
    local function sub(en, ru)
        if en and ru and en ~= ru then
            local i, j = text:find(en, 1, true)
            if i then text = text:sub(1, i - 1) .. ru .. text:sub(j + 1) end
        end
    end
    for _, o in ipairs(objs[3] or {}) do sub(safe(DB.Item.name, o[1]), FG:TrItem(o[1])) end
    for _, o in ipairs(objs[1] or {}) do sub(safe(DB.Npc.name, o[1]), FG:TrNpc(o[1])) end
    for _, o in ipairs(objs[2] or {}) do sub(safe(DB.Object.name, o[1]), FG:TrObject(o[1])) end
    text = text:gsub(" slain:", " — убито:")
    if not A.extraKeys then
        A.extraKeys = {}
        for en in pairs(FG.ExtraNames or {}) do A.extraKeys[#A.extraKeys + 1] = en end
        table.sort(A.extraKeys, function(a, b) return #a > #b end) -- сначала длинные названия
    end
    for _, en in ipairs(A.extraKeys) do
        local i, j = text:find(en, 1, true)
        if i then text = text:sub(1, i - 1) .. FG.ExtraNames[en] .. text:sub(j + 1) end
    end
    return text
end

-- Сбрасываем кэш доступности при любых изменениях квестов/уровня
local function invalidate() doableCache = {} end
FG:On("QUEST_TURNED_IN", function(_, id) if id then completed[id] = true end A.titlesDirty = true; invalidate() end)
FG:On("QUEST_ACCEPTED", invalidate)
FG:On("QUEST_REMOVED", invalidate)
FG:On("PLAYER_LEVEL_UP", invalidate)
FG:On("SKILL_LINES_CHANGED", invalidate)

FG:OnInit(function() A:Init() end)

-- Подсказку пересчитываем и при движении игрока (раз в 3 секунды)
C_Timer.NewTicker(3, function() if A.ready then FG:Refresh() end end)


---------------------------------------------------------------------------
-- Подземелья: квесты выбранного подземелья, цепочки и куда идти
---------------------------------------------------------------------------
local function areaName(areaId, fallback)
    if C_Map and C_Map.GetAreaInfo then
        local ok, n = pcall(C_Map.GetAreaInfo, areaId)
        if ok and type(n) == "string" and n ~= "" then return FG:TrZone(n) end
    end
    return fallback
end

-- Собираем список подземелий, где у персонажа есть квесты
function A:BuildDungeons()
    self.dungeonList, self.dungeonByKey = {}, {}
    local areaToKey, byName = {}, {}
    for area, d in pairs(self.rawDungeons or {}) do
        local name = d[1] or tostring(area)
        local dg = byName[name]
        if not dg then
            dg = { key = name, name = name, areas = {}, entrances = {}, quests = {} }
            byName[name] = dg
        end
        dg.areas[#dg.areas + 1] = area
        if A.RaidAreas[area] then dg.raid = true end
        if not dg.locEn and C_Map and C_Map.GetAreaInfo then
            local ok, n = pcall(C_Map.GetAreaInfo, area)
            if ok and type(n) == "string" and n ~= "" then dg.locEn = n end
        end
        areaToKey[area] = name
        if type(d[2]) == "table" then for _, alt in ipairs(d[2]) do areaToKey[alt] = name end end
        self.areaToKey = areaToKey
        if type(d[4]) == "table" then
            for _, loc in ipairs(d[4]) do
                local m = zoneToMap[loc[1]]
                if m and m > 0 and loc[2] then dg.entrances[#dg.entrances + 1] = { m, loc[2] / 100, loc[3] / 100 } end
            end
        end
    end
    local Q = DB.Quest
    for _, id in ipairs(safe(Q.GetAllIds) or {}) do
        local zone = safe(Q.zoneOrSort, id) or 0
        local key = zone > 0 and areaToKey[zone]
        -- уровни подземелья считаем по всем его квестам (и чужой фракции тоже)
        if key then
            local qlv = safe(Q.questLevel, id) or 0
            if qlv > 0 then
                local dgA = byName[key]
                dgA.allLv = dgA.allLv or {}
                dgA.allLv[#dgA.allLv + 1] = qlv
            end
        end
        if key and raceOK(safe(Q.requiredRaces, id)) and hasFlag(safe(Q.requiredClasses, id), playerClassFlag) then
            local st = safe(Q.startedBy, id)
            -- квестодатель должен быть своей фракции (квесты без ограничения по расе тоже бывают «чужими»)
            local ownGiver = true
            if st and st[1] and #st[1] > 0 and not (st[2] and #st[2] > 0) and not (st[3] and #st[3] > 0) then
                ownGiver = false
                for _, n in ipairs(st[1]) do if friendly(n) then ownGiver = true break end end
            end
            if ownGiver and st and ((st[1] and #st[1] > 0) or (st[2] and #st[2] > 0) or (st[3] and #st[3] > 0)) then
                local dg = byName[key]
                local ql = safe(Q.questLevel, id) or 0
                local rl = safe(Q.requiredLevel, id) or 0
                dg.quests[#dg.quests + 1] = { id = id, ql = ql, rl = rl }
                if ql > 0 then
                    dg.minL = math.min(dg.minL or ql, ql)
                    dg.maxL = math.max(dg.maxL or ql, ql)
                end
            end
        end
    end
    -- поля боя и трамвай — не подземелья
    local skip = { ["Warsong Gulch"] = true, ["Arathi Basin"] = true, ["Alterac Valley"] = true, ["Deeprun Tram"] = true }
    -- Дубли: в базе один и тот же квест бывает записан несколькими вариантами
    -- (например «The Sparklematic 5200!» — по варианту на каждый тип кольца, взять можно только один),
    -- плюс повторяемые версии. Оставляем по одному квесту на название.
    local done = A.DungeonQuestDone
    local function rank(id)
        if FG.log[id] then return 0 end
        if done and done(id) then return 2 end
        return 1
    end
    for _, dg in pairs(byName) do
        local best, order = {}, {}
        for _, q in ipairs(dg.quests) do
            local flags = safe(Q.specialFlags, q.id) or 0
            local repeatable = flags % 2 == 1
            if not repeatable or FG.log[q.id] then
                local n = safe(Q.name, q.id) or tostring(q.id)
                local b = best[n]
                if not b then best[n] = q; order[#order + 1] = n
                else
                    local ra, rb = rank(q.id), rank(b.id)
                    if ra < rb or (ra == rb and q.id < b.id) then best[n] = q end
                end
            end
        end
        local list = {}
        for _, n in ipairs(order) do list[#list + 1] = best[n] end
        -- цепочка — одна строка: квесты, которые являются шагами другого квеста
        -- этого подземелья, отдельно не показываем (они видны внутри карточки)
        local inChain = {}
        for _, q in ipairs(list) do
            for _, c in ipairs(self:FullChain(q.id)) do
                if c ~= q.id then inChain[c] = true end
            end
        end
        dg.quests = {}
        for _, q in ipairs(list) do
            if not inChain[q.id] then dg.quests[#dg.quests + 1] = q end
        end
    end
    for _, dg in pairs(byName) do
        -- уровни: без случайных квестов низкого уровня (берём от 15-го перцентиля)
        local lv = {}
        for _, q in ipairs(dg.quests) do if (q.ql or 0) > 0 then lv[#lv + 1] = q.ql end end
        table.sort(lv)
        if #lv == 0 and dg.allLv then lv = dg.allLv; table.sort(lv) end -- своих квестов нет: уровни по всем
        if #lv > 0 then
            dg.minL = lv[math.max(1, math.floor(#lv * 0.15 + 0.5))]
            dg.maxL = lv[#lv]
        end
        -- подземелье показываем, даже если квестов для вашей фракции нет (стрелка ведёт ко входу)
        if (#dg.quests > 0 or (dg.allLv and #dg.entrances > 0)) and not skip[dg.name] then
            table.sort(dg.quests, function(a, b) return (a.ql or 0) < (b.ql or 0) end)
            self.dungeonList[#self.dungeonList + 1] = dg
            self.dungeonByKey[dg.key] = dg
        end
    end
    -- подземелья Forever, которых нет в базе Questie (данные вручную)
    local myFac = playerFaction or (UnitFactionGroup and UnitFactionGroup("player")) -- фракция из меню
    for _, def in ipairs(FG.ExtraDungeons or {}) do
        if not byName[def.name] then
            local dg = { key = def.name, name = def.name, def = def, manual = true, areas = {}, quests = {},
                         minL = def.minL, maxL = def.maxL,
                         entrances = { { def.entrance[1], def.entrance[2] / 100, def.entrance[3] / 100 } } }
            for _, mq in ipairs(def.quests) do
                if not mq.fac or not myFac or mq.fac == myFac then
                    dg.quests[#dg.quests + 1] = { manual = true, def = mq, ql = mq.ql, rl = mq.rl }
                end
            end
            if #dg.quests > 0 then
                self.dungeonList[#self.dungeonList + 1] = dg
                self.dungeonByKey[dg.key] = dg
            end
        end
    end
    -- уровни подземелий WoW Forever (вход / рекомендуемые), а не по уровням квестов из старой базы
    for _, dg in ipairs(self.dungeonList) do
        local lv = A.ForeverLevels and A.ForeverLevels[dg.name]
        if lv then dg.enterL, dg.minL, dg.maxL = lv[1], lv[2], lv[3] end
    end
    -- если игра сама отдаёт уровни (окно «Найти группу») — берём их
    pcall(A.ApplyGameLevels, A)
    table.sort(self.dungeonList, function(a, b) return (a.minL or 99) < (b.minL or 99) end)
end

-- Уровни подземелий в WoW Forever: { можно войти с, рекомендуется от, до }
-- (как в окне подземелий игры / AtlasLoot для Forever; Руины Лордерона — по гайдам)
A.ForeverLevels = {
    ["Ragefire Chasm"] = { 8, 13, 16 },
    ["Wailing Caverns"] = { 10, 17, 21 },
    ["The Deadmines"] = { 10, 18, 22 },
    ["Shadowfang Keep"] = { 14, 18, 21 },
    ["Blackfathom Deeps"] = { 19, 22, 24 },
    ["The Stockade"] = { 15, 23, 29 },
    ["Gnomeregan"] = { 15, 25, 28 },
    ["Razorfen Kraul"] = { 17, 24, 27 },
    ["Scarlet Monastery"] = { 20, 30, 40 },
    ["Razorfen Downs"] = { 25, 34, 37 },
    ["Uldaman"] = { 30, 36, 40 },
    ["Zul'Farrak"] = { 35, 42, 46 },
    ["Maraudon"] = { 30, 43, 48 },
    ["The Temple of Atal'Hakkar"] = { 35, 47, 50 },
    ["Blackrock Depths"] = { 40, 48, 56 },
    ["Blackrock Spire"] = { 45, 54, 60 },
    ["Dire Maul"] = { 31, 55, 60 },
    ["Scholomance"] = { 45, 58, 60 },
    ["Stratholme"] = { 45, 58, 60 },
    ["Hall of Thanes"] = { 10, 13, 18 },
    ["Ruins of Lordaeron"] = { 10, 15, 20 },
    ["Excavation Site: Wetlands"] = { 20, 24, 29 },
    ["City of Dalaran"] = { 28, 28, 33 },
}

-- Уровни подземелий из игры (C_LFGList): у разных крыльев одного подземелья берём общий диапазон
local function normName(n) return (n or ""):lower():gsub("^the ", ""):gsub("[%s%-–:']", "") end
-- Рейды (по зоне): в окне выбора они в отдельном списке «Рейд»
A.RaidAreas = {
    [2717] = true, -- Огненные Недра
    [2159] = true, -- Логово Ониксии
    [2677] = true, -- Логово Крыла Тьмы
    [1977] = true, -- Зул'Гуруб
    [3429] = true, -- Руины Ан'Киража
    [3428] = true, -- Храм Ан'Киража
    [3456] = true, -- Наксрамас
}

-- Новые рейды WoW Forever (откроются 9 декабря, источник: warcrafttavern.com)
A.UpcomingRaids = {
    { en = "Barrow Deeps", ru = "Курганные глубины", size = 10, when = { en = "Dec 9", ru = "9 дек" },
      zone = { en = "10 players", ru = "10 игроков" } },
    { en = "Hyjal Summit", ru = "Вершина Хиджала", size = 20, when = { en = "Dec 9", ru = "9 дек" },
      zone = { en = "20 players", ru = "20 игроков" } },
}

-- Новые подземелья WoW Forever, которых ещё нет в игре (или нет данных о квестах).
-- Источник: classicwow.gg/forever/dungeons (октябрь 2026). Показываются в окне выбора другим цветом.
A.UpcomingDungeons = {
    { en = "The Drowned City", ru = "Затонувший город", min = 35, max = 40,
      zone = { en = "Stranglethorn Vale coast", ru = "побережье Тернистой долины" } },
    { en = "Krol'dok Stronghold", ru = "Крепость Крол'док", min = 40, max = 45,
      zone = { en = "Riverglades", ru = "Речные долины" } },
    { en = "Alcaz Prison", ru = "Тюрьма острова Алькац", min = 48, max = 53,
      zone = { en = "Alcaz Island, Dustwallow Marsh", ru = "остров Алькац, Пылевые топи" } },
    { en = "Blackmaw Hold", ru = "Крепость Черной Пасти", min = 55, max = 60,
      zone = { en = "northern Azshara", ru = "север Азшары" } },
    { en = "Shaper's Terrace", ru = "Терраса Ваятеля", min = 58, max = 60,
      zone = { en = "Un'Goro Crater", ru = "кратер Ун'Горо" } },
}

function A:ApplyGameLevels()
    if not (C_LFGList and C_LFGList.GetAvailableCategories and C_LFGList.GetAvailableActivities and C_LFGList.GetActivityInfoTable) then return end
    local acts = {}
    for _, cat in ipairs(C_LFGList.GetAvailableCategories() or {}) do
        for _, id in ipairs(C_LFGList.GetAvailableActivities(cat) or {}) do
            local info = C_LFGList.GetActivityInfoTable(id)
            if info and info.fullName then
                local lo = (info.minLevelSuggestion and info.minLevelSuggestion > 0) and info.minLevelSuggestion or info.minLevel
                local hi = (info.maxLevelSuggestion and info.maxLevelSuggestion > 0) and info.maxLevelSuggestion or info.maxLevel
                if lo and lo > 0 then acts[#acts + 1] = { n = normName(info.fullName), lo = lo, hi = (hi and hi > 0) and hi or lo } end
            end
        end
    end
    if #acts == 0 then return end
    for _, dg in ipairs(self.dungeonList) do
        local key = normName(dg.name)
        local lo, hi
        for _, a in ipairs(acts) do
            if a.n == key or a.n:find(key, 1, true) then
                lo = lo and math.min(lo, a.lo) or a.lo
                hi = hi and math.max(hi, a.hi) or a.hi
            end
        end
        if lo then dg.minL, dg.maxL, dg.gameLevels = lo, hi, true end
    end
    table.sort(self.dungeonList, function(a, b) return (a.minL or 99) < (b.minL or 99) end)
end

-- Ручные квесты: ищем в журнале по названию, запоминаем id для проверки «выполнен»
local function manualLogEntry(title)
    local low = title:lower()
    for id, e in pairs(FG.log or {}) do
        if e.title and e.title:lower() == low then
            FG.cdb.manualIds = FG.cdb.manualIds or {}
            FG.cdb.manualIds[title] = id
            return id, e
        end
    end
end

-- Названия уже выполненных квестов (для квестов без id в базе).
-- Берём из базы Questie, а для новых квестов Forever — у самой игры.
local doneTitles, newTitles, titleScanned, titleWaiting = {}, {}, {}, {}
local function gameTitle(id)
    if C_QuestLog and C_QuestLog.GetTitleForQuestID then
        local ok, t = pcall(C_QuestLog.GetTitleForQuestID, id)
        if ok and t and t ~= "" then return t end
    end
    if QuestUtils_GetQuestName then
        local ok, t = pcall(QuestUtils_GetQuestName, id)
        if ok and t and t ~= "" then return t end
    end
end
local function scanDoneTitles()
    if not A.titlesDirty then return end
    A.titlesDirty = false
    for id in pairs(completed) do
        if not titleScanned[id] then
            titleScanned[id] = true
            local t = safe(DB.Quest.name, id)
            if t then doneTitles[t:lower()] = id end
            -- квесты Forever с новыми номерами, которых нет в базе: узнаём по названию у игры
            local g = (not t) and gameTitle(id)
            if g then doneTitles[g:lower()] = id; newTitles[g:lower()] = id
            elseif not t and C_QuestLog and C_QuestLog.RequestLoadQuestByID then
                titleWaiting[id] = true
                pcall(C_QuestLog.RequestLoadQuestByID, id)
            end
        end
    end
end
A.ScanDoneTitles = scanDoneTitles
FG:On("QUEST_DATA_LOAD_RESULT", function(_, id, ok)
    if id and titleWaiting[id] then
        titleWaiting[id] = nil
        local g = gameTitle(id)
        if g then doneTitles[g:lower()] = id; newTitles[g:lower()] = id; if FG.cdb and FG.cdb.dungeon then FG:Refresh() end end
    end
end)

-- Квест из базы выполнен: по номеру или (если в Forever у него новый номер) по названию
local function dqDone(id)
    if completed[id] or FG:IsQuestDone(id) then return true end
    scanDoneTitles()
    local n = safe(DB.Quest.name, id)
    return n and newTitles[n:lower()] and true or false
end
A.DungeonQuestDone = dqDone

-- Ручной квест по английскому названию из журнала
local manualByTitle
function A:ManualDef(title)
    if not title then return end
    if not manualByTitle then
        manualByTitle = {}
        for _, dg in ipairs(FG.ExtraDungeons or {}) do
            for _, mq in ipairs(dg.quests) do manualByTitle[mq.title:lower()] = manualByTitle[mq.title:lower()] or mq end
        end
    end
    return manualByTitle[title:lower()]
end

-- Название квеста для показа: перевод из базы, свой перевод новых квестов или как в игре
function A:QuestTitle(id, title)
    local t = FG:TrQuest(id)
    if t then return t end
    if FG:Lang() == "ru" then
        local d = self:ManualDef(title or (FG.log[id] and FG.log[id].title))
        if d and d.ruTitle then return d.ruTitle end
    end
    return title or safe(DB.Quest.name, id)
end

local function manualDone(title)
    local id = FG.cdb.manualIds and FG.cdb.manualIds[title]
    if id and (completed[id] or FG:IsQuestDone(id)) then return true end
    scanDoneTitles()
    local did = doneTitles[title:lower()]
    if did then
        FG.cdb.manualIds = FG.cdb.manualIds or {}
        FG.cdb.manualIds[title] = did
        return true
    end
    return false
end

local function loc(t) if type(t) ~= "table" then return t end return (FG:Lang() == "en") and t.en or t.ru end
local function mtitle(d) return (FG:Lang() == "ru" and d.ruTitle) or d.title end

local function mapZone(m)
    local info = C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(m)
    return info and FG:TrZone(info.name)
end

function A:ManualState(q)
    local d = q.def
    local id, e = manualLogEntry(d.title)
    if e then return e.complete and "turnin" or "active", nil, id, e end
    if manualDone(d.title) then return "done" end
    if (q.rl or 0) > UnitLevel("player") then return "level" end
    if d.prereq and not manualDone(d.prereq.title) then
        local pid = manualLogEntry(d.prereq.title)
        if not pid then return "prereq" end
    end
    return "available"
end

function A:ManualLine(q)
    local d = q.def
    local state, _, id, e = self:ManualState(q)
    local name = mtitle(d)
    local lvl = (q.ql and q.ql > 0) and (" |cff8a909a[" .. q.ql .. "]|r") or ""
    if state ~= "done" then lvl = lvl .. self:XpText(nil, q.ql, d) end
    local function at(p) if not p then return "" end local z = mapZone(p[2]); return p[1] .. (z and (", " .. z) or "") end
    local function turnText() return d.turnin and at(d.turnin) or loc(d.turninInside) or FG.L("unknown_place") end
    if state == "done" then
        return "|cff5c636e" .. name .. " — " .. FG.L("dq_done") .. "|r", state
    elseif state == "turnin" then
        return "|cff66e07a" .. name .. "|r" .. lvl .. "\n   " .. FG.L("dq_turnin", turnText()), state
    elseif state == "active" then
        local parts = {}
        for _, o in ipairs(e and e.objs or {}) do
            parts[#parts + 1] = (o.done and "|cff66e07a" or "|cffc8ccd2") .. A:TrObjective(nil, o.text) .. "|r"
        end
        if d.obj then parts[#parts + 1] = "|cff8a909a" .. loc(d.obj) .. "|r" end
        return "|cffffd100" .. name .. "|r" .. lvl .. "\n   " .. table.concat(parts, "\n   "), state
    elseif state == "level" then
        return "|cff8a909a" .. name .. lvl .. " — " .. FG.L("dq_level", q.rl or 0) .. "|r", state
    end
    local how
    if state == "prereq" then
        how = "|cffffa94d" .. FG.L("dq_prereq", loc(d.prereq)) .. "|r\n   " .. FG.L("dq_pickup", at(d.giver))
    elseif d.giver then how = FG.L("dq_pickup", at(d.giver))
    elseif d.inside then how = FG.L("dq_inside", loc(d.inside))
    elseif d.item then how = FG.L("dq_item", loc(d.item)) end
    local extra = d.obj and ("\n   |cff8a909a" .. loc(d.obj) .. "|r") or ""
    local tin = "\n   |cff8a909a" .. FG.L("dq_turnin", turnText()) .. "|r"
    local color = (state == "prereq") and "|cffffa94d" or "|cffffd166"
    return color .. name .. "|r" .. lvl .. "\n   " .. (how or "") .. extra .. tin, state
end

function A:DungeonName(dg)
    if not dg then return "" end
    if dg.def then return (FG:Lang() == "ru" and dg.def.ru) or dg.name end
    -- dg.name — английское название из базы; locEn — название из клиента (на его языке)
    if FG:Lang() == "ru" then
        return (FG.RuZones and FG.RuZones[dg.name]) or dg.locEn or dg.name
    end
    return dg.name
end

-- Цепочка: от первого незавершённого предшественника до самого квеста
local function missingPrereqs(id)
    local Q = DB.Quest
    local out = {}
    local single = safe(Q.preQuestSingle, id)
    if single and #single > 0 then
        local any = false
        for _, p in ipairs(single) do if dqDone(p) then any = true end end
        if not any then
            -- берём первый из вариантов, который можно сделать (или первый вообще)
            local pick = single[1]
            for _, p in ipairs(single) do if FG.log[p] or A:IsDoable(p) then pick = p break end end
            out[#out + 1] = pick
        end
    end
    local group = safe(Q.preQuestGroup, id)
    if group then
        for _, p in ipairs(group) do
            local pp = math.abs(p)
            if not dqDone(pp) then out[#out + 1] = pp end
        end
    end
    return out
end

function A:Chain(id)
    local chain, seen = {}, {}
    local function walk(q, depth)
        if seen[q] or depth > 12 then return end
        seen[q] = true
        if not dqDone(q) and not FG.log[q] then
            for _, p in ipairs(missingPrereqs(q)) do walk(p, depth + 1) end
        end
        chain[#chain + 1] = q
    end
    walk(id, 0)
    return chain
end

-- Состояние квеста подземелья
-- done / turnin / active / available / level / locked
function A:DungeonState(q)
    if q.manual then return self:ManualState(q) end
    local id = q.id
    if dqDone(id) then return "done" end
    local e = FG.log[id]
    if e then return e.complete and "turnin" or "active" end
    local level = UnitLevel("player")
    if self:IsDoable(id) then
        if (q.rl or 0) > level then return "level" end
        return "available"
    end
    local chain = self:Chain(id)
    if #chain > 1 then return "locked", chain end
    if (q.rl or 0) > level then return "level" end
    return "locked", chain
end

local function qname(id) return (FG:TrQuest(id)) or safe(DB.Quest.name, id) or FG.L("quest_n", tostring(id)) end

-- Где взять квест: имя NPC и зона
-- Подсказки, где именно стоит NPC (внутри подземелья координат нет)
local NPC_HINT = {
    [7850] = { ru = "в Спальнях (Dormitory), рядом с выходом к Заводной дороге (Clockwerk Run)",
               en = "in the Dormitory, near the exit to Clockwerk Run" },  -- Кернаби
    [7853] = { ru = "Пиратская Бухта, у гоблинского телепорта", en = "Booty Bay, by the goblin transporter" }, -- Скути
}

-- Где находится: «зона x, y» или «внутри подземелья «…»»
local function zoneWhere(zone, sp, hint)
    local dkey = zone and A.areaToKey and A.areaToKey[zone]
    local label
    if dkey then
        local dg = A.dungeonByKey and A.dungeonByKey[dkey]
        label = FG.L("qc_inside", dg and A:DungeonName(dg) or dkey)
    else
        label = zone and zone > 0 and areaName(zone, nil) or nil
        local p = sp and zone and sp[zone] and sp[zone][1]
        if label and p and p[1] and p[1] >= 0 then
            label = label .. string.format(" %.0f, %.0f", p[1], p[2])
        end
    end
    if hint then label = (label and (label .. " — ") or "") .. hint end
    return label
end

local function npcWhere(npc)
    return zoneWhere(safe(DB.Npc.zoneID, npc), safe(DB.Npc.spawns, npc), NPC_HINT[npc] and loc(NPC_HINT[npc]))
end

local function objWhere(obj)
    return zoneWhere(safe(DB.Object.zoneID, obj), safe(DB.Object.spawns, obj))
end

-- предмет, с которого начинается квест: «предмет, падает с: …, внутри «…»»
local function itemWhere(item)
    local src = A.ItemSourceNames and A.ItemSourceNames(item)
    local where
    for _, n in ipairs(safe(DB.Item.npcDrops, item) or {}) do
        where = zoneWhere(safe(DB.Npc.zoneID, n), safe(DB.Npc.spawns, n))
        if where then break end
    end
    local t = FG.L("qc_item_word")
    if src then t = t .. ", " .. FG.L("dq_drops", src) end
    if where then t = t .. " (" .. where .. ")" end
    return t
end

-- Особые требования квеста (профессия, репутация): текст или nil
local SKILLS = { [186] = "skill_mining", [164] = "skill_bs", [202] = "skill_eng", [165] = "skill_lw", [197] = "skill_tailor",
    [171] = "skill_alch", [333] = "skill_ench", [182] = "skill_herb", [393] = "skill_skin", [185] = "skill_cook",
    [129] = "skill_aid", [356] = "skill_fish", [755] = "skill_jc" }
local function requirement(id)
    local sk = safe(DB.Quest.requiredSkill, id)
    if type(sk) == "table" and sk[1] then
        local key = SKILLS[sk[1]]
        return FG.L("req_skill", key and FG.L(key) or ("#" .. sk[1]), sk[2] or 1)
    end
    local rep = safe(DB.Quest.requiredMinRep, id)
    if type(rep) == "table" and rep[1] then return FG.L("req_rep") end
end
A.Requirement = requirement

-- Квест берут внутри подземелья (NPC/объект там, или предмет падает там)
local function startsInside(id)
    local inDg = function(zone) return zone and A.areaToKey and A.areaToKey[zone] and true or false end
    local st = safe(DB.Quest.startedBy, id) or {}
    if st[1] and st[1][1] then return inDg(safe(DB.Npc.zoneID, st[1][1])) end
    if st[2] and st[2][1] then return inDg(safe(DB.Object.zoneID, st[2][1])) end
    if st[3] and st[3][1] then
        for _, n in ipairs(safe(DB.Item.npcDrops, st[3][1]) or {}) do
            if inDg(safe(DB.Npc.zoneID, n)) then return true end
        end
    end
    return false
end

-- возвращает: название, где, вид («npc», «obj», «item»)
local function giverInfo(id)
    local st = safe(DB.Quest.startedBy, id) or {}
    local npc = st[1] and st[1][1]
    if npc then return FG:TrNpc(npc, safe(DB.Npc.name, npc)), npcWhere(npc), "npc" end
    local obj = st[2] and st[2][1]
    if obj then return FG:TrObject(obj, safe(DB.Object.name, obj)), objWhere(obj), "obj" end
    local item = st[3] and st[3][1]
    if item then return FG:TrItem(item, safe(DB.Item.name, item)), itemWhere(item), "item" end
end

local function finisherInfo(id)
    local fin = safe(DB.Quest.finishedBy, id) or {}
    local npc = fin[1] and fin[1][1]
    if npc then return FG:TrNpc(npc, safe(DB.Npc.name, npc)), npcWhere(npc), "npc" end
    local obj = fin[2] and fin[2][1]
    if obj then return FG:TrObject(obj, safe(DB.Object.name, obj)), objWhere(obj), "obj" end
end

-- «Что нужно сделать» по квесту: текст задания из журнала игры или из базы
function A:WhatToDo(id)
    if FG:Lang() == "ru" then
        local _, ro = FG:TrQuest(id)
        if type(ro) == "table" and #ro > 0 then return table.concat(ro, " ") end
        -- новый квест Forever: своё описание; иначе английский текст игры не показываем
        local d = self:ManualDef(FG.log[id] and FG.log[id].title)
        if d and d.obj then return loc(d.obj) end
        if d and d.item then return loc(d.item) end
        return nil
    end
    local e = id and FG.log[id]
    if e and e.index and GetQuestLogQuestText and SelectQuestLogEntry then
        local prev = GetQuestLogSelection and GetQuestLogSelection()
        local ok, _, objText = pcall(function() SelectQuestLogEntry(e.index); return GetQuestLogQuestText() end)
        if prev and prev > 0 then pcall(SelectQuestLogEntry, prev) end
        if ok and objText and objText ~= "" then return objText end
    end
    if id and id > 0 then
        local t = safe(DB.Quest.objectivesText, id)
        if type(t) == "table" and #t > 0 then return table.concat(t, " ") end
        if type(t) == "string" and t ~= "" then return t end
    end
end

-- Подробности квеста для панели: задание, цели, где взять и кому сдать
function A:QuestDetails(id, q)
    local L = FG.L
    local out = {}
    if q and q.manual then
        local d = q.def
        local state, _, lid, e = self:ManualState(q)
        local wt = lid and FG:Lang() ~= "ru" and self:WhatToDo(lid)
        if wt then out[#out + 1] = "|cffffd100" .. L("qd_task") .. "|r |cffc8ccd2" .. wt .. "|r" end
        local full = self:ManualLine(q)
        local rest = full:match("\n(.*)$")
        if rest then out[#out + 1] = rest:gsub("^%s+", ""):gsub("\n%s+", "\n") end
        return table.concat(out, "\n")
    end
    if not id or id <= 0 then return "" end
    local wt = self:WhatToDo(id)
    if wt then out[#out + 1] = "|cffffd100" .. L("qd_task") .. "|r |cffc8ccd2" .. wt .. "|r" end
    local e = FG.log[id]
    if e then
        local items = (safe(DB.Quest.objectives, id) or {})[3] or {}
        for _, o in ipairs(e.objs or {}) do
            local line = (o.done and "|TInterface\\RaidFrame\\ReadyCheck-Ready:12:12|t |cff66e07a" or "|cffc8ccd2- ") .. A:TrObjective(id, o.text) .. "|r"
            if not o.done then
                for _, it in ipairs(items) do
                    local iname = safe(DB.Item.name, it[1])
                    if iname and o.text and o.text:find(iname, 1, true) then
                        local src = A.ItemSourceNames(it[1])
                        if src then line = line .. " |cff8a909a(" .. L("dq_drops", src) .. ")|r" end
                        break
                    end
                end
            end
            out[#out + 1] = line
        end
    else
        local gn, gz = giverInfo(id)
        if gn then out[#out + 1] = "|cffffd100" .. L("qd_take") .. "|r " .. gn .. (gz and (", " .. gz) or "") end
    end
    local fn, fz = finisherInfo(id)
    if fn then out[#out + 1] = "|cff66e07a" .. L("qd_turnin") .. "|r " .. fn .. (fz and (", " .. fz) or "")
    else
        local d = self:ManualDef(e and e.title)
        if d and d.turnin then
            local z = mapZone(d.turnin[2])
            out[#out + 1] = "|cff66e07a" .. L("qd_turnin") .. "|r " .. d.turnin[1] .. (z and (", " .. z) or "")
        end
    end
    return table.concat(out, "\n")
end

-- Текстовая строка для списка квестов подземелья на панели
function A:DungeonLine(q)
    if q.manual then return self:ManualLine(q) end
    local state, chain = self:DungeonState(q)
    local name = qname(q.id)
    local lvl = (q.ql and q.ql > 0) and (" |cff8a909a[" .. q.ql .. "]|r") or ""
    if state ~= "done" then lvl = lvl .. self:XpText(q.id, q.ql) end
    local function where(n, z) return n and (n .. (z and (", " .. z) or "")) or FG.L("unknown_place") end
    if state == "done" then
        return "|cff5c636e" .. name .. " — " .. FG.L("dq_done") .. "|r", state
    elseif state == "turnin" then
        return "|cff66e07a" .. name .. "|r" .. lvl .. "\n   " .. FG.L("dq_turnin", where(finisherInfo(q.id))), state
    elseif state == "active" then
        local e = FG.log[q.id]
        local parts = {}
        local items = (safe(DB.Quest.objectives, q.id) or {})[3] or {}
        for _, o in ipairs(e and e.objs or {}) do
            local line = (o.done and "|cff66e07a" or "|cffc8ccd2") .. A:TrObjective(q.id, o.text) .. "|r"
            if not o.done then
                for _, it in ipairs(items) do
                    local iname = safe(DB.Item.name, it[1])
                    if iname and o.text and o.text:find(iname, 1, true) then
                        local src = itemSourceNames(it[1])
                        if src then line = line .. "\n      |cff8a909a" .. FG.L("dq_drops", src) .. "|r" end
                        break
                    end
                end
            end
            parts[#parts + 1] = line
        end
        if #parts == 0 then
            local t = safe(DB.Quest.objectivesText, q.id)
            if t and t[1] then parts[1] = "|cffc8ccd2" .. t[1] .. "|r" end
        end
        return "|cffffd100" .. name .. "|r" .. lvl .. "\n   " .. table.concat(parts, "\n   "), state
    elseif state == "available" then
        return "|cffffd166" .. name .. "|r" .. lvl .. "\n   " .. FG.L("dq_pickup", where(giverInfo(q.id))), state
    elseif state == "level" then
        return "|cff8a909a" .. name .. lvl .. " — " .. FG.L("dq_level", q.rl or 0) .. "|r", state
    end
    -- цепочка
    local first = chain and chain[1]
    if first and first ~= q.id then
        local fs = FG.log[first] and (FG.log[first].complete and FG.L("dq_chain_turn") or FG.L("dq_chain_do")) or FG.L("dq_chain_take")
        local n, z = giverInfo(first)
        if FG.log[first] and FG.log[first].complete then n, z = finisherInfo(first) end
        local steps = #chain - 1
        return "|cffffa94d" .. name .. "|r" .. lvl .. "\n   " .. FG.L("dq_chain", steps) ..
            "\n   " .. fs .. " «" .. qname(first) .. "»" .. ((not FG.log[first] or FG.log[first].complete) and (" — " .. where(n, z)) or ""), state
    end
    return "|cff8a909a" .. name .. lvl .. " — " .. FG.L("dq_unavailable") .. "|r", state
end

-- Подсказки в режиме подземелья
function A:RecalcDungeon(dg)
    self.dungeon = dg
    local pm, px, py = FG:GetPlayerPos()
    local w, h = 1000, 667
    if pm then local a, b = FG:MapSize(pm); if a then w, h = a, b end end
    local list = {}
    local curKey -- квест подземелья, к которому относится шаг
    local entranceFor = {}
    local insideNote = {} -- квест берут внутри подземелья: у кого и где
    local function add(s, factor)
        s.fk = s.fk or curKey
        if not px then s.dist = FAR * 2; s.score = FAR * 2 * (factor or 1) else
            s.dist = distTo({ s.m, s.x, s.y }, pm, px, py, w, h)
            s.score = s.dist * (factor or 1)
        end
        list[#list + 1] = s
    end
    local entrance = dg.entrances[1]
    if px and #dg.entrances > 1 then
        local d, p = nearest(dg.entrances, pm, px, py, w, h)
        if p then entrance = p end
    end
    local needEntrance = false
    local inside = IsInInstance and IsInInstance() or false
    local summary = { total = 0, done = 0 }
    for _, q in ipairs(dg.quests) do
        local state, chain = self:DungeonState(q)
        summary.total = summary.total + 1
        if state == "done" then summary.done = summary.done + 1 end
        local id = q.id
        curKey = A:DungeonKey(q)
        if state == "done" and FG.cdb.dqFocus == curKey then FG.cdb.dqFocus = nil end
        local needBefore = needEntrance
        needEntrance = false
        if q.manual then
            local d = q.def
            local _, _, lid = self:ManualState(q)
            local function pt(p) return { p[2], p[3] / 100, p[4] / 100 } end
            if state == "turnin" and d.turnin then
                local p = pt(d.turnin)
                add({ k = "t", q = lid, t = mtitle(d), mt = d.title, npc = d.turnin[1], m = p[1], x = p[2], y = p[3], dungeon = true }, 1.0)
            elseif state == "active" then
                needEntrance = true
                if inside then
                    local e = entrance
                    add({ k = "d", q = lid, t = mtitle(d), mt = d.title, obj = loc(d.obj) or mtitle(d), m = e[1], x = e[2], y = e[3], dungeon = true }, 0.5)
                end
            elseif state == "available" and d.giver then
                local p = pt(d.giver)
                add({ k = "a", q = 0, t = mtitle(d), mt = d.title, npc = d.giver[1], ql = q.ql, m = p[1], x = p[2], y = p[3], dungeon = true }, 0.7)
            elseif state == "available" and (d.inside or d.item) then
                needEntrance = true
            elseif state == "prereq" and d.prereq.point then
                local pp = d.prereq.point
                add({ k = "d", q = 0, t = d.prereq.title, obj = pp[4], m = pp[1], x = pp[2] / 100, y = pp[3] / 100,
                      chainFor = FG.L("dq_for", mtitle(d)) }, 0.8)
            end
        elseif state == "turnin" then
            local pts, npc = finisherPoints(id)
            local d, p = nearest(pts, pm or 0, px or 0, py or 0, w, h)
            if p then add({ k = "t", q = id, t = qname(id), npc = p[4] or npc, m = p[1], x = p[2], y = p[3], dungeon = true }, 1.0) end
        elseif state == "active" then
            needEntrance = true
            if inside then
                local e = FG.log[id]
                for _, obj in ipairs(self:ObjectiveTargets(id, e)) do
                    local p = obj.points and obj.points[1] or entrance
                    if p then
                        add({ k = "d", q = id, t = qname(id), obj = obj.label, src = obj.src, m = p[1], x = p[2], y = p[3], dungeon = true }, 0.5)
                    end
                end
            end
        elseif state == "available" then
            local pts, npc = starterPoints(id)
            local d, p = nearest(pts, pm or 0, px or 0, py or 0, w, h)
            if p then add({ k = "a", q = id, t = qname(id), npc = p[4] or npc, ql = q.ql, m = p[1], x = p[2], y = p[3], dungeon = true }, 0.7)
            else
                -- квест берут внутри подземелья (у NPC там нет координат): ведём ко входу
                needEntrance = true
                local gn, gw = giverInfo(id)
                if gn then insideNote[curKey] = FG.L("dq_take_inside", qname(id), gn .. (gw and (", " .. gw) or "")) end
            end
        elseif state == "locked" and not (chain and chain[1] ~= id) then
            -- не цепочка: квест закрыт требованием (профессия, репутация) — ведём к месту и объясняем
            local req = requirement(id)
            local pts, npc = starterPoints(id)
            local d, p = nearest(pts, pm or 0, px or 0, py or 0, w, h)
            if p then
                add({ k = "a", q = id, t = qname(id), npc = p[4] or npc, ql = q.ql, m = p[1], x = p[2], y = p[3], dungeon = true,
                      chainFor = req or FG.L("dq_not_yet") }, 1.2)
            else
                needEntrance = true
                local gn, gw = giverInfo(id)
                insideNote[curKey] = (gn and FG.L("dq_take_inside", qname(id), gn .. (gw and (", " .. gw) or "")) or qname(id))
                    .. (req and (" — " .. req) or "")
            end
        elseif state == "locked" and chain and chain[1] ~= id then
            -- текущий шаг цепочки (с учётом вводных квестов и того, что уже в журнале)
            local first = chain[1]
            local full = self:FullChain(id)
            local ci = A.ChainCur and A.ChainCur(full)
            if ci and full[ci] and full[ci] ~= id then first = full[ci] end
            local e = FG.log[first]
            local note = FG.L("dq_for", qname(id))
            if e and e.complete then
                local pts, npc = finisherPoints(first)
                local d, p = nearest(pts, pm or 0, px or 0, py or 0, w, h)
                if p then add({ k = "t", q = first, t = qname(first), npc = p[4] or npc, m = p[1], x = p[2], y = p[3], chainFor = note }, 0.8) end
            elseif e then
                for _, obj in ipairs(self:ObjectiveTargets(first, e)) do
                    local d, p = nearest(obj.points, pm or 0, px or 0, py or 0, w, h)
                    if p then add({ k = "d", q = first, t = qname(first), obj = obj.label, m = p[1], x = p[2], y = p[3], chainFor = note }, 0.9) end
                end
            elseif self:IsDoable(first) then
                local pts, npc = starterPoints(first)
                local d, p = nearest(pts, pm or 0, px or 0, py or 0, w, h)
                if p then add({ k = "a", q = first, t = qname(first), npc = p[4] or npc, m = p[1], x = p[2], y = p[3], chainFor = note }, 0.8)
                else
                    -- первый шаг берут внутри подземелья (NPC, предмет с монстров, объект)
                    needEntrance = true
                    local gn, gw = giverInfo(first)
                    if gn then insideNote[curKey] = FG.L("dq_take_inside", qname(first), gn .. (gw and (", " .. gw) or "")) end
                end
            else
                -- первый шаг цепочки пока недоступен (уровень, репутация, класс и т.п.):
                -- всё равно показываем, к кому он ведёт, чтобы было понятно, с чего начинать
                local pts, npc = starterPoints(first)
                local d, p = nearest(pts, pm or 0, px or 0, py or 0, w, h)
                if p then
                    add({ k = "a", q = first, t = qname(first), npc = p[4] or npc, m = p[1], x = p[2], y = p[3],
                          chainFor = note .. " — " .. FG.L("dq_not_yet") }, 1.2)
                else
                    needEntrance = true
                    local gn, gw = giverInfo(first)
                    if gn then insideNote[curKey] = FG.L("dq_take_inside", qname(first), gn .. (gw and (", " .. gw) or "")) end
                end
            end
        end
        if needEntrance then entranceFor[curKey] = true end
        needEntrance = needEntrance or needBefore
    end
    curKey = nil
    if #dg.quests == 0 then needEntrance = true end -- квестов нет — просто ведём ко входу
    if needEntrance and entrance and not inside then
        -- вход в подземелье — после того, как собраны квесты рядом
        add({ k = "e", q = 0, t = self:DungeonName(dg), m = entrance[1], x = entrance[2], y = entrance[3], dungeon = true, fk = "e" }, 1.3)
    end
    table.sort(list, function(a, b) return a.score < b.score end)
    -- выбранный игроком квест: ведём только по нему (вход — если он нужен этому квесту)
    local focus = FG.cdb.dqFocus
    if focus == "none" then focus = nil end -- все квесты свёрнуты: выбираем шаг сам
    if focus ~= nil then
        local only = {}
        for _, st in ipairs(list) do
            if st.fk == focus or (st.k == "e" and entranceFor[focus]) then only[#only + 1] = st end
        end
        list = only -- выбранный квест держим, даже если идти по нему сейчас некуда
    end
    -- выбран квест, который берут внутри: у шага «вход» пишем, у кого и где его взять
    if focus ~= nil and insideNote[focus] then
        for i, st in ipairs(list) do
            if st.k == "e" then
                local c = {}
                for k2, v in pairs(st) do c[k2] = v end
                c.chainFor = insideNote[focus]
                list[i] = c
            end
        end
    end
    self.suggestions = list
    self.step = list[1]
    self.dungeonSummary = summary
    if #dg.quests == 0 then
        self.status = FG.L("dq_nofaction")
        if self.step then self.step.chainFor = FG.L("dq_nofaction_short") end
    end
    if not self.step and focus ~= nil then
        self.status = insideNote[focus] or FG.L("dq_focus_wait")
    elseif not self.step then
        if summary.done == summary.total then
            self.status = FG.L("dq_all_done", self:DungeonName(dg))
        else
            self.status = FG.L("dq_nothing", self:DungeonName(dg))
        end
    else
        self.status = ""
    end
end

-- Название квеста подземелья для списка
function A:DungeonTitle(q)
    if q.manual then return mtitle(q.def) end
    return qname(q.id)
end
function A:DungeonXp(q)
    if q.manual then return self:XpText(nil, q.ql, q.def) end
    return self:XpText(q.id, q.ql)
end

-- Ключ квеста подземелья (номер или название для ручных)
function A:DungeonKey(q) return q.manual and q.def.title or q.id end

-- Выбрать квест подземелья, по которому вести (nil — выбирать автоматически)
function A:FocusDungeonQuest(key)
    FG.cdb.dqFocus = key
    self.pinned = nil
    FG:Refresh(true)
end

function A:SetDungeon(key)
    if key and not (self.dungeonByKey and self.dungeonByKey[key]) then key = nil end
    FG.cdb.dqFocus = nil
    FG.cdb.dungeon = key
    self.pinned = nil
    if key then FG:Print(FG.L("dq_selected", self:DungeonName(self.dungeonByKey[key])))
    else FG:Print(FG.L("dq_off")) end
    FG:Refresh(true)
end

---------------------------------------------------------------------------
-- Карточка квеста для раскрытого квеста в списке подземелья:
-- только «где взять», «что сделать», «кому сдать»; для цепочки — все шаги,
-- что уже сделано и что делать сейчас
---------------------------------------------------------------------------
local function allPrereqs(id)
    local Q = DB.Quest
    local out = {}
    local single = safe(Q.preQuestSingle, id)
    if single and #single > 0 then
        local pick
        for _, p in ipairs(single) do if dqDone(p) or FG.log[p] then pick = p break end end
        if not pick then
            pick = single[1]
            for _, p in ipairs(single) do if A:IsDoable(p) then pick = p break end end
        end
        out[#out + 1] = pick
    end
    for _, p in ipairs(safe(Q.preQuestGroup, id) or {}) do out[#out + 1] = math.abs(p) end
    -- вводный квест («иди к такому-то»): необязательный первый шаг цепочки
    if #out == 0 then
        local bc = safe(Q.breadcrumbs, id)
        if type(bc) == "table" and #bc > 0 then
            local pick = bc[1]
            for _, p in ipairs(bc) do if dqDone(p) or FG.log[p] then pick = p break end end
            out[#out + 1] = pick
        end
    end
    return out
end

-- текущий шаг цепочки: после последнего выполненного (или взятого) шага;
-- вводный квест можно пропустить, поэтому смотрим на самый дальний шаг
local function chainCur(chain)
    local cur = 1
    for i, c in ipairs(chain) do
        if FG.log[c] then cur = i
        elseif dqDone(c) then cur = math.min(i + 1, #chain) end
    end
    return cur
end
A.ChainCur = chainCur

function A:FullChain(id)
    local chain, seen = {}, {}
    local function walk(q, depth)
        if seen[q] or depth > 12 then return end
        seen[q] = true
        for _, p in ipairs(allPrereqs(q)) do walk(p, depth + 1) end
        chain[#chain + 1] = q
    end
    walk(id, 0)
    return chain
end

local GOLD, TXT, DIM = "|cffffd100", "|cffe6e6e6", "|cff8a909a"
local CHECK = "|TInterface\\RaidFrame\\ReadyCheck-Ready:12:12|t "
local function place(n, z) return (n or FG.L("unknown_place")) .. (z and (", " .. z) or "") end

-- цели квеста из журнала (с переводом и «падает с»)
local function objLines(id, e, indent)
    local out = {}
    local items = (safe(DB.Quest.objectives, id) or {})[3] or {}
    for _, o in ipairs(e and e.objs or {}) do
        local line = indent .. (o.done and (CHECK .. "|cff66e07a") or (TXT .. "- ")) .. A:TrObjective(id, o.text) .. "|r"
        if not o.done then
            for _, it in ipairs(items) do
                local iname = safe(DB.Item.name, it[1])
                if iname and o.text and o.text:find(iname, 1, true) then
                    local src = A.ItemSourceNames(it[1])
                    if src then line = line .. DIM .. " (" .. FG.L("dq_drops", src) .. ")|r" end
                    break
                end
            end
        end
        out[#out + 1] = line
    end
    return out
end

-- что делать сейчас по одному квесту цепочки
local function stepAction(id)
    local L = FG.L
    local e = FG.log[id]
    if e and e.complete then
        return L("qc_turn") .. " " .. place(finisherInfo(id))
    elseif e then
        local o = objLines(id, e, "      ")
        return L("qc_do") .. (#o > 0 and ("\n" .. table.concat(o, "\n")) or (" " .. (A:WhatToDo(id) or "")))
    end
    local n, w, kind = giverInfo(id)
    if kind == "item" then
        local word = L("qc_item_word")
        if w and w:sub(1, #word) == word then w = w:sub(#word + 1):gsub("^,%s*", "") end
        return L("qc_find_item") .. " «" .. (n or "?") .. "»" .. ((w and w ~= "") and (" — " .. w) or "")
    end
    if kind == "obj" then return L("qc_use_obj") .. " " .. place(n, w) end
    return L("qc_take") .. " " .. place(n, w)
end

-- Цепочка для строки списка: шаг и всего шагов (nil — обычный квест)
local chainCache, chainTime = {}, 0
function A:ChainInfo(q)
    if q.manual then
        local pr = q.def.prereq
        if not pr then return end
        return manualDone(pr.title) and 2 or 1, 2
    end
    local chain = self:ChainFor(q)
    if chain then return chainCur(chain), #chain end
end

-- Цепочка, в которую входит квест: своя (если до него есть шаги)
-- или цепочка другого квеста этого подземелья, которая начинается с него
function A:ChainFor(q)
    if not q.id then return end
    local now = GetTime and GetTime() or 0
    if now - chainTime > 5 then chainCache, chainTime = {}, now end
    local function get(id)
        local c = chainCache[id]
        if not c then c = self:FullChain(id); chainCache[id] = c end
        return c
    end
    local chain = get(q.id)
    local dg
    for _, o in ipairs(self.dungeonList or {}) do
        for _, oq in ipairs(o.quests) do if oq == q then dg = o break end end
        if dg then break end
    end
    -- берём самую длинную цепочку подземелья, в которую входит квест
    local best = (#chain >= 2) and chain or nil
    for _, oq in ipairs(dg and dg.quests or {}) do
        if oq.id and oq.id ~= q.id then
            local oc = get(oq.id)
            for _, c in ipairs(oc) do
                if c == q.id and (not best or #oc > #best) then best = oc end
            end
        end
    end
    return best
end

-- Взят ли квест (или текущий шаг его цепочки): "turnin" — можно сдать, "active" — в журнале, nil — не взят
function A:TakenState(q)
    if q.manual then
        local st = self:ManualState(q)
        if st == "turnin" or st == "active" then return st end
        return
    end
    local chain = self:ChainFor(q) or { q.id }
    local found
    for _, c in ipairs(chain) do
        local e = FG.log[c]
        if e then found = e.complete and "turnin" or "active" end
    end
    if not found and FG.log[q.id] then found = FG.log[q.id].complete and "turnin" or "active" end
    return found
end

-- Брать квест (или текущий шаг его цепочки) нужно внутри подземелья
function A:StartsInside(q)
    if q.manual then
        local d = q.def
        return (d.inside or d.item) and not d.giver and true or false
    end
    local chain = self:ChainFor(q)
    local id = q.id
    if chain and #chain > 1 then id = chain[A.ChainCur(chain)] or id end
    return startsInside(id)
end

function A:QuestCard(q)
    local L = FG.L
    local out = {}
    if q.manual then
        local d = q.def
        local state, _, lid, e = self:ManualState(q)
        if d.prereq then
            local done = manualDone(d.prereq.title)
            out[#out + 1] = GOLD .. L("qc_chain_first") .. "|r " .. (done and (CHECK .. DIM) or TXT) .. loc(d.prereq) .. "|r"
        end
        if not e then
            local how = d.giver and place(d.giver[1], mapZone(d.giver[2]))
                or (d.inside and loc(d.inside)) or (d.item and (L("qc_item") .. " " .. loc(d.item)))
            if how then out[#out + 1] = GOLD .. L("qd_take") .. "|r " .. TXT .. how .. "|r" end
        end
        if d.obj then out[#out + 1] = GOLD .. L("qd_task") .. "|r " .. TXT .. loc(d.obj) .. "|r" end
        if e then for _, l in ipairs(objLines(lid, e, "")) do out[#out + 1] = l end end
        local tin = d.turnin and place(d.turnin[1], mapZone(d.turnin[2])) or loc(d.turninInside)
        if tin then out[#out + 1] = GOLD .. L("qd_turnin") .. "|r " .. TXT .. tin .. "|r" end
        return table.concat(out, "\n")
    end
    local id = q.id
    -- цепочка: все шаги по порядку, отмечено пройденное и что делать сейчас
    local chain = self:ChainFor(q)
    if chain and #chain > 1 then
        local cur = chainCur(chain)
        out[#out + 1] = GOLD .. L("qc_chain", cur, #chain) .. "|r"
        for i, c in ipairs(chain) do
            local this = (c == id) and (" " .. L("qc_this")) or ""
            if i < cur then
                out[#out + 1] = "  " .. CHECK .. DIM .. i .. ". " .. qname(c) .. this .. "|r"
            elseif i == cur and c ~= id then
                out[#out + 1] = "  " .. GOLD .. i .. ". " .. qname(c) .. "|r\n      " .. TXT .. stepAction(c) .. "|r"
            elseif i == cur then
                out[#out + 1] = "  " .. GOLD .. i .. ". " .. qname(c) .. this .. "|r"
            else
                -- следующие шаги: к кому идти, чтобы было понятно даже при одинаковых названиях
                out[#out + 1] = "  " .. DIM .. i .. ". " .. qname(c) .. this .. " — " .. place(giverInfo(c)) .. "|r"
            end
        end
        out[#out + 1] = ""
    end
    local e = FG.log[id]
    local req = requirement(id)
    if req and not e then out[#out + 1] = "|cffff7f50" .. req .. "|r" end
    if not e then out[#out + 1] = GOLD .. L("qd_take") .. "|r " .. TXT .. place(giverInfo(id)) .. "|r" end
    local wt = self:WhatToDo(id)
    if wt then out[#out + 1] = GOLD .. L("qd_task") .. "|r " .. TXT .. wt .. "|r" end
    if e then for _, l in ipairs(objLines(id, e, "")) do out[#out + 1] = l end end
    out[#out + 1] = GOLD .. L("qd_turnin") .. "|r " .. TXT .. place(finisherInfo(id)) .. "|r"
    return table.concat(out, "\n")
end
