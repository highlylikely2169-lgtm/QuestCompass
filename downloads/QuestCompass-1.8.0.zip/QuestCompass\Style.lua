-- QuestCompass: оформление — цвета, шрифты, своя графика и элементы интерфейса.
-- Тёмная тема со скруглёнными углами и бирюзовым акцентом (тот же цвет, что у пунктира на карте).
local _, ns = ...
local FG = ns.FG
local S = {}
FG.Style = S

local WHITE = "Interface\\Buttons\\WHITE8x8"
local MEDIA = "Interface\\AddOns\\QuestCompass\\Media\\"
S.media = {
    circle = MEDIA .. "circle",
    ring   = MEDIA .. "ring",
    glow   = MEDIA .. "glow",
    gradv  = MEDIA .. "gradv",
    arrow  = MEDIA .. "arrow",
    pin    = MEDIA .. "pin",
    logo   = MEDIA .. "logo",
}

S.c = {
    bg      = { 0, 0, 0, 0.9 },
    bg2     = { 0.06, 0.06, 0.06, 1 },
    bg3     = { 0.16, 0.16, 0.16, 1 },
    border  = { 0.55, 0.55, 0.55, 1 },
    accent  = { 1.000, 0.820, 0.000, 1 },   -- золото Blizzard (GameFontNormal)
    accentD = { 1.000, 0.820, 0.000, 0.16 },
    text    = { 1, 1, 1, 1 },
    muted   = { 0.62, 0.62, 0.62, 1 },
    soft    = { 0.86, 0.86, 0.86, 1 },
    dark    = { 0.05, 0.05, 0.05, 1 },
    gold    = { 1.000, 0.820, 0.000, 1 },
    green   = { 0.25, 1.0, 0.25, 1 },
}
-- рамка и фон в стиле окон игры
S.backdrop = { bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } }
function S:Backdrop(f, alpha, border, kind, header)
    if not f.SetBackdrop and BackdropTemplateMixin then Mixin(f, BackdropTemplateMixin) end
    if S:IsPaper() and S:Themed(f) then
        if kind == "window" then return S:PaperWindow(f, header) end
        if f.SetBackdrop then
            f:SetBackdrop(S.backdrop)
            f:SetBackdropColor(0.45, 0.32, 0.18, 0.18)
            f:SetBackdropBorderColor(0.45, 0.32, 0.18, 1)
        end
        return
    end
    if f.SetBackdrop then
        f:SetBackdrop(S.backdrop)
        f:SetBackdropColor(0, 0, 0, alpha or 0.9)
        local b = border or { 0.62, 0.62, 0.62 }
        f:SetBackdropBorderColor(b[1], b[2], b[3], 1)
    else
        S:Box(f, 4, { 0, 0, 0, alpha or 0.9 }, { 0.5, 0.5, 0.5, 1 })
    end
end

---------------------------------------------------------------------------
-- Тема «Пергамент»: светлая бумага, деревянная рамка, тёмные чернила.
-- Применяется только к окнам аддона (меню, панель заданий и их правым частям).
---------------------------------------------------------------------------
function S:IsPaper() return true end -- оформление одно: пергамент
S.PAPER = { 0.92, 0.78, 0.57, 1 } -- цвет пергамента (как окно задания)
S.HEADER = { 0.2, 0.12, 0.06 } -- тёмная шапка окна
S.PAPER_EDGE = { 0.27, 0.17, 0.09 } -- тёмно-коричневая рамка
-- принадлежит ли фрейм окну аддона (корни помечены qcRoot)
function S:Themed(f)
    local n = 0
    while f and n < 20 do
        if f.qcRoot == true then return true end
        f = f.GetParent and f:GetParent() or nil
        n = n + 1
    end
    return false
end
local function lumsat(r, g, b)
    local mx, mn = math.max(r, g, b), math.min(r, g, b)
    return (r + g + b) / 3, mx - mn
end
-- цвет текста на пергаменте (тёмные цвета не трогаем — так перекраска не накапливается)
function S:InkRGB(r, g, b)
    r, g, b = r or 1, g or 1, b or 1
    local lum, sat = lumsat(r, g, b)
    if lum < 0.38 then return r, g, b end
    if sat < 0.15 then
        if lum > 0.8 then return 0.2, 0.11, 0.04 end
        return 0.36, 0.25, 0.14
    end
    if r > 0.85 and g > 0.6 and b < 0.45 then return 0.5, 0.1, 0.02 end   -- золото → тёмно-красный
    if r > 0.8 and g > 0.3 and g <= 0.6 and b < 0.4 then return 0.6, 0.27, 0 end -- оранжевый
    if g >= r and g >= b then
        if b > 0.6 and r < 0.5 then return 0, 0.33, 0.42 end            -- бирюзовый
        return 0.05, 0.38, 0.05                                         -- зелёный
    end
    if r >= g and r >= b and g < 0.45 then return 0.62, 0.05, 0.05 end  -- красный
    if b >= r and b >= g then
        if r > 0.45 then return 0.4, 0.08, 0.55 end                    -- фиолетовый
        return 0.05, 0.22, 0.55                                         -- синий
    end
    return r * 0.5, g * 0.5, b * 0.5
end
function S:InkText(t)
    if type(t) ~= "string" or not t:find("|c", 1, true) then return t end
    return (t:gsub("|c(%x%x)(%x%x)(%x%x)(%x%x)", function(a, rr, gg, bb)
        local r, g, b = S:InkRGB(tonumber(rr, 16) / 255, tonumber(gg, 16) / 255, tonumber(bb, 16) / 255)
        return string.format("|c%s%02x%02x%02x", a, math.floor(r * 255 + 0.5), math.floor(g * 255 + 0.5), math.floor(b * 255 + 0.5))
    end))
end
-- цвет заливки/линий на пергаменте
function S:PaperFill(r, g, b, a)
    a = a or 1
    local lum, sat = lumsat(r, g, b)
    if lum < 0.25 and sat < 0.15 then return 0.42, 0.29, 0.15, math.min(0.28, a * 0.35) end -- тёмные плашки → бумажная тень
    if sat < 0.15 then return 0.36, 0.24, 0.12, math.max(a, 0.3) end                       -- линии, дорожки
    if r > 0.85 and g > 0.6 and b < 0.45 then return 0.5, 0.34, 0.1, a end -- золото → тёмное золото
    local ir, ig, ib = S:InkRGB(r, g, b)
    return ir, ig, ib, a
end
-- перекрасить надпись (один раз; дальше SetText/SetTextColor перекрашиваются сами)
function S:Ink(fs)
    if not fs or fs.qcInk == true or fs.qcNoInk == true then return end
    fs.qcInk = true
    local oSet, oCol = fs.SetText, fs.SetTextColor
    fs.SetText = function(self, t, ...) if S:IsPaper() then t = S:InkText(t) end return oSet(self, t, ...) end
    fs.SetTextColor = function(self, r, g, b, a) if S:IsPaper() then r, g, b = S:InkRGB(r, g, b) end return oCol(self, r, g, b, a) end
    if S:IsPaper() then
        -- на бумаге чернила без тени и обводки
        pcall(fs.SetShadowColor, fs, 0, 0, 0, 0)
        local ok, f, sz, fl = pcall(fs.GetFont, fs)
        if ok and f and type(fl) == "string" and fl:find("OUTLINE") then pcall(fs.SetFont, fs, f, sz, "") end
    end
    local r, g, b, a = fs:GetTextColor()
    if r then fs:SetTextColor(r, g, b, a) end
    local t = fs:GetText()
    if t and t ~= "" then fs:SetText(t) end
end
-- надпись в тёмной шапке: оставить светлой (вызывать до SetText)
function S:NoInk(fs)
    if not fs then return fs end
    fs.qcNoInk = true
    if fs.qcInk == true then
        fs.SetText = nil; fs.SetTextColor = nil
        fs.qcInk = false
        pcall(fs.SetShadowColor, fs, 0, 0, 0, 1)
    end
    return fs
end
-- пройти по окну и перекрасить все надписи (кроме надписей на красных кнопках игры)
function S:SkinTree(f, depth)
    if not S:IsPaper() or not f then return end
    depth = depth or 0
    if depth > 14 or f.qcNoInk == true then return end
    if f.GetRegions then
        for _, r in ipairs({ f:GetRegions() }) do
            if r.GetObjectType and r:GetObjectType() == "FontString" and r.qcInk ~= true then
                local skip = f.qcTemplate == true and f.GetFontString and f:GetFontString() == r
                if not skip then S:Ink(r) end
            end
        end
    end
    if f.GetChildren then
        for _, c in ipairs({ f:GetChildren() }) do S:SkinTree(c, depth + 1) end
    end
end
-- бумага: атлас нового окна заданий или старая текстура
local function paperTexture(t)
    local okA = false
    if t.SetAtlas and C_Texture and C_Texture.GetAtlasInfo then
        for _, name in ipairs({ "QuestBG-Parchment", "QuestDetailsBackgrounds", "Professions-Recipe-Background" }) do
            local ok, info = pcall(C_Texture.GetAtlasInfo, name)
            if ok and info then okA = pcall(t.SetAtlas, t, name) break end
        end
    end
    if not okA then
        t:SetTexture("Interface\\QuestFrame\\QuestBG")
        t:SetTexCoord(0, 0.586, 0, 0.66)
    end
end
S.PaperTexture = paperTexture
-- фон окна в стиле пергамента: своя отрисовка со скруглёнными углами
-- (тёмное дерево → бронзовая кайма → бумага с затемнёнными краями → тёмная шапка)
local function rawTex(f, layer, sub, r, g, b, a, file)
    local t = f:CreateTexture(nil, layer, nil, sub)
    t:SetTexture(file or WHITE)
    t:SetVertexColor(r, g, b, a or 1)
    return t
end
local function rawRounded(f, rad, c, sub, inset, parts)
    local C = S.media.circle
    local function p(file) local t = rawTex(f, "BACKGROUND", sub, c[1], c[2], c[3], c[4], file); parts[#parts + 1] = t; return t end
    local tl = p(C); tl:SetTexCoord(0, 0.5, 0, 0.5); tl:SetSize(rad, rad); tl:SetPoint("TOPLEFT", inset, -inset)
    local tr = p(C); tr:SetTexCoord(0.5, 1, 0, 0.5); tr:SetSize(rad, rad); tr:SetPoint("TOPRIGHT", -inset, -inset)
    local bl = p(C); bl:SetTexCoord(0, 0.5, 0.5, 1); bl:SetSize(rad, rad); bl:SetPoint("BOTTOMLEFT", inset, inset)
    local br = p(C); br:SetTexCoord(0.5, 1, 0.5, 1); br:SetSize(rad, rad); br:SetPoint("BOTTOMRIGHT", -inset, inset)
    local top = p(); top:SetPoint("TOPLEFT", tl, "TOPRIGHT"); top:SetPoint("BOTTOMRIGHT", tr, "BOTTOMLEFT")
    local bot = p(); bot:SetPoint("TOPLEFT", bl, "TOPRIGHT"); bot:SetPoint("BOTTOMRIGHT", br, "BOTTOMLEFT")
    local mid = p(); mid:SetPoint("TOPLEFT", f, "TOPLEFT", inset, -inset - rad); mid:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -inset, inset + rad)
end
function S:PaperWindow(f, header)
    if f.SetBackdrop then pcall(f.SetBackdrop, f, nil) end
    if type(f.qcParts) == "table" then
        for _, t in ipairs(f.qcParts) do t:Show() end
        return
    end
    local parts = {}
    f.qcParts = parts
    local R = 12
    rawRounded(f, R, { 0.16, 0.09, 0.04, 1 }, -8, 0, parts)          -- тёмное дерево
    rawRounded(f, R - 2, { 0.6, 0.44, 0.22, 1 }, -7, 3, parts)      -- бронзовая кайма
    rawRounded(f, R - 4, { 0.27, 0.16, 0.07, 1 }, -6, 4, parts)     -- тонкая тёмная линия
    rawRounded(f, R - 5, S.PAPER, -5, 6, parts)                      -- бумага
    -- текстура бумаги
    local t = f:CreateTexture(nil, "BACKGROUND", nil, -4)
    t:SetPoint("TOPLEFT", 8, -8); t:SetPoint("BOTTOMRIGHT", -8, 8)
    paperTexture(t)
    t:SetVertexColor(1, 0.95, 0.82, 0.45)
    parts[#parts + 1] = t
    -- затемнение к краям, как у окна задания
    local function edge(p1, p2, horiz, size, flip)
        local e = f:CreateTexture(nil, "BACKGROUND", nil, -3)
        e:SetColorTexture(1, 1, 1, 1)
        e:SetPoint(p1, f, p1, flip and (horiz and -6 or 0) or (horiz and 6 or 0), (not horiz) and (flip and -6 or 6) or 0)
        e:SetPoint(p2, f, p2, flip and (horiz and -6 or 0) or (horiz and 6 or 0), (not horiz) and (flip and -6 or 6) or 0)
        if horiz then e:SetWidth(size) else e:SetHeight(size) end
        local dark, clear = { 0.4, 0.24, 0.09, 0.45 }, { 0.4, 0.24, 0.09, 0 }
        local a, b = dark, clear
        if flip then a, b = clear, dark end
        local ok = false
        if e.SetGradient and CreateColor then
            ok = pcall(e.SetGradient, e, horiz and "HORIZONTAL" or "VERTICAL", CreateColor(a[1], a[2], a[3], a[4]), CreateColor(b[1], b[2], b[3], b[4]))
        end
        if not ok then e:SetColorTexture(0.36, 0.2, 0.07, 0.15) end
        parts[#parts + 1] = e
    end
    edge("TOPLEFT", "BOTTOMLEFT", true, 60, false)
    edge("TOPRIGHT", "BOTTOMRIGHT", true, 60, true)
    edge("BOTTOMLEFT", "BOTTOMRIGHT", false, 50, false)
    edge("TOPLEFT", "TOPRIGHT", false, 50, true)
    -- тёмная шапка с бронзовой линией
    if header and header > 0 then
        local h = f:CreateTexture(nil, "BACKGROUND", nil, -2)
        h:SetColorTexture(S.HEADER[1], S.HEADER[2], S.HEADER[3], 1)
        h:SetPoint("TOPLEFT", 6 + R - 5, -6); h:SetPoint("TOPRIGHT", -6 - (R - 5), -6); h:SetHeight(header - 6)
        parts[#parts + 1] = h
        local hl = f:CreateTexture(nil, "BACKGROUND", nil, -2)
        hl:SetColorTexture(S.HEADER[1], S.HEADER[2], S.HEADER[3], 1)
        hl:SetPoint("TOPLEFT", 6, -6 - (R - 5)); hl:SetPoint("BOTTOMRIGHT", h, "BOTTOMRIGHT", R - 5, 0)
        parts[#parts + 1] = hl
        -- скруглённые верхние углы шапки
        local C = S.media.circle
        local c1 = rawTex(f, "BACKGROUND", -2, S.HEADER[1], S.HEADER[2], S.HEADER[3], 1, C)
        c1:SetTexCoord(0, 0.5, 0, 0.5); c1:SetSize(R - 5, R - 5); c1:SetPoint("TOPLEFT", 6, -6)
        local c2 = rawTex(f, "BACKGROUND", -2, S.HEADER[1], S.HEADER[2], S.HEADER[3], 1, C)
        c2:SetTexCoord(0.5, 1, 0, 0.5); c2:SetSize(R - 5, R - 5); c2:SetPoint("TOPRIGHT", -6, -6)
        local hr = f:CreateTexture(nil, "BACKGROUND", nil, -2)
        hr:SetColorTexture(S.HEADER[1], S.HEADER[2], S.HEADER[3], 1)
        hr:SetPoint("TOPRIGHT", -6, -6 - (R - 5)); hr:SetPoint("BOTTOMLEFT", h, "BOTTOMRIGHT", 0, 0)
        parts[#parts + 1] = c1; parts[#parts + 1] = c2; parts[#parts + 1] = hr
        local ln = f:CreateTexture(nil, "BACKGROUND", nil, -1)
        ln:SetColorTexture(0.6, 0.44, 0.22, 1)
        ln:SetPoint("TOPLEFT", f, "TOPLEFT", 6, -header); ln:SetPoint("TOPRIGHT", f, "TOPRIGHT", -6, -header); ln:SetHeight(2)
        parts[#parts + 1] = ln
    end
end
-- показать/спрятать фон окна (меню, когда открыта правая часть)
function S:BackdropShown(f, show)
    if S:IsPaper() and S:Themed(f) then
        if type(f.qcParts) == "table" then
            for _, t in ipairs(f.qcParts) do if show then t:Show() else t:Hide() end end
        end
        return
    end
    if not f.SetBackdropColor then return end
    if show then f:SetBackdropColor(0, 0, 0, 0.92); f:SetBackdropBorderColor(0.62, 0.62, 0.62, 1)
    else f:SetBackdropColor(0, 0, 0, 0); f:SetBackdropBorderColor(0, 0, 0, 0) end
end

S.HL = "Interface\\QuestFrame\\UI-QuestLogTitleHighlight"
-- золотая полоса выделения (как выбранная строка в окнах игры)
function S:GoldBar(f, alpha, layer)
    local t = f:CreateTexture(nil, layer or "BACKGROUND")
    t:SetTexture(S.HL)
    if S:IsPaper() and S:Themed(f) then
        -- на бумаге — тёмно-коричневая подсветка
        t:SetBlendMode("BLEND")
        t:SetVertexColor(0.42, 0.27, 0.1, math.min(0.4, (alpha or 0.8) * 0.5))
        t:SetAllPoints()
        return t
    end
    t:SetBlendMode("ADD")
    t:SetVertexColor(1, 0.75, 0, alpha or 0.8)
    t:SetAllPoints()
    return t
end
S.hex = { accent = "ffd100", muted = "8a909a", text = "eceff3", gold = "ffd166", green = "66e07a" }

---------------------------------------------------------------------------
-- Шрифты: родной шрифт WoW (Friz Quadrata) и Morpheus для названия. Файлы *_CYR — с кириллицей.
---------------------------------------------------------------------------
-- Наборы шрифтов: «современный» (Inter, свой файл) и «игровой» (Friz Quadrata из WoW).
-- Название аддона всегда Morpheus.
local FONT_SETS = {
    game   = { body = "Fonts\\FRIZQT___CYR.TTF", bold = "Fonts\\FRIZQT___CYR.TTF", size = 0 },
}
local fontSpecs = {
    title = { "bold", 18, "", GameFontNormalLarge },
    head  = { "bold", 12, "", GameFontNormalSmall },
    label = { "body", 13, "", GameFontHighlight },
    body  = { "body", 15, "", GameFontHighlight },
    small = { "body", 13, "", GameFontHighlightSmall },
    seg   = { "bold", 13, "", GameFontHighlight },
    num   = { "bold", 14, "", GameFontHighlightLarge },
    badge = { "bold", 17, "OUTLINE", GameFontNormalLarge },
    arrow = { "bold", 12, "OUTLINE", GameFontNormal },
}

S.font = {}
for name in pairs(fontSpecs) do
    local f = CreateFont("QuestCompassFont_" .. name)
    f:SetShadowOffset(1, -1)
    f:SetShadowColor(0, 0, 0, 0.85)
    S.font[name] = f
end

-- Применить выбранный набор шрифтов (FG.db.font: "modern" / "game")
function S:ApplyFonts()
    local key = "game" -- всегда игровой шрифт
    local set = FONT_SETS[key] or FONT_SETS.modern
    for name, spec in pairs(fontSpecs) do
        local f = S.font[name]
        local path = set[spec[1]]
        local ok, res = pcall(f.SetFont, f, path, spec[2] + set.size, spec[3])
        if not ok or res == false or not f:GetFont() then
            -- запасной вариант: шрифт игры
            local ok2 = pcall(f.SetFont, f, "Fonts\\FRIZQT___CYR.TTF", spec[2], spec[3])
            if (not ok2 or not f:GetFont()) and spec[4] then f:CopyFontObject(spec[4]) end
        end
    end
end
S:ApplyFonts()
FG:OnInit(function() S:ApplyFonts() end)

function S:Text(parent, font, color, layer)
    local fs = parent:CreateFontString(nil, layer or "OVERLAY")
    fs:SetFontObject(S.font[font or "body"])
    local c = color or S.c.text
    if S:IsPaper() and S:Themed(parent) then S:Ink(fs) end
    fs:SetTextColor(c[1], c[2], c[3], c[4] or 1)
    fs:SetJustifyH("LEFT")
    fs:SetWordWrap(true)
    return fs
end

---------------------------------------------------------------------------
-- Простые текстуры
---------------------------------------------------------------------------
local function tex(parent, layer, c, sub, file)
    local t = parent:CreateTexture(nil, layer, nil, sub or 0)
    t:SetTexture(file or WHITE)
    local r, g, b, a = c[1], c[2], c[3], c[4] or 1
    if (not file or file == S.media.circle) and S:IsPaper() and S:Themed(parent) then
        r, g, b, a = S:PaperFill(r, g, b, a)
        t.qcPaperFill = true
        -- последующие перекраски тоже по бумаге
        local oV = t.SetVertexColor
        t.SetVertexColor = function(self, rr, gg, bb, aa) return oV(self, S:PaperFill(rr, gg, bb, aa)) end
        oV(t, r, g, b, a)
        return t
    end
    t:SetVertexColor(r, g, b, a)
    return t
end
S.Tex = tex

-- Скруглённый прямоугольник из 9 частей: 4 четверти круга по углам + 3 полосы.
-- inset — отступ от краёв фрейма (можно отрицательный — тень наружу).
function S:Rounded(f, r, c, layer, sub, inset)
    inset = inset or 0
    layer = layer or "BACKGROUND"
    local o = { parts = {} }
    local function part(file) local t = tex(f, layer, c, sub, file); table.insert(o.parts, t); return t end
    local tl = part(S.media.circle); tl:SetTexCoord(0, 0.5, 0, 0.5); tl:SetSize(r, r); tl:SetPoint("TOPLEFT", inset, -inset)
    local tr = part(S.media.circle); tr:SetTexCoord(0.5, 1, 0, 0.5); tr:SetSize(r, r); tr:SetPoint("TOPRIGHT", -inset, -inset)
    local bl = part(S.media.circle); bl:SetTexCoord(0, 0.5, 0.5, 1); bl:SetSize(r, r); bl:SetPoint("BOTTOMLEFT", inset, inset)
    local br = part(S.media.circle); br:SetTexCoord(0.5, 1, 0.5, 1); br:SetSize(r, r); br:SetPoint("BOTTOMRIGHT", -inset, inset)
    local top = part(); top:SetPoint("TOPLEFT", tl, "TOPRIGHT"); top:SetPoint("BOTTOMRIGHT", tr, "BOTTOMLEFT")
    local bot = part(); bot:SetPoint("TOPLEFT", bl, "TOPRIGHT"); bot:SetPoint("BOTTOMRIGHT", br, "BOTTOMLEFT")
    local mid = part(); mid:SetPoint("TOPLEFT", f, "TOPLEFT", inset, -inset - r); mid:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -inset, inset + r)
    function o:SetColor(cr, cg, cb, ca) for _, t in ipairs(self.parts) do t:SetVertexColor(cr, cg, cb, ca or 1) end end
    function o:Show() for _, t in ipairs(self.parts) do t:Show() end end
    function o:Hide() for _, t in ipairs(self.parts) do t:Hide() end end
    return o
end

-- Толщина рамки: не меньше одного физического пикселя экрана,
-- иначе при мелком масштабе интерфейса верхняя/нижняя линия пропадает
function S:Onepx()
    local px = 1
    if GetPhysicalScreenSize and UIParent and UIParent.GetEffectiveScale then
        local _, h = GetPhysicalScreenSize()
        local sc = UIParent:GetEffectiveScale() or 1
        if h and h > 0 and sc > 0 then px = 768 / h / sc end
    end
    return math.max(1, px * 1.05)
end

-- «Таблетка»: два полукруга по бокам и прямоугольник между ними.
-- Без горизонтальных стыков, поэтому нет полосы посередине при любом масштабе.
function S:Capsule(f, r, c, layer, sub, inset)
    inset = inset or 0
    layer = layer or "BACKGROUND"
    local o = { parts = {} }
    local function part(file) local t = tex(f, layer, c, sub, file); table.insert(o.parts, t); return t end
    local l = part(S.media.circle); l:SetTexCoord(0, 0.5, 0, 1)
    l:SetPoint("TOPLEFT", inset, -inset); l:SetPoint("BOTTOMLEFT", inset, inset); l:SetWidth(r)
    local rr = part(S.media.circle); rr:SetTexCoord(0.5, 1, 0, 1)
    rr:SetPoint("TOPRIGHT", -inset, -inset); rr:SetPoint("BOTTOMRIGHT", -inset, inset); rr:SetWidth(r)
    local m = part(); m:SetPoint("TOPLEFT", l, "TOPRIGHT"); m:SetPoint("BOTTOMRIGHT", rr, "BOTTOMLEFT")
    function o:SetColor(cr, cg, cb, ca) for _, t in ipairs(self.parts) do t:SetVertexColor(cr, cg, cb, ca or 1) end end
    function o:Show() for _, t in ipairs(self.parts) do t:Show() end end
    function o:Hide() for _, t in ipairs(self.parts) do t:Hide() end end
    function o:SetAlpha(a) for _, t in ipairs(self.parts) do t:SetAlpha(a) end end
    return o
end

-- «Таблетка» с рамкой
function S:PillBox(f, h, fill, border, layer)
    local w = S:Onepx()
    local b = S:Capsule(f, h / 2, border or S.c.border, layer or "BACKGROUND", 1, 0)
    local i = S:Capsule(f, h / 2 - w, fill or S.c.bg2, layer or "BACKGROUND", 2, w)
    return { border = b, fill = i }
end

-- Скруглённая плашка с рамкой в 1 пиксель: { border, fill }
function S:Box(f, r, fill, border, layer)
    local w = S:Onepx()
    local b = S:Rounded(f, r, border or S.c.border, layer or "BACKGROUND", 1, 0)
    local i = S:Rounded(f, r - w, fill or S.c.bg2, layer or "BACKGROUND", 2, w)
    f.qpBox = { border = b, fill = i }
    return f.qpBox
end

-- Совместимость: прямоугольная рамка (используется в мелких местах)
function S:Border(f, c, layer)
    c = c or S.c.border
    local e = {}
    e.t = tex(f, layer or "BORDER", c); e.t:SetPoint("TOPLEFT"); e.t:SetPoint("TOPRIGHT"); e.t:SetHeight(1)
    e.b = tex(f, layer or "BORDER", c); e.b:SetPoint("BOTTOMLEFT"); e.b:SetPoint("BOTTOMRIGHT"); e.b:SetHeight(1)
    e.l = tex(f, layer or "BORDER", c); e.l:SetPoint("TOPLEFT"); e.l:SetPoint("BOTTOMLEFT"); e.l:SetWidth(1)
    e.r = tex(f, layer or "BORDER", c); e.r:SetPoint("TOPRIGHT"); e.r:SetPoint("BOTTOMRIGHT"); e.r:SetWidth(1)
    function e:SetColor(r, g, b, a) for _, k in ipairs({ "t", "b", "l", "r" }) do self[k]:SetVertexColor(r, g, b, a or 1) end end
    f.qpBorder = e
    return e
end

-- Окно: тень, скруглённый фон с рамкой, бирюзовое свечение у шапки, плавное появление
function S:Window(f, opts)
    S:Backdrop(f, 0.92, nil, "window", opts and opts.header)
    if f.CreateAnimationGroup then pcall(function()
        local ag = f:CreateAnimationGroup()
        local a = ag:CreateAnimation("Alpha")
        a:SetFromAlpha(0); a:SetToAlpha(1); a:SetDuration(0.12)
        f:HookScript("OnShow", function() ag:Stop(); ag:Play() end)
    end) end
    return f
end

function S:Divider(parent, x1, y, x2)
    local d = tex(parent, "ARTWORK", S.c.border)
    d:SetPoint("TOPLEFT", x1, y); d:SetPoint("TOPRIGHT", x2 or -x1, y); d:SetHeight(1)
    return d
end

-- Заголовок раздела: бирюзовая точка + МЕЛКИЙ ТЕКСТ + линия до правого края
function S:Section(parent, key, x, y, rightPad)
    local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    fs:SetPoint("TOPLEFT", x, y + 1)
    FG:Localize(fs, key)
    local line = tex(parent, "ARTWORK", { 0.45, 0.45, 0.45, 0.9 })
    line:SetPoint("LEFT", fs, "RIGHT", 8, 0)
    line:SetPoint("RIGHT", parent, "RIGHT", -(rightPad or x), 0)
    line:SetHeight(1)
    return fs
end

---------------------------------------------------------------------------
-- Подсказка при наведении
---------------------------------------------------------------------------
function S:Tip(f, titleKey, tipKey)
    f:HookScript("OnEnter", function(self)
        if not tipKey then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        if titleKey then GameTooltip:AddLine(FG.L(titleKey), S.c.accent[1], S.c.accent[2], S.c.accent[3]) end
        GameTooltip:AddLine(FG.L(tipKey), 1, 1, 1, true)
        GameTooltip:Show()
    end)
    f:HookScript("OnLeave", function() GameTooltip:Hide() end)
end

local function sound(on)
    if not PlaySound then return end
    local id = SOUNDKIT and (on == false and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF or SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON) or 856
    pcall(PlaySound, id)
end

---------------------------------------------------------------------------
-- Кнопка со скруглёнными углами
---------------------------------------------------------------------------
function S:Button(parent, key, w, h, onClick, opts)
    opts = opts or {}
    local ok, b = pcall(CreateFrame, "Button", nil, parent, "UIPanelButtonTemplate")
    if not ok or not b then b = CreateFrame("Button", nil, parent) else b.qcTemplate = true end
    b:SetSize(w, h or 22)
    if b.SetText then b:SetText(" ") end
    local fsr = b.GetFontString and b:GetFontString()
    if type(fsr) ~= "table" or not fsr.SetText then
        fsr = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        fsr:SetPoint("CENTER")
        S:Backdrop(b, 0.8)
    end
    b.label = fsr
    b.label:SetWordWrap(false)
    if key then
        if opts.raw then b.label:SetText(key) else FG:Localize(b.label, key) end
    end
    b:SetScript("OnClick", function(self, ...) sound(true); if onClick then onClick(self, ...) end end)
    if opts.tip then S:Tip(b, opts.tipTitle, opts.tip) end
    return b
end

-- Круглая кнопка-крестик
function S:Close(parent, onClick)
    local ok, b = pcall(CreateFrame, "Button", nil, parent, "UIPanelCloseButton")
    if not ok or not b then b = CreateFrame("Button", nil, parent) end
    b:SetSize(26, 26)
    b:SetScript("OnClick", onClick)
    return b
end

---------------------------------------------------------------------------
-- Переключатель-«таблетка» с круглым бегунком и подписью
---------------------------------------------------------------------------
function S:Toggle(parent, key, tipKey, get, set, width)
    local row = CreateFrame("Button", nil, parent)
    row:SetSize(width, 26)
    local ok, cb = pcall(CreateFrame, "CheckButton", nil, row, "UICheckButtonTemplate")
    if not ok or not cb then cb = CreateFrame("CheckButton", nil, row) end
    cb:SetSize(24, 24)
    cb:SetPoint("LEFT", 2, 0)
    row.check = cb
    row.label = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.label:SetPoint("LEFT", cb, "RIGHT", 4, 1)
    row.label:SetPoint("RIGHT", -6, 0)
    row.label:SetJustifyH("LEFT")
    row.label:SetWordWrap(false)
    FG:Localize(row.label, key)
    function row:Refresh()
        local on = get() and true or false
        if cb.SetChecked then cb:SetChecked(on) end
        if on then self.label:SetTextColor(1, 1, 1) else self.label:SetTextColor(0.62, 0.62, 0.62) end
    end
    local function flip()
        set(not get())
        sound(get())
        row:Refresh()
    end
    cb:SetScript("OnClick", flip)
    row:SetScript("OnClick", flip)
    row:SetScript("OnEnter", function(self) self.label:SetTextColor(1, 0.82, 0) end)
    row:SetScript("OnLeave", function(self) self:Refresh() end)
    if tipKey then S:Tip(row, key, tipKey); S:Tip(cb, key, tipKey) end
    row:Refresh()
    return row
end

---------------------------------------------------------------------------
-- Сегменты: несколько вариантов, выбранный — бирюзовая «таблетка»
---------------------------------------------------------------------------
function S:Segmented(parent, items, width, height, get, set, opts)
    opts = opts or {}
    height = height or 24
    local g = CreateFrame("Frame", nil, parent)
    g:SetSize(width, height)
    S:Backdrop(g, 0.85)
    local pad = 4
    local n = #items
    local segW = (width - pad * 2) / n
    local ih = height - pad * 2

    -- выбранный вариант — золотая «плашка», которая плавно переезжает к новому выбору
    local plate = CreateFrame("Frame", nil, g)
    plate:SetSize(segW, ih)
    plate.glow = S:GoldBar(plate, 0.7)
    local edge = { 1, 0.82, 0, 0.9 }
    local function line(p1, p2, horiz)
        local t = plate:CreateTexture(nil, "ARTWORK")
        t:SetTexture("Interface\\Buttons\\WHITE8x8")
        t:SetVertexColor(edge[1], edge[2], edge[3], edge[4])
        t:SetPoint(p1); t:SetPoint(p2)
        if horiz then t:SetHeight(1) else t:SetWidth(1) end
    end
    line("TOPLEFT", "TOPRIGHT", true); line("BOTTOMLEFT", "BOTTOMRIGHT", true)
    line("TOPLEFT", "BOTTOMLEFT", false); line("TOPRIGHT", "BOTTOMRIGHT", false)
    plate.x, plate.tx = nil, 0
    plate:SetScript("OnUpdate", function(p, dt)
        if not p.x then p.x = p.tx end
        local d = p.tx - p.x
        if math.abs(d) < 0.5 then p.x = p.tx else p.x = p.x + d * math.min(1, dt * 14) end
        p:ClearAllPoints()
        p:SetPoint("TOPLEFT", g, "TOPLEFT", pad + p.x, -pad)
    end)

    g.buttons = {}
    for i, it in ipairs(items) do
        local b = CreateFrame("Button", nil, g)
        b:SetSize(segW, ih)
        b:SetPoint("TOPLEFT", pad + (i - 1) * segW, -pad)
        b:SetFrameLevel(plate:GetFrameLevel() + 2)
        b.hover = S:GoldBar(b, 0.18)
        b.hover:Hide()
        b.label = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        b.label:SetJustifyH("CENTER")
        b.label:SetWordWrap(false)
        b.ficon = false
        if opts.icons and opts.icons[i] then
            local ic = opts.icons[i]
            b.ficon = b:CreateTexture(nil, "OVERLAY")
            b.ficon:SetTexture(ic[1])
            if ic[2] then b.ficon:SetTexCoord(unpack(ic[2])) end
            b.ficon:SetSize(ih - 2, ih - 2)
            b.label:SetPoint("CENTER", (ih - 2) / 2 + 2, 0)
            b.ficon:SetPoint("RIGHT", b.label, "LEFT", -3, 0)
        else
            b.label:SetPoint("CENTER", 0, 0)
        end
        if opts.raw then b.label:SetText(it[2]) else FG:Localize(b.label, it[2]) end
        b:SetScript("OnEnter", function(self)
            if not self.selected then self.hover:Show(); self.label:SetTextColor(1, 0.9, 0.5) end
        end)
        b:SetScript("OnLeave", function(self)
            self.hover:Hide()
            if not self.selected then self.label:SetTextColor(0.62, 0.62, 0.62) end
        end)
        b:SetScript("OnClick", function()
            sound(true)
            set(it[1]); g:Refresh()
        end)
        b.value = it[1]
        b.index = i
        g.buttons[i] = b
    end
    function g:Refresh()
        local v = get()
        for _, b in ipairs(self.buttons) do
            b.selected = (b.value == v)
            b.hover:Hide()
            if b.selected then
                plate.tx = (b.index - 1) * segW
                b.label:SetTextColor(1, 1, 1)
                if b.ficon then b.ficon:SetDesaturated(false); b.ficon:SetAlpha(1) end
            else
                b.label:SetTextColor(0.62, 0.62, 0.62)
                if b.ficon then b.ficon:SetDesaturated(true); b.ficon:SetAlpha(0.6) end
            end
        end
    end
    if opts.tip then for _, sb in ipairs(g.buttons) do S:Tip(sb, nil, opts.tip) end end
    g:Refresh()
    return g
end

---------------------------------------------------------------------------
-- Числовое поле: ( - ) [ 20 ] ( + ), колёсико мыши тоже работает
---------------------------------------------------------------------------
function S:Stepper(parent, get, set)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(96, 24)
    local minus = S:Button(f, "-", 24, 22, function() set(get() - 1); f:Refresh() end, { raw = true })
    minus:SetPoint("LEFT")
    local box = CreateFrame("Frame", nil, f)
    box:SetSize(40, 24)
    box:SetPoint("LEFT", minus, "RIGHT", 2, 0)
    S:Backdrop(box, 0.9)
    f.value = box:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    f.value:SetPoint("CENTER", 0, 0)
    f.value:SetJustifyH("CENTER")
    local plus = S:Button(f, "+", 24, 22, function() set(get() + 1); f:Refresh() end, { raw = true })
    plus:SetPoint("LEFT", box, "RIGHT", 2, 0)
    f:EnableMouseWheel(true)
    f:SetScript("OnMouseWheel", function(_, delta) set(get() + delta); f:Refresh() end)
    function f:Refresh() self.value:SetText(get()) end
    f:Refresh()
    return f
end

---------------------------------------------------------------------------
-- Круглый значок типа задания: «!» взять, «?» сдать, прицел — выполнить
---------------------------------------------------------------------------
function S:Badge(parent, size)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(size, size)
    f.icon = f:CreateTexture(nil, "ARTWORK")
    f.icon:SetAllPoints()
    -- значки как в игре: «!» взять, «?» сдать, следы — выполнить, ключ — подземелье
    local kinds = {
        a = { "Interface\\GossipFrame\\AvailableQuestIcon", nil },
        t = { "Interface\\GossipFrame\\ActiveQuestIcon", nil },
        d = { "Interface\\Icons\\Ability_Hunter_Pathfinding", { 0.08, 0.92, 0.08, 0.92 } },
        e = { "Interface\\Icons\\INV_Misc_Key_03", { 0.08, 0.92, 0.08, 0.92 } },
        n = { "Interface\\Icons\\INV_Misc_QuestionMark", { 0.08, 0.92, 0.08, 0.92 } },
    }
    function f:SetKind(k)
        local d = kinds[k] or kinds.n
        self.icon:SetTexture(d[1])
        if d[2] then self.icon:SetTexCoord(unpack(d[2])) else self.icon:SetTexCoord(0, 1, 0, 1) end
    end
    f:SetKind("n")
    return f
end

-- Маленькая скруглённая «таблетка» с текстом (например, расстояние)
function S:Pill(parent)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(50, 18)
    f.text = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    f.text:SetPoint("RIGHT", 0, 0)
    f.text:SetJustifyH("RIGHT")
    f.text:SetWordWrap(false)
    function f:SetValue(t, color)
        if not t or t == "" then self:Hide() return end
        self.text:SetText(t)
        local c = color or S.c.gold
        self.text:SetTextColor(c[1], c[2], c[3])
        self:SetWidth(math.max(30, (self.text:GetStringWidth() or 0) + 4))
        self:Show()
    end
    return f
end

---------------------------------------------------------------------------
-- Полоса прокрутки: тонкая дорожка и золотой ползунок (можно тянуть мышью)
-- onScroll(offset) вызывается при перетаскивании; sb:Update(offset, total, visible)
---------------------------------------------------------------------------
function S:ScrollBar(parent, onScroll)
    local sb = CreateFrame("Frame", nil, parent)
    sb:SetWidth(8)
    sb.track = sb:CreateTexture(nil, "ARTWORK")
    sb.track:SetPoint("TOP"); sb.track:SetPoint("BOTTOM"); sb.track:SetWidth(3)
    sb.track:SetColorTexture(1, 1, 1, 0.08)
    sb.thumb = CreateFrame("Button", nil, sb)
    sb.thumb:SetWidth(8)
    sb.thumb.tex = sb.thumb:CreateTexture(nil, "OVERLAY")
    sb.thumb.tex:SetPoint("TOP"); sb.thumb.tex:SetPoint("BOTTOM"); sb.thumb.tex:SetWidth(4)
    sb.thumb.tex:SetColorTexture(1, 0.82, 0, 0.75)
    sb.thumb:SetScript("OnEnter", function(t) t.tex:SetColorTexture(1, 0.9, 0.3, 1) end)
    sb.thumb:SetScript("OnLeave", function(t) t.tex:SetColorTexture(1, 0.82, 0, 0.75) end)
    sb.offset, sb.total, sb.vis = 0, 0, 1
    sb.thumb:SetScript("OnMouseDown", function(t)
        local _, cy = GetCursorPosition()
        t.dragY, t.dragOff = cy / (sb:GetEffectiveScale() or 1), sb.offset
    end)
    sb.thumb:SetScript("OnMouseUp", function(t) t.dragY = nil end)
    sb.thumb:SetScript("OnUpdate", function(t)
        if not t.dragY then return end
        if IsMouseButtonDown and not IsMouseButtonDown("LeftButton") then t.dragY = nil return end
        local _, cy = GetCursorPosition()
        cy = cy / (sb:GetEffectiveScale() or 1)
        local h = sb:GetHeight() or 1
        local maxOff = math.max(0, sb.total - sb.vis)
        if maxOff <= 0 then return end
        local per = h / sb.total -- пикселей на строку
        local off = math.floor(t.dragOff + (t.dragY - cy) / per + 0.5)
        off = math.max(0, math.min(maxOff, off))
        if off ~= sb.offset and onScroll then onScroll(off) end
    end)
    function sb:Update(offset, total, vis)
        self.offset, self.total, self.vis = offset or 0, total or 0, vis or 1
        if self.total <= self.vis then self:Hide() return end
        self:Show()
        local h = self:GetHeight() or 100
        local th = math.max(20, h * self.vis / self.total)
        local maxOff = self.total - self.vis
        local y = (h - th) * (self.offset / maxOff)
        self.thumb:SetHeight(th)
        self.thumb:ClearAllPoints(); self.thumb:SetPoint("TOP", self, "TOP", 0, -y)
    end
    sb:Hide()
    return sb
end
