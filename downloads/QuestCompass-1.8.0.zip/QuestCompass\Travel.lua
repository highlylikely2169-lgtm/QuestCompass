-- Quest Compass: маршрут с поворотами (как система путешествий Zygor).
-- Игра не даёт аддонам данных о стенах и рельефе, поэтому маршрут строится по графу
-- известных точек: распорядители полётов, которых знает персонаж, и пути, записанные
-- игроком (вход в пещеру, подъём на гору, дорога в город). Из этих точек выбирается
-- самый быстрый путь (алгоритм Дейкстры), а стрелка ведёт к следующей точке пути.
local _, ns = ...
local FG = ns.FG
local T = {}
FG.Travel = T

local FLY_SPEED = 30      -- ярдов в секунду на грифоне/ветрокрыле
local FLY_CURVE = 1.25    -- маршруты полётов не прямые
local FM_OVERHEAD = 25    -- секунд: поговорить, взлететь, приземлиться
local PATH_BONUS = 0.85   -- записанный путь чуть «дешевле» — он проверен ногами
local GUARD_YARDS = 60    -- цель рядом с концом записанного пути: подходим только по нему
local REC_STEP = 14       -- шаг записи пути, ярдов
local REACHED = 12        -- точка пути считается пройденной ближе этого

---------------------------------------------------------------------------
-- Мировые координаты (ярды, общие для континента)
---------------------------------------------------------------------------
local worldCache = {}
function T.World(m, x, y, live)
    if not (m and x and y and C_Map and C_Map.GetWorldPosFromMapPos and CreateVector2D) then return end
    local key = m .. ":" .. math.floor(x * 10000) .. ":" .. math.floor(y * 10000)
    local c = not live and worldCache[key]
    if c then return c[1], c[2], c[3] end
    local ok, cont, vec = pcall(C_Map.GetWorldPosFromMapPos, m, CreateVector2D(x, y))
    if not ok or not cont or not vec then return end
    local wx, wy
    if vec.GetXY then wx, wy = vec:GetXY() else wx, wy = vec.x, vec.y end
    if not wx then return end
    if not live then worldCache[key] = { cont, wx, wy } end -- позицию игрока не кэшируем
    return cont, wx, wy
end
local World = T.World

local function dist(a, b)
    local dx, dy = a.wx - b.wx, a.wy - b.wy
    return math.sqrt(dx * dx + dy * dy)
end

local function runSpeed()
    if IsMounted and IsMounted() then return 10.5 end
    local lvl = UnitLevel("player") or 1
    return (lvl >= 40) and 10.5 or 7
end

---------------------------------------------------------------------------
-- Корабли и дирижабли между континентами (и до Тельдрассила).
-- Пристань: { uiMapID, x, y (проценты) }. fac: кто может пользоваться спокойно.
-- uiMapID: 1437 Болотина, 1439 Тёмные берега, 1445 Пылевые топи, 1434 Тернистая долина,
-- 1413 Степи, 1420 Тирисфальские леса, 1411 Дуротар, 1438 Тельдрассил
---------------------------------------------------------------------------
local BOAT_TIME = 150 -- секунд: ожидание + плавание/полёт
T.Transports = {
    { kind = "boat", fac = "Alliance", a = { 1437, 4.6, 57.2 }, b = { 1439, 32.4, 43.8 },
      ru = { "Пристань Гавани Менетил", "Пристань Аубердина" }, en = { "Menethil Harbor dock", "Auberdine dock" } },
    { kind = "boat", fac = "Alliance", a = { 1437, 5.0, 63.5 }, b = { 1445, 71.6, 56.4 },
      ru = { "Пристань Гавани Менетил", "Пристань Терамора" }, en = { "Menethil Harbor dock", "Theramore dock" } },
    { kind = "boat", fac = "Alliance", a = { 1439, 33.2, 40.2 }, b = { 1438, 55.0, 93.7 }, time = 90,
      ru = { "Пристань Аубердина", "Гавань Рут'теран" }, en = { "Auberdine dock", "Rut'theran Village" } },
    { kind = "boat", fac = nil, a = { 1434, 25.9, 73.1 }, b = { 1413, 63.7, 38.6 },
      ru = { "Пристань Пиратской Бухты", "Пристань Кабестана" }, en = { "Booty Bay dock", "Ratchet dock" } },
    { kind = "zep", fac = "Horde", a = { 1420, 60.7, 58.8 }, b = { 1411, 50.8, 13.8 },
      ru = { "Башня дирижаблей (Подгород)", "Башня дирижаблей (Оргриммар)" }, en = { "Zeppelin tower (Undercity)", "Zeppelin tower (Orgrimmar)" } },
    { kind = "zep", fac = "Horde", a = { 1411, 50.6, 12.6 }, b = { 1434, 31.6, 29.1 },
      ru = { "Башня дирижаблей (Оргриммар)", "Башня дирижаблей (Гром'гол)" }, en = { "Zeppelin tower (Orgrimmar)", "Zeppelin tower (Grom'gol)" } },
    { kind = "zep", fac = "Horde", a = { 1420, 61.9, 59.1 }, b = { 1434, 31.6, 30.4 },
      ru = { "Башня дирижаблей (Подгород)", "Башня дирижаблей (Гром'гол)" }, en = { "Zeppelin tower (Undercity)", "Zeppelin tower (Grom'gol)" } },
}

---------------------------------------------------------------------------
-- Распорядители полётов, известные персонажу
-- FG.cdb.taxi[cont][name] = { m, x, y, wx, wy, exact }
---------------------------------------------------------------------------
local function taxiStore(cont)
    FG.cdb.taxi = FG.cdb.taxi or {}
    FG.cdb.taxi[cont] = FG.cdb.taxi[cont] or {}
    return FG.cdb.taxi[cont]
end

local function addTaxi(name, m, x, y, exact)
    if not name or not m or not x then return end
    local cont, wx, wy = World(m, x, y)
    if not cont then return end
    local st = taxiStore(cont)
    local old = st[name]
    if old and old.exact and not exact then return end -- точная позиция (стояли рядом) важнее
    st[name] = { m = m, x = x, y = y, wx = wx, wy = wy, exact = exact or nil }
end

local function scanTaxiMap()
    local mapID = GetTaxiMapID and GetTaxiMapID()
    -- современный способ: все точки с их положением на карте континента
    if mapID and C_TaxiMap and C_TaxiMap.GetAllTaxiNodes then
        local ok, nodes = pcall(C_TaxiMap.GetAllTaxiNodes, mapID)
        if ok and type(nodes) == "table" then
            for _, n in ipairs(nodes) do
                local st = n.state
                local known = (st == 0 or st == 1) or (Enum and Enum.FlightPathState and (st == Enum.FlightPathState.Current or st == Enum.FlightPathState.Reachable))
                if known and n.position and n.name then
                    local px, py = n.position.x, n.position.y
                    if n.position.GetXY then px, py = n.position:GetXY() end
                    addTaxi(n.name, mapID, px, py, false)
                end
            end
        end
    end
    -- классический способ
    if NumTaxiNodes and TaxiNodeName then
        local pm, ppx, ppy = FG:GetPlayerPos()
        local cm = T.ContinentMap and T.ContinentMap() or mapID
        local flip = true
        if T.TaxiFlip then flip = T.TaxiFlip(cm) end
        for i = 1, NumTaxiNodes() or 0 do
            local name = TaxiNodeName(i)
            local kind = TaxiNodeGetType and TaxiNodeGetType(i)
            if kind == "CURRENT" and pm and ppx then
                addTaxi(name, pm, ppx, ppy, true) -- стоим рядом с этим распорядителем
            elseif kind == "REACHABLE" and cm and TaxiNodePosition then
                local x, y = TaxiNodePosition(i)
                -- у карты полётов y может отсчитываться снизу (проверяем по текущему пункту)
                if x and y then addTaxi(name, cm, x, flip and (1 - y) or y, false) end
            end
        end
    end
    T.dirty = true
end
---------------------------------------------------------------------------
-- Карта полётов: подсветка, куда лететь, и метка цели
---------------------------------------------------------------------------

-- Континент, на котором стоит игрок (карта полётов — это карта континента)
local function continentMap()
    local m = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
    local guard = 0
    while m and guard < 10 do
        local info = C_Map.GetMapInfo(m)
        if not info then break end
        if info.mapType == 2 or (Enum and Enum.UIMapType and info.mapType == Enum.UIMapType.Continent) then return m end
        m = info.parentMapID
        guard = guard + 1
    end
    local t = GetTaxiMapID and GetTaxiMapID()
    if t and t > 0 then return t end
end

-- Как координаты карты полётов соотносятся с картой континента:
-- сверяем «текущий» пункт с положением игрока (ось y у карты полётов бывает снизу)
local function taxiFlip(cm)
    local pm, px, py = FG:GetPlayerPos()
    if not (pm and px and cm and NumTaxiNodes) then return true end
    local ax, ay = FG:ConvertPos(pm, px, py, cm)
    if not ax then return true end
    for i = 1, NumTaxiNodes() do
        if TaxiNodeGetType and TaxiNodeGetType(i) == "CURRENT" then
            local x, y = TaxiNodePosition(i)
            if x and y then return math.abs(y - (1 - ay)) < math.abs(y - ay) end
        end
    end
    return true
end
T.TaxiFlip = taxiFlip
T.ContinentMap = continentMap

-- Куда лететь: точка на этом континенте, к которой надо попасть
-- (сама цель или пристань корабля, если цель на другом материке)
local function localTarget(s)
    local list = T:Get(s)
    local pm, px, py = FG:GetPlayerPos()
    local c0 = pm and px and World(pm, px, py, true)
    if list and c0 then
        local last
        for _, p in ipairs(list) do
            if p.cont == c0 and p.kind ~= "fm" then last = p end
            if p.cont and p.cont ~= c0 then break end
        end
        if last then return last end
    end
    return s
end

-- Кнопка пункта на карте полётов (по имени TaxiButtonN или поиском среди кнопок окна)
local function taxiButton(i)
    local b = _G["TaxiButton" .. i]
    if b then return b end
    local function scan(f, depth)
        if not f or depth > 4 or not f.GetChildren then return end
        for _, c in ipairs({ f:GetChildren() }) do
            if c.GetObjectType and c:GetObjectType() == "Button" and ((c.GetID and c:GetID() == i) or c.index == i or c.taxiNodeIndex == i) then return c end
            local r = scan(c, depth + 1)
            if r then return r end
        end
    end
    return scan(_G.TaxiFrame, 0) or scan(_G.TaxiRouteMap, 0)
end

local litButton, litTex, litW, litH -- подсвеченная кнопка и её прежний вид
local function unlight()
    local b = litButton
    if not b then return end
    litButton = nil
    if b.UnlockHighlight then b:UnlockHighlight() end
    if litTex and b.SetNormalTexture then b:SetNormalTexture(litTex) end
    if litW then b:SetSize(litW, litH) end
    litTex, litW, litH = nil, nil, nil
end

local function light(b)
    unlight()
    litButton = b
    if b.LockHighlight then b:LockHighlight() end
    -- золотой значок и чуть крупнее — как при наведении мыши
    local nt = b.GetNormalTexture and b:GetNormalTexture()
    local tex = nt and nt.GetTexture and nt:GetTexture()
    litTex = (type(tex) == "string" or type(tex) == "number") and tex or nil
    local w, h = b:GetSize()
    if type(w) == "number" and type(h) == "number" and w > 0 then
        litW, litH = w, h
        b:SetSize(w * 1.35, h * 1.35)
    end
    if b.SetNormalTexture then b:SetNormalTexture("Interface\\TaxiFrame\\UI-Taxi-Icon-Yellow") end
end
T.TaxiButton = taxiButton

local function showTaxiHints()
    unlight()
    local s = FG.Advisor and FG.Advisor.step
    if not NumTaxiNodes then return end
    if not s or not s.m then FG:Print(FG.L("taxi_dbg", "no step")) return end
    T.dirty = true
    local tgt = localTarget(s)
    local cm = continentMap()
    local tx, ty = FG:ConvertPos(tgt.m, tgt.x, tgt.y, cm)
    if not tx then FG:Print(FG.L("taxi_dbg", "map " .. tostring(tgt.m) .. "->" .. tostring(cm))) return end
    if taxiFlip(cm) then ty = 1 - ty end
    -- ближайший к цели пункт, куда можно долететь
    local best, bestD, bestI, curD
    for i = 1, NumTaxiNodes() do
        local kind = TaxiNodeGetType and TaxiNodeGetType(i)
        if kind == "REACHABLE" or kind == "CURRENT" then
            local x, y = TaxiNodePosition(i)
            if x and y then
                local d = (x - tx) ^ 2 + (y - ty) ^ 2
                if kind == "CURRENT" then curD = d end
                if not bestD or d < bestD then best, bestD, bestI = kind, d, i end
            end
        end
    end
    -- нужный пункт «горит», как при наведении мыши
    if not bestI then FG:Print(FG.L("taxi_dbg", "nodes " .. tostring(NumTaxiNodes()))) end
    if bestI and best ~= "CURRENT" then
        local btn = taxiButton(bestI)
        if btn then light(btn) else FG:Print(FG.L("taxi_dbg", "no button " .. bestI)) end
        FG:Print(FG.L("taxi_fly_to", TaxiNodeName(bestI) or "?"))
    elseif best == "CURRENT" then
        FG:Print(FG.L("taxi_walk"))
    end
end

-- запуск: по событию игры и (на всякий случай) при показе окна полётов
local lastRun = 0
local function onTaxiOpen()
    local now = GetTime and GetTime() or 0
    if now - lastRun < 0.5 then return end
    lastRun = now
    pcall(scanTaxiMap)
    -- кнопки распорядителей игра расставляет в этот же момент — подсвечиваем чуть позже
    local function run()
        local ok, err = pcall(showTaxiHints)
        if not ok then FG:Print(FG.L("taxi_dbg", tostring(err))) end
    end
    if C_Timer and C_Timer.After then C_Timer.After(0.15, run) else run() end
end
T.OnTaxiOpen = function() lastRun = 0; onTaxiOpen() end
FG:On("TAXIMAP_OPENED", onTaxiOpen)
FG:OnInit(function()
    if _G.TaxiFrame and _G.TaxiFrame.HookScript then _G.TaxiFrame:HookScript("OnShow", onTaxiOpen) end
    if _G.FlightMapFrame and _G.FlightMapFrame.HookScript then _G.FlightMapFrame:HookScript("OnShow", onTaxiOpen) end
end)

FG:On("TAXIMAP_CLOSED", function() pcall(unlight) end)

---------------------------------------------------------------------------
-- Запись пути игроком. FG.db.paths = { { cont, pts = { {m,x,y,wx,wy}, ... } } }
---------------------------------------------------------------------------
local rec -- текущая запись
function T:IsRecording() return rec ~= nil end
function T:RecordCount() return rec and #rec.pts or 0 end
function T:PathCount() return #(FG.db.paths or {}) end

local function recordTick()
    if not rec then return end
    local pm, px, py = FG:GetPlayerPos()
    if not px then return end
    local cont, wx, wy = World(pm, px, py, true)
    if not cont then return end
    if rec.cont and rec.cont ~= cont then return end
    rec.cont = cont
    local last = rec.pts[#rec.pts]
    local p = { m = pm, x = px, y = py, wx = wx, wy = wy }
    if not last or dist(last, p) >= REC_STEP then
        rec.pts[#rec.pts + 1] = p
        if FG.UI and FG.UI.Update then FG.UI:Update() end
    end
end

T.RecordTick = function() return recordTick() end
function T:StartRecording()
    rec = { pts = {} }
    recordTick()
    FG:Print(FG.L("rec_started"))
    if FG.Menu and FG.Menu.Sync then FG.Menu:Sync() end
end

function T:StopRecording()
    if not rec then return end
    recordTick()
    if #rec.pts >= 2 then
        FG.db.paths = FG.db.paths or {}
        table.insert(FG.db.paths, { cont = rec.cont, pts = rec.pts })
        FG:Print(FG.L("rec_saved", #rec.pts))
    else
        FG:Print(FG.L("rec_empty"))
    end
    rec = nil
    T.dirty = true
    if FG.Menu and FG.Menu.Sync then FG.Menu:Sync() end
    FG:Refresh(true)
end

function T:ToggleRecording()
    if rec then self:StopRecording() else self:StartRecording() end
end

function T:ClearPaths()
    FG.db.paths = {}
    T.dirty = true
    FG:Print(FG.L("paths_cleared"))
    FG:Refresh(true)
end

---------------------------------------------------------------------------
-- Поиск пути
---------------------------------------------------------------------------
-- Возвращает список точек маршрута (без стартовой) или nil, если идти по прямой
function T:Compute(s)
    if FG.db.travel == false then return end
    if not s or not s.m or not s.x then return end
    local pm, px, py = FG:GetPlayerPos()
    if not px then return end
    local c0, sx, sy = World(pm, px, py, true)
    local c1, tx, ty = World(s.m, s.x, s.y)
    if not c0 or not c1 then return end
    local S = { cont = c0, wx = sx, wy = sy, m = pm, x = px, y = py, kind = "start" }
    local G = { cont = c1, wx = tx, wy = ty, m = s.m, x = s.x, y = s.y, kind = "goal" }
    local nodes = { S, G }
    local conts = { [c0] = true, [c1] = true }

    -- корабли и дирижабли (пристани обеих сторон)
    local myFac = UnitFactionGroup and UnitFactionGroup("player")
    for ti, tr in ipairs(T.Transports) do
        if not tr.fac or tr.fac == myFac then
            local ca, ax, ay = World(tr.a[1], tr.a[2] / 100, tr.a[3] / 100)
            local cb, bx, by = World(tr.b[1], tr.b[2] / 100, tr.b[3] / 100)
            if ca and cb then
                local names = (FG:Lang() == "ru") and tr.ru or tr.en
                local na = { cont = ca, wx = ax, wy = ay, m = tr.a[1], x = tr.a[2] / 100, y = tr.a[3] / 100, kind = "dock", tkind = tr.kind, name = names[1], tr = ti, time = tr.time }
                local nb = { cont = cb, wx = bx, wy = by, m = tr.b[1], x = tr.b[2] / 100, y = tr.b[3] / 100, kind = "dock", tkind = tr.kind, name = names[2], tr = ti, time = tr.time }
                na.pair, nb.pair = nb, na
                nodes[#nodes + 1] = na; nodes[#nodes + 1] = nb
                conts[ca] = true; conts[cb] = true
            end
        end
    end

    -- распорядители полётов (на всех континентах маршрута)
    local fms = {}
    for cont in pairs(conts) do
        for name, n in pairs((FG.cdb.taxi or {})[cont] or {}) do
            local node = { cont = cont, wx = n.wx, wy = n.wy, m = n.m, x = n.x, y = n.y, kind = "fm", name = name }
            nodes[#nodes + 1] = node
            fms[#fms + 1] = node
        end
    end
    -- записанные пути
    local guardS, guardG -- путь, по которому только и можно уйти от старта / подойти к цели
    for pi, path in ipairs(FG.db.paths or {}) do
        if conts[path.cont] and path.pts and #path.pts >= 2 then
            local first, last = path.pts[1], path.pts[#path.pts]
            for i, p in ipairs(path.pts) do
                nodes[#nodes + 1] = { cont = path.cont, wx = p.wx, wy = p.wy, m = p.m, x = p.x, y = p.y, kind = "path", path = pi, idx = i, n = #path.pts }
            end
            local dSg = (c0 == c1) and dist(S, G) or math.huge
            for _, e in ipairs({ first, last }) do
                if path.cont == c1 and dist(e, G) <= GUARD_YARDS and dSg > GUARD_YARDS then guardG = guardG or pi end
                if path.cont == c0 and dist(e, S) <= GUARD_YARDS * 0.6 and dSg > GUARD_YARDS then guardS = guardS or pi end
            end
        end
    end
    if #nodes == 2 then return end -- ни полётов, ни путей: по прямой
    -- одна сторона пары не на нужных континентах — такая пристань не поможет, но не мешает

    local speed = runSpeed()
    local function cost(a, b)
        -- цель/старт рядом с концом записанного пути: только по этому пути
        -- корабль/дирижабль: только между двумя пристанями одной линии
        if a.kind == "dock" and b == a.pair then return (a.time or BOAT_TIME) end
        if a.cont ~= b.cont then return nil end
        if b == G and guardG and not (a.kind == "path" and a.path == guardG and dist(a, G) <= GUARD_YARDS) then return nil end
        if a == S and guardS and not (b.kind == "path" and b.path == guardS and dist(b, S) <= GUARD_YARDS) then return nil end
        local d = dist(a, b)
        if a.kind == "fm" and b.kind == "fm" then
            return d * FLY_CURVE / FLY_SPEED + FM_OVERHEAD
        end
        local c = d / speed
        if a.kind == "path" and b.kind == "path" and a.path == b.path and math.abs(a.idx - b.idx) == 1 then
            c = c * PATH_BONUS
        end
        return c
    end

    -- Дейкстра на полном графе (точек немного)
    local n = #nodes
    local best, prev, done = {}, {}, {}
    for i = 1, n do best[i] = math.huge end
    best[1] = 0
    for _ = 1, n do
        local u, bu = nil, math.huge
        for i = 1, n do if not done[i] and best[i] < bu then u, bu = i, best[i] end end
        if not u or u == 2 then break end
        done[u] = true
        local a = nodes[u]
        for v = 2, n do
            if not done[v] then
                local b = nodes[v]
                local skip = false
                -- по записанному пути идём только к соседним точкам (или сходим с него)
                if a.kind == "path" and b.kind == "path" and a.path == b.path and math.abs(a.idx - b.idx) > 1 then skip = true end
                if not skip then
                    local c = cost(a, b)
                    if c and bu + c < best[v] then best[v] = bu + c; prev[v] = u end
                end
            end
        end
    end
    if best[2] == math.huge then return end
    -- прямой путь (без ограничений) для сравнения: не усложняем маршрут ради пары секунд
    local direct = (c0 == c1) and (dist(S, G) / speed) or math.huge
    local list = {}
    local v = 2
    while v and v ~= 1 do table.insert(list, 1, nodes[v]); v = prev[v] end
    if #list <= 1 then return end
    if c0 == c1 and not guardG and not guardS and best[2] > direct * 0.85 then return end
    return list, best[2]
end

-- Текущий маршрут для подсказки (пересчитывается не чаще раза в секунду)
local cache = { key = nil, t = 0 }
function T:Get(s)
    if not s or not s.m then return end
    if UnitOnTaxi and UnitOnTaxi("player") then return cache.list end
    local key = s.m .. ":" .. (s.x or 0) .. ":" .. (s.y or 0)
    local now = GetTime and GetTime() or 0
    if cache.key == key and not T.dirty and now - cache.t < 1 then return cache.list end
    T.dirty = false
    local ok, list = pcall(self.Compute, self, s)
    cache = { key = key, t = now, list = ok and list or nil }
    return cache.list
end

-- Ближайшая непройденная точка маршрута (её и показывает стрелка)
function T:NextWaypoint(s)
    local list = self:Get(s)
    if not list then return end
    local pm, px, py = FG:GetPlayerPos()
    local c0, sx, sy = World(pm, px, py, true)
    if not c0 then return list[1] end
    local me = { wx = sx, wy = sy }
    local lastHere
    for i, p in ipairs(list) do
        if p.cont == nil or p.cont == c0 then
            lastHere = p
            if i == #list or dist(me, p) > REACHED then return p end
        elseif lastHere then
            return lastHere -- дошли до пристани: ждём корабль здесь
        end
    end
    return lastHere or list[#list]
end

-- Короткое описание маршрута для панели
function T:Describe(s)
    local list = self:Get(s)
    if not list then return end
    local parts, usedPath = {}, false
    for i, p in ipairs(list) do
        if p.kind == "dock" and list[i + 1] == p.pair then
            parts[#parts + 1] = FG.L(p.tkind == "zep" and "route_zep" or "route_boat", p.name, p.pair.name)
        elseif p.kind == "fm" then
            local nextp = list[i + 1]
            if nextp and nextp.kind == "fm" then
                parts[#parts + 1] = FG.L("route_fly", p.name, nextp.name)
            end
        elseif p.kind == "path" then
            usedPath = true
        end
    end
    if usedPath then table.insert(parts, 1, FG.L("route_path")) end
    if #parts == 0 then return end
    return table.concat(parts, "\n")
end

FG:OnInit(function()
    FG.db.paths = FG.db.paths or {}
    local f = CreateFrame("Frame")
    local t = 0
    f:SetScript("OnUpdate", function(_, dt)
        t = t + dt
        if t < 0.5 then return end
        t = 0
        if rec then pcall(recordTick) end
    end)
end)
