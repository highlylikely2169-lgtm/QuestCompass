---@type ZoneDB
local ZoneDB = QuestieLoader:ImportModule("ZoneDB")
---@type Expansions
local Expansions = QuestieLoader:ImportModule("Expansions")
local isHorde = UnitFactionGroup("Player") == "Horde"

---@class DungeonZoneEntry
---@field [1] string name
---@field [2] AreaId[]? alternativeAreaIds
---@field [3] AreaId parentZone
---@field [4] table<AreaId, AreaCoordinate> dungeonLocations

-- Era-framed entrances in changed zones are stored in Forever percentages, not converted at load.
-- DBC 1.15.9.69722 -> 1.60.1.69893; see docs/forever-coordinate-audit.md for source points and exclusions.
---@type table<AreaId, DungeonZoneEntry>
local dungeons = {
    [206] = {"Utgarde Keep",{10057,10058},495,{{495, 58.8, 48.3}}},
    [209] = {"Shadowfang Keep",{10014,10015,10016,10017,10018,10019},130,{{130, 44.8, 67.8}}}, -- removed 236, not used by anything
    [491] = {"Razorfen Kraul",{1717},17,{{17, 42.9, 90.2}}}, -- quests are 1717
    [717] = {"The Stockade",nil,1519,{{1519, 52.41, 70.01}}},
    [718] = {"Wailing Caverns",nil,17,{{17, 46, 36.5}}},
    [719] = {"Blackfathom Deeps",{10020,10021},331,{{331, 14.5, 14.2}}}, -- removed 2797, not used by anything
    [721] = {"Gnomeregan",{133,10030,10031,10032},1,{{1, 24.3, 39.8}}}, -- quests are 133
    [722] = {"Razorfen Downs",nil,17,{{17, 49, 93.9}}}, -- removed 1316, not used by anything
    [796] = {"Scarlet Monastery",{6109,6386,10008,10009,10010},85,{{85, 82.6, 33.8}}},
    [1176] = {"Zul'Farrak",{978},440,{{440, 38.7, 20.1}}}, -- quests are 978
    [1196] = {"Utgarde Pinnacle",{10053},495,{{495, 57.3, 46.8}}},
    [1337] = {"Uldaman",{1517,10033},3,{{3, 44.6, 12.1},{3, 65.2, 43.5}}}, -- quests are 1517
    [1477] = {"The Temple of Atal'Hakkar",{1417},8,{{8, 69.9, 53.5}}}, -- quests are 1417
    [1581] = {"The Deadmines",{10029},40,{{40, 42.5, 71.7}}},
    [1583] = {"Blackrock Spire",{10003,10004,10005,10006,10007},51,{{51, 34.8, 85.3}, {46, 29.4, 38.3}}},
    [1584] = {"Blackrock Depths",{1585},51,{{51, 34.8, 85.3},{46, 29.4, 38.3}}},
    [1977] = {"Zul'Gurub",nil,33,{{33, 53.89, 17.6}}},
    [2017] = {"Stratholme",nil,139,{{139, 26.52, 10.36}, {139, 41.45, 17.74}}}, -- removed 2279, not used by anything
    [2057] = {"Scholomance",{10011,10012,10013},28,{{28, 69.7, 73.2}}},
    [2100] = {"Maraudon",{10000},405,{{405, 29.1, 62.5}}},
    [2159] = {"Onyxia's Lair",nil,15,{{15, 52.6, 76.8}}},
    [2257] = {"Deeprun Tram",nil,1519,{{1519, 71.98, 27.61}, {1537, 84.1, 53.1}}},
    [2366] = {"The Black Morass",nil,440,{{440, 65.7, 49.8}}},
    [2367] = {"Old Hillsbrad Foothills",nil,440,{{440, 65.7, 49.8}}},
    [2437] = {"Ragefire Chasm",nil,1637,{{1637, 52.6, 49}}},
    [2557] = {"Dire Maul",nil,357,{{357, 59.2, 45.1}}}, -- removed 2577, not used by anything
    [2597] = {"Alterac Valley",nil,36,{(isHorde and {36, 39.5, 80.2}) or {36, 63.6, 58.8}}},
    [2677] = {"Blackwing Lair",nil,46,{{51, 34.8, 85.3}, {46, 29.4, 38.3}}}, -- this one needs the map IDs added
    [2717] = {"Molten Core",nil,46,{{51, 34.8, 85.3}, {46, 29.4, 38.3}}},
    [2917] = {"Hall of Legends",nil,1637,{{1637, 40.4, 68.3}}},
    [2918] = {"Champions' Hall",nil,1519,{{1519, 75.93, 66.22}}},
    [3277] = {"Warsong Gulch",nil,17,{(isHorde and {17, 46.52,8.56}) or {331, 61.66,84.52}}},
    [3358] = {"Arathi Basin",nil,36,{(isHorde and {45, 73.5, 29.0}) or {45, 45.4, 44.4}}},
    [3428] = {"Temple of Ahn'Qiraj",{10040,10041},1377,{{1377, 28.6, 92.3}}},
    [3429] = {"Ruins of Ahn'Qiraj",nil,1377,{{1377, 28.6, 92.3}}},
    [3456] = {"Naxxramas",{10062,10063,10064,10065,10066},65,{{139, 34.25, 19.45}}},
    [3457] = {"Karazhan",{10103,10104,10105,10106,10107,10108,10109,10110,10111,10112,10113,10114,10115,10116,10117,10118},41,{{41, 46.7, 70.2},{41, 46.9, 74.7}}},
    [3562] = {"Hellfire Ramparts",nil,3483,{{3483, 47.7, 53.6}}},
    [3606] = {"Hyjal Summit",nil,440,{{440, 65.7, 49.8}}},
    [3607] = {"Serpentshire Cavern",nil,3521,{{3521, 50.4, 40.9}}},
    [3713] = {"The Blood Furnace",nil,3483,{{3483, 46.0, 51.8}}},
    [3714] = {"The Shattered Halls",nil,3483,{{3483, 47.7, 52.0}}},
    [3715] = {"The Steamvault",nil,3521,{{3521, 50.4, 40.9}}},
    [3716] = {"The Underbog",nil,3521,{{3521, 50.4, 40.9}}},
    [3717] = {"The Slave Pens",nil,3521,{{3521, 50.4, 40.9}}},
    [3789] = {"Shadow Labyrinth",nil,3519,{{3519, 39.6, 71.0}}},
    [3790] = {"Auchenai Crypts",{10043},3519,{{3519, 36.1, 65.6}}},
    [3791] = {"Sethekk Halls",{10042},3519,{{3519, 43.2, 65.6}}},
    [3792] = {"Mana-Tombs",nil,3519,{{3519, 39.7, 60.2}}},
    [3805] = {"Zul'Aman",nil,3433,{{3433, 82.25, 64.3}}},
    [3836] = {"Magtheridon's Lair",nil,3483,{{3483, 46.6, 52.81}}},
    [3845] = {"Tempest Keep",nil,3523,{{3523, 73.7, 63.7}}},
    [3847] = {"The Botanica",nil,3523,{{3523, 71.7, 55.0}}},
    [3848] = {"The Arcatraz",{10045,10046},3523,{{3523, 74.4, 57.7}}},
    [3849] = {"The Mechanar",{10044},3523,{{3523, 70.6, 69.7}}},
    [3923] = {"Gruul's Lair",nil,3522,{{3522, 68.7, 24.3}}},
    [3959] = {"Black Temple",nil,3520,{{3520, 71, 46.4}}}, -- this one needs the map IDs added
    [4075] = {"Sunwell Plateau",nil,4080,{{4080, 44.3, 45.5}}},
    [4100] = {"The Culling of Stratholme",{10059},440,{{440, 65.7, 49.8}}},
    [4131] = {"Magisters' Terrace",{10028},4080,{{4080, 61.2, 30.9}}},
    [4196] = {"Drak'Tharon Keep",{10060},66,{{66, 29.0, 83.9},{394, 17.5, 27.0}}},
    [4228] = {"The Oculus",{10047,10048,10049},3537,{{3537, 27.6, 26.6}}},
    [4264] = {"Halls of Stone",nil,67,{{67, 39.6, 26.9}}},
    [4265] = {"The Nexus",nil,3537,{{3537, 27.6, 26.6}}},
    [4272] = {"Halls of Lightning",{10054},67,{{67, 45.4, 21.4}}},
    [4273] = {"Ulduar",{4657,10050,10051,10052},67,{{67, 41.6, 17.8}}},
    [4277] = {"Azjol-Nerub",{10055,10056},65,{{65, 26.2, 49.6}}},
    [4415] = {"The Violet Hold",nil,4395,{{4395, 66.8, 68.2}}},
    [4416] = {"Gundrak",{10061},66,{{66, 76.2, 21.1},{66, 81.2, 28.9}}},
    [4493] = {"The Obsidian Sanctum",nil,65,{{65, 59.6, 51.1}}},
    [4494] = {"Ahn'kahet: The Old Kingdom",nil,65,{{65, 26.2, 49.6}}},
    [4500] = {"The Eye of Eternity",nil,3537,{{3537, 27.6, 26.6}}},
    [4603] = {"Vault of Archavon",nil,4197,{{4197, 50.5, 16.4}}},
    [4722] = {"Trial of the Crusader",nil,210,{{210, 75.1, 21.8}}},
    [4723] = {"Trial of the Champion",nil,210,{{210, 74.2, 20.5}}},
    [4809] = {"The Forge of Souls",nil,210,{{210, 52.6, 89.4}}},
    [4812] = {"Icecrown Citadel",{10067,10068,10069,10070,10071,10072},210,{{210, 53.3, 85.5}}},
    [4813] = {"Pit of Saron",nil,210,{{210, 52.6, 89.4}}},
    [4820] = {"Halls of Reflection",nil,210,{{210, 52.6, 89.4}}},
    [4926] = {"Blackrock Caverns",nil,51,{{51, 34.9, 83.9}, {46, 21, 37.9}}}, -- this one needs the map IDs added, maybe?
    [4950] = {"Grim Batol",nil,4922,{{4922, 19.2, 54.0}}},
    [4945] = {"Halls of Origination",nil,5034,{{5034, 71.6, 52.2}}}, -- this one needs the map IDs added
    [4987] = {"The Ruby Sanctum",nil,65,{{65, 59.6, 51.1}}},
    [5004] = {"Throne of the Tides",nil,5146,{{5145, 70.8, 29.0}}}, -- this one needs the map IDs added, maybe?
    [5035] = {"The Vortex Pinnacle",nil,5034,{{5034, 76.7, 84.4}}},
    [5088] = {"The Stonecore",nil,5042,{{5042, 47.6, 52.0}}},
    [5094] = {"Blackwing Descent",nil,46,{{46, 23.0, 26.6}}},
    [5334] = {"The Bastion of Twilight",nil,4922,{{4922, 34.0, 78.0}}},
    [5396] = {"Lost City of the Tol'vir",nil,5034,{{5034, 60.5, 64.2}}},
    [5600] = {"Baradin Hold",nil,5095,{{5095, 46.3, 47.9}}},
    [5638] = {"Throne of the Four Winds",nil,5034,{{5034, 38.4, 80.6}}},
    [5723] = {"Firelands",nil,616,{{616, 47.3, 78.0}}},
    [5733] = {"Molten Front",nil,616,{{616, 27.51, 56.41}}}, -- Not a real dungeon, but still a sub-zone entered through a portal
    [5788] = {"Well of Eternity",nil,440,{{440, 64.8, 50}}},
    [5789] = {"End Time",{5790,5792,5793,5794,5795},440,{{440, 64.8, 50}}},
    [5844] = {"Hour of Twilight",{10039},440,{{440, 64.8, 50}}},
    [5861] = {"Darkmoon Faire Island",nil,440,{{12, 41.79, 69.52},{215, 36.85, 35.86}}}, -- Cata portal frame; not Era-converted, Forever placement unverified
    [5892] = {"Dragon Soul",nil,440,{{440, 64.8, 50}}}, -- this one needs the map IDs added
    [5918] = {"Shado-Pan Monastery",{6173},5841,{{5841, 36.7, 47.4}}}, -- this one needs the map IDs added
    [5956] = {"Temple of the Jade Serpent",nil,5785,{{5785, 56.2, 57.9}}}, -- this one needs the map IDs added
    [5963] = {"Stormstout Brewery",nil,5805,{{5805, 36.1, 69.2}}}, -- this one needs the map IDs added
    [5976] = {"Gate of the Setting Sun",nil,5840,{{5840, 15.8, 74.3}}}, -- this one needs the map IDs added
    [6052] = {"Scarlet Halls",{10076},85,{{85, 82.5, 33.3}}},
    [6066] = {"Scholomance",{10077,10078,10079},28,{{28, 69.7, 73.2}}}, -- MoP version
    [6067] = {"Terrace of Endless Spring",nil,6006,{{6006, 48.4, 61.4}}},
    [6125] = {"Mogu'shan Vaults",nil,5841,{{5841, 59.6, 39.2}}}, -- this one needs the map IDs added
    [6182] = {"Mogu'shan Palace",nil,5840,{{5840, 80.9, 32.7}}}, -- this one needs the map IDs added
    [6214] = {"Siege of Niuzao Temple",nil,5842,{{5842, 34.7, 81.5}}}, -- this one needs the map IDs added
    [6297] = {"Heart of Fear",nil,6138,{{6138, 38.8, 35}}}, -- this one needs the map IDs added
    [6298] = {"Brawl'gar Arena",nil,1637,{{1637, 70.7, 30.6}}},
    [6618] = {"Bizmo's Brawlpub",nil,1519,{{1519, 69.49, 31.2},{1537, 84.1, 53.1}}}, -- MoP frame; not Era-converted, Forever placement unverified
    [6622] = {"Throne of Thunder",{10093,10094,10095,10096,10097,10098,10099},6507,{{6507, 63.6, 32.2}}},
    [6738] = {"Siege of Orgrimmar",nil,5840,{{5840, 72.4, 44.18}}}, -- this one needs the map IDs added
    -- [7307] = {"Upper Blackrock Spire",nil,51,{{51, 34.8, 85.3}, {46, 29.4, 38.3}}}, -- only added in WoD
    [10001] = {"Stratholme",nil,139,{{139, 43.5, 19.4}}}, -- The Gauntlet: Cata frame, not Era-converted; Forever placement unverified
    [10022] = {"Dire Maul",nil,357,{{357, 62.5,24.9}}}, -- North
    [10023] = {"Dire Maul",nil,357,{{357, 60.3,30.2}}}, -- West
    [10024] = {"Dire Maul",nil,357,{{357, 60.3,30.2}}}, -- West
    [10025] = {"Dire Maul",nil,357,{{357, 60.3,30.2}}}, -- West
    [10026] = {"Dire Maul",nil,357,{{357, 64.8,30.2}}}, -- East
    [10027] = {"Dire Maul",nil,357,{{357, 64.8,30.2}}}, -- East
    [15475] = {"Demon Fall Canyon",nil,331,{{331, 84.7, 74.4}}},
    [15531] = {"The Tainted Scar",nil,4,{{4, 45.3,55.0}}},
    [15828] = {"The Burning of Andorhal",nil,28,{{28, 69.6,79.6}}},
    [16074] = {"Karazhan Crypts",nil,41,{{41, 39.99, 74.16}}},
    [16236] = {"Scarlet Enclave",nil,139,{{139, 60.14, 75.32}}}, -- SoD/Era point projected; Forever content availability unverified
    [16544] = {"City of Dalaran",nil,36,{{36, 8.46, 59.21}}},
    [16611] = {"Ruins of Lordaeron",nil,1497,{{1497, 72.48, 11.33}}},
    [16732] = {"Excavation Site: Wetlands",nil,11,{{11, 47.79, 56.16}}},
    [16919] = {"The Hall of Thanes",nil,1537,{{1537, 27.63, 47.83}}},
}

if Expansions.Current >= Expansions.Wotlk then
    dungeons[717][4] = {{1519, 52.4, 70}} -- The Stockade
    dungeons[2257][4] = {{1519, 72, 28}, {1537, 84.1, 53.1}} -- Deeprun Tram
    dungeons[3456][4] = {{65, 87.4, 51.1}} -- Naxxramas
end

if Expansions.Current >= Expansions.Cata then
    dungeons[491][3] = 4709 -- Utgarde Keep
    dungeons[491][4] = {{4709, 41, 94.6}} -- Utgarde Keep
    dungeons[718][4] = {{17, 38.9, 69.1}} -- Wailing Caverns
    dungeons[719][4] = {{331, 14.2, 13.9}} -- Blackfathom Deeps
    dungeons[721][4] = {{1, 31.1, 37.9}} -- Gnomeregan
    dungeons[722][3] = 400 -- Razorfen Downs
    dungeons[722][4] = {{400, 41.5, 29.4}} -- Razorfen Downs
    dungeons[796][4] = {{85, 82.5, 33.3}} -- Scarlet Monastery
    dungeons[1176][4] = {{440, 39.2, 21.3}} -- Zul'Farrak
    dungeons[1337][4] = {{3, 41.7, 11.6}, {3, 58.6, 37}} -- Uldaman
    dungeons[1477][4] = {{8, 69.7, 53.5}} -- The Temple of Atal'Hakkar
    dungeons[1581][4] = {{40, 42.6, 71.8}} -- The Deadmines
    dungeons[1583][4] = {{51, 34.9, 83.9}, {46, 21, 37.9}} -- Blackrock Spire
    dungeons[1584][4] = {{51, 34.9, 83.9}, {46, 21, 37.9}} -- Blackrock Depths
    dungeons[1977][4] = {{33, 72.1, 32.9}} -- Zul'Gurub
    dungeons[2017][4] = {{139, 27.7, 11.5}} -- Stratholme
    dungeons[2100][4] = {{405, 29.1, 62.6}} -- Maraudon
    dungeons[2257][4] = {{1519, 69.49, 31.2}, {1537, 84.1, 53.1}} -- Deeprun Tram
    dungeons[2366][4] = {{440, 64.8, 50}} -- The Black Morass
    dungeons[2367][4] = {{440, 64.8, 50}} -- Old Hillsbrad Foothills
    dungeons[2437][4] = {{1637, 55.2, 51.2}} -- Ragefire Chasm
    dungeons[2557][4] = {{357, 62.1, 30.2}} -- Dire Maul
    dungeons[2597][4] = {(isHorde and {267, 58.4, 33.3}) or {267, 44.5, 46}} -- Alterac Valley
    dungeons[2677][4] = {{51, 34.9, 83.9}, {46, 21, 37.9}} -- Blackwing Lair
    dungeons[2717][4] = {{51, 34.9, 83.9}, {46, 21, 37.9}} -- Molten Core
    dungeons[3277][4] = {(isHorde and {17, 39.91,20.26}) or {331, 61.66,84.52}} -- Warsong Gulch
    dungeons[3428][4] = {{1377, 24.4, 87.5}} -- Temple of Ahn'Qiraj
    dungeons[3429][4] = {{1377, 36.5, 93.9}} -- Ruins of Ahn'Qiraj
    dungeons[3606][4] = {{440, 64.8, 50}} -- Hyjal Summit
    dungeons[4100][4] = {{440, 64.8, 50}} -- The Culling of Stratholme
    -- dungeons[7307][4] = {{51, 34.9, 83.9}, {46, 21, 37.9}} -- Upper Blackrock Spire -- only added in WoD
    dungeons[10023][4] = {{357, 60.3,31.3}} -- West
    dungeons[10024][4] = {{357, 60.3,31.3}} -- West
    dungeons[10025][4] = {{357, 60.3,31.3}} -- West
end

ZoneDB.private.dungeons = dungeons
