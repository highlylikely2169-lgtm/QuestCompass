# QuestCompass

## 1.8.0
- No Questie needed: the quest, NPC, item and object database now ships with the addon as QuestCompass_Data (QuestieDB, WoW Forever data only). Install both folders.
- Talents: read straight from the WoW Forever talent tree (new ranks and positions), all three trees side by side like the game window, Primary and Secondary talent sets (second from level 40), points are staged and confirmed with Apply Changes, unspent points shown, the next talent glows.
- New Interface tab: your own player and target frames (class or reaction colors, portrait or class icon, sizes in one click), party frames and a raid grid, buffs and debuffs with timers (right-click cancels a buff), readable text on the experience bar, move everything with the mouse on a grid, three ready styles (Dark, Classic, Minimal) and "Restore defaults".
- New Healing tab: set what each mouse button does on a frame (with Shift / Ctrl / Alt): heals, shields, buffs, removing poison, disease, curse or magic, resurrection, target or menu. Heals land only on the member you clicked, never on yourself.
- Professions: clearer skill bar, the guide opens only when you click a profession, and the arrow stays on the profession target instead of jumping back to quests.
- One window size for all tabs.

## 1.7.0
- One "Go" button everywhere (Leveling, Professions, Reputation, Companion): it opens a small separate window with what to do right now, and the arrow leads you there. The window can be moved and resized; "Stop" ends the guidance.
- Professions: the tracker shows what to make, materials you have/need and what comes next. Gathering professions lead you to the nearest herb or vein (fishing: to water in the best zone). Crafting professions point to a vendor for missing materials, the Auction House or your trainer.
- "Bring with you" icons: fishing pole and the best lure for your skill, mining pick, skinning knife, blacksmith hammer, engineering tools, enchanting rod, flint and tinder — green when you have it, click to search the Auction House.
- Reputation: "Go" for every faction shows your standing, goal and how to raise it; the arrow leads to the faction's NPC (Thorium Point, Yojamba Isle, Timbermaw, Argent Dawn camps, Cenarion Hold, Hydraxis, city cloth quartermasters).
- Fixed: fishing (and other secondary skills) shown as "not learned"; skill is also remembered from the profession window and skill-up messages.
- Dungeon quest list redesigned to look lighter: no boxes, softer colors, faded completed quests.
- BiS item window shows the whole character model.
- The Skills tab is now called Professions and sits right under Leveling.

## 1.6.0
- Skills: new "Recipes" view in the profession guide (next to Route and Shopping). Filters: Available at your skill, Not learned, All.
- Every recipe shows the required skill colored by difficulty (orange / yellow / green / grey), whether you already know it, and where to get it: learned automatically, profession trainer, vendor (name and zone, your faction only), drop (mob, level and zone), quest reward or chest.
- Tooltip lists all four skill thresholds, reagents per craft with how many you have, and every known recipe source with vendor prices.
- Left-click a recipe to search the Auction House for a missing reagent; right-click to search for the recipe itself.
- Learned recipes are remembered per character after you open the profession window once.
- Data: 2465 WoW Forever recipes for Alchemy, Blacksmithing, Enchanting, Engineering, Leatherworking, Tailoring, Cooking and First Aid.

## 1.5.0
- New settings window with side tabs: Leveling, Talents, Companion, BiS Gear, Skills, Reputation. The window keeps one size; extra panels open on the right as part of it.
- Talents: pick the tree you level through (any of the three) and get a top leveling build 10-60 with the next talent to take, a "Learn" button, a chat reminder for every new point and English/Russian names.
- Skills: all 12 professions with your current skill and a step-by-step 1-300 route (what to make, how many, materials, where to get recipes, when to train ranks) plus a shopping list.
- "Start leveling" for a profession: a block shows what to do right now, materials you have/need and what is next. For Mining and Herbalism the arrow leads to the nearest vein or herb you can gather; for Skinning and Fishing — to the best zone.
- Companion: nearest class trainer, flight master, innkeeper, repairs, food, goods, bank, auction house, reagents and your profession trainers, with distance. "Guide" points the arrow there and opens a built-in map with you, the target and a dotted line.
- BiS Gear: crafted items show profession, skill, specialization, reputation, recipe source and materials; world drops are marked. Recommended enchants for your role with formula source, materials and whether your item already has it.
- Reputation: factions you need for your BiS items and enchants, your standing and progress, and how to raise each one.
- English mode on a Russian client now shows English item, NPC, quest, zone, dungeon, talent and enchant names.
- Hint panel is compact (fits the current quest) with a lighter background when not in dungeon mode.
- Choosing a route or level range turns off dungeon mode so regular quests show again; returning to the Leveling tab points the arrow back to quests.
- Fixes: scroll bars in long lists, missing auction house, item tooltips for items the game has not loaded, symbols that showed as squares.

## 1.4.1
- New WoW Forever dungeon: City of Dalaran (levels 28-33) with its quests for Alliance (Heart of Disruption, Starving Arcane, Power Overwhelming, A Green Sample) and Horde (Heart of Disruption, The Grave Knight, Source of Power, Opportunistic Education), lead-in quests and the sewer gate entrance.

## 1.4.0
- Quest card: only where to pick up, what to do and where to turn in. For a chain — every step in order, what is done and what to do next.
- Chains are shown as one row (with a "chain 2/3" tag and a blue stripe); breadcrumb quests are part of the chain.
- Rows show whether a quest is taken ("taken" / "turn in") and whether it is picked up inside the dungeon ("inside").
- Quests started inside dungeons, by items or by objects: the arrow leads to the entrance and the card says where exactly.
- Duplicate quests removed (e.g. six "Sparklematic 5200" variants in Gnomeregan); full check of all dungeons for both factions.
- New WoW Forever dungeon: Excavation Site: Wetlands (separate Alliance and Horde quests). Shadowfang Keep and other dungeons without quests for your faction are listed too.
- Dungeon levels for WoW Forever; new dungeons in a different color, upcoming dungeons and raids listed as "soon".
- Separate Raid list; dungeon and raid lists open as a drawer of the settings window.
- BiS gear for your class: pre-raid lists (Icy Veins) and best upgrades for your level, where each item drops, boss model; BiS items are announced when you enter a dungeon.
- Auto-accept now takes only the quest selected on the panel.
- Map line: blue, even spacing at any zoom, no longer disappears when zoomed in or when viewing another map.
- XP numbers removed from quests (progress bar and percent stay).

## 1.3.0
- Dungeon mode: pick a dungeon and see all its quests, the chains leading to them, where to pick them up, what to do (who drops what) and where to turn in. Pick one quest and the arrow guides you only by it.
- New WoW Forever dungeons: Hall of Thanes and Ruins of Lordaeron.
- "Best XP" route: leads where you get the most experience for the time spent and skips poor quests ("Nearest" mode still available).
- XP reward shown for every quest; the bar at the bottom shows how much of the selected quest is done.
- Travel between continents: tells you which boat or zeppelin to take; the flight map highlights where to fly.
- Full Russian: quest, NPC, item and zone names (translations from Questie, GPLv3).
- New look in the style of the game's own windows; panel has a fixed size and no longer jumps.
- Completed quests are recognized even when WoW Forever gave them new IDs.
- Removed: XP per hour, automatic reward choice.
- License: GNU GPL v3.

## 1.2.1
- Renamed to Quest Compass (folder `QuestCompass`, commands `/qc`).
- Fixed broken separator characters and clipped hint text at the bottom of the settings menu.

## 1.2.0
- Hub-first leveling: pick up every worthwhile quest at a quest hub, then do objectives, then turn in.
- Quests whose objectives are too far away, on another continent, elite or in dungeons are skipped (not suggested, not auto-accepted).
- New look: rounded dark theme, custom compass logo, navigation arrow with glow, round route dots, pulsing map marker.
- Native WoW font (Friz Quadrata) everywhere.
- Russian / English interface switch (menu → RU | EN, or `/qc lang en`).

## 1.1.0
- Settings menu with faction and level range filters.
- Minimap icon.

## 1.0.0
- First release: next-step suggestions, on-screen arrow, world map marker, dotted line on map and minimap, auto accept / turn in / reward choice, XP per hour.
