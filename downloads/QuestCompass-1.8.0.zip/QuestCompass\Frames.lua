-- QuestCompass: вкладка «Интерфейс» — своя рамка здоровья, баффы и полоса опыта.
-- Всё настраивается на вкладке, изменения видны сразу; «Двигать» — перетащить мышью.
-- Рамка игрока и баффы — защищённые фреймы (клик выбирает себя, ПКМ снимает бафф),
-- поэтому в бою их размеры не меняются: изменения применяются сразу после боя.
local _, ns = ...
local FG = ns.FG
local L = FG.L
local F = {}
FG.Frames = F

local S
local page
local W = FG.PAGE_W
local COLW = math.floor((W - 48) / 2)
local WHITE = "Interface\\Buttons\\WHITE8x8"
local FONT = "Fonts\\FRIZQT___CYR.TTF"
local TEX = {
    classic = "Interface\\TargetingFrame\\UI-StatusBar",
    smooth = "Interface\\RaidFrame\\Raid-Bar-Hp-Fill",
    flat = WHITE,
}
local AURA = 32 -- размер кнопки ауры в шаблоне; нужный размер — через масштаб заголовка

local function safe(f, ...) if not f then return nil end local ok, a, b, c, d, e, g = pcall(f, ...) if ok then return a, b, c, d, e, g end end
local function db() return FG.db.frames end

-- Шрифт для имён: у NPC бывают имена на китайском/корейском, а FRIZQT знает только латиницу и кириллицу.
-- Семейство шрифтов, как у стандартных рамок игры: для каждой письменности свой файл.
local families = {}
local function nameFont(fs, size)
    size = math.floor(size)
    local fam = families[size]
    if fam == nil and rawget(_G, "CreateFontFamily") then
        local ok, f = pcall(CreateFontFamily, "QuestCompassNameFont" .. size, {
            { alphabet = "roman", file = "Fonts\\FRIZQT__.TTF", height = size, flags = "OUTLINE" },
            { alphabet = "russian", file = FONT, height = size, flags = "OUTLINE" },
            { alphabet = "korean", file = "Fonts\\2002.TTF", height = size, flags = "OUTLINE" },
            { alphabet = "simplifiedchinese", file = "Fonts\\ARKai_T.ttf", height = size, flags = "OUTLINE" },
            { alphabet = "traditionalchinese", file = "Fonts\\blei00d.TTF", height = size, flags = "OUTLINE" },
        })
        fam = ok and f or false
        families[size] = fam
    end
    if fam then fs:SetFontObject(fam) else fs:SetFont(FONT, size, "OUTLINE") end
end

-- Защищённые фреймы в бою не трогаем: откладываем до конца боя
local pending = {}
local function protected(key, fn)
    if InCombatLockdown() then pending[key] = fn return end
    fn()
end
FG:On("PLAYER_REGEN_ENABLED", function()
    local list = pending
    pending = {}
    for _, fn in pairs(list) do pcall(fn) end
end)

-- Скрыть стандартную рамку игры: переносим в невидимый фрейм, вернуть — обратно к прежнему родителю
local hider = CreateFrame("Frame")
hider:Hide()
local saved = {}
local function hideBlizz(f, hide)
    if not f then return end
    if hide then
        if f:GetParent() ~= hider then saved[f] = f:GetParent(); f:SetParent(hider) end
    elseif saved[f] then
        f:SetParent(saved[f]); saved[f] = nil
    end
end
local function blizz(name) return rawget(_G, name) end

local function place(f, pt, def)
    pt = pt or def
    f:ClearAllPoints()
    f:SetPoint(pt[1], UIParent, pt[2], pt[3], pt[4])
end
local function savePoint(f, cfg, field)
    local p, _, rp, x, y = f:GetPoint(1)
    if p then cfg[field or "pt"] = { p, rp, math.floor(x + 0.5), math.floor(y + 0.5) } end
end

local function border(f, r, g, b, a)
    local t = {}
    for i, p in ipairs({ { "TOPLEFT", "TOPRIGHT", true }, { "BOTTOMLEFT", "BOTTOMRIGHT", true }, { "TOPLEFT", "BOTTOMLEFT" }, { "TOPRIGHT", "BOTTOMRIGHT" } }) do
        local e = f:CreateTexture(nil, "OVERLAY", nil, 7)
        e:SetTexture(WHITE); e:SetVertexColor(r, g, b, a)
        e:SetPoint(p[1]); e:SetPoint(p[2])
        if p[3] then e:SetHeight(1) else e:SetWidth(1) end
        t[i] = e
    end
    return t
end

local function short(n)
    n = n or 0
    if n >= 1000000 then return string.format("%.1fm", n / 1000000) end
    if n >= 100000 then return string.format("%.0fk", n / 1000) end
    return tostring(n)
end

---------------------------------------------------------------------------
-- Рамки игрока и цели: одна и та же рамка, у цели портрет справа
---------------------------------------------------------------------------
local frames = {} -- player, target
local PF_DEF = { "TOPLEFT", "TOPLEFT", 30, -30 }
local TF_DEF = { "TOPLEFT", "TOPLEFT", 320, -30 }

-- На WoW Forever здоровье и мана — «скрытые числа»: аддону нельзя их считать и сравнивать.
-- Полосе их можно отдать как есть, а текст собирает игра (string.format / AbbreviateNumbers).
local issecret = rawget(_G, "issecretvalue") or function() return false end
local function plain(v) return type(v) == "number" and not issecret(v) end

-- цвет полосы: игроки — по классу (или зелёный), мобы — по отношению к вам, «чужие» и мёртвые — серые
local function unitColor(unit)
    local green = db().pf.color == "green"
    if unit == "player" or UnitIsPlayer(unit) then
        if green then return 0.2, 0.78, 0.2 end
        local _, cl = UnitClass(unit)
        local cc = cl and (rawget(_G, "CUSTOM_CLASS_COLORS") or RAID_CLASS_COLORS)[cl]
        if cc then return cc.r, cc.g, cc.b end
        return 0.2, 0.78, 0.2
    end
    if UnitIsDeadOrGhost(unit) or (UnitIsTapDenied and UnitIsTapDenied(unit)) then return 0.5, 0.5, 0.5 end
    local r = UnitReaction(unit, "player")
    local fc = rawget(_G, "FACTION_BAR_COLORS")
    if plain(r) and fc and fc[r] then return fc[r].r, fc[r].g, fc[r].b end
    return 0.2, 0.78, 0.2
end

local function setBar(bar, cur, max)
    if plain(max) then bar:SetMinMaxValues(0, math.max(1, max)) else pcall(bar.SetMinMaxValues, bar, 0, max) end
    pcall(bar.SetValue, bar, cur)
end

-- текст «число / максимум  процент»; pctFn — процент от игры (для скрытых чисел)
local function setValueText(fs, cur, max, mode, pctFn)
    if mode == "none" then fs:SetText("") return end
    if plain(cur) and plain(max) then
        if max <= 0 then fs:SetText("") return end
        local pct = math.floor(cur / max * 100 + 0.5) .. "%"
        if mode == "pct" then fs:SetText(pct)
        elseif mode == "value" then fs:SetText(short(cur) .. " / " .. short(max))
        else fs:SetText(short(cur) .. " / " .. short(max) .. "  " .. pct) end
        return
    end
    local abbr = rawget(_G, "AbbreviateNumbers")
    local val, pct
    if mode ~= "pct" then
        local ok, s = pcall(function()
            if abbr then return string.format("%s / %s", abbr(cur), abbr(max)) end
            return string.format("%s / %s", cur, max)
        end)
        if ok then val = s end
    end
    if mode ~= "value" and pctFn then
        local ok, s = pcall(function() return string.format("%.0f%%", pctFn()) end)
        if ok then pct = s end
    end
    local ok
    if val and pct then ok = pcall(fs.SetFormattedText, fs, "%s  %s", val, pct)
    elseif val or pct then ok = pcall(fs.SetText, fs, val or pct) end
    if not ok then fs:SetText("") end
end

-- процент от игры (0–100), если клиент умеет
local function healthPct(unit)
    local f = rawget(_G, "UnitHealthPercent")
    local curve = rawget(_G, "CurveConstants") and CurveConstants.ScaleTo100
    if f and curve then return f(unit, true, curve) end
    error("no pct")
end
local function powerPct(unit, pt)
    local f = rawget(_G, "UnitPowerPercent")
    local curve = rawget(_G, "CurveConstants") and CurveConstants.ScaleTo100
    if f and curve then return f(unit, pt, true, curve) end
    error("no pct")
end

-- уровень цели: цвет по сложности, «??» для черепа, «+» у элиты
local function levelText(unit)
    local lv = UnitLevel(unit)
    if not plain(lv) then return "", 1, 0.82, 0 end
    if lv < 0 then return "??", 1, 0.1, 0.1 end
    local cls = UnitClassification and UnitClassification(unit)
    local plus = (cls == "elite" or cls == "rareelite" or cls == "worldboss") and "+" or ""
    if unit ~= "player" and GetQuestDifficultyColor then
        local col = GetQuestDifficultyColor(lv)
        if col then return lv .. plus, col.r, col.g, col.b end
    end
    return lv .. plus, 1, 0.82, 0
end

local function updateUnit(f)
    if not f or not f:IsShown() then return end
    local unit = f.unit
    if not UnitExists(unit) then return end
    local c = db().pf
    local hp, hpMax = UnitHealth(unit), UnitHealthMax(unit)
    setBar(f.hp, hp, hpMax)
    local r, gg, b = unitColor(unit)
    f.hp:SetStatusBarColor(r, gg, b)
    f.hp.bg:SetVertexColor(r * 0.22, gg * 0.22, b * 0.22, 0.95) -- тёмный фон в цвет полосы, как в ElvUI
    setValueText(f.hpText, hp, hpMax, c.text, function() return healthPct(unit) end)
    if UnitIsDeadOrGhost(unit) then f.hpText:SetText(L(UnitIsGhost(unit) and "fr_ghost" or "fr_dead")) end
    if UnitIsConnected and not UnitIsConnected(unit) then
        f.hpText:SetText(L("fr_offline")); f.hp:SetStatusBarColor(0.4, 0.4, 0.4)
    end
    -- имя может прийти «скрытым»: без проверок, просто отдаём надписи
    if not pcall(f.name.SetText, f.name, (UnitName(unit))) then f.name:SetText("") end
    local lt, lr, lg, lb = levelText(unit)
    f.lvl:SetText(lt); f.lvl:SetTextColor(lr, lg, lb)
    if c.power then
        local pt, token = UnitPowerType(unit)
        local pw, pwMax = UnitPower(unit, pt), UnitPowerMax(unit, pt)
        setBar(f.pw, pw, pwMax)
        local pbc = rawget(_G, "PowerBarColor") or {}
        local col = pbc[token] or pbc[pt] or { r = 0, g = 0.45, b = 1 }
        f.pw:SetStatusBarColor(col.r, col.g, col.b)
        f.pw.bg:SetVertexColor(col.r * 0.22, col.g * 0.22, col.b * 0.22, 0.95)
        setValueText(f.pwText, pw, pwMax, c.text, function() return powerPct(unit, pt) end)
    end
    -- портрет: лицо или круглая иконка класса
    if c.pmode == "class" then
        local _, cl = UnitClass(unit)
        local tc = cl and rawget(_G, "CLASS_ICON_TCOORDS") and CLASS_ICON_TCOORDS[cl]
        if tc then
            f.portrait:SetTexture("Interface\\TargetingFrame\\UI-Classes-Circles")
            f.portrait:SetTexCoord(tc[1], tc[2], tc[3], tc[4])
        elseif SetPortraitTexture then
            f.portrait:SetTexCoord(0.12, 0.88, 0.12, 0.88); SetPortraitTexture(f.portrait, unit)
        end
    elseif c.pmode ~= "none" and SetPortraitTexture then
        f.portrait:SetTexCoord(0.12, 0.88, 0.12, 0.88); SetPortraitTexture(f.portrait, unit)
    end
    if unit == "player" then
        f.rest:SetShown(IsResting and IsResting() or false)
        f.combat:SetShown(UnitAffectingCombat("player") and true or false)
    end
end

-- стиль рамок: насколько тёмный фон и какого цвета тонкая рамка
local LOOKS = {
    dark = { bg = 0.75, edge = { 0, 0, 0, 1 } },
    classic = { bg = 0.55, edge = { 0.78, 0.62, 0.22, 1 } },
    min = { bg = 0.3, edge = { 0, 0, 0, 0 } },
}
local function applyLook(f)
    local lk = LOOKS[db().look or "dark"] or LOOKS.dark
    if f.bg then f.bg:SetVertexColor(0, 0, 0, lk.bg) end
    for _, e in ipairs(f.edges or {}) do e:SetVertexColor(lk.edge[1], lk.edge[2], lk.edge[3], lk.edge[4]) end
end

-- Клики по рамкам: модификатор + кнопка («1», «shift-2») → { kind = "spell" | "target" | "menu", spell = имя }.
-- Хранятся у нас (db().clicks). Стартовые — как в установленном хилботе HealForever, иначе — набор для класса.
local CLASS_CLICKS = {
    PRIEST = { ["1"] = 2061, ["2"] = 17, ["3"] = 139, ["4"] = 1243, ["5"] = 14752 },
    DRUID = { ["1"] = 8936, ["2"] = 5185, ["3"] = 774, ["4"] = 1126, ["5"] = 2782 },
    PALADIN = { ["1"] = 19750, ["2"] = 635, ["4"] = 19742, ["5"] = 4987 },
    SHAMAN = { ["1"] = 8004, ["2"] = 331, ["3"] = 1064, ["5"] = 526 },
}
local function spellName(id)
    if C_Spell and C_Spell.GetSpellInfo then
        local i = safe(C_Spell.GetSpellInfo, id)
        if type(i) == "table" then return i.name end
    end
    return rawget(_G, "GetSpellInfo") and (safe(GetSpellInfo, id))
end
local function seedClicks()
    local out = { ["1"] = { kind = "target" }, ["2"] = { kind = "menu" } }
    -- как в хилботе, если он установлен (только заклинания, цель и меню)
    local hf = rawget(_G, "HealForeverFrames")
    local store = hf and hf.db and hf.BindingStore and safe(hf.BindingStore, hf.GetMode and safe(hf.GetMode) or "healer")
    if type(store) == "table" and next(store) then
        out = {}
        for key, v in pairs(store) do
            if type(key) == "string" and key:match("^%l*%-?%l*%-?%l*%-?%d$") and type(v) == "table" then
                if v.kind == "spell" and type(v.spell) == "string" then out[key] = { kind = "spell", spell = v.spell }
                elseif v.kind == "target" or v.kind == "menu" then out[key] = { kind = v.kind } end
            end
        end
        return out
    end
    -- набор для класса: лечение и баффы, меню — на Shift + правую
    local _, cl = UnitClass("player")
    local set = CLASS_CLICKS[cl]
    if set then
        out = { ["shift-2"] = { kind = "menu" }, ["shift-1"] = { kind = "target" } }
        for key, id in pairs(set) do
            local n = spellName(id)
            if n then out[key] = { kind = "spell", spell = n } end
        end
        if not out["1"] then out["1"] = { kind = "target" } end
    end
    return out
end
local function clickStore()
    local c = db()
    if type(c.clicks) ~= "table" then c.clicks = seedClicks() end
    return c.clicks
end
F.ClickStore = clickStore

local function applyClicks(f)
    if f.hfKeys then for k in pairs(f.hfKeys) do f:SetAttribute(k, nil) end end
    f.hfKeys = {}
    f:SetAttribute("type1", "target")
    f:SetAttribute("type2", "togglemenu")
    if not db().party.healClicks then return end
    for key, b in pairs(clickStore()) do
        local prefix, btn = key:match("^(.-)(%d)$")
        if btn and type(b) == "table" then
            local tk, sk, mk = prefix .. "type" .. btn, prefix .. "spell" .. btn, prefix .. "macrotext" .. btn
            if b.kind == "spell" then
                -- строго на того, чья это рамка: иначе, если союзник далеко, игра
                -- «автоприменением на себя» вешает заклинание на вас
                f:SetAttribute(tk, "macro"); f:SetAttribute(mk, "/cast [@" .. f.unit .. (f.unit == "player" and "" or ",help,nodead") .. "] " .. b.spell)
            elseif b.kind == "target" then f:SetAttribute(tk, "target")
            elseif b.kind == "menu" then f:SetAttribute(tk, "togglemenu")
            else f:SetAttribute(tk, nil) end
            f.hfKeys[tk], f.hfKeys[sk], f.hfKeys[mk] = true, true, true
        end
    end
end

local UNIT_EVENTS = { "UNIT_HEALTH", "UNIT_HEALTH_FREQUENT", "UNIT_MAXHEALTH", "UNIT_POWER_UPDATE", "UNIT_POWER_FREQUENT",
    "UNIT_MAXPOWER", "UNIT_DISPLAYPOWER", "UNIT_PORTRAIT_UPDATE", "UNIT_LEVEL", "UNIT_NAME_UPDATE", "UNIT_FACTION",
    "UNIT_CLASSIFICATION_CHANGED", "UNIT_FLAGS", "UNIT_CONNECTION" }

-- Клик по рамке союзника: на время клика выключаем «автоприменение на себя» (autoSelfCast),
-- иначе клиент Forever вешает лечение на вас, когда союзник далеко. Если игра всё же
-- подняла курсор выбора цели — отменяем его. После клика настройка возвращается как была.
local function cvarGet(n) local f = (C_CVar and C_CVar.GetCVar) or rawget(_G, "GetCVar") return f and safe(f, n) end
local function cvarSet(n, v) local f = (C_CVar and C_CVar.SetCVar) or rawget(_G, "SetCVar") if f then pcall(f, n, v) end end
local function guardSelfCast(f)
    f:HookScript("PreClick", function(self)
        if self.unit == "player" then return end
        self.qcAuto = cvarGet("autoSelfCast")
        if self.qcAuto ~= nil then cvarSet("autoSelfCast", "0") end
    end)
    f:HookScript("PostClick", function(self)
        if self.qcAuto == nil then return end
        local st = rawget(_G, "SpellIsTargeting")
        if st and st() and rawget(_G, "SpellStopTargeting") then pcall(SpellStopTargeting) end
        cvarSet("autoSelfCast", self.qcAuto)
        self.qcAuto = nil
    end)
end

local function createUnit(unit, gname)
    local f = CreateFrame("Button", gname, UIParent, "SecureUnitButtonTemplate")
    f.unit = unit
    f:SetAttribute("unit", unit)
    f:SetAttribute("type1", "target")
    f:SetAttribute("type2", "togglemenu")
    f:RegisterForClicks("AnyUp")
    guardSelfCast(f)
    f:SetMovable(true); f:SetClampedToScreen(true)
    f.bg = f:CreateTexture(nil, "BACKGROUND")
    f.bg:SetTexture(WHITE); f.bg:SetVertexColor(0, 0, 0, 0.6); f.bg:SetAllPoints()
    f.edges = border(f, 0, 0, 0, 1)
    f.portrait = f:CreateTexture(nil, "ARTWORK")
    f.portrait:SetTexCoord(0.12, 0.88, 0.12, 0.88)
    f.hp = CreateFrame("StatusBar", nil, f)
    f.hp.bg = f.hp:CreateTexture(nil, "BACKGROUND")
    f.hp.bg:SetAllPoints(); f.hp.bg:SetTexture(WHITE); f.hp.bg:SetVertexColor(0.15, 0.03, 0.03, 0.9)
    f.pw = CreateFrame("StatusBar", nil, f)
    f.pw.bg = f.pw:CreateTexture(nil, "BACKGROUND")
    f.pw.bg:SetAllPoints(); f.pw.bg:SetTexture(WHITE); f.pw.bg:SetVertexColor(0.03, 0.05, 0.15, 0.9)
    local function fs(parent) local t = parent:CreateFontString(nil, "OVERLAY") t:SetShadowOffset(1, -1) t:SetWordWrap(false) return t end
    f.name = fs(f.hp); f.lvl = fs(f.hp); f.hpText = fs(f.hp); f.pwText = fs(f.pw)
    if unit == "player" then
        f.rest = f:CreateTexture(nil, "OVERLAY")
        f.rest:SetTexture("Interface\\CharacterFrame\\UI-StateIcon"); f.rest:SetTexCoord(0, 0.5, 0, 0.421875)
        f.rest:SetSize(18, 18); f.rest:SetPoint("CENTER", f.portrait, "TOPLEFT", 2, -2)
        f.combat = f:CreateTexture(nil, "OVERLAY")
        f.combat:SetTexture("Interface\\CharacterFrame\\UI-StateIcon"); f.combat:SetTexCoord(0.5, 1, 0, 0.484375)
        f.combat:SetSize(18, 18); f.combat:SetPoint("CENTER", f.portrait, "BOTTOMRIGHT", -2, 2)
    end
    f:SetScript("OnEnter", function(self)
        if GameTooltip_SetDefaultAnchor then GameTooltip_SetDefaultAnchor(GameTooltip, self) else GameTooltip:SetOwner(self, "ANCHOR_BOTTOMRIGHT") end
        GameTooltip:SetUnit(self.unit); GameTooltip:Show()
    end)
    f:SetScript("OnLeave", function() GameTooltip:Hide() end)
    -- клиент может отдать неожиданные значения: ошибка не должна сыпаться окнами
    f:SetScript("OnEvent", function(self) pcall(updateUnit, self) end)
    f:HookScript("OnShow", function(self) pcall(updateUnit, self) end)
    for _, ev in ipairs(UNIT_EVENTS) do pcall(f.RegisterUnitEvent, f, ev, unit) end
    local evs = unit == "player"
        and { "PLAYER_ENTERING_WORLD", "PLAYER_LEVEL_UP", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "PLAYER_UPDATE_RESTING", "PLAYER_DEAD", "PLAYER_ALIVE", "PLAYER_UNGHOST" }
        or { "PLAYER_TARGET_CHANGED", "PLAYER_ENTERING_WORLD", "GROUP_ROSTER_UPDATE" }
    for _, ev in ipairs(evs) do pcall(f.RegisterEvent, f, ev) end
    return f
end

-- размеры и расположение частей рамки; mirror — портрет справа (рамка цели)
local function layoutUnit(f, c, def, field, mirror)
    local h = c.h
    local ph = c.power and math.max(6, math.floor(h * 0.5)) or 0
    local total = 2 + h + (c.power and (1 + ph) or 0) + 2
    local showP = c.pmode ~= "none"
    local port = showP and total or 0
    f:SetSize(c.w + port, total)
    f:SetScale(c.scale / 100)
    if c[field] or not f.dockTo then
        place(f, c[field], def)
    else
        f:ClearAllPoints(); f:SetPoint("TOPLEFT", f.dockTo, "TOPRIGHT", 8, 0)
    end
    f.portrait:ClearAllPoints()
    if mirror then f.portrait:SetPoint("TOPRIGHT", -1, -1) else f.portrait:SetPoint("TOPLEFT", 1, -1) end
    f.portrait:SetSize(math.max(1, port - 2), total - 2)
    f.portrait:SetShown(showP)
    local tex = TEX[c.tex] or TEX.smooth
    f.hp:SetStatusBarTexture(tex); f.pw:SetStatusBarTexture(tex)
    f.hp:ClearAllPoints()
    if mirror then f.hp:SetPoint("TOPLEFT", 2, -2); f.hp:SetPoint("TOPRIGHT", -(port + 2), -2)
    else f.hp:SetPoint("TOPLEFT", port + 2, -2); f.hp:SetPoint("TOPRIGHT", -2, -2) end
    f.hp:SetHeight(h)
    f.pw:ClearAllPoints(); f.pw:SetPoint("TOPLEFT", f.hp, "BOTTOMLEFT", 0, -1); f.pw:SetPoint("TOPRIGHT", f.hp, "BOTTOMRIGHT", 0, -1)
    f.pw:SetHeight(math.max(1, ph)); f.pw:SetShown(c.power)
    local big = math.max(9, math.floor(h * 0.55))
    nameFont(f.name, big); f.lvl:SetFont(FONT, big, "OUTLINE"); f.hpText:SetFont(FONT, big, "OUTLINE")
    f.pwText:SetFont(FONT, math.max(8, math.floor(ph * 0.8)), "OUTLINE")
    f.lvl:SetShown(c.level ~= false); f.name:SetShown(c.name ~= false)
    f.lvl:ClearAllPoints(); f.lvl:SetPoint("LEFT", 4, 0)
    f.name:ClearAllPoints()
    if c.level ~= false then f.name:SetPoint("LEFT", f.lvl, "RIGHT", 4, 0) else f.name:SetPoint("LEFT", 4, 0) end
    f.name:SetPoint("RIGHT", f.hpText, "LEFT", -4, 0)
    f.name:SetJustifyH("LEFT")
    f.hpText:ClearAllPoints(); f.hpText:SetPoint("RIGHT", -4, 0)
    f.pwText:ClearAllPoints(); f.pwText:SetPoint("CENTER", 0, 0)
    f.pwText:SetShown(ph >= 8)
    applyLook(f)
end

function F:ApplyPF()
    local c = db().pf
    -- полосы стали короче: прежние варианты размера переводим в новые (один раз)
    if c.pmode == nil then c.pmode = (c.portrait == false) and "none" or "face" end
    if not c.short then
        local MAP = { [170] = 120, [220] = 150, [270] = 180, [320] = 210 }
        if MAP[c.w] then c.w = MAP[c.w] end
        if c.h == 28 then c.h = 26 elseif c.h == 34 then c.h = 30 end
        c.short = true
    end
    protected("pf", function()
        -- защищённые рамки создаём только вне боя
        if c.on and not frames.player then frames.player = createUnit("player", "QuestCompassPlayerFrame") end
        if c.on and c.target and not frames.target then frames.target = createUnit("target", "QuestCompassTargetFrame") end
        -- своя рамка включена — стандартная прячется сама
        hideBlizz(blizz("PlayerFrame"), c.on)
        hideBlizz(blizz("TargetFrame"), c.on and c.target)
        local p = frames.player
        if p then
            if c.on then layoutUnit(p, c, PF_DEF, "pt", false); applyClicks(p); p:Show(); pcall(updateUnit, p) else p:Hide() end
        end
        local t = frames.target
        if t then
            if c.on and c.target then
                t.dockTo = c.on and p or nil -- пока её не двигали мышью, стоит рядом с рамкой игрока
                layoutUnit(t, c, TF_DEF, "tpt", true)
                RegisterUnitWatch(t) -- показывается сама, когда есть цель
                pcall(updateUnit, t)
            else
                UnregisterUnitWatch(t); t:Hide()
            end
        end
    end)
end

---------------------------------------------------------------------------
-- Группа и рейд: рамки группы — как рамка игрока, рейд — сетка 8×5.
-- В рейде видна сетка, в группе — рамки группы (переключает сама игра: RegisterStateDriver).
---------------------------------------------------------------------------
local anchors, raidCells = {}, {}
local PARTY_DEF = { "TOPLEFT", "TOPLEFT", 30, -110 }
local RAID_DEF = { "TOPLEFT", "TOPLEFT", 30, -300 }
local RAID_SIZES = { s = { 58, 28 }, m = { 72, 34 }, l = { 90, 42 } }

local function anchorFor(key)
    if anchors[key] then return anchors[key] end
    local a = CreateFrame("Frame", "QuestCompass" .. key .. "Anchor", UIParent)
    a:SetMovable(true); a:SetClampedToScreen(true); a:SetSize(10, 10)
    anchors[key] = a
    return a
end

local function updateCell(f)
    if not f or not f:IsShown() then return end
    local u = f.unit
    if not UnitExists(u) then return end
    local hp, mx = UnitHealth(u), UnitHealthMax(u)
    setBar(f.hp, hp, mx)
    local online = not UnitIsConnected or UnitIsConnected(u)
    local r, g, b = unitColor(u)
    if not online then r, g, b = 0.4, 0.4, 0.4 end
    f.hp:SetStatusBarColor(r, g, b)
    f.hp.bg:SetVertexColor(r * 0.22, g * 0.22, b * 0.22, 0.95)
    if not pcall(f.name.SetText, f.name, (UnitName(u))) then f.name:SetText("") end
    local st = ""
    if not online then st = L("fr_offline")
    elseif UnitIsDeadOrGhost(u) then st = L(UnitIsGhost(u) and "fr_ghost" or "fr_dead") end
    f.status:SetText(st)
end

local CELL_EVENTS = { "UNIT_HEALTH", "UNIT_HEALTH_FREQUENT", "UNIT_MAXHEALTH", "UNIT_NAME_UPDATE", "UNIT_CONNECTION", "UNIT_FLAGS" }

local function createCell(i, parent)
    local f = CreateFrame("Button", "QuestCompassRaid" .. i, parent, "SecureUnitButtonTemplate")
    f.unit = "raid" .. i
    f:SetAttribute("unit", f.unit)
    f:SetAttribute("type1", "target")
    f:SetAttribute("type2", "togglemenu")
    f:RegisterForClicks("AnyUp")
    guardSelfCast(f)
    f.bg = f:CreateTexture(nil, "BACKGROUND")
    f.bg:SetTexture(WHITE); f.bg:SetVertexColor(0, 0, 0, 0.75); f.bg:SetAllPoints()
    f.edges = border(f, 0, 0, 0, 1)
    f.hp = CreateFrame("StatusBar", nil, f)
    f.hp:SetPoint("TOPLEFT", 1, -1); f.hp:SetPoint("BOTTOMRIGHT", -1, 1)
    f.hp.bg = f.hp:CreateTexture(nil, "BACKGROUND")
    f.hp.bg:SetAllPoints(); f.hp.bg:SetTexture(WHITE)
    f.name = f.hp:CreateFontString(nil, "OVERLAY")
    f.name:SetPoint("TOP", 0, -3); f.name:SetPoint("LEFT", 3, 0); f.name:SetPoint("RIGHT", -3, 0)
    f.name:SetWordWrap(false); f.name:SetJustifyH("CENTER")
    f.status = f.hp:CreateFontString(nil, "OVERLAY")
    f.status:SetFont(FONT, 9, "OUTLINE"); f.status:SetPoint("BOTTOM", 0, 3)
    f:SetScript("OnEnter", function(self)
        if GameTooltip_SetDefaultAnchor then GameTooltip_SetDefaultAnchor(GameTooltip, self) else GameTooltip:SetOwner(self, "ANCHOR_BOTTOMRIGHT") end
        GameTooltip:SetUnit(self.unit); GameTooltip:Show()
    end)
    f:SetScript("OnLeave", function() GameTooltip:Hide() end)
    f:SetScript("OnEvent", function(self) pcall(updateCell, self) end)
    f:HookScript("OnShow", function(self) pcall(updateCell, self) end)
    for _, ev in ipairs(CELL_EVENTS) do pcall(f.RegisterUnitEvent, f, ev, f.unit) end
    for _, ev in ipairs({ "GROUP_ROSTER_UPDATE", "PLAYER_ENTERING_WORLD" }) do pcall(f.RegisterEvent, f, ev) end
    return f
end

function F:ApplyGroup()
    local c = db()
    protected("grp", function()
        local pc, rc, look = c.party, c.raid, c.pf
        -- группа: стандартные рамки группы прячутся, свои — под рамкой игрока
        hideBlizz(blizz("PartyFrame"), pc.on)
        for i = 1, 4 do hideBlizz(blizz("PartyMemberFrame" .. i), pc.on) end
        hideBlizz(blizz("CompactPartyFrame"), pc.on)
        if pc.on then
            local a = anchorFor("Party")
            place(a, pc.pt, PARTY_DEF)
            local step
            for i = 1, 4 do
                local key = "party" .. i
                local f = frames[key] or createUnit(key, "QuestCompassParty" .. i)
                frames[key] = f
                f:SetParent(a)
                applyClicks(f)
                layoutUnit(f, look, PARTY_DEF, "nopos", false)
                f:SetScale(look.scale / 100 * 0.9)
                step = f:GetHeight() + 8
                f:ClearAllPoints(); f:SetPoint("TOPLEFT", a, "TOPLEFT", 0, -(i - 1) * step)
                RegisterUnitWatch(f)
            end
            local f1 = frames.party1
            a:SetSize(f1:GetWidth() * f1:GetScale(), 4 * step * f1:GetScale())
            RegisterStateDriver(a, "visibility", "[group:raid] hide; [group:party] show; hide")
        elseif anchors.Party then
            UnregisterStateDriver(anchors.Party, "visibility"); anchors.Party:Hide()
            for i = 1, 4 do local f = frames["party" .. i] if f then UnregisterUnitWatch(f); f:Hide() end end
        end
        -- рейд: сетка по 5 в столбце
        hideBlizz(blizz("CompactRaidFrameManager"), rc.on)
        hideBlizz(blizz("CompactRaidFrameContainer"), rc.on)
        if rc.on then
            local a = anchorFor("Raid")
            place(a, rc.pt, RAID_DEF)
            local sz = RAID_SIZES[rc.size] or RAID_SIZES.m
            local w, h, gap = sz[1], sz[2], 3
            for i = 1, 40 do
                local f = raidCells[i] or createCell(i, a)
                raidCells[i] = f
                applyClicks(f)
                f:SetSize(w, h)
                local col, row = math.floor((i - 1) / 5), (i - 1) % 5
                f:ClearAllPoints(); f:SetPoint("TOPLEFT", a, "TOPLEFT", col * (w + gap), -row * (h + gap))
                f.hp:SetStatusBarTexture(TEX[look.tex] or TEX.flat)
                nameFont(f.name, h >= 34 and 11 or 9)
                f.name:SetShown(rc.names)
                applyLook(f)
                RegisterUnitWatch(f)
            end
            a:SetSize(8 * (w + gap), 5 * (h + gap))
            RegisterStateDriver(a, "visibility", "[group:raid] show; hide")
        elseif anchors.Raid then
            UnregisterStateDriver(anchors.Raid, "visibility"); anchors.Raid:Hide()
            for _, f in ipairs(raidCells) do UnregisterUnitWatch(f); f:Hide() end
        end
    end)
end

-- кто далеко (вне досягаемости заклинаний) — полупрозрачный
local function inRange(u)
    local f = rawget(_G, "UnitInRange")
    if not f then return true end
    local ok, a, checked = pcall(f, u)
    if not ok or issecret(a) or issecret(checked) or checked == false then return true end
    return a and true or false
end
local rangeFrame = CreateFrame("Frame")
local rAcc = 0
rangeFrame:SetScript("OnUpdate", function(_, dt)
    rAcc = rAcc + dt
    if rAcc < 0.5 then return end
    rAcc = 0
    local c = FG.db and db()
    if not c then return end
    local fade = c.raid.range
    for i = 1, 4 do
        local f = frames["party" .. i]
        if f and f:IsVisible() then f:SetAlpha((fade and not inRange(f.unit)) and 0.45 or 1) end
    end
    for _, f in ipairs(raidCells) do
        if f:IsVisible() then f:SetAlpha((fade and not inRange(f.unit)) and 0.45 or 1) end
    end
end)

---------------------------------------------------------------------------
-- Готовые стили: одна кнопка ставит все настройки и включает все рамки
---------------------------------------------------------------------------
local STYLES = {
    dark = {
        look = "dark",
        pf = { tex = "flat", color = "class", text = "pct", pmode = "class", power = true, name = true, level = true, w = 150, h = 22, scale = 100 },
        bf = { timers = true, size = 32, grow = "left" },
        xp = { ticks = false, text = "full", rested = true },
        raid = { size = "m", names = true, range = true },
    },
    classic = {
        look = "classic",
        pf = { tex = "classic", color = "green", text = "both", pmode = "face", power = true, name = true, level = true, w = 180, h = 26, scale = 100 },
        bf = { timers = true, size = 32, grow = "left" },
        xp = { ticks = true, text = "full", rested = true },
        raid = { size = "l", names = true, range = true },
    },
    min = {
        look = "min",
        pf = { tex = "flat", color = "class", text = "none", pmode = "none", power = false, name = true, level = false, w = 120, h = 18, scale = 100 },
        bf = { timers = true, size = 26, grow = "left" },
        xp = { ticks = false, text = "pct", rested = true },
        raid = { size = "s", names = true, range = true },
    },
}
function F:ApplyStyle(name)
    local st = STYLES[name]
    if not st then return end
    if InCombatLockdown() then FG:Print(L("fr_combat")) return end
    local c = db()
    c.look = st.look
    for part, vals in pairs(st) do
        if type(vals) == "table" then for k, v in pairs(vals) do c[part][k] = v end end
    end
    c.pf.on, c.pf.target, c.party.on, c.raid.on, c.bf.on, c.xp.on = true, true, true, true, true, true
    F:ApplyAll()
    if F.unlocked then F:SetUnlocked(true) end
    FG:Print(L("fr_style_set", L("fr_style_" .. name)))
    if page and page.Refresh then page.Refresh() end
end

---------------------------------------------------------------------------
-- Полоса опыта
---------------------------------------------------------------------------
local xb
local XP_DEF = { "BOTTOM", "BOTTOM", 0, 110 }
local XP_C, REST_C = { 0.58, 0, 0.55 }, { 0, 0.39, 0.88 }

-- 12848 → «12 848»: так длинные числа на полосе читаются легче
local function group(n)
    local s = tostring(math.floor(n + 0.5))
    local out = s:reverse():gsub("(%d%d%d)", "%1 "):reverse()
    return (out:gsub("^ ", ""))
end

-- стандартная полоса опыта игры: на неё кладём свой текст
local XP_BLIZZ = { "MainMenuExpBar", "MainStatusTrackingBarContainer", "StatusTrackingBarManager" }
local function blizzXPBar()
    for _, n in ipairs(XP_BLIZZ) do
        local f = blizz(n)
        if f and f.GetWidth and (f:GetWidth() or 0) > 50 then return f end
    end
end

local function maxLevel()
    local m = rawget(_G, "GetMaxPlayerLevel") and safe(GetMaxPlayerLevel)
    return tonumber(m) or rawget(_G, "MAX_PLAYER_LEVEL") or 60
end

local function updateXP()
    if not xb then return end
    local c = db().xp
    if not c.on or (UnitLevel("player") or 1) >= maxLevel() then xb:Hide() return end
    xb:Show()
    local cur, max = UnitXP("player") or 0, UnitXPMax("player") or 1
    local rest = (GetXPExhaustion and GetXPExhaustion()) or 0
    if not (plain(cur) and plain(max) and plain(rest)) then
        -- скрытые числа: полоса и текст без расчётов
        setBar(xb.bar, cur, max); xb.rest:Hide()
        xb.bar:SetStatusBarColor(XP_C[1], XP_C[2], XP_C[3])
        setValueText(xb.text, cur, max, (c.text == "none" or c.text == "pct") and c.text or "value")
        return
    end
    xb.bar:SetMinMaxValues(0, math.max(1, max)); xb.bar:SetValue(cur)
    xb.rest:SetMinMaxValues(0, math.max(1, max)); xb.rest:SetValue(math.min(max, cur + rest))
    xb.rest:SetShown(c.rested and rest > 0)
    local col = (rest > 0 and c.rested) and REST_C or XP_C
    xb.bar:SetStatusBarColor(col[1], col[2], col[3])
    local pct = string.format("%.1f%%", cur / math.max(1, max) * 100)
    -- коротко: отдых виден заливкой, уровень и подробности — в подсказке при наведении
    local t
    if c.text == "none" then t = ""
    elseif c.text == "pct" then t = pct
    elseif c.text == "left" then t = L("fr_xp_left", group(max - cur))
    else t = group(cur) .. " / " .. group(max) .. "  (" .. pct .. ")" end
    xb.text:SetText(t)
end

local function createXP()
    xb = CreateFrame("Frame", "QuestCompassXPBar", UIParent)
    xb:SetMovable(true); xb:SetClampedToScreen(true); xb:EnableMouse(true)
    xb.bg = xb:CreateTexture(nil, "BACKGROUND")
    xb.bg:SetTexture(WHITE); xb.bg:SetVertexColor(0, 0, 0, 0.6); xb.bg:SetAllPoints()
    xb.edges = border(xb, 0, 0, 0, 1)
    xb.rest = CreateFrame("StatusBar", nil, xb)
    xb.rest:SetPoint("TOPLEFT", 1, -1); xb.rest:SetPoint("BOTTOMRIGHT", -1, 1)
    xb.rest:SetStatusBarColor(REST_C[1], REST_C[2], REST_C[3], 0.35)
    xb.bar = CreateFrame("StatusBar", nil, xb)
    xb.bar:SetPoint("TOPLEFT", 1, -1); xb.bar:SetPoint("BOTTOMRIGHT", -1, 1)
    -- 20 делений, как у полосы опыта в игре
    xb.ticks = {}
    for i = 1, 19 do
        local t = xb.bar:CreateTexture(nil, "OVERLAY")
        t:SetTexture(WHITE); t:SetVertexColor(0, 0, 0, 0.45); t:SetWidth(1)
        xb.ticks[i] = t
    end
    xb.top = CreateFrame("Frame", nil, xb)
    xb.top:SetAllPoints(); xb.top:SetFrameLevel(xb.bar:GetFrameLevel() + 5)
    xb.text = xb.top:CreateFontString(nil, "OVERLAY")
    xb.text:SetShadowOffset(1, -1); xb.text:SetPoint("CENTER", 0, 0)
    xb:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        local cur, max = UnitXP("player") or 0, UnitXPMax("player") or 1
        local rest = (GetXPExhaustion and GetXPExhaustion()) or 0
        GameTooltip:AddLine(L("fr_xp_tip_title", UnitLevel("player") or 0), 1, 0.82, 0)
        if plain(cur) and plain(max) and plain(rest) then
            GameTooltip:AddDoubleLine(L("fr_xp_tip_have"), cur .. " / " .. max, 1, 1, 1, 1, 1, 1)
            GameTooltip:AddDoubleLine(L("fr_xp_tip_left"), tostring(max - cur), 1, 1, 1, 1, 1, 1)
            if rest > 0 then GameTooltip:AddDoubleLine(L("fr_xp_tip_rest"), tostring(rest), 0.4, 0.7, 1, 0.4, 0.7, 1) end
        end
        GameTooltip:Show()
    end)
    xb:SetScript("OnLeave", function() GameTooltip:Hide() end)
    xb:SetScript("OnEvent", function() pcall(updateXP) end)
    for _, ev in ipairs({ "PLAYER_XP_UPDATE", "UPDATE_EXHAUSTION", "PLAYER_LEVEL_UP", "PLAYER_ENTERING_WORLD", "PLAYER_UPDATE_RESTING" }) do
        pcall(xb.RegisterEvent, xb, ev)
    end
end

function F:ApplyXP()
    local c = db().xp
    if c.on and not xb then createXP() end
    -- стандартную полосу больше не прячем (если раньше спрятали — возвращаем)
    for _, n in ipairs({ "MainMenuExpBar", "ExhaustionTick", "MainStatusTrackingBarContainer", "StatusTrackingBarManager" }) do
        hideBlizz(blizz(n), false)
    end
    if not xb then return end
    if not c.on then xb:Hide() return end
    local blz = blizzXPBar()
    F.xpOverlay = blz and true or false
    local w, h = c.w, c.h
    if blz then
        -- поверх стандартной полосы: она остаётся как есть, от нас — только крупный текст
        xb:ClearAllPoints(); xb:SetAllPoints(blz)
        xb:SetFrameStrata(blz:GetFrameStrata() or "MEDIUM"); xb:SetFrameLevel((blz:GetFrameLevel() or 1) + 10)
        w, h = blz:GetWidth() or w, blz:GetHeight() or h
        xb.bg:SetAlpha(0); xb.bar:SetAlpha(0); xb.rest:SetAlpha(0)
        for _, e in ipairs(xb.edges) do e:SetAlpha(0) end
        for _, t in ipairs(xb.ticks) do t:Hide() end
    else
        -- стандартной нет — своя полоса
        xb:SetSize(w, h)
        place(xb, c.pt, XP_DEF)
        xb.bg:SetAlpha(1); xb.bar:SetAlpha(1); xb.rest:SetAlpha(1)
        for _, e in ipairs(xb.edges) do e:SetAlpha(1) end
        xb.bar:SetStatusBarTexture(TEX.smooth); xb.rest:SetStatusBarTexture(TEX.smooth)
        xb.rest:SetStatusBarColor(REST_C[1], REST_C[2], REST_C[3], 0.35)
        for i, t in ipairs(xb.ticks) do
            t:ClearAllPoints(); t:SetPoint("TOP", xb.bar, "TOPLEFT", (w - 2) * i / 20, 0); t:SetPoint("BOTTOM", xb.bar, "BOTTOMLEFT", (w - 2) * i / 20, 0)
            t:SetShown(c.ticks ~= false)
        end
    end
    xb.text:SetFont(FONT, math.max(11, math.min(14, math.floor(h) + 1)), "OUTLINE")
    xb.text:SetShown(true)
    pcall(updateXP)
end

---------------------------------------------------------------------------
-- Баффы и дебаффы: свои панели аур; ПКМ по баффу снимает его (вне боя)
---------------------------------------------------------------------------
local hdr = {}
local BF_DEF = { "TOPRIGHT", "TOPRIGHT", -215, -14 }
local DF_DEF = { "TOPRIGHT", "TOPRIGHT", -215, -120 }

local function auraData(index, filter)
    if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
        local a = C_UnitAuras.GetAuraDataByIndex("player", index, filter)
        if a then return a.icon, a.applications, a.duration, a.expirationTime, a.dispelName, a.auraInstanceID end
        return nil
    end
    local name, icon, count, dtype, duration, expires = UnitAura("player", index, filter)
    if name then return icon, count, duration, expires, dtype end
end

-- есть ли аура с таким номером (без сравнения её полей: они могут быть «скрытыми»)
local function auraExists(index, filter)
    if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
        return C_UnitAuras.GetAuraDataByIndex("player", index, filter) ~= nil
    end
    return UnitAura("player", index, filter) ~= nil
end

local function timeText(s)
    if s >= 3600 then return math.floor(s / 3600 + 0.5) .. L("fr_h") end
    if s >= 60 then return math.floor(s / 60 + 0.5) .. L("fr_m") end
    return math.floor(s + 0.5) .. ""
end

local function styleAura(b)
    if b.qcIcon then return end
    b.qcIcon = b:CreateTexture(nil, "ARTWORK")
    b.qcIcon:SetAllPoints(); b.qcIcon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    -- затемнение по таймеру (сама игра считает время, работает и со скрытыми числами)
    b.qcCD = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
    b.qcCD:SetAllPoints(); b.qcCD:SetReverse(true); b.qcCD:SetDrawEdge(false)
    if b.qcCD.SetDrawBling then b.qcCD:SetDrawBling(false) end
    b.qcBorder = border(b, 0, 0, 0, 1)
    local over = CreateFrame("Frame", nil, b)
    over:SetAllPoints(); over:SetFrameLevel(b.qcCD:GetFrameLevel() + 2)
    b.qcCount = over:CreateFontString(nil, "OVERLAY")
    b.qcCount:SetFont(FONT, 12, "OUTLINE"); b.qcCount:SetPoint("BOTTOMRIGHT", 1, 1)
    b.qcTime = over:CreateFontString(nil, "OVERLAY")
    b.qcTime:SetFont(FONT, 11, "OUTLINE"); b.qcTime:SetPoint("TOP", b, "BOTTOM", 0, -1)
end

local function setCooldown(cd, duration, expires)
    cd:Clear()
    if plain(duration) and plain(expires) then
        if duration > 0 then cd:SetCooldown(expires - duration, duration) end
        return true
    end
    -- скрытые числа: пусть игра сама поставит таймер
    if cd.SetCooldownFromExpirationTime then return pcall(cd.SetCooldownFromExpirationTime, cd, expires, duration) end
    return false
end

local function updateAura(b)
    local index, filter = b.index, b.filter or "HELPFUL"
    if not index then return end
    styleAura(b)
    if not auraExists(index, filter) then return end
    local icon, count, duration, expires, dtype, inst = auraData(index, filter)
    local c = db().bf
    b.qcIcon:SetTexture(icon)
    -- стаки
    if plain(count) then
        b.qcCount:SetText(count > 1 and count or "")
    else
        local f = C_UnitAuras and C_UnitAuras.GetAuraApplicationDisplayCount
        local ok = inst and f and pcall(function() b.qcCount:SetText(f("player", inst, 2, 99)) end)
        if not ok then b.qcCount:SetText("") end
    end
    -- таймер: числа под иконкой, если можно посчитать; иначе — отсчёт самой игры на иконке
    local hasCD = setCooldown(b.qcCD, duration, expires)
    if plain(duration) and plain(expires) then
        b.qcExpires = duration > 0 and expires or nil
        b.qcTime:SetShown(c.timers)
        if b.qcCD.SetHideCountdownNumbers then b.qcCD:SetHideCountdownNumbers(true) end
    else
        b.qcExpires = nil
        b.qcTime:Hide()
        if b.qcCD.SetHideCountdownNumbers then b.qcCD:SetHideCountdownNumbers(not (c.timers and hasCD)) end
    end
    b.qcCD:SetShown(hasCD and true or false)
    local col = { r = 0, g = 0, b = 0 }
    if filter == "HARMFUL" then
        local dc = rawget(_G, "DebuffTypeColor")
        local key = (type(dtype) == "string" and not issecret(dtype)) and dtype or "none"
        col = (dc and (dc[key] or dc.none)) or { r = 0.8, g = 0, b = 0 }
    end
    for _, e in ipairs(b.qcBorder) do e:SetVertexColor(col.r, col.g, col.b, 1) end
end

-- подсказка по ауре; ПКМ по баффу снимает его (вне боя — так разрешает игра)
local function auraEnter(self)
    if not self.index then return end
    GameTooltip:SetOwner(self, "ANCHOR_BOTTOMLEFT")
    if GameTooltip.SetUnitAura then pcall(GameTooltip.SetUnitAura, GameTooltip, "player", self.index, self.filter) end
    if self.filter == "HELPFUL" then GameTooltip:AddLine(L("fr_cancel_tip"), 0.6, 0.6, 0.6) end
    GameTooltip:Show()
end
local function auraClick(self, btn)
    if btn ~= "RightButton" or self.filter ~= "HELPFUL" or not self.index then return end
    if InCombatLockdown() then FG:Print(L("fr_cancel_combat")) return end
    local f = rawget(_G, "CancelUnitBuff")
    if f then pcall(f, "player", self.index, self.filter) end
end

local MAX_AURAS = 40

-- панель аур: обычные кнопки, расставленные рядами (защищённая панель игры в этом клиенте недоступна)
local function createPanel(key, filter)
    local p = CreateFrame("Frame", "QuestCompass" .. key, UIParent)
    p.filter = filter
    p:SetMovable(true); p:SetClampedToScreen(true)
    p.buttons = {}
    p:SetScript("OnEvent", function(self) pcall(F.UpdatePanel, F, self) end)
    pcall(p.RegisterUnitEvent, p, "UNIT_AURA", "player")
    pcall(p.RegisterEvent, p, "PLAYER_ENTERING_WORLD")
    hdr[key] = p
    return p
end

local function auraButton(p, i)
    local b = p.buttons[i]
    if b then return b end
    b = CreateFrame("Button", nil, p)
    b:SetSize(AURA, AURA)
    b.filter = p.filter
    b:RegisterForClicks("RightButtonUp")
    b:SetScript("OnEnter", auraEnter)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:SetScript("OnClick", auraClick)
    p.buttons[i] = b
    return b
end

-- расставить и заполнить кнопки по текущим аурам
function F:UpdatePanel(p)
    local c = db().bf
    local gap = 4
    local step = AURA + gap
    local rowH = AURA + gap + (c.timers and 13 or 0)
    local left = c.grow == "left"
    local n = 0
    for i = 1, MAX_AURAS do
        if not auraExists(i, p.filter) then break end
        n = i
        local b = auraButton(p, i)
        b.index = i
        local col, row = (i - 1) % c.row, math.floor((i - 1) / c.row)
        b:ClearAllPoints()
        if left then b:SetPoint("TOPRIGHT", p, "TOPRIGHT", -col * step, -row * rowH)
        else b:SetPoint("TOPLEFT", p, "TOPLEFT", col * step, -row * rowH) end
        b:Show()
        pcall(updateAura, b)
    end
    for i = n + 1, #p.buttons do p.buttons[i]:Hide(); p.buttons[i].index = nil end
    p:SetSize(c.row * step, math.max(1, math.ceil(math.max(n, 1) / c.row)) * rowH)
end

local function children(p)
    local i = 0
    return function()
        i = i + 1
        return p.buttons and p.buttons[i]
    end
end

-- таймеры аур: раз в 0,2 с
local ticker = CreateFrame("Frame")
local tAcc = 0
ticker:SetScript("OnUpdate", function(_, dt)
    tAcc = tAcc + dt
    if tAcc < 0.2 then return end
    tAcc = 0
    local now = GetTime()
    for _, h in pairs(hdr) do
        if h:IsShown() then
            for b in children(h) do
                if b:IsShown() and b.qcTime then
                    if b.qcExpires then
                        local left = b.qcExpires - now
                        b.qcTime:SetText(left > 0 and timeText(left) or "")
                        if left > 0 and left < 10 then b.qcTime:SetTextColor(1, 0.3, 0.3) else b.qcTime:SetTextColor(1, 1, 1) end
                    else
                        b.qcTime:SetText("")
                    end
                end
            end
        end
    end
end)

function F:ApplyBF()
    local c = db().bf
    if c.on and not hdr.Buffs then
        createPanel("Buffs", "HELPFUL")
        createPanel("Debuffs", "HARMFUL")
    end
    protected("bf", function()
        hideBlizz(blizz("BuffFrame"), c.on) -- свои баффы включены — стандартные прячутся сами
        hideBlizz(blizz("DebuffFrame"), c.on and c.debuffs)
        local b, d = hdr.Buffs, hdr.Debuffs
        if not b then return end
        if not c.on then b:Hide(); d:Hide() return end
        b:SetScale(c.size / AURA); d:SetScale(c.size / AURA)
        place(b, c.pt, BF_DEF); place(d, c.dpt, DF_DEF)
        b:Show(); d:SetShown(c.debuffs)
        pcall(F.UpdatePanel, F, b); pcall(F.UpdatePanel, F, d)
    end)
end

function F:Debug()
    local function kind(v)
        if v == nil then return "nil" end
        if issecret(v) then return "|cffff6060secret|r" end
        return type(v) .. " (" .. tostring(v) .. ")"
    end
    for _, u in ipairs({ "player", "target" }) do
        if UnitExists(u) then
            FG:Print(u .. ": name=" .. kind((UnitName(u))) .. " hp=" .. kind(UnitHealth(u)) .. " max=" .. kind(UnitHealthMax(u))
                .. " power=" .. kind(UnitPower(u)) .. " level=" .. kind(UnitLevel(u)))
            local ok = pcall(string.format, "%s", UnitHealth(u))
            FG:Print("  format(hp)=" .. tostring(ok))
        end
    end
    FG:Print("AbbreviateNumbers=" .. tostring(rawget(_G, "AbbreviateNumbers") ~= nil)
        .. " UnitHealthPercent=" .. tostring(rawget(_G, "UnitHealthPercent") ~= nil)
        .. " CurveConstants=" .. tostring(rawget(_G, "CurveConstants") ~= nil)
        .. " CreateFontFamily=" .. tostring(rawget(_G, "CreateFontFamily") ~= nil))
end

function F:ApplyAll()
    F:ApplyPF(); F:ApplyGroup(); F:ApplyXP(); F:ApplyBF()
end

---------------------------------------------------------------------------
-- «Двигать мышью» (как «Toggle Anchors» в ElvUI): зелёные рамки + сетка на экране,
-- при отпускании рамка прилипает к сетке (с Shift — без прилипания)
---------------------------------------------------------------------------
local movers = {}
local GRID = 16
F.unlocked = false

local grid
local function showGrid(on)
    if not on then if grid then grid:Hide() end return end
    if not grid then
        grid = CreateFrame("Frame", nil, UIParent)
        grid:SetAllPoints(UIParent); grid:SetFrameStrata("BACKGROUND")
        grid.lines = {}
    end
    for _, t in ipairs(grid.lines) do t:Hide() end
    local w, h = UIParent:GetWidth(), UIParent:GetHeight()
    local n = 0
    local function line(vert, pos, center)
        n = n + 1
        local t = grid.lines[n]
        if not t then t = grid:CreateTexture(nil, "BACKGROUND"); t:SetTexture(WHITE); grid.lines[n] = t end
        t:ClearAllPoints()
        if center then t:SetVertexColor(1, 0.2, 0.2, 0.6) else t:SetVertexColor(0, 0, 0, 0.35) end
        if vert then t:SetPoint("TOP", grid, "TOPLEFT", pos, 0); t:SetSize(1, h)
        else t:SetPoint("LEFT", grid, "TOPLEFT", 0, -pos); t:SetSize(w, 1) end
        t:Show()
    end
    local step = GRID * 4
    for x = w / 2, w, step do line(true, x, x == w / 2) end
    for x = w / 2 - step, 0, -step do line(true, x) end
    for y = h / 2, h, step do line(false, y, y == h / 2) end
    for y = h / 2 - step, 0, -step do line(false, y) end
    grid:Show()
end

local function moverFor(key)
    if movers[key] then return movers[key] end
    local m = CreateFrame("Frame", nil, UIParent)
    m:SetFrameStrata("DIALOG")
    m.bg = m:CreateTexture(nil, "BACKGROUND")
    m.bg:SetTexture(WHITE); m.bg:SetVertexColor(0.1, 0.75, 0.3, 0.35); m.bg:SetAllPoints()
    border(m, 0.25, 1, 0.45, 1)
    m.text = m:CreateFontString(nil, "OVERLAY")
    m.text:SetFont(FONT, 12, "OUTLINE"); m.text:SetPoint("CENTER")
    m:EnableMouse(true)
    m:RegisterForDrag("LeftButton")
    m:SetScript("OnEnter", function(self) self.bg:SetVertexColor(0.1, 0.9, 0.35, 0.55) end)
    m:SetScript("OnLeave", function(self) self.bg:SetVertexColor(0.1, 0.75, 0.3, 0.35) end)
    movers[key] = m
    return m
end

local function targets()
    local c = db()
    return {
        { "pf", frames.player, c.pf, "pt", "fr_pf_title", c.pf.on },
        { "tf", frames.target, c.pf, "tpt", "fr_tf_title", c.pf.on and c.pf.target },
        { "party", anchors.Party, c.party, "pt", "fr_party_title", c.party.on },
        { "raid", anchors.Raid, c.raid, "pt", "fr_raid_title", c.raid.on },
        { "xp", xb, c.xp, "pt", "fr_xp_title", c.xp.on and not F.xpOverlay }, -- на стандартной полосе не двигается
        { "bf", hdr.Buffs, c.bf, "pt", "fr_bf_buffs", c.bf.on },
        { "df", hdr.Debuffs, c.bf, "dpt", "fr_bf_debuffs", c.bf.on and c.bf.debuffs },
    }
end

local function snap(f, cfg, field)
    savePoint(f, cfg, field)
    local pt = cfg[field]
    if pt and not IsShiftKeyDown() then
        local s = GRID / (f:GetScale() or 1)
        pt[3] = math.floor(pt[3] / s + 0.5) * s
        pt[4] = math.floor(pt[4] / s + 0.5) * s
        place(f, pt)
    end
end

function F:SetUnlocked(on)
    if on and InCombatLockdown() then FG:Print(L("fr_combat")) return end
    F.unlocked = on and true or false
    local any = false
    for _, t in ipairs(targets()) do
        local key, f, cfg, field, label, shown = t[1], t[2], t[3], t[4], t[5], t[6]
        local m = movers[key]
        if F.unlocked and f and shown then
            m = moverFor(key)
            m:ClearAllPoints(); m:SetAllPoints(f)
            m.text:SetText(L(label))
            m:SetScript("OnDragStart", function() if not InCombatLockdown() then f:StartMoving() end end)
            m:SetScript("OnDragStop", function()
                f:StopMovingOrSizing()
                if f.SetUserPlaced then pcall(f.SetUserPlaced, f, false) end
                snap(f, cfg, field)
            end)
            m:Show()
            any = true
        elseif m then
            m:Hide()
        end
    end
    if F.unlocked and not any then FG:Print(L("fr_nothing")) end
    showGrid(F.unlocked)
    if page and page.Refresh then page.Refresh() end
end
FG:On("PLAYER_REGEN_DISABLED", function() if F.unlocked then F:SetUnlocked(false) end end)

function F:ResetPositions()
    local c = db()
    c.pf.pt, c.pf.tpt, c.xp.pt, c.bf.pt, c.bf.dpt, c.party.pt, c.raid.pt = nil, nil, nil, nil, nil, nil, nil
    F:ApplyAll()
    if F.unlocked then F:SetUnlocked(true) end
end

-- «Вернуть всё как было»: свои рамки выключены, стандартные рамки игры на месте, настройки по умолчанию
local DEFAULTS = {
    pf = { on = false, target = true, pmode = "face", power = true, name = true, level = true, color = "class", text = "both", tex = "flat", w = 150, h = 22, scale = 100 },
    xp = { on = false, hideDef = false, dock = true, rested = true, ticks = true, text = "full", w = 600, h = 14 },
    bf = { on = false, hideDef = false, debuffs = true, timers = true, grow = "left", size = 32, row = 10 },
    party = { on = false, healClicks = true },
    raid = { on = false, size = "m", names = true, range = true },
}
function F:RestoreAll()
    if InCombatLockdown() then FG:Print(L("fr_combat")) return end
    if F.unlocked then F:SetUnlocked(false) end
    local c = db()
    for part, def in pairs(DEFAULTS) do
        c[part] = {}
        for k, v in pairs(def) do c[part][k] = v end
    end
    c.look = "dark"
    c.clicks = nil
    F:ApplyAll()
    FG:Print(L("fr_restored"))
    if page and page.Refresh then page.Refresh() end
end

function F:SyncClicks()
    protected("hfclicks", function()
        if frames.player then applyClicks(frames.player) end
        for i = 1, 4 do if frames["party" .. i] then applyClicks(frames["party" .. i]) end end
        for _, f in ipairs(raidCells) do applyClicks(f) end
    end)
end
-- что можно повесить на клик: заклинания класса по разделам (ID первого ранга, имя и иконку даёт игра)
local CLICK_SPELLS = {
    PRIEST = {
        { "fr_ck_heal", { 2050, 2054, 2060, 2061, 139, 596 } },
        { "fr_ck_shield", { 17 } },
        { "fr_ck_buff", { 1243, 14752, 976, 6346 } },
        { "fr_ck_dispel", { 527, 528, 552 } },
        { "fr_ck_res", { 2006 } },
    },
    DRUID = {
        { "fr_ck_heal", { 5185, 774, 8936, 18562 } },
        { "fr_ck_buff", { 1126, 467 } },
        { "fr_ck_dispel", { 2782, 8946, 2893 } },
        { "fr_ck_res", { 20484 } },
    },
    PALADIN = {
        { "fr_ck_heal", { 635, 19750, 20473, 633 } },
        { "fr_ck_shield", { 1022, 1044 } },
        { "fr_ck_buff", { 19740, 19742, 20217, 1038, 19977 } },
        { "fr_ck_dispel", { 1152, 4987 } },
        { "fr_ck_res", { 7328 } },
    },
    SHAMAN = {
        { "fr_ck_heal", { 331, 8004, 1064 } },
        { "fr_ck_dispel", { 526, 2870 } },
        { "fr_ck_res", { 2008 } },
    },
    MAGE = { { "fr_ck_buff", { 1459, 604, 1008 } }, { "fr_ck_dispel", { 475 } } },
    WARLOCK = { { "fr_ck_buff", { 5697, 132 } } },
}
local function knows(id)
    local f = rawget(_G, "IsPlayerSpell") or rawget(_G, "IsSpellKnown")
    if not f then return true end
    local ok, r = pcall(f, id)
    return (not ok) or (r and true or false)
end
local function spellNameIcon(id)
    if C_Spell and C_Spell.GetSpellInfo then
        local i = safe(C_Spell.GetSpellInfo, id)
        if type(i) == "table" then return i.name, i.iconID end
    end
    if rawget(_G, "GetSpellInfo") then local n, _, ic = safe(GetSpellInfo, id) return n, ic end
end
-- разделы с известными персонажу заклинаниями: { { заголовок, { {name, icon}, ... } }, ... }
function F:ClickChoices()
    local _, cl = UnitClass("player")
    local out = {}
    for _, grp in ipairs(CLICK_SPELLS[cl] or {}) do
        local list = {}
        for _, id in ipairs(grp[2]) do
            local n, ic = spellNameIcon(id)
            if n and knows(id) then list[#list + 1] = { name = n, icon = ic } end
        end
        if #list > 0 then out[#out + 1] = { grp[1], list } end
    end
    return out
end
-- записать действие на клик (b = nil — «ничего»)
function F:SetClick(key, b)
    if InCombatLockdown() then FG:Print(L("fr_combat")) return end
    clickStore()[key] = b
    F:SyncClicks()
end

FG:OnInit(function() F:ApplyAll() end)
FG:On("PLAYER_ENTERING_WORLD", function() C_Timer.After(1, function() F:ApplyAll() end) end)

---------------------------------------------------------------------------
-- Страница настроек: разделы переключаются сверху, внизу — положение и откат
---------------------------------------------------------------------------
local refreshers = {}
local TOP, BOTTOM = 84, 92

local function choice(parent, key, items, get, set, raw, wide)
    local row = CreateFrame("Frame", nil, parent)
    row:SetSize(COLW, wide and 50 or 30)
    local lb = S:Text(row, "label", S.c.text)
    if wide then lb:SetPoint("TOPLEFT", 4, -1) else lb:SetPoint("LEFT", 4, 0); lb:SetWidth(84) end
    lb:SetWordWrap(false)
    FG:Localize(lb, key)
    local seg = S:Segmented(row, items, wide and COLW or (COLW - 92), 26, get, set, { raw = raw })
    if wide then seg:SetPoint("BOTTOMLEFT", 0, 0) else seg:SetPoint("RIGHT", 0, 0) end
    function row:Refresh() seg:Refresh() end
    refreshers[#refreshers + 1] = row
    return row
end

-- готовый вариант размера: один выбор задаёт сразу несколько чисел (ширину, высоту, масштаб)
local function preset(sec, key, items)
    local list = {}
    for i, it in ipairs(items) do list[i] = { i, it[1] } end
    local function get()
        local c = sec.cfg()
        for i, it in ipairs(items) do
            local same = true
            for k, v in pairs(it[2]) do if c[k] ~= v then same = false break end end
            if same then return i end
        end
    end
    local function set(i)
        local c = sec.cfg()
        for k, v in pairs(items[i][2]) do c[k] = v end
        sec.apply()
        if F.unlocked then F:SetUnlocked(true) end
    end
    return choice(sec, key, list, get, set, nil, #items >= 4)
end

local function toggle(parent, key, get, set)
    local t = S:Toggle(parent, key, nil, get, set, COLW)
    refreshers[#refreshers + 1] = t
    return t
end

-- колонка внутри раздела: элементы друг под другом
local function column(parent, x, y)
    local col = { x = x, y = y }
    function col:add(w, h, gap)
        w:SetPoint("TOPLEFT", parent, "TOPLEFT", self.x, self.y)
        self.y = self.y - (h or w:GetHeight()) - (gap or 6)
        return w
    end
    function col:head(key)
        local t = S:Text(parent, "head", S.c.accent)
        t:SetPoint("TOPLEFT", parent, "TOPLEFT", self.x + 4, self.y)
        FG:Localize(t, key)
        self.y = self.y - 20
    end
    return col
end

-- раздел: «Включить» сверху (стандартная рамка игры прячется сама), ниже — вид (слева) и размеры (справа)
local function section(cfg, apply, onKey)
    local sec = CreateFrame("Frame", nil, page)
    sec:SetPoint("TOPLEFT", 0, -TOP); sec:SetPoint("BOTTOMRIGHT", 0, BOTTOM)
    local function set(k) return function(v) cfg()[k] = v; apply(); if F.unlocked then F:SetUnlocked(true) end end end
    local function get(k) return function() return cfg()[k] end end
    -- плашка-карточка под настройками вида и размера
    local card = CreateFrame("Frame", nil, sec)
    card:SetPoint("TOPLEFT", 12, -46); card:SetPoint("BOTTOMRIGHT", -12, 4)
    S:Box(card, 6, { 0.1, 0.09, 0.05, 0.5 }, { 0.5, 0.36, 0.15, 0.5 })
    local L1 = column(sec, 16, -8)
    L1:add(toggle(sec, onKey or "fr_on", get("on"), set("on")), 26)
    sec.left, sec.right = column(sec, 18, -58), column(sec, 16 + COLW + 16, -58)
    sec.get, sec.set, sec.cfg, sec.apply = get, set, cfg, apply
    sec:Hide()
    return sec
end

local function pageRefresh()
    for _, r in ipairs(refreshers) do if r.Refresh then r:Refresh() end end
    if page.lock then page.lock.label:SetText(L(F.unlocked and "fr_lock" or "fr_unlock")) end
    local cur = FG.db.framesTab or "pf"
    for k, sec in pairs(page.secs) do sec:SetShown(k == cur) end
    if page.tabs then page.tabs:Refresh() end
end

function F:BuildPage(parent)
    if page then return end
    S = FG.Style
    page = CreateFrame("Frame", "QuestCompassFramesPage", parent)
    page:SetAllPoints(parent)
    page.Refresh = pageRefresh
    page.secs = {}
    page:HookScript("OnShow", pageRefresh)
    local title = S:Text(page, "title", S.c.accent)
    title:SetPoint("TOPLEFT", 16, -14)
    FG:Localize(title, "fr_title")
    -- готовые стили одной кнопкой
    local prev
    for _, k in ipairs({ "min", "classic", "dark" }) do
        local b = S:Button(page, "fr_style_" .. k, 104, 24, function() F:ApplyStyle(k) end, { font = "label", tip = "fr_style_tip_" .. k })
        if prev then b:SetPoint("RIGHT", prev, "LEFT", -6, 0) else b:SetPoint("TOPRIGHT", -16, -12) end
        prev = b
    end
    local stl = S:Text(page, "label", S.c.muted)
    stl:SetPoint("RIGHT", prev, "LEFT", -8, 0)
    FG:Localize(stl, "fr_style")
    -- переключатель разделов
    page.tabs = S:Segmented(page, { { "pf", "fr_tab_pf" }, { "grp", "fr_tab_grp" }, { "bf", "fr_tab_bf" }, { "xp", "fr_tab_xp" } }, W - 32, 30,
        function() return FG.db.framesTab or "pf" end,
        function(v) FG.db.framesTab = v; pageRefresh() end)
    page.tabs:SetPoint("TOPLEFT", 16, -44)

    -- рамка игрока
    local pfs = section(function() return db().pf end, function() F:ApplyPF() end)
    local g, s = pfs.get, pfs.set
    pfs.left:head("fr_look")
    pfs.left:add(toggle(pfs, "fr_target", g("target"), s("target")), 26, 0)
    pfs.left:add(choice(pfs, "fr_portrait", { { "face", "fr_p_face" }, { "class", "fr_p_class" }, { "none", "fr_t_none" } }, g("pmode"), s("pmode")), 30)
    pfs.left:add(toggle(pfs, "fr_power", g("power"), s("power")), 26, 8)
    pfs.left:add(choice(pfs, "fr_color", { { "class", "fr_c_class" }, { "green", "fr_c_green" } }, g("color"), s("color")), 30)
    pfs.left:add(choice(pfs, "fr_text", { { "none", "fr_t_none" }, { "value", "fr_t_value" }, { "pct", "fr_t_pct" }, { "both", "fr_t_both" } }, g("text"), s("text")), 30)
    pfs.left:add(choice(pfs, "fr_tex", { { "flat", "fr_x_flat" }, { "smooth", "fr_x_smooth" }, { "classic", "fr_x_classic" } }, g("tex"), s("tex")), 30)
    pfs.right:head("fr_size")
    pfs.right:add(preset(pfs, "fr_sz", {
        { "fr_sz_s", { w = 120, h = 18, scale = 100 } }, { "fr_sz_m", { w = 150, h = 22, scale = 100 } },
        { "fr_sz_l", { w = 180, h = 26, scale = 100 } }, { "fr_sz_xl", { w = 210, h = 30, scale = 110 } },
    }), 50, 10)
    pfs.right:add(toggle(pfs, "fr_name", g("name"), s("name")), 26, 0)
    pfs.right:add(toggle(pfs, "fr_level", g("level"), s("level")), 26, 0)
    page.secs.pf = pfs

    -- группа и рейд (вид и размер рамок группы — как у рамки игрока)
    local grs = section(function() return db().party end, function() F:ApplyGroup() end, "fr_party_on")
    local function raidSet(k) return function(v) db().raid[k] = v; F:ApplyGroup(); if F.unlocked then F:SetUnlocked(true) end end end
    local function raidGet(k) return function() return db().raid[k] end end
    grs.left:head("fr_raid_title")
    grs.left:add(toggle(grs, "fr_raid_on", raidGet("on"), raidSet("on")), 26, 0)
    grs.left:add(toggle(grs, "fr_raid_names", raidGet("names"), raidSet("names")), 26, 0)
    grs.left:add(toggle(grs, "fr_raid_range", raidGet("range"), raidSet("range")), 26, 8)
    grs.right:head("fr_size")
    grs.right:add(choice(grs, "fr_raid_size", { { "s", "fr_i_s" }, { "m", "fr_i_m" }, { "l", "fr_i_l" } }, raidGet("size"), raidSet("size")), 30, 10)
    local gnote = S:Text(grs, "small", S.c.muted)
    gnote:SetWidth(COLW - 8)
    grs.right:add(gnote, 60)
    FG:Localize(gnote, "fr_grp_note")
    page.secs.grp = grs


    -- баффы
    local bfs = section(function() return db().bf end, function() F:ApplyBF() end)
    g, s = bfs.get, bfs.set
    bfs.left:head("fr_look")
    bfs.left:add(toggle(bfs, "fr_debuffs", g("debuffs"), s("debuffs")), 26, 0)
    bfs.left:add(toggle(bfs, "fr_timers", g("timers"), s("timers")), 26, 8)
    bfs.left:add(choice(bfs, "fr_grow", { { "left", "fr_g_left" }, { "right", "fr_g_right" } }, g("grow"), s("grow")), 30)
    bfs.right:head("fr_size")
    bfs.right:add(preset(bfs, "fr_icons", { { "fr_i_s", { size = 26 } }, { "fr_i_m", { size = 32 } }, { "fr_i_l", { size = 40 } } }), 30)
    bfs.right:add(choice(bfs, "fr_row", { { 8, "8" }, { 10, "10" }, { 12, "12" }, { 16, "16" } }, g("row"), s("row"), true), 30)
    page.secs.bf = bfs

    -- полоса опыта
    local xps = section(function() return db().xp end, function() F:ApplyXP() end)
    g, s = xps.get, xps.set
    xps.left:head("fr_look")
    xps.left:add(toggle(xps, "fr_rested", g("rested"), s("rested")), 26, 0)
    xps.left:add(toggle(xps, "fr_ticks", g("ticks"), s("ticks")), 26, 8)
    xps.left:add(choice(xps, "fr_text", { { "none", "fr_t_none" }, { "full", "fr_t_value" }, { "pct", "fr_t_pct" }, { "left", "fr_t_left" } }, g("text"), s("text")), 30)
    page.secs.xp = xps

    -- низ: положение и откат
    local bw = math.floor((W - 32 - 16) / 3)
    page.lock = S:Button(page, " ", bw, 28, function() F:SetUnlocked(not F.unlocked) end, { raw = true, font = "label", primary = true })
    page.lock:SetPoint("BOTTOMLEFT", 16, 44)
    local reset = S:Button(page, "fr_reset", bw, 28, function() F:ResetPositions() end, { font = "label" })
    reset:SetPoint("LEFT", page.lock, "RIGHT", 8, 0)
    local undo = S:Button(page, "fr_restore", bw, 28, function() F:RestoreAll() end, { font = "label", tip = "fr_restore_tip" })
    undo:SetPoint("LEFT", reset, "RIGHT", 8, 0)
    local note = S:Text(page, "small", S.c.muted)
    note:SetPoint("BOTTOMLEFT", 18, 8); note:SetPoint("BOTTOMRIGHT", -18, 8); note:SetJustifyH("CENTER")
    FG:Localize(note, "fr_note")

    FG:OnLanguageChanged(pageRefresh)
    pageRefresh()
end

---------------------------------------------------------------------------
-- Вкладка «Лечение»: что делает клик по рамкам (с Shift / Ctrl / Alt) и рамки группы и рейда
---------------------------------------------------------------------------
local hp
local healRefreshers = {}
local function healRefresh()
    for _, r in ipairs(healRefreshers) do if r.Refresh then r:Refresh() end end
end

function F:BuildHealPage(parent)
    if hp then return end
    S = FG.Style
    hp = CreateFrame("Frame", "QuestCompassHealPage", parent)
    hp:SetAllPoints(parent)
    hp:HookScript("OnShow", healRefresh)
    local title = S:Text(hp, "title", S.c.accent)
    title:SetPoint("TOPLEFT", 16, -14)
    FG:Localize(title, "hl_title")
    local hint = S:Text(hp, "small", S.c.muted)
    hint:SetPoint("LEFT", title, "RIGHT", 12, -1); hint:SetPoint("RIGHT", -16, 0); hint:SetWordWrap(false)
    FG:Localize(hint, "hl_hint")
    -- регистрируем свои строки в списке обновления этой вкладки
    local function track(w) healRefreshers[#healRefreshers + 1] = w; return w end
    local function tog(key, get, set) return track(S:Toggle(hp, key, nil, get, set, COLW)) end

    local top = column(hp, 16, -48)
    top:add(tog("fr_clicks_on", function() return db().party.healClicks end,
        function(v) db().party.healClicks = v; F:SyncClicks() end), 26, 8)

    -- карточка под настройками
    local card = CreateFrame("Frame", nil, hp)
    card:SetPoint("TOPLEFT", 12, -84); card:SetPoint("BOTTOMRIGHT", -12, 12)
    S:Box(card, 6, { 0.1, 0.09, 0.05, 0.5 }, { 0.5, 0.36, 0.15, 0.5 })
    local left, right = column(hp, 18, -96), column(hp, 16 + COLW + 16, -96)

    -- слева: модификатор и пять кнопок мыши
    left:head("hl_clicks")
    hp.ckMod = ""
    local mod = choice(hp, "fr_ck_mod", { { "", "fr_ck_m_none" }, { "shift-", "Shift" }, { "ctrl-", "Ctrl" }, { "alt-", "Alt" } },
        function() return hp.ckMod end, function(v) hp.ckMod = v; healRefresh() end, nil, true)
    left:add(track(mod), 50, 8)
    -- список действий (открывается под кнопкой строки)
    local picker = CreateFrame("Frame", nil, hp)
    picker:SetFrameStrata("DIALOG"); picker:SetWidth(240); picker:Hide()
    picker:EnableMouse(true)
    S:Box(picker, 6, { 0.08, 0.06, 0.04, 0.97 }, { 1, 0.82, 0, 0.6 })
    picker.qcNoInk = true
    picker.rows = {}
    hp:HookScript("OnHide", function() picker:Hide() end)
    local function clickLabel(b)
        if type(b) ~= "table" then return "|cff9aa0a8" .. L("fr_ck_none") .. "|r" end
        if b.kind == "spell" then return b.spell or "?" end
        if b.kind == "target" then return L("fr_ck_target") end
        if b.kind == "menu" then return L("fr_ck_menu") end
        return L("fr_ck_other") .. " (" .. tostring(b.spell or b.kind) .. ")"
    end
    local function openPicker(btn, key)
        if picker:IsShown() and picker.key == key then picker:Hide() return end
        picker.key = key
        local items = {}
        for _, grp in ipairs(F:ClickChoices()) do
            items[#items + 1] = { head = grp[1] }
            for _, sp in ipairs(grp[2]) do items[#items + 1] = { b = { kind = "spell", spell = sp.name }, text = sp.name, icon = sp.icon } end
        end
        items[#items + 1] = { head = "fr_ck_other_h" }
        items[#items + 1] = { b = { kind = "target" }, text = L("fr_ck_target"), icon = "Interface\\Icons\\Ability_Hunter_SniperShot" }
        items[#items + 1] = { b = { kind = "menu" }, text = L("fr_ck_menu"), icon = "Interface\\Icons\\INV_Misc_Note_01" }
        items[#items + 1] = { b = false, text = L("fr_ck_none"), icon = "Interface\\Buttons\\UI-GroupLoot-Pass-Up" }
        local y = -8
        for i, it in ipairs(items) do
            local r = picker.rows[i]
            if not r then
                r = CreateFrame("Button", nil, picker)
                r:SetHeight(20)
                r.hl = r:CreateTexture(nil, "BACKGROUND"); r.hl:SetAllPoints(); r.hl:SetTexture(WHITE); r.hl:SetVertexColor(1, 0.82, 0, 0.18); r.hl:Hide()
                r.icon = r:CreateTexture(nil, "ARTWORK"); r.icon:SetSize(16, 16); r.icon:SetPoint("LEFT", 2, 0); r.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
                r.text = S:NoInk(r:CreateFontString(nil, "OVERLAY", "GameFontHighlight"))
                r.text:SetJustifyH("LEFT"); r.text:SetWordWrap(false)
                r:SetScript("OnEnter", function(self) if not self.head then self.hl:Show() end end)
                r:SetScript("OnLeave", function(self) self.hl:Hide() end)
                r:SetScript("OnClick", function(self)
                    if self.head then return end
                    F:SetClick(picker.key, self.b or nil)
                    picker:Hide(); healRefresh()
                end)
                picker.rows[i] = r
            end
            r:ClearAllPoints(); r:SetPoint("TOPLEFT", 8, y); r:SetPoint("TOPRIGHT", -8, y)
            r.head, r.b = it.head and true or false, it.b
            r.text:ClearAllPoints()
            if it.head then
                r.icon:Hide(); r.text:SetText(L(it.head)); r.text:SetTextColor(1, 0.82, 0)
                r.text:SetPoint("LEFT", 2, 0); r.text:SetPoint("RIGHT", -2, 0)
            else
                r.icon:Show(); r.icon:SetTexture(it.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
                r.text:SetText(it.text); r.text:SetTextColor(1, 1, 1)
                r.text:SetPoint("LEFT", r.icon, "RIGHT", 6, 0); r.text:SetPoint("RIGHT", -2, 0)
            end
            r:Show()
            y = y - 20
        end
        for i = #items + 1, #picker.rows do picker.rows[i]:Hide() end
        picker:SetHeight(-y + 8)
        picker:ClearAllPoints(); picker:SetPoint("TOPLEFT", btn, "BOTTOMLEFT", 0, -2)
        picker:SetFrameLevel(hp:GetFrameLevel() + 50)
        picker:Show()
    end
    for _, bt in ipairs({ { "1", "fr_ck_b1" }, { "2", "fr_ck_b2" }, { "3", "fr_ck_b3" }, { "4", "fr_ck_b4" }, { "5", "fr_ck_b5" } }) do
        local row = CreateFrame("Frame", nil, hp)
        row:SetSize(COLW, 30)
        local lb = S:Text(row, "label", S.c.text)
        lb:SetPoint("LEFT", 4, 0); lb:SetWidth(110); lb:SetWordWrap(false)
        FG:Localize(lb, bt[2])
        local btn = S:Button(row, " ", COLW - 118, 26, function(self) openPicker(self, hp.ckMod .. bt[1]) end, { raw = true, font = "label" })
        btn:SetPoint("RIGHT", 0, 0)
        function row:Refresh() btn.label:SetText(clickLabel(clickStore()[hp.ckMod .. bt[1]])) end
        left:add(track(row), 30, 4)
    end
    local reset = S:Button(hp, "hl_reset", COLW, 26, function()
        if InCombatLockdown() then FG:Print(L("fr_combat")) return end
        db().clicks = nil; F:SyncClicks(); healRefresh()
    end, { font = "label" })
    left:add(reset, 26, 0)

    -- справа: рамки группы и рейда (те же настройки, что во вкладке «Интерфейс»)
    right:head("hl_frames")
    local function grp(part, k) return function() return db()[part][k] end,
        function(v) db()[part][k] = v; F:ApplyGroup() end end
    local g1, s1 = grp("party", "on"); right:add(tog("fr_party_on", g1, s1), 26, 0)
    local g2, s2 = grp("raid", "on"); right:add(tog("fr_raid_on", g2, s2), 26, 0)
    local g3, s3 = grp("raid", "range"); right:add(tog("fr_raid_range", g3, s3), 26, 0)
    local g4, s4 = grp("raid", "names"); right:add(tog("fr_raid_names", g4, s4), 26, 10)
    local note = S:Text(hp, "small", S.c.muted)
    note:SetWidth(COLW - 8)
    right:add(note, 120)
    FG:Localize(note, "hl_note")

    FG:OnLanguageChanged(healRefresh)
    healRefresh()
end
